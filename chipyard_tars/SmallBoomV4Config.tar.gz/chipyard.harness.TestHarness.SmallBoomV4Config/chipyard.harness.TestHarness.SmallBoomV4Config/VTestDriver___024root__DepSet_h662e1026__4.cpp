// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See VTestDriver.h for the primary calling header

#include "VTestDriver__pch.h"
#include "VTestDriver__Syms.h"
#include "VTestDriver___024root.h"

void VTestDriver___024unit____Vdpiimwrap_uart_tick_TOP____024unit(IData/*31:0*/ uartno, CData/*0:0*/ serial_out_valid, CData/*0:0*/ &serial_out_ready, CData/*7:0*/ serial_out_bits, CData/*0:0*/ &serial_in_valid, CData/*0:0*/ serial_in_ready, CData/*7:0*/ &serial_in_bits);

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__2709(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__2709\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Init
    CData/*0:0*/ __Vtask_uart_tick__1__serial_out_ready;
    __Vtask_uart_tick__1__serial_out_ready = 0;
    CData/*0:0*/ __Vtask_uart_tick__1__serial_in_valid;
    __Vtask_uart_tick__1__serial_in_valid = 0;
    CData/*7:0*/ __Vtask_uart_tick__1__serial_in_bits;
    __Vtask_uart_tick__1__serial_in_bits = 0;
    // Body
    if (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__ram__DOT__serdesser__DOT__ser_2__DOT___GEN_2) 
         & (0U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__ram__DOT__serdesser__DOT__ser_2__DOT__beat)))) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__ram__DOT__serdesser__DOT__ser_2__DOT__data_2 = 0U;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__ram__DOT__serdesser__DOT__ser_2__DOT__data_1 = 0U;
    }
    if (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__ram__DOT__serdesser__DOT__ser_4__DOT___GEN_2) 
         & (0U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__ram__DOT__serdesser__DOT__ser_4__DOT__beat)))) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__ram__DOT__serdesser__DOT__ser_4__DOT__data_2 
            = (0xffffffU & ((vlSelfRef.TestDriver__DOT__testHarness__DOT__ram__DOT__serdesser__DOT___out_channels_4_2_io_beat_bits_payload[2U] 
                             << 2U) | (vlSelfRef.TestDriver__DOT__testHarness__DOT__ram__DOT__serdesser__DOT___out_channels_4_2_io_beat_bits_payload[1U] 
                                       >> 0x1eU)));
        vlSelfRef.TestDriver__DOT__testHarness__DOT__ram__DOT__serdesser__DOT__ser_4__DOT__data_1 
            = ((vlSelfRef.TestDriver__DOT__testHarness__DOT__ram__DOT__serdesser__DOT___out_channels_4_2_io_beat_bits_payload[1U] 
                << 2U) | (vlSelfRef.TestDriver__DOT__testHarness__DOT__ram__DOT__serdesser__DOT___out_channels_4_2_io_beat_bits_payload[0U] 
                          >> 0x1eU));
    }
    vlSelfRef.TestDriver__DOT__testHarness__DOT__uart_sim_0_uartno0__DOT__rxm__DOT__pulse 
        = (0U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__uart_sim_0_uartno0__DOT__rxm__DOT__prescaler));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__uart_sim_0_uartno0__DOT__rxm__DOT___GEN_1 
        = ((0U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__uart_sim_0_uartno0__DOT__rxm__DOT__prescaler)) 
           & (0U != (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__uart_sim_0_uartno0__DOT__rxm__DOT__counter)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__ram__DOT__phy__DOT__out_phits_out_async_io_enq_q_2__DOT__ptr_match 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__ram__DOT__phy__DOT__out_phits_out_async_io_enq_q_2__DOT__deq_ptr_value) 
           == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__ram__DOT__phy__DOT__out_phits_out_async_io_enq_q_2__DOT__enq_ptr_value));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__ram__DOT__serdesser__DOT__out_channels_4_2__DOT__head 
        = (0U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__ram__DOT__serdesser__DOT__out_channels_4_2__DOT__head_counter));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__ram__DOT__serdesser__DOT___out_channels_4_2_io_beat_bits_head 
        = ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__ram__DOT__serdesser__DOT__out_channels_4_2__DOT__is_body)) 
           & (0U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__ram__DOT__serdesser__DOT__out_channels_4_2__DOT__head_counter)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__ram__DOT__buffer__DOT__nodeIn_d_q__DOT__ptr_match 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__ram__DOT__buffer__DOT__nodeIn_d_q__DOT__deq_ptr_value) 
           == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__ram__DOT__buffer__DOT__nodeIn_d_q__DOT__enq_ptr_value));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__ram__DOT__phy__DOT__out_phits_out_async_io_enq_q_4__DOT__ptr_match 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__ram__DOT__phy__DOT__out_phits_out_async_io_enq_q_4__DOT__deq_ptr_value) 
           == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__ram__DOT__phy__DOT__out_phits_out_async_io_enq_q_4__DOT__enq_ptr_value));
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__ram__DOT__phy__DOT__in_phits_in_async_1__DOT__sink__DOT____Vcellinp__sink_valid_0__reset) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__uart_sim_0_uartno0__DOT__sim__DOT_____05Fin_valid = 0U;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__uart_sim_0_uartno0__DOT__sim__DOT_____05Fout_ready = 0U;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__uart_sim_0_uartno0__DOT__sim__DOT_____05Fin_valid_reg = 0U;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__uart_sim_0_uartno0__DOT__sim__DOT_____05Fin_bits_reg = 0U;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__uart_sim_0_uartno0__DOT__sim__DOT_____05Fout_ready_reg = 0U;
    } else {
        VTestDriver___024unit____Vdpiimwrap_uart_tick_TOP____024unit(0U, (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__uart_sim_0_uartno0__DOT___txq_io_deq_valid), __Vtask_uart_tick__1__serial_out_ready, 
                                                                     vlSelfRef.TestDriver__DOT__testHarness__DOT__uart_sim_0_uartno0__DOT__txq__DOT__ram_ext__DOT__Memory
                                                                     [vlSelfRef.TestDriver__DOT__testHarness__DOT__uart_sim_0_uartno0__DOT__txq__DOT__deq_ptr_value], __Vtask_uart_tick__1__serial_in_valid, 
                                                                     ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__uart_sim_0_uartno0__DOT__rxq__DOT__full)) 
                                                                      & (7U 
                                                                         > 
                                                                         (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__uart_sim_0_uartno0__DOT__rxq__DOT__full) 
                                                                           << 3U) 
                                                                          | (7U 
                                                                             & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__uart_sim_0_uartno0__DOT__rxq__DOT__enq_ptr_value) 
                                                                                - (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__uart_sim_0_uartno0__DOT__rxq__DOT__deq_ptr_value)))))), __Vtask_uart_tick__1__serial_in_bits);
        vlSelfRef.TestDriver__DOT__testHarness__DOT__uart_sim_0_uartno0__DOT__sim__DOT_____05Fout_ready 
            = __Vtask_uart_tick__1__serial_out_ready;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__uart_sim_0_uartno0__DOT__sim__DOT_____05Fin_valid 
            = __Vtask_uart_tick__1__serial_in_valid;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__uart_sim_0_uartno0__DOT__sim__DOT_____05Fin_bits 
            = __Vtask_uart_tick__1__serial_in_bits;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__uart_sim_0_uartno0__DOT__sim__DOT_____05Fout_ready_reg 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__uart_sim_0_uartno0__DOT__sim__DOT_____05Fout_ready;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__uart_sim_0_uartno0__DOT__sim__DOT_____05Fin_valid_reg 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__uart_sim_0_uartno0__DOT__sim__DOT_____05Fin_valid;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__uart_sim_0_uartno0__DOT__sim__DOT_____05Fin_bits_reg 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__uart_sim_0_uartno0__DOT__sim__DOT_____05Fin_bits;
    }
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__2731(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__2731\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if ((1U & (~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT___system_debug_systemjtag_reset_catcher_io_sync_reset)))) {
        if (vlSymsp->_vm_contextp__->assertOnGet(2, 1)) {
            if (VL_UNLIKELY(((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__dtm__DOT____Vcellinp__tapIO_idcodeChain__io_chainIn_capture) 
                               & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__dtm__DOT____Vcellinp__tapIO_idcodeChain__io_chainIn_update)) 
                              | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__dtm__DOT____Vcellinp__tapIO_idcodeChain__io_chainIn_shift) 
                                 & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__dtm__DOT____Vcellinp__tapIO_idcodeChain__io_chainIn_capture) 
                                    | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__dtm__DOT____Vcellinp__tapIO_idcodeChain__io_chainIn_update))))))) {
                VL_WRITEF_NX("[%0t] %%Error: CaptureChain_JTAGIdcodeBundle.sv:106: Assertion failed in %NTestDriver.testHarness.chiptop0.system.dtm.tapIO_idcodeChain.assert__assert: 'assert' failed.\n",0,
                             64,VL_TIME_UNITED_Q(1000),
                             -9,vlSymsp->name());
                VL_STOP_MT("/local/scratch/tah56/misc/chipyard-upstream/sims/verilator/generated-src/chipyard.harness.TestHarness.SmallBoomV4Config/gen-collateral/CaptureChain_JTAGIdcodeBundle.sv", 106, "");
            }
        }
    }
    if ((1U & (~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT___system_debug_systemjtag_reset_catcher_io_sync_reset)))) {
        if (vlSymsp->_vm_contextp__->assertOnGet(2, 1)) {
            if (VL_UNLIKELY((((0xaU == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__dtm__DOT__tapIO_controllerInternal__DOT__stateMachine__DOT__currState)) 
                              & ((0xeU == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__dtm__DOT__tapIO_controllerInternal__DOT__stateMachine__DOT__currState)) 
                                 | (0xdU == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__dtm__DOT__tapIO_controllerInternal__DOT__stateMachine__DOT__currState))))))) {
                VL_WRITEF_NX("[%0t] %%Error: CaptureUpdateChain_UInt5_To_UInt5.sv:80: Assertion failed in %NTestDriver.testHarness.chiptop0.system.dtm.tapIO_controllerInternal.irChain.assert__assert: 'assert' failed.\n",0,
                             64,VL_TIME_UNITED_Q(1000),
                             -9,vlSymsp->name());
                VL_STOP_MT("/local/scratch/tah56/misc/chipyard-upstream/sims/verilator/generated-src/chipyard.harness.TestHarness.SmallBoomV4Config/gen-collateral/CaptureUpdateChain_UInt5_To_UInt5.sv", 80, "");
            }
        }
    }
    if ((1U & (~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT___system_debug_systemjtag_reset_catcher_io_sync_reset)))) {
        if (vlSymsp->_vm_contextp__->assertOnGet(2, 1)) {
            if (VL_UNLIKELY((((2U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__dtm__DOT__tapIO_controllerInternal__DOT__stateMachine__DOT__currState)) 
                              & ((6U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__dtm__DOT__tapIO_controllerInternal__DOT__stateMachine__DOT__currState)) 
                                 | (5U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__dtm__DOT__tapIO_controllerInternal__DOT__stateMachine__DOT__currState))))))) {
                VL_WRITEF_NX("[%0t] %%Error: JtagBypassChain.sv:75: Assertion failed in %NTestDriver.testHarness.chiptop0.system.dtm.tapIO_bypassChain.assert__assert: 'assert' failed.\n",0,
                             64,VL_TIME_UNITED_Q(1000),
                             -9,vlSymsp->name());
                VL_STOP_MT("/local/scratch/tah56/misc/chipyard-upstream/sims/verilator/generated-src/chipyard.harness.TestHarness.SmallBoomV4Config/gen-collateral/JtagBypassChain.sv", 75, "");
            }
        }
    }
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__2732(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__2732\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if ((1U & (~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT___system_debug_systemjtag_reset_catcher_io_sync_reset)))) {
        if (vlSymsp->_vm_contextp__->assertOnGet(2, 1)) {
            if (VL_UNLIKELY((((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__dtm__DOT__stickyBusyReg)) 
                              & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__dtm__DOT___dmiAccessChain_io_update_valid) 
                                 & ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__dtm__DOT___GEN_4)) 
                                    & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__dtm__DOT___GEN_2))))))) {
                VL_WRITEF_NX("[%0t] %%Error: DebugTransportModuleJTAG.sv:137: Assertion failed in %NTestDriver.testHarness.chiptop0.system.dtm.assert__assert: 'assert' failed.\n",0,
                             64,VL_TIME_UNITED_Q(1000),
                             -9,vlSymsp->name());
                VL_STOP_MT("/local/scratch/tah56/misc/chipyard-upstream/sims/verilator/generated-src/chipyard.harness.TestHarness.SmallBoomV4Config/gen-collateral/DebugTransportModuleJTAG.sv", 137, "");
            }
        }
    }
    if ((1U & (~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT___system_debug_systemjtag_reset_catcher_io_sync_reset)))) {
        if (vlSymsp->_vm_contextp__->assertOnGet(2, 1)) {
            if (VL_UNLIKELY(((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__dtm__DOT____Vcellinp__dtmInfoChain__io_chainIn_capture) 
                               & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__dtm__DOT____Vcellinp__dtmInfoChain__io_chainIn_update)) 
                              | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__dtm__DOT____Vcellinp__dtmInfoChain__io_chainIn_shift) 
                                 & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__dtm__DOT____Vcellinp__dtmInfoChain__io_chainIn_capture) 
                                    | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__dtm__DOT____Vcellinp__dtmInfoChain__io_chainIn_update))))))) {
                VL_WRITEF_NX("[%0t] %%Error: CaptureUpdateChain_DTMInfo_To_DTMInfo.sv:109: Assertion failed in %NTestDriver.testHarness.chiptop0.system.dtm.dtmInfoChain.assert__assert: 'assert' failed.\n",0,
                             64,VL_TIME_UNITED_Q(1000),
                             -9,vlSymsp->name());
                VL_STOP_MT("/local/scratch/tah56/misc/chipyard-upstream/sims/verilator/generated-src/chipyard.harness.TestHarness.SmallBoomV4Config/gen-collateral/CaptureUpdateChain_DTMInfo_To_DTMInfo.sv", 109, "");
            }
        }
    }
    if ((1U & (~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT___system_debug_systemjtag_reset_catcher_io_sync_reset)))) {
        if (vlSymsp->_vm_contextp__->assertOnGet(2, 1)) {
            if (VL_UNLIKELY((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tlDM__DOT__dmOuter__DOT__dmiXbar__DOT__winner_0) 
                              & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tlDM__DOT__dmOuter__DOT__dmiXbar__DOT__winner_1))))) {
                VL_WRITEF_NX("[%0t] %%Error: TLXbar_dmixbar_i1_o2_a9d32s1k1z2u.sv:119: Assertion failed in %NTestDriver.testHarness.chiptop0.system.tlDM.dmOuter.dmiXbar.assert__assert: 'assert' failed.\n",0,
                             64,VL_TIME_UNITED_Q(1000),
                             -9,vlSymsp->name());
                VL_STOP_MT("/local/scratch/tah56/misc/chipyard-upstream/sims/verilator/generated-src/chipyard.harness.TestHarness.SmallBoomV4Config/gen-collateral/TLXbar_dmixbar_i1_o2_a9d32s1k1z2u.sv", 119, "");
            }
        }
        if (vlSymsp->_vm_contextp__->assertOnGet(2, 1)) {
            if (VL_UNLIKELY(((1U & (~ ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tlDM__DOT__dmOuter__DOT__dmiXbar__DOT___in_0_d_valid_T)) 
                                       | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tlDM__DOT__dmOuter__DOT__dmiXbar__DOT__winner_0) 
                                          | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tlDM__DOT__dmOuter__DOT__dmiXbar__DOT__winner_1)))))))) {
                VL_WRITEF_NX("[%0t] %%Error: TLXbar_dmixbar_i1_o2_a9d32s1k1z2u.sv:120: Assertion failed in %NTestDriver.testHarness.chiptop0.system.tlDM.dmOuter.dmiXbar.assert__assert_1: 'assert' failed.\n",0,
                             64,VL_TIME_UNITED_Q(1000),
                             -9,vlSymsp->name());
                VL_STOP_MT("/local/scratch/tah56/misc/chipyard-upstream/sims/verilator/generated-src/chipyard.harness.TestHarness.SmallBoomV4Config/gen-collateral/TLXbar_dmixbar_i1_o2_a9d32s1k1z2u.sv", 120, "");
            }
        }
    }
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__2733(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__2733\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if ((1U & (~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT___system_debug_systemjtag_reset_catcher_io_sync_reset)))) {
        if (vlSymsp->_vm_contextp__->assertOnGet(2, 1)) {
            if (VL_UNLIKELY(((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__dtm__DOT____Vcellinp__dmiAccessChain__io_chainIn_capture) 
                               & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__dtm__DOT____Vcellinp__dmiAccessChain__io_chainIn_update)) 
                              | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__dtm__DOT____Vcellinp__dmiAccessChain__io_chainIn_shift) 
                                 & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__dtm__DOT____Vcellinp__dmiAccessChain__io_chainIn_capture) 
                                    | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__dtm__DOT____Vcellinp__dmiAccessChain__io_chainIn_update))))))) {
                VL_WRITEF_NX("[%0t] %%Error: CaptureUpdateChain_DMIAccessCapture_To_DMIAccessUpdate.sv:123: Assertion failed in %NTestDriver.testHarness.chiptop0.system.dtm.dmiAccessChain.assert__assert: 'assert' failed.\n",0,
                             64,VL_TIME_UNITED_Q(1000),
                             -9,vlSymsp->name());
                VL_STOP_MT("/local/scratch/tah56/misc/chipyard-upstream/sims/verilator/generated-src/chipyard.harness.TestHarness.SmallBoomV4Config/gen-collateral/CaptureUpdateChain_DMIAccessCapture_To_DMIAccessUpdate.sv", 123, "");
            }
        }
    }
    if (VL_UNLIKELY((((((~ (IData)(vlSelfRef.TestDriver__DOT__reset)) 
                        & (IData)(vlSelfRef.TestDriver__DOT__verbose)) 
                       & (~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT___system_debug_systemjtag_reset_catcher_io_sync_reset))) 
                      & (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__dtm__DOT____Vcellinp__tapIO_idcodeChain__io_chainIn_capture) 
                          & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__dtm__DOT____Vcellinp__tapIO_idcodeChain__io_chainIn_update)) 
                         | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__dtm__DOT____Vcellinp__tapIO_idcodeChain__io_chainIn_shift) 
                            & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__dtm__DOT____Vcellinp__tapIO_idcodeChain__io_chainIn_capture) 
                               | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__dtm__DOT____Vcellinp__tapIO_idcodeChain__io_chainIn_update)))))))) {
        VL_FWRITEF_NX(0x80000002U,"Assertion failed\n    at JtagShifter.scala:118 assert(!(io.chainIn.capture && io.chainIn.update)\n",0);
    }
    if (VL_UNLIKELY((((((~ (IData)(vlSelfRef.TestDriver__DOT__reset)) 
                        & (IData)(vlSelfRef.TestDriver__DOT__verbose)) 
                       & (~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT___system_debug_systemjtag_reset_catcher_io_sync_reset))) 
                      & ((0xaU == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__dtm__DOT__tapIO_controllerInternal__DOT__stateMachine__DOT__currState)) 
                         & ((0xeU == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__dtm__DOT__tapIO_controllerInternal__DOT__stateMachine__DOT__currState)) 
                            | (0xdU == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__dtm__DOT__tapIO_controllerInternal__DOT__stateMachine__DOT__currState)))))))) {
        VL_FWRITEF_NX(0x80000002U,"Assertion failed\n    at JtagShifter.scala:185 assert(!(io.chainIn.capture && io.chainIn.update)\n",0);
    }
    if (VL_UNLIKELY((((((~ (IData)(vlSelfRef.TestDriver__DOT__reset)) 
                        & (IData)(vlSelfRef.TestDriver__DOT__verbose)) 
                       & (~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT___system_debug_systemjtag_reset_catcher_io_sync_reset))) 
                      & ((2U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__dtm__DOT__tapIO_controllerInternal__DOT__stateMachine__DOT__currState)) 
                         & ((6U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__dtm__DOT__tapIO_controllerInternal__DOT__stateMachine__DOT__currState)) 
                            | (5U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__dtm__DOT__tapIO_controllerInternal__DOT__stateMachine__DOT__currState)))))))) {
        VL_FWRITEF_NX(0x80000002U,"Assertion failed\n    at JtagShifter.scala:72 assert(!(io.chainIn.capture && io.chainIn.update)\n",0);
    }
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__2734(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__2734\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if (VL_UNLIKELY((((((~ (IData)(vlSelfRef.TestDriver__DOT__reset)) 
                        & (IData)(vlSelfRef.TestDriver__DOT__verbose)) 
                       & (~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT___system_debug_systemjtag_reset_catcher_io_sync_reset))) 
                      & ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__dtm__DOT__stickyBusyReg)) 
                         & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__dtm__DOT___dmiAccessChain_io_update_valid) 
                            & ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__dtm__DOT___GEN_4)) 
                               & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__dtm__DOT___GEN_2)))))))) {
        VL_FWRITEF_NX(0x80000002U,"Assertion failed: Conflicting updates for dmiReqValidReg, should not happen.\n    at DebugTransport.scala:203 assert(!(dmiReqValidCheck && io.dmi.req.fire), \"Conflicting updates for dmiReqValidReg, should not happen.\");\n",0);
    }
    if (VL_UNLIKELY((((((~ (IData)(vlSelfRef.TestDriver__DOT__reset)) 
                        & (IData)(vlSelfRef.TestDriver__DOT__verbose)) 
                       & (~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT___system_debug_systemjtag_reset_catcher_io_sync_reset))) 
                      & (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__dtm__DOT____Vcellinp__dtmInfoChain__io_chainIn_capture) 
                          & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__dtm__DOT____Vcellinp__dtmInfoChain__io_chainIn_update)) 
                         | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__dtm__DOT____Vcellinp__dtmInfoChain__io_chainIn_shift) 
                            & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__dtm__DOT____Vcellinp__dtmInfoChain__io_chainIn_capture) 
                               | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__dtm__DOT____Vcellinp__dtmInfoChain__io_chainIn_update)))))))) {
        VL_FWRITEF_NX(0x80000002U,"Assertion failed\n    at JtagShifter.scala:185 assert(!(io.chainIn.capture && io.chainIn.update)\n",0);
    }
    if (VL_UNLIKELY((((((~ (IData)(vlSelfRef.TestDriver__DOT__reset)) 
                        & (IData)(vlSelfRef.TestDriver__DOT__verbose)) 
                       & (~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT___system_debug_systemjtag_reset_catcher_io_sync_reset))) 
                      & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tlDM__DOT__dmOuter__DOT__dmiXbar__DOT__winner_0) 
                         & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tlDM__DOT__dmOuter__DOT__dmiXbar__DOT__winner_1)))))) {
        VL_FWRITEF_NX(0x80000002U,"Assertion failed\n    at Arbiter.scala:77 assert((prefixOR zip winner) map { case (p,w) => !p || !w } reduce {_ && _})\n",0);
    }
    if (VL_UNLIKELY((((((~ (IData)(vlSelfRef.TestDriver__DOT__reset)) 
                        & (IData)(vlSelfRef.TestDriver__DOT__verbose)) 
                       & (~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT___system_debug_systemjtag_reset_catcher_io_sync_reset))) 
                      & (~ ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tlDM__DOT__dmOuter__DOT__dmiXbar__DOT___in_0_d_valid_T)) 
                            | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tlDM__DOT__dmOuter__DOT__dmiXbar__DOT__winner_0) 
                               | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tlDM__DOT__dmOuter__DOT__dmiXbar__DOT__winner_1)))))))) {
        VL_FWRITEF_NX(0x80000002U,"Assertion failed\n    at Arbiter.scala:79 assert (!valids.reduce(_||_) || winner.reduce(_||_))\n",0);
    }
    if (VL_UNLIKELY((((((~ (IData)(vlSelfRef.TestDriver__DOT__reset)) 
                        & (IData)(vlSelfRef.TestDriver__DOT__verbose)) 
                       & (~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT___system_debug_systemjtag_reset_catcher_io_sync_reset))) 
                      & (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__dtm__DOT____Vcellinp__dmiAccessChain__io_chainIn_capture) 
                          & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__dtm__DOT____Vcellinp__dmiAccessChain__io_chainIn_update)) 
                         | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__dtm__DOT____Vcellinp__dmiAccessChain__io_chainIn_shift) 
                            & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__dtm__DOT____Vcellinp__dmiAccessChain__io_chainIn_capture) 
                               | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__dtm__DOT____Vcellinp__dmiAccessChain__io_chainIn_update)))))))) {
        VL_FWRITEF_NX(0x80000002U,"Assertion failed\n    at JtagShifter.scala:185 assert(!(io.chainIn.capture && io.chainIn.update)\n",0);
    }
    if ((1U & (~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT___system_debug_systemjtag_reset_catcher_io_sync_reset)))) {
        if (vlSymsp->_vm_contextp__->assertOnGet(2, 1)) {
            if (VL_UNLIKELY(((1U & (~ ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tlDM__DOT__dmOuter__DOT__dmiBypass__DOT__error__DOT__r_counter)) 
                                       | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tlDM__DOT__dmOuter__DOT__dmiBypass__DOT__error__DOT__idle))))))) {
                VL_WRITEF_NX("[%0t] %%Error: TLError_1.sv:90: Assertion failed in %NTestDriver.testHarness.chiptop0.system.tlDM.dmOuter.dmiBypass.error.assert__assert: 'assert' failed.\n",0,
                             64,VL_TIME_UNITED_Q(1000),
                             -9,vlSymsp->name());
                VL_STOP_MT("/local/scratch/tah56/misc/chipyard-upstream/sims/verilator/generated-src/chipyard.harness.TestHarness.SmallBoomV4Config/gen-collateral/TLError_1.sv", 90, "");
            }
        }
    }
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__2745(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__2745\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if (((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tlDM__DOT__dmInner__DOT__dmInner__DOT__goAbstract)) 
         & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tlDM__DOT__dmInner__DOT__dmactive_synced_dmactive_synced_dmactiveSync__DOT__output_chain__DOT__sync_0) 
            & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__debug_reset_syncd_debug_reset_sync__DOT__output_chain__DOT__sync_0) 
               & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tlDM__DOT__dmInner__DOT__dmInner__DOT__hartGoingWrEn))))) {
        if (vlSymsp->_vm_contextp__->assertOnGet(2, 1)) {
            if (VL_UNLIKELY(((0U != (0x3ffU & (IData)(
                                                      (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT___cbus_auto_coupler_to_debug_fragmenter_anon_out_a_bits_data 
                                                       >> 0x20U))))))) {
                VL_WRITEF_NX("[%0t] %%Error: TLDebugModuleInner.sv:1457: Assertion failed in %NTestDriver.testHarness.chiptop0.system.tlDM.dmInner.dmInner.assert__assert: 'assert' failed.\n",0,
                             64,VL_TIME_UNITED_Q(1000),
                             -9,vlSymsp->name());
                VL_STOP_MT("/local/scratch/tah56/misc/chipyard-upstream/sims/verilator/generated-src/chipyard.harness.TestHarness.SmallBoomV4Config/gen-collateral/TLDebugModuleInner.sv", 1457, "");
            }
        }
    }
    if (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tlDM__DOT__dmInner__DOT__dmInner__DOT___GEN_9) 
         & ((2U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tlDM__DOT__dmInner__DOT__dmInner__DOT__ctrlStateReg)) 
            & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__debug_reset_syncd_debug_reset_sync__DOT__output_chain__DOT__sync_0) 
               & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tlDM__DOT__dmInner__DOT__dmInner__DOT__hartExceptionWrEn))))) {
        if (vlSymsp->_vm_contextp__->assertOnGet(2, 1)) {
            if (VL_UNLIKELY(((0U != (0x3ffU & (IData)(
                                                      (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT___cbus_auto_coupler_to_debug_fragmenter_anon_out_a_bits_data 
                                                       >> 0x20U))))))) {
                VL_WRITEF_NX("[%0t] %%Error: TLDebugModuleInner.sv:1459: Assertion failed in %NTestDriver.testHarness.chiptop0.system.tlDM.dmInner.dmInner.assert__assert_2: 'assert' failed.\n",0,
                             64,VL_TIME_UNITED_Q(1000),
                             -9,vlSymsp->name());
                VL_STOP_MT("/local/scratch/tah56/misc/chipyard-upstream/sims/verilator/generated-src/chipyard.harness.TestHarness.SmallBoomV4Config/gen-collateral/TLDebugModuleInner.sv", 1459, "");
            }
        }
    }
    if (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tlDM__DOT__dmInner__DOT__dmInner__DOT___GEN_9) 
         & ((2U != (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tlDM__DOT__dmInner__DOT__dmInner__DOT__ctrlStateReg)) 
            & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__debug_reset_syncd_debug_reset_sync__DOT__output_chain__DOT__sync_0) 
               & (3U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tlDM__DOT__dmInner__DOT__dmInner__DOT__ctrlStateReg)))))) {
        if (VL_UNLIKELY((vlSymsp->_vm_contextp__->assertOnGet(2, 1)))) {
            VL_WRITEF_NX("[%0t] %%Error: TLDebugModuleInner.sv:1461: Assertion failed in %NTestDriver.testHarness.chiptop0.system.tlDM.dmInner.dmInner.assert__assert_3: 'assert' failed.\n",0,
                         64,VL_TIME_UNITED_Q(1000),
                         -9,vlSymsp->name());
            VL_STOP_MT("/local/scratch/tah56/misc/chipyard-upstream/sims/verilator/generated-src/chipyard.harness.TestHarness.SmallBoomV4Config/gen-collateral/TLDebugModuleInner.sv", 1461, "");
        }
    }
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__2746(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__2746\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if ((1U & (~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__debug_reset)))) {
        if (vlSymsp->_vm_contextp__->assertOnGet(2, 1)) {
            if (VL_UNLIKELY(((1U & (~ ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tlDM__DOT__dmInner__DOT__dmactive_synced_dmactive_synced_dmactiveSync__DOT__output_chain__DOT__sync_0)) 
                                       | ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tlDM__DOT__dmInner__DOT__dmInner__DOT__hartExceptionWrEn)) 
                                          | (2U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tlDM__DOT__dmInner__DOT__dmInner__DOT__ctrlStateReg))))))))) {
                VL_WRITEF_NX("[%0t] %%Error: TLDebugModuleInner.sv:1463: Assertion failed in %NTestDriver.testHarness.chiptop0.system.tlDM.dmInner.dmInner.assert__assert_4: 'assert' failed.\n",0,
                             64,VL_TIME_UNITED_Q(1000),
                             -9,vlSymsp->name());
                VL_STOP_MT("/local/scratch/tah56/misc/chipyard-upstream/sims/verilator/generated-src/chipyard.harness.TestHarness.SmallBoomV4Config/gen-collateral/TLDebugModuleInner.sv", 1463, "");
            }
        }
    }
    vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tlDM__DOT__dmInner__DOT__dmInner__DOT__hrmaskReg_0 
        = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tlDM__DOT__dmInner__DOT__dmInner__DOT__hrmaskReg_0;
    if (VL_UNLIKELY((((((~ (IData)(vlSelfRef.TestDriver__DOT__reset)) 
                        & (IData)(vlSelfRef.TestDriver__DOT__verbose)) 
                       & ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tlDM__DOT__dmInner__DOT__dmInner__DOT__goAbstract)) 
                          & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tlDM__DOT__dmInner__DOT__dmactive_synced_dmactive_synced_dmactiveSync__DOT__output_chain__DOT__sync_0) 
                             & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__debug_reset_syncd_debug_reset_sync__DOT__output_chain__DOT__sync_0) 
                                & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tlDM__DOT__dmInner__DOT__dmInner__DOT__hartGoingWrEn))))) 
                      & (0U != (0x3ffU & (IData)((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT___cbus_auto_coupler_to_debug_fragmenter_anon_out_a_bits_data 
                                                  >> 0x20U)))))))) {
        VL_FWRITEF_NX(0x80000002U,"Assertion failed: Unexpected 'GOING' hart.\n    at Debug.scala:1505 assert(hartGoingId === 0.U, \"Unexpected 'GOING' hart.\")//Chisel3 #540 %%%%x, expected %%%%x\", hartGoingId, 0.U)\n",0);
    }
    if (VL_UNLIKELY((((((~ (IData)(vlSelfRef.TestDriver__DOT__reset)) 
                        & (IData)(vlSelfRef.TestDriver__DOT__verbose)) 
                       & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tlDM__DOT__dmInner__DOT__dmInner__DOT___GEN_9) 
                          & ((2U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tlDM__DOT__dmInner__DOT__dmInner__DOT__ctrlStateReg)) 
                             & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__debug_reset_syncd_debug_reset_sync__DOT__output_chain__DOT__sync_0) 
                                & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tlDM__DOT__dmInner__DOT__dmInner__DOT__hartExceptionWrEn))))) 
                      & (0U != (0x3ffU & (IData)((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT___cbus_auto_coupler_to_debug_fragmenter_anon_out_a_bits_data 
                                                  >> 0x20U)))))))) {
        VL_FWRITEF_NX(0x80000002U,"Assertion failed: Unexpected 'EXCEPTION' hart\n    at Debug.scala:1826 assert(hartExceptionId === 0.U, \"Unexpected 'EXCEPTION' hart\")//Chisel3 #540, %%%%x, expected %%%%x\", hartExceptionId, 0.U)\n",0);
    }
    if (VL_UNLIKELY(((((~ (IData)(vlSelfRef.TestDriver__DOT__reset)) 
                       & (IData)(vlSelfRef.TestDriver__DOT__verbose)) 
                      & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tlDM__DOT__dmInner__DOT__dmInner__DOT___GEN_9) 
                         & ((2U != (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tlDM__DOT__dmInner__DOT__dmInner__DOT__ctrlStateReg)) 
                            & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__debug_reset_syncd_debug_reset_sync__DOT__output_chain__DOT__sync_0) 
                               & (3U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tlDM__DOT__dmInner__DOT__dmInner__DOT__ctrlStateReg))))))))) {
        VL_FWRITEF_NX(0x80000002U,"Assertion failed: Should not be in custom state unless we need it.\n    at Debug.scala:1831 assert(needCustom.B, \"Should not be in custom state unless we need it.\")\n",0);
    }
}

extern const VlWide<8>/*255:0*/ VTestDriver__ConstPool__CONST_h0595eb7c_0;

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__2890(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__2890\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.TestDriver__DOT__trace_count = (1ULL 
                                              + vlSelfRef.TestDriver__DOT__trace_count);
    if ((1U & (~ (IData)(vlSelfRef.TestDriver__DOT__reset)))) {
        if (((0ULL < vlSelfRef.TestDriver__DOT__max_cycles) 
             & (vlSelfRef.TestDriver__DOT__trace_count 
                > vlSelfRef.TestDriver__DOT__max_cycles))) {
            vlSelfRef.TestDriver__DOT__reason[0U] = 
                VTestDriver__ConstPool__CONST_h0595eb7c_0[0U];
            vlSelfRef.TestDriver__DOT__reason[1U] = 
                VTestDriver__ConstPool__CONST_h0595eb7c_0[1U];
            vlSelfRef.TestDriver__DOT__reason[2U] = 
                VTestDriver__ConstPool__CONST_h0595eb7c_0[2U];
            vlSelfRef.TestDriver__DOT__reason[3U] = 
                VTestDriver__ConstPool__CONST_h0595eb7c_0[3U];
            vlSelfRef.TestDriver__DOT__reason[4U] = 
                VTestDriver__ConstPool__CONST_h0595eb7c_0[4U];
            vlSelfRef.TestDriver__DOT__reason[5U] = 
                VTestDriver__ConstPool__CONST_h0595eb7c_0[5U];
            vlSelfRef.TestDriver__DOT__reason[6U] = 
                VTestDriver__ConstPool__CONST_h0595eb7c_0[6U];
            vlSelfRef.TestDriver__DOT__reason[7U] = 
                VTestDriver__ConstPool__CONST_h0595eb7c_0[7U];
            vlSelfRef.TestDriver__DOT__failure = 1U;
        }
        if (VL_UNLIKELY((vlSelfRef.TestDriver__DOT__failure))) {
            VL_FWRITEF_NX(0x80000002U,"*** FAILED ***%s after %20# simulation cycles\n",0,
                          256,vlSelfRef.TestDriver__DOT__reason.data(),
                          64,vlSelfRef.TestDriver__DOT__trace_count);
            VL_WRITEF_NX("[%0t] %%Fatal: TestDriver.v:147: Assertion failed in %NTestDriver\n",0,
                         64,VL_TIME_UNITED_Q(1000),
                         -9,vlSymsp->name());
            VL_STOP_MT("/local/scratch/tah56/misc/chipyard-upstream/sims/verilator/generated-src/chipyard.harness.TestHarness.SmallBoomV4Config/gen-collateral/TestDriver.v", 147, "", false);
        }
        if (VL_UNLIKELY((((1U == vlSelfRef.TestDriver__DOT__testHarness__DOT__success_exit_sim__DOT_____05Fexit_reg) 
                          | (1U == vlSelfRef.TestDriver__DOT__testHarness__DOT___jtag_exit))))) {
            if (VL_UNLIKELY((vlSelfRef.TestDriver__DOT__verbose))) {
                VL_FWRITEF_NX(0x80000002U,"*** PASSED *** Completed after %20# simulation cycles\n",0,
                              64,vlSelfRef.TestDriver__DOT__trace_count);
            }
            VL_FINISH_MT("/local/scratch/tah56/misc/chipyard-upstream/sims/verilator/generated-src/chipyard.harness.TestHarness.SmallBoomV4Config/gen-collateral/TestDriver.v", 158, "");
        }
    }
}

void VTestDriver___024unit____Vdpiimwrap_tsi_tick_TOP____024unit(IData/*31:0*/ chip_id, CData/*0:0*/ tsi_out_valid, CData/*0:0*/ &tsi_out_ready, IData/*31:0*/ tsi_out_bits, CData/*0:0*/ &tsi_in_valid, CData/*0:0*/ tsi_in_ready, IData/*31:0*/ &tsi_in_bits, IData/*31:0*/ &tsi_tick__Vfuncrtn);

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__2973(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__2973\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Init
    IData/*31:0*/ __Vfunc_tsi_tick__5__Vfuncout;
    __Vfunc_tsi_tick__5__Vfuncout = 0;
    CData/*0:0*/ __Vfunc_tsi_tick__5__tsi_out_ready;
    __Vfunc_tsi_tick__5__tsi_out_ready = 0;
    CData/*0:0*/ __Vfunc_tsi_tick__5__tsi_in_valid;
    __Vfunc_tsi_tick__5__tsi_in_valid = 0;
    IData/*31:0*/ __Vfunc_tsi_tick__5__tsi_in_bits;
    __Vfunc_tsi_tick__5__tsi_in_bits = 0;
    // Body
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__ram__DOT__phy__DOT__in_phits_in_async_1__DOT__sink__DOT____Vcellinp__sink_valid_0__reset) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__success_exit_sim__DOT_____05Fin_valid = 0U;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__success_exit_sim__DOT_____05Fout_ready = 0U;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__success_exit_sim__DOT_____05Fexit = 0U;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__success_exit_sim__DOT_____05Fin_valid_reg = 0U;
        vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__success_exit_sim__DOT_____05Fin_bits_reg = 0U;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__success_exit_sim__DOT_____05Fout_ready_reg = 0U;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__success_exit_sim__DOT_____05Fexit_reg = 0U;
    } else {
        VTestDriver___024unit____Vdpiimwrap_tsi_tick_TOP____024unit(0U, 
                                                                    (5U 
                                                                     == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__ram__DOT__tsi2tl__DOT__state)), __Vfunc_tsi_tick__5__tsi_out_ready, 
                                                                    ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__ram__DOT__tsi2tl__DOT__idx)
                                                                      ? vlSelfRef.TestDriver__DOT__testHarness__DOT__ram__DOT__tsi2tl__DOT__body_1
                                                                      : vlSelfRef.TestDriver__DOT__testHarness__DOT__ram__DOT__tsi2tl__DOT__body_0), __Vfunc_tsi_tick__5__tsi_in_valid, 
                                                                    ((0U 
                                                                      == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__ram__DOT__tsi2tl__DOT__state)) 
                                                                     | ((1U 
                                                                         == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__ram__DOT__tsi2tl__DOT__state)) 
                                                                        | ((2U 
                                                                            == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__ram__DOT__tsi2tl__DOT__state)) 
                                                                           | (6U 
                                                                              == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__ram__DOT__tsi2tl__DOT__state))))), __Vfunc_tsi_tick__5__tsi_in_bits, __Vfunc_tsi_tick__5__Vfuncout);
        vlSelfRef.TestDriver__DOT__testHarness__DOT__success_exit_sim__DOT_____05Fout_ready 
            = __Vfunc_tsi_tick__5__tsi_out_ready;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__success_exit_sim__DOT_____05Fin_valid 
            = __Vfunc_tsi_tick__5__tsi_in_valid;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__success_exit_sim__DOT_____05Fin_bits 
            = __Vfunc_tsi_tick__5__tsi_in_bits;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__success_exit_sim__DOT_____05Fexit 
            = __Vfunc_tsi_tick__5__Vfuncout;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__success_exit_sim__DOT_____05Fout_ready_reg 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__success_exit_sim__DOT_____05Fout_ready;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__success_exit_sim__DOT_____05Fin_valid_reg 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__success_exit_sim__DOT_____05Fin_valid;
        vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__success_exit_sim__DOT_____05Fin_bits_reg 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__success_exit_sim__DOT_____05Fin_bits;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__success_exit_sim__DOT_____05Fexit_reg 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__success_exit_sim__DOT_____05Fexit;
    }
    if ((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__ram__DOT__tsi2tl__DOT___GEN_17) 
          & (0ULL != vlSelfRef.TestDriver__DOT__testHarness__DOT__ram__DOT__tsi2tl__DOT__len)) 
         | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__ram__DOT__tsi2tl__DOT___GEN_11))) {
        vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__ram__DOT__tsi2tl__DOT__addr 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__ram__DOT__tsi2tl__DOT___GEN;
    } else if (vlSelfRef.TestDriver__DOT__testHarness__DOT__ram__DOT__tsi2tl__DOT___GEN_7) {
        vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__ram__DOT__tsi2tl__DOT__addr 
            = (vlSelfRef.TestDriver__DOT__testHarness__DOT__ram__DOT__tsi2tl__DOT__addr 
               | (((QData)((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__ram__DOT__tsi2tl__DOT___addr_T_2[1U])) 
                   << 0x20U) | (QData)((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__ram__DOT__tsi2tl__DOT___addr_T_2[0U]))));
    } else if (vlSelfRef.TestDriver__DOT__testHarness__DOT__ram__DOT__tsi2tl__DOT___GEN_6) {
        vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__ram__DOT__tsi2tl__DOT__addr = 0ULL;
    }
}
