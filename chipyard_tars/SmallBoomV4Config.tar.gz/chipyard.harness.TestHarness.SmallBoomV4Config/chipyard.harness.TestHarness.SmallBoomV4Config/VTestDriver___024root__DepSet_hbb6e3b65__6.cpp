// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See VTestDriver.h for the primary calling header

#include "VTestDriver__pch.h"
#include "VTestDriver___024root.h"

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__643(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__643\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__pbus__DOT__atomics__DOT___GEN_3) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__pbus__DOT__atomics__DOT__cam_a_0_bits_size 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__pbus__DOT___buffer_1_auto_out_a_bits_size;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___GEN_55) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__reg_pmp_7_cfg_r 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__newCfg_7_r;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___GEN_53) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__reg_pmp_6_cfg_r 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__newCfg_6_r;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___GEN_52) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__reg_pmp_5_cfg_r 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__newCfg_5_r;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___GEN_49) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__reg_pmp_2_cfg_r 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__newCfg_2_r;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___GEN_48) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__reg_pmp_1_cfg_r 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__newCfg_1_r;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___GEN_46) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__reg_pmp_0_cfg_r 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__newCfg_r;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___GEN_51) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__reg_pmp_4_cfg_r 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__newCfg_4_r;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___GEN_50) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__reg_pmp_3_cfg_r 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__newCfg_3_r;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT____Vcellinp__mshrs_5__io_allocate_valid) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_5__DOT__request_prio_0 = 0U;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT____Vcellinp__mshrs_6__io_allocate_valid) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_6__DOT__request_prio_0 = 0U;
    }
    if ((1U & (~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__pred_rename_stage__DOT___GEN_20)))) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_rename_stage__DOT__r_uop_is_sfb 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_is_sfb;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__tlb__DOT___GEN_114) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__tlb__DOT__r_sectored_hit_bits 
            = ((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__tlb__DOT__sector_hits_7) 
                 | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__tlb__DOT__sector_hits_6) 
                    | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__tlb__DOT__sector_hits_5) 
                       | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__tlb__DOT__sector_hits_4)))) 
                << 2U) | (((0U != (3U & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__tlb__DOT___r_sectored_hit_bits_T_2) 
                                         >> 1U))) << 1U) 
                          | (IData)((0U != (5U & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__tlb__DOT___r_sectored_hit_bits_T_2))))));
    }
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__loop__DOT__columns_0__DOT__f4_idx 
        = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__loop__DOT__columns_0__DOT__f4_idx_REG;
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__loop__DOT__columns_1__DOT__f4_idx 
        = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__loop__DOT__columns_1__DOT__f4_idx_REG;
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__loop__DOT__columns_2__DOT__f4_idx 
        = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__loop__DOT__columns_2__DOT__f4_idx_REG;
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__loop__DOT__columns_3__DOT__f4_idx 
        = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__loop__DOT__columns_3__DOT__f4_idx_REG;
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__pbus__DOT__coupler_to_bootaddressreg__DOT__fragmenter__DOT__repeater__DOT___GEN) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__pbus__DOT__coupler_to_bootaddressreg__DOT__fragmenter__DOT__repeater__DOT__saved_size 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__pbus__DOT___buffer_auto_out_a_bits_size;
    }
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__644(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__644\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if ((1U & (~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__pred_rename_stage__DOT___GEN_20)))) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__pred_rename_stage__DOT__r_uop_is_sfb 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_is_sfb;
    }
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_exe_unit_1__DOT__rrd_uop_bits_prs1 
        = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_exe_unit_1__DOT__arb_uop_bits_prs1;
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT____Vcellinp__bpd__io_f0_req_valid) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT__btb_ebtb__DOT__btb_ebtb_ext__DOT__mem_0_0__DOT__ram_R_0_addr_pipe_0 
            = (0x7fU & (IData)((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT____Vcellinp__bpd__io_f0_req_bits_pc 
                                >> 3U)));
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT__btb_data_way_0__DOT__btb_data_way_0_ext__DOT__mem_0_0__DOT__ram_R_0_addr_pipe_0 
            = (0x7fU & (IData)((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT____Vcellinp__bpd__io_f0_req_bits_pc 
                                >> 3U)));
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT__btb_data_way_0__DOT__btb_data_way_0_ext__DOT__mem_0_1__DOT__ram_R_0_addr_pipe_0 
            = (0x7fU & (IData)((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT____Vcellinp__bpd__io_f0_req_bits_pc 
                                >> 3U)));
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT__btb_data_way_0__DOT__btb_data_way_0_ext__DOT__mem_0_2__DOT__ram_R_0_addr_pipe_0 
            = (0x7fU & (IData)((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT____Vcellinp__bpd__io_f0_req_bits_pc 
                                >> 3U)));
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT__btb_data_way_0__DOT__btb_data_way_0_ext__DOT__mem_0_3__DOT__ram_R_0_addr_pipe_0 
            = (0x7fU & (IData)((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT____Vcellinp__bpd__io_f0_req_bits_pc 
                                >> 3U)));
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT__btb_data_way_1__DOT__btb_data_way_1_ext__DOT__mem_0_0__DOT__ram_R_0_addr_pipe_0 
            = (0x7fU & (IData)((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT____Vcellinp__bpd__io_f0_req_bits_pc 
                                >> 3U)));
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT__btb_data_way_1__DOT__btb_data_way_1_ext__DOT__mem_0_1__DOT__ram_R_0_addr_pipe_0 
            = (0x7fU & (IData)((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT____Vcellinp__bpd__io_f0_req_bits_pc 
                                >> 3U)));
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT__btb_data_way_1__DOT__btb_data_way_1_ext__DOT__mem_0_2__DOT__ram_R_0_addr_pipe_0 
            = (0x7fU & (IData)((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT____Vcellinp__bpd__io_f0_req_bits_pc 
                                >> 3U)));
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT__btb_data_way_1__DOT__btb_data_way_1_ext__DOT__mem_0_3__DOT__ram_R_0_addr_pipe_0 
            = (0x7fU & (IData)((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT____Vcellinp__bpd__io_f0_req_bits_pc 
                                >> 3U)));
    }
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__slots_6__DOT__slot_uop_prs2_busy 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__issue_slots_6_in_uop_valid)
            ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT___slots_7_io_out_uop_prs2_busy)
            : (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT___slots_6_io_out_uop_prs2_busy));
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__mmios_0__DOT___GEN_5) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__mmios_0__DOT__req_uop_mem_size 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__s2_req_0_uop_mem_size;
    }
    if ((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__cbus__DOT__atomics__DOT___GEN_5) 
          & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__cbus__DOT__atomics__DOT__d_cam_sel_0)) 
         & (1U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__cbus__DOT___buffer_auto_in_d_bits_opcode)))) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__cbus__DOT__atomics__DOT__cam_d_0_denied 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__cbus__DOT___buffer_auto_in_d_bits_denied;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__cbus__DOT__coupler_to_clint__DOT__fragmenter__DOT__repeater__DOT___GEN) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__cbus__DOT__coupler_to_clint__DOT__fragmenter__DOT__repeater__DOT__saved_address 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__cbus__DOT___out_xbar_auto_anon_out_3_a_bits_address;
    }
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__645(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__645\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_585) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_addr_is_virtual_7 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__exe_tlb_miss_0;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___GEN_45) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__reg_satp_ppn 
            = (QData)((IData)((0xfffffU & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___wdata_T_2) 
                                           & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___wdata_T_6)))));
    }
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__slots_6__DOT__slot_uop_iw_issued 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__issue_slots_6_in_uop_valid)
            ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT___slots_7_io_out_uop_iw_issued)
            : (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT___slots_6_io_out_uop_iw_issued));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__b2_jalr_target 
        = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__brinfos_0_bits_jalr_target;
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT__s1_idx 
        = (0x1fffffffffULL & (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT____Vcellinp__bpd__io_f0_req_bits_pc 
                              >> 3U));
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_584) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_addr_is_virtual_6 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__exe_tlb_miss_0;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_582) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_addr_is_virtual_4 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__exe_tlb_miss_0;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_581) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_addr_is_virtual_3 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__exe_tlb_miss_0;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_579) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_addr_is_virtual_1 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__exe_tlb_miss_0;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_580) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_addr_is_virtual_2 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__exe_tlb_miss_0;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_583) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_addr_is_virtual_5 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__exe_tlb_miss_0;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_578) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_addr_is_virtual_0 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__exe_tlb_miss_0;
    }
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__b2_pc_sel 
        = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__brinfos_0_bits_pc_sel;
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_0__DOT__rpq__DOT__main_io_deq_ready) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_0__DOT__rpq__DOT__out_reg_addr 
            = (0xffffffffffULL & (((QData)((IData)(
                                                   vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_0__DOT__rpq__DOT__main__DOT___ram_ext_R0_data[3U])) 
                                   << 0x16U) | ((QData)((IData)(
                                                                vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_0__DOT__rpq__DOT__main__DOT___ram_ext_R0_data[2U])) 
                                                >> 0xaU)));
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_1__DOT__rpq__DOT__main_io_deq_ready) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_1__DOT__rpq__DOT__out_reg_addr 
            = (0xffffffffffULL & (((QData)((IData)(
                                                   vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_1__DOT__rpq__DOT__main__DOT___ram_ext_R0_data[3U])) 
                                   << 0x16U) | ((QData)((IData)(
                                                                vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_1__DOT__rpq__DOT__main__DOT___ram_ext_R0_data[2U])) 
                                                >> 0xaU)));
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__cbus__DOT__atomics__DOT___GEN_4) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__cbus__DOT__atomics__DOT__cam_a_0_bits_source 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__cbus__DOT___in_xbar_auto_anon_out_a_bits_source;
    }
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__flush_pc_REG_1 
        = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___rob_io_com_xcpt_bits_edge_inst;
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__flush_pc_REG 
        = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___rob_io_com_xcpt_bits_pc_lob;
    if (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___csr_wen_T_4) 
         & (0xfffU == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___decoded_addr_decoded_decoded_andMatrixOutputs_T_11)))) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__reg_stval 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___GEN_43;
    } else if ((1U & (~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___GEN_39)))) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__reg_stval 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__tval;
    }
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__646(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__646\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if ((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__cbus__DOT__atomics__DOT___GEN_5) 
          & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__cbus__DOT__atomics__DOT__d_cam_sel_0)) 
         & (1U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__cbus__DOT___buffer_auto_in_d_bits_opcode)))) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__cbus__DOT__atomics__DOT__cam_d_0_corrupt 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__cbus__DOT___buffer_auto_in_d_bits_corrupt;
    }
    if (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___csr_wen_T_4) 
         & (0xfffU == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___decoded_addr_decoded_decoded_andMatrixOutputs_T_8)))) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__reg_sscratch 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__wdata;
    }
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unq_iss_unit__DOT__slots_0__DOT__slot_uop_iw_issued 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unq_iss_unit__DOT__issue_slots_0_in_uop_valid)
            ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unq_iss_unit__DOT___slots_1_io_out_uop_iw_issued)
            : ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT____Vcellinp__unq_iss_unit__io_squash_grant)) 
               & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unq_iss_unit__DOT__issue_slots_0_grant)));
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT____Vcellinp__bpd__io_f0_req_valid) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT__btb_meta_way_1__DOT__btb_meta_way_1_ext__DOT__mem_0_0__DOT__ram_R_0_addr_pipe_0 
            = (0x7fU & (IData)((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT____Vcellinp__bpd__io_f0_req_bits_pc 
                                >> 3U)));
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT__btb_meta_way_1__DOT__btb_meta_way_1_ext__DOT__mem_0_1__DOT__ram_R_0_addr_pipe_0 
            = (0x7fU & (IData)((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT____Vcellinp__bpd__io_f0_req_bits_pc 
                                >> 3U)));
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT__btb_meta_way_1__DOT__btb_meta_way_1_ext__DOT__mem_0_2__DOT__ram_R_0_addr_pipe_0 
            = (0x7fU & (IData)((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT____Vcellinp__bpd__io_f0_req_bits_pc 
                                >> 3U)));
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT__btb_meta_way_1__DOT__btb_meta_way_1_ext__DOT__mem_0_3__DOT__ram_R_0_addr_pipe_0 
            = (0x7fU & (IData)((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT____Vcellinp__bpd__io_f0_req_bits_pc 
                                >> 3U)));
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT__btb_meta_way_0__DOT__btb_meta_way_0_ext__DOT__mem_0_0__DOT__ram_R_0_addr_pipe_0 
            = (0x7fU & (IData)((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT____Vcellinp__bpd__io_f0_req_bits_pc 
                                >> 3U)));
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT__btb_meta_way_0__DOT__btb_meta_way_0_ext__DOT__mem_0_1__DOT__ram_R_0_addr_pipe_0 
            = (0x7fU & (IData)((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT____Vcellinp__bpd__io_f0_req_bits_pc 
                                >> 3U)));
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT__btb_meta_way_0__DOT__btb_meta_way_0_ext__DOT__mem_0_2__DOT__ram_R_0_addr_pipe_0 
            = (0x7fU & (IData)((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT____Vcellinp__bpd__io_f0_req_bits_pc 
                                >> 3U)));
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT__btb_meta_way_0__DOT__btb_meta_way_0_ext__DOT__mem_0_3__DOT__ram_R_0_addr_pipe_0 
            = (0x7fU & (IData)((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT____Vcellinp__bpd__io_f0_req_bits_pc 
                                >> 3U)));
    }
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__flush_typ 
        = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___rob_io_flush_bits_flush_typ;
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__pbus__DOT__atomics__DOT___GEN_3) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__pbus__DOT__atomics__DOT__cam_a_0_bits_mask 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__pbus__DOT___buffer_1_auto_out_a_bits_mask;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__cbus__DOT__atomics__DOT___GEN_4) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__cbus__DOT__atomics__DOT__cam_a_0_bits_mask 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__cbus__DOT___in_xbar_auto_anon_out_a_bits_mask;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__cbus__DOT__atomics__DOT__cam_a_0_bits_size 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__cbus__DOT___in_xbar_auto_anon_out_a_bits_size;
    }
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__647(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__647\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__pbus__DOT__atomics__DOT___GEN_3) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__pbus__DOT__atomics__DOT__cam_a_0_bits_address 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__pbus__DOT___buffer_1_auto_out_a_bits_address;
    }
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_0__DOT__slot_uop_iw_issued 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__issue_slots_0_in_uop_valid)
            ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT___slots_1_io_out_uop_iw_issued)
            : ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT___fp_exe_unit_0_io_squash_iss)) 
               & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__issue_slots_0_grant)));
    if (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___csr_wen_T_4) 
         & (0x7ffU == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___decoded_addr_decoded_decoded_andMatrixOutputs_T_6)))) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__reg_scounteren 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___GEN_42;
    }
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__b2_cfi_type 
        = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__brinfos_0_bits_cfi_type;
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_582) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_addr_4_bits 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___ldq_addr_bits_T;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_583) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_addr_5_bits 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___ldq_addr_bits_T;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_578) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_addr_0_bits 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___ldq_addr_bits_T;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_584) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_addr_6_bits 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___ldq_addr_bits_T;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_581) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_addr_3_bits 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___ldq_addr_bits_T;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_585) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_addr_7_bits 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___ldq_addr_bits_T;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_580) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_addr_2_bits 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___ldq_addr_bits_T;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_579) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_addr_1_bits 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___ldq_addr_bits_T;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__chipyard_prcictrl_domain__DOT__fragmenter__DOT__repeater__DOT___GEN) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__chipyard_prcictrl_domain__DOT__fragmenter__DOT__repeater__DOT__saved_opcode 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__chipyard_prcictrl_domain__DOT___xbar_auto_anon_out_1_a_bits_opcode;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT____Vcellinp__mshrs_0__io_allocate_valid) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_0__DOT__request_source 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT____Vcellinp__mshrs_0__io_allocate_bits_source;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT____Vcellinp__mshrs_1__io_allocate_valid) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_1__DOT__request_source 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT____Vcellinp__mshrs_1__io_allocate_bits_source;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT____Vcellinp__mshrs_2__io_allocate_valid) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_2__DOT__request_source 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT____Vcellinp__mshrs_2__io_allocate_bits_source;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT____Vcellinp__mshrs_3__io_allocate_valid) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_3__DOT__request_source 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT____Vcellinp__mshrs_3__io_allocate_bits_source;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT____Vcellinp__mshrs_4__io_allocate_valid) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_4__DOT__request_source 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT____Vcellinp__mshrs_4__io_allocate_bits_source;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT____Vcellinp__mshrs_5__io_allocate_valid) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_5__DOT__request_source 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT____Vcellinp__mshrs_5__io_allocate_bits_source;
    }
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__648(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__648\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT____Vcellinp__mshrs_6__io_allocate_valid) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_6__DOT__request_source 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT____Vcellinp__mshrs_6__io_allocate_bits_source;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___GEN_46) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__reg_pmp_0_cfg_x 
            = (1U & ((IData)((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___wdata_T_2 
                              >> 2U)) & (IData)((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___wdata_T_6 
                                                 >> 2U))));
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___GEN_55) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__reg_pmp_7_cfg_x 
            = (1U & ((IData)((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___wdata_T_2 
                              >> 0x3aU)) & (IData)(
                                                   (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___wdata_T_6 
                                                    >> 0x3aU))));
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___GEN_50) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__reg_pmp_3_cfg_x 
            = (1U & ((IData)((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___wdata_T_2 
                              >> 0x1aU)) & (IData)(
                                                   (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___wdata_T_6 
                                                    >> 0x1aU))));
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___GEN_49) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__reg_pmp_2_cfg_x 
            = (1U & ((IData)((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___wdata_T_2 
                              >> 0x12U)) & (IData)(
                                                   (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___wdata_T_6 
                                                    >> 0x12U))));
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___GEN_52) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__reg_pmp_5_cfg_x 
            = (1U & ((IData)((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___wdata_T_2 
                              >> 0x2aU)) & (IData)(
                                                   (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___wdata_T_6 
                                                    >> 0x2aU))));
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___GEN_48) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__reg_pmp_1_cfg_x 
            = (1U & ((IData)((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___wdata_T_2 
                              >> 0xaU)) & (IData)((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___wdata_T_6 
                                                   >> 0xaU))));
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___GEN_53) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__reg_pmp_6_cfg_x 
            = (1U & ((IData)((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___wdata_T_2 
                              >> 0x32U)) & (IData)(
                                                   (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___wdata_T_6 
                                                    >> 0x32U))));
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__reg_pmp_6_cfg_w 
            = (((IData)((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___wdata_T_2 
                         >> 0x31U)) & (IData)((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___wdata_T_6 
                                               >> 0x31U))) 
               & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__newCfg_6_r));
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___GEN_51) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__reg_pmp_4_cfg_x 
            = (1U & ((IData)((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___wdata_T_2 
                              >> 0x22U)) & (IData)(
                                                   (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___wdata_T_6 
                                                    >> 0x22U))));
    }
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__649(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__649\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___GEN_49) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__reg_pmp_2_cfg_w 
            = (((IData)((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___wdata_T_2 
                         >> 0x11U)) & (IData)((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___wdata_T_6 
                                               >> 0x11U))) 
               & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__newCfg_2_r));
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___GEN_46) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__reg_pmp_0_cfg_w 
            = (((IData)((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___wdata_T_2 
                         >> 1U)) & (IData)((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___wdata_T_6 
                                            >> 1U))) 
               & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__newCfg_r));
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___GEN_55) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__reg_pmp_7_cfg_w 
            = (((IData)((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___wdata_T_2 
                         >> 0x39U)) & (IData)((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___wdata_T_6 
                                               >> 0x39U))) 
               & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__newCfg_7_r));
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___GEN_50) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__reg_pmp_3_cfg_w 
            = (((IData)((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___wdata_T_2 
                         >> 0x19U)) & (IData)((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___wdata_T_6 
                                               >> 0x19U))) 
               & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__newCfg_3_r));
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___GEN_52) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__reg_pmp_5_cfg_w 
            = (((IData)((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___wdata_T_2 
                         >> 0x29U)) & (IData)((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___wdata_T_6 
                                               >> 0x29U))) 
               & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__newCfg_5_r));
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___GEN_48) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__reg_pmp_1_cfg_w 
            = (((IData)((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___wdata_T_2 
                         >> 9U)) & (IData)((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___wdata_T_6 
                                            >> 9U))) 
               & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__newCfg_1_r));
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___GEN_51) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__reg_pmp_4_cfg_w 
            = (((IData)((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___wdata_T_2 
                         >> 0x21U)) & (IData)((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___wdata_T_6 
                                               >> 0x21U))) 
               & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__newCfg_4_r));
    }
    if (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___csr_wen_T_4) 
         & (0x7ffU == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___decoded_addr_decoded_decoded_andMatrixOutputs_T_20)))) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__reg_mcounteren 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___GEN_42;
    }
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__650(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__650\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__fb__DOT___GEN_31) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__fb__DOT__fb_uop_ram_0_is_sfb 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__fb__DOT__in_uops_3_is_sfb;
    } else if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__fb__DOT___GEN_22) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__fb__DOT__fb_uop_ram_0_is_sfb 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__fb__DOT__in_uops_2_is_sfb;
    } else if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__fb__DOT___GEN_13) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__fb__DOT__fb_uop_ram_0_is_sfb 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__fb__DOT__in_uops_1_is_sfb;
    } else if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__fb__DOT___GEN_4) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__fb__DOT__fb_uop_ram_0_is_sfb 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__fb__DOT__in_uops_0_is_sfb;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__fb__DOT___GEN_35) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__fb__DOT__fb_uop_ram_4_is_sfb 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__fb__DOT__in_uops_3_is_sfb;
    } else if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__fb__DOT___GEN_26) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__fb__DOT__fb_uop_ram_4_is_sfb 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__fb__DOT__in_uops_2_is_sfb;
    } else if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__fb__DOT___GEN_17) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__fb__DOT__fb_uop_ram_4_is_sfb 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__fb__DOT__in_uops_1_is_sfb;
    } else if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__fb__DOT___GEN_8) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__fb__DOT__fb_uop_ram_4_is_sfb 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__fb__DOT__in_uops_0_is_sfb;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__fb__DOT___GEN_34) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__fb__DOT__fb_uop_ram_3_is_sfb 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__fb__DOT__in_uops_3_is_sfb;
    } else if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__fb__DOT___GEN_25) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__fb__DOT__fb_uop_ram_3_is_sfb 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__fb__DOT__in_uops_2_is_sfb;
    } else if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__fb__DOT___GEN_16) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__fb__DOT__fb_uop_ram_3_is_sfb 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__fb__DOT__in_uops_1_is_sfb;
    } else if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__fb__DOT___GEN_7) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__fb__DOT__fb_uop_ram_3_is_sfb 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__fb__DOT__in_uops_0_is_sfb;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__fb__DOT___GEN_38) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__fb__DOT__fb_uop_ram_7_is_sfb 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__fb__DOT__in_uops_3_is_sfb;
    } else if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__fb__DOT___GEN_29) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__fb__DOT__fb_uop_ram_7_is_sfb 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__fb__DOT__in_uops_2_is_sfb;
    } else if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__fb__DOT___GEN_20) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__fb__DOT__fb_uop_ram_7_is_sfb 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__fb__DOT__in_uops_1_is_sfb;
    } else if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__fb__DOT___GEN_11) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__fb__DOT__fb_uop_ram_7_is_sfb 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__fb__DOT__in_uops_0_is_sfb;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__fb__DOT___GEN_37) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__fb__DOT__fb_uop_ram_6_is_sfb 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__fb__DOT__in_uops_3_is_sfb;
    } else if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__fb__DOT___GEN_28) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__fb__DOT__fb_uop_ram_6_is_sfb 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__fb__DOT__in_uops_2_is_sfb;
    } else if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__fb__DOT___GEN_19) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__fb__DOT__fb_uop_ram_6_is_sfb 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__fb__DOT__in_uops_1_is_sfb;
    } else if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__fb__DOT___GEN_10) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__fb__DOT__fb_uop_ram_6_is_sfb 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__fb__DOT__in_uops_0_is_sfb;
    }
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__651(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__651\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__fb__DOT___GEN_32) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__fb__DOT__fb_uop_ram_1_is_sfb 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__fb__DOT__in_uops_3_is_sfb;
    } else if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__fb__DOT___GEN_23) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__fb__DOT__fb_uop_ram_1_is_sfb 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__fb__DOT__in_uops_2_is_sfb;
    } else if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__fb__DOT___GEN_14) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__fb__DOT__fb_uop_ram_1_is_sfb 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__fb__DOT__in_uops_1_is_sfb;
    } else if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__fb__DOT___GEN_5) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__fb__DOT__fb_uop_ram_1_is_sfb 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__fb__DOT__in_uops_0_is_sfb;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__fb__DOT___GEN_36) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__fb__DOT__fb_uop_ram_5_is_sfb 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__fb__DOT__in_uops_3_is_sfb;
    } else if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__fb__DOT___GEN_27) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__fb__DOT__fb_uop_ram_5_is_sfb 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__fb__DOT__in_uops_2_is_sfb;
    } else if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__fb__DOT___GEN_18) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__fb__DOT__fb_uop_ram_5_is_sfb 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__fb__DOT__in_uops_1_is_sfb;
    } else if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__fb__DOT___GEN_9) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__fb__DOT__fb_uop_ram_5_is_sfb 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__fb__DOT__in_uops_0_is_sfb;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__fb__DOT___GEN_33) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__fb__DOT__fb_uop_ram_2_is_sfb 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__fb__DOT__in_uops_3_is_sfb;
    } else if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__fb__DOT___GEN_24) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__fb__DOT__fb_uop_ram_2_is_sfb 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__fb__DOT__in_uops_2_is_sfb;
    } else if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__fb__DOT___GEN_15) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__fb__DOT__fb_uop_ram_2_is_sfb 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__fb__DOT__in_uops_1_is_sfb;
    } else if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__fb__DOT___GEN_6) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__fb__DOT__fb_uop_ram_2_is_sfb 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__fb__DOT__in_uops_0_is_sfb;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_576) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__ldq_addr_7_bits 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___ldq_addr_bits_T;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__chipyard_prcictrl_domain__DOT__fragmenter_1__DOT__repeater__DOT___GEN) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__chipyard_prcictrl_domain__DOT__fragmenter_1__DOT__repeater__DOT__saved_opcode 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__chipyard_prcictrl_domain__DOT___xbar_auto_anon_out_1_a_bits_opcode;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__cbus__DOT__atomics__DOT___GEN_4) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__cbus__DOT__atomics__DOT__cam_a_0_bits_address 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__cbus__DOT___in_xbar_auto_anon_out_a_bits_address;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_575) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__ldq_addr_6_bits 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___ldq_addr_bits_T;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_569) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__ldq_addr_0_bits 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___ldq_addr_bits_T;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_574) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__ldq_addr_5_bits 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___ldq_addr_bits_T;
    }
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__slots_7__DOT__slot_uop_prs1_busy 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__issue_slots_7_in_uop_valid)
            ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__alu_iss_unit__DOT____Vcellinp__slots_7__io_in_uop_bits_prs1_busy)
            : (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT___slots_7_io_out_uop_prs1_busy));
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_573) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__ldq_addr_4_bits 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___ldq_addr_bits_T;
    }
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__652(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__652\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_571) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__ldq_addr_2_bits 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___ldq_addr_bits_T;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_572) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__ldq_addr_3_bits 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___ldq_addr_bits_T;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__tlb__DOT___GEN_114) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__tlb__DOT__r_sectored_hit_valid 
            = ((((((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__tlb__DOT__sector_hits_0) 
                     | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__tlb__DOT__sector_hits_1)) 
                    | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__tlb__DOT__sector_hits_2)) 
                   | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__tlb__DOT__sector_hits_3)) 
                  | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__tlb__DOT__sector_hits_4)) 
                 | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__tlb__DOT__sector_hits_5)) 
                | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__tlb__DOT__sector_hits_6)) 
               | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__tlb__DOT__sector_hits_7));
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_570) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__ldq_addr_1_bits 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___ldq_addr_bits_T;
    }
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__slots_5__DOT__slot_uop_prs2_busy 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__issue_slots_5_in_uop_valid)
            ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT___slots_6_io_out_uop_prs2_busy)
            : (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT___slots_5_io_out_uop_prs2_busy));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__io_ifu_redirect_pc_r_2 
        = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__io_ifu_redirect_pc_r_1;
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__chipyard_prcictrl_domain__DOT__fragmenter__DOT__repeater__DOT___GEN) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__chipyard_prcictrl_domain__DOT__fragmenter__DOT__repeater__DOT__saved_size 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__chipyard_prcictrl_domain__DOT___xbar_auto_anon_out_1_a_bits_size;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__mbus__DOT__coupler_to_memory_controller_port_named_axi4__DOT__axi4yank__DOT__Queue1_BundleMap__DOT__do_enq) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__mbus__DOT__coupler_to_memory_controller_port_named_axi4__DOT__axi4yank__DOT__Queue1_BundleMap__DOT__ram 
            = (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__mbus__DOT__coupler_to_memory_controller_port_named_axi4__DOT___tl2axi4_auto_out_aw_bits_echo_tl_state_size) 
                << 4U) | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__mbus__DOT__coupler_to_memory_controller_port_named_axi4__DOT___tl2axi4_auto_out_aw_bits_echo_tl_state_source));
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__mbus__DOT__coupler_to_memory_controller_port_named_axi4__DOT__axi4yank__DOT__Queue1_BundleMap_1__DOT__do_enq) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__mbus__DOT__coupler_to_memory_controller_port_named_axi4__DOT__axi4yank__DOT__Queue1_BundleMap_1__DOT__ram 
            = (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__mbus__DOT__coupler_to_memory_controller_port_named_axi4__DOT___tl2axi4_auto_out_aw_bits_echo_tl_state_size) 
                << 4U) | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__mbus__DOT__coupler_to_memory_controller_port_named_axi4__DOT___tl2axi4_auto_out_aw_bits_echo_tl_state_source));
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__mbus__DOT__coupler_to_memory_controller_port_named_axi4__DOT__axi4yank__DOT__Queue1_BundleMap_2__DOT__do_enq) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__mbus__DOT__coupler_to_memory_controller_port_named_axi4__DOT__axi4yank__DOT__Queue1_BundleMap_2__DOT__ram 
            = (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__mbus__DOT__coupler_to_memory_controller_port_named_axi4__DOT___tl2axi4_auto_out_aw_bits_echo_tl_state_size) 
                << 4U) | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__mbus__DOT__coupler_to_memory_controller_port_named_axi4__DOT___tl2axi4_auto_out_aw_bits_echo_tl_state_source));
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__mbus__DOT__coupler_to_memory_controller_port_named_axi4__DOT__axi4yank__DOT__Queue1_BundleMap_3__DOT__do_enq) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__mbus__DOT__coupler_to_memory_controller_port_named_axi4__DOT__axi4yank__DOT__Queue1_BundleMap_3__DOT__ram 
            = (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__mbus__DOT__coupler_to_memory_controller_port_named_axi4__DOT___tl2axi4_auto_out_aw_bits_echo_tl_state_size) 
                << 4U) | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__mbus__DOT__coupler_to_memory_controller_port_named_axi4__DOT___tl2axi4_auto_out_aw_bits_echo_tl_state_source));
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__mbus__DOT__coupler_to_memory_controller_port_named_axi4__DOT__axi4yank__DOT__Queue1_BundleMap_4__DOT__do_enq) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__mbus__DOT__coupler_to_memory_controller_port_named_axi4__DOT__axi4yank__DOT__Queue1_BundleMap_4__DOT__ram 
            = (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__mbus__DOT__coupler_to_memory_controller_port_named_axi4__DOT___tl2axi4_auto_out_aw_bits_echo_tl_state_size) 
                << 4U) | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__mbus__DOT__coupler_to_memory_controller_port_named_axi4__DOT___tl2axi4_auto_out_aw_bits_echo_tl_state_source));
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__mbus__DOT__coupler_to_memory_controller_port_named_axi4__DOT__axi4yank__DOT__Queue1_BundleMap_5__DOT__do_enq) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__mbus__DOT__coupler_to_memory_controller_port_named_axi4__DOT__axi4yank__DOT__Queue1_BundleMap_5__DOT__ram 
            = (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__mbus__DOT__coupler_to_memory_controller_port_named_axi4__DOT___tl2axi4_auto_out_aw_bits_echo_tl_state_size) 
                << 4U) | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__mbus__DOT__coupler_to_memory_controller_port_named_axi4__DOT___tl2axi4_auto_out_aw_bits_echo_tl_state_source));
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__mbus__DOT__coupler_to_memory_controller_port_named_axi4__DOT__axi4yank__DOT__Queue1_BundleMap_6__DOT__do_enq) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__mbus__DOT__coupler_to_memory_controller_port_named_axi4__DOT__axi4yank__DOT__Queue1_BundleMap_6__DOT__ram 
            = (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__mbus__DOT__coupler_to_memory_controller_port_named_axi4__DOT___tl2axi4_auto_out_aw_bits_echo_tl_state_size) 
                << 4U) | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__mbus__DOT__coupler_to_memory_controller_port_named_axi4__DOT___tl2axi4_auto_out_aw_bits_echo_tl_state_source));
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__mbus__DOT__coupler_to_memory_controller_port_named_axi4__DOT__axi4yank__DOT__Queue1_BundleMap_7__DOT__do_enq) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__mbus__DOT__coupler_to_memory_controller_port_named_axi4__DOT__axi4yank__DOT__Queue1_BundleMap_7__DOT__ram 
            = (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__mbus__DOT__coupler_to_memory_controller_port_named_axi4__DOT___tl2axi4_auto_out_aw_bits_echo_tl_state_size) 
                << 4U) | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__mbus__DOT__coupler_to_memory_controller_port_named_axi4__DOT___tl2axi4_auto_out_aw_bits_echo_tl_state_source));
    }
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__653(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__653\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__mbus__DOT__coupler_to_memory_controller_port_named_axi4__DOT__axi4yank__DOT__Queue1_BundleMap_8__DOT__do_enq) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__mbus__DOT__coupler_to_memory_controller_port_named_axi4__DOT__axi4yank__DOT__Queue1_BundleMap_8__DOT__ram 
            = (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__mbus__DOT__coupler_to_memory_controller_port_named_axi4__DOT___tl2axi4_auto_out_aw_bits_echo_tl_state_size) 
                << 4U) | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__mbus__DOT__coupler_to_memory_controller_port_named_axi4__DOT___tl2axi4_auto_out_aw_bits_echo_tl_state_source));
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__mbus__DOT__coupler_to_memory_controller_port_named_axi4__DOT__axi4yank__DOT__Queue1_BundleMap_9__DOT__do_enq) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__mbus__DOT__coupler_to_memory_controller_port_named_axi4__DOT__axi4yank__DOT__Queue1_BundleMap_9__DOT__ram 
            = (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__mbus__DOT__coupler_to_memory_controller_port_named_axi4__DOT___tl2axi4_auto_out_aw_bits_echo_tl_state_size) 
                << 4U) | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__mbus__DOT__coupler_to_memory_controller_port_named_axi4__DOT___tl2axi4_auto_out_aw_bits_echo_tl_state_source));
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__mbus__DOT__coupler_to_memory_controller_port_named_axi4__DOT__axi4yank__DOT__Queue1_BundleMap_10__DOT__do_enq) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__mbus__DOT__coupler_to_memory_controller_port_named_axi4__DOT__axi4yank__DOT__Queue1_BundleMap_10__DOT__ram 
            = (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__mbus__DOT__coupler_to_memory_controller_port_named_axi4__DOT___tl2axi4_auto_out_aw_bits_echo_tl_state_size) 
                << 4U) | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__mbus__DOT__coupler_to_memory_controller_port_named_axi4__DOT___tl2axi4_auto_out_aw_bits_echo_tl_state_source));
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__mbus__DOT__coupler_to_memory_controller_port_named_axi4__DOT__axi4yank__DOT__Queue1_BundleMap_11__DOT__do_enq) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__mbus__DOT__coupler_to_memory_controller_port_named_axi4__DOT__axi4yank__DOT__Queue1_BundleMap_11__DOT__ram 
            = (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__mbus__DOT__coupler_to_memory_controller_port_named_axi4__DOT___tl2axi4_auto_out_aw_bits_echo_tl_state_size) 
                << 4U) | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__mbus__DOT__coupler_to_memory_controller_port_named_axi4__DOT___tl2axi4_auto_out_aw_bits_echo_tl_state_source));
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__mbus__DOT__coupler_to_memory_controller_port_named_axi4__DOT__axi4yank__DOT__Queue1_BundleMap_12__DOT__do_enq) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__mbus__DOT__coupler_to_memory_controller_port_named_axi4__DOT__axi4yank__DOT__Queue1_BundleMap_12__DOT__ram 
            = (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__mbus__DOT__coupler_to_memory_controller_port_named_axi4__DOT___tl2axi4_auto_out_aw_bits_echo_tl_state_size) 
                << 4U) | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__mbus__DOT__coupler_to_memory_controller_port_named_axi4__DOT___tl2axi4_auto_out_aw_bits_echo_tl_state_source));
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__mbus__DOT__coupler_to_memory_controller_port_named_axi4__DOT__axi4yank__DOT__Queue1_BundleMap_13__DOT__do_enq) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__mbus__DOT__coupler_to_memory_controller_port_named_axi4__DOT__axi4yank__DOT__Queue1_BundleMap_13__DOT__ram 
            = (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__mbus__DOT__coupler_to_memory_controller_port_named_axi4__DOT___tl2axi4_auto_out_aw_bits_echo_tl_state_size) 
                << 4U) | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__mbus__DOT__coupler_to_memory_controller_port_named_axi4__DOT___tl2axi4_auto_out_aw_bits_echo_tl_state_source));
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__mbus__DOT__coupler_to_memory_controller_port_named_axi4__DOT__axi4yank__DOT__Queue1_BundleMap_14__DOT__do_enq) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__mbus__DOT__coupler_to_memory_controller_port_named_axi4__DOT__axi4yank__DOT__Queue1_BundleMap_14__DOT__ram 
            = (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__mbus__DOT__coupler_to_memory_controller_port_named_axi4__DOT___tl2axi4_auto_out_aw_bits_echo_tl_state_size) 
                << 4U) | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__mbus__DOT__coupler_to_memory_controller_port_named_axi4__DOT___tl2axi4_auto_out_aw_bits_echo_tl_state_source));
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__mbus__DOT__coupler_to_memory_controller_port_named_axi4__DOT__axi4yank__DOT__Queue1_BundleMap_15__DOT__do_enq) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__mbus__DOT__coupler_to_memory_controller_port_named_axi4__DOT__axi4yank__DOT__Queue1_BundleMap_15__DOT__ram 
            = (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__mbus__DOT__coupler_to_memory_controller_port_named_axi4__DOT___tl2axi4_auto_out_aw_bits_echo_tl_state_size) 
                << 4U) | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__mbus__DOT__coupler_to_memory_controller_port_named_axi4__DOT___tl2axi4_auto_out_aw_bits_echo_tl_state_source));
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__mbus__DOT__coupler_to_memory_controller_port_named_axi4__DOT__axi4yank__DOT__Queue1_BundleMap_16__DOT__do_enq) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__mbus__DOT__coupler_to_memory_controller_port_named_axi4__DOT__axi4yank__DOT__Queue1_BundleMap_16__DOT__ram 
            = (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__mbus__DOT__coupler_to_memory_controller_port_named_axi4__DOT___tl2axi4_auto_out_aw_bits_echo_tl_state_size) 
                << 4U) | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__mbus__DOT__coupler_to_memory_controller_port_named_axi4__DOT___tl2axi4_auto_out_aw_bits_echo_tl_state_source));
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__mbus__DOT__coupler_to_memory_controller_port_named_axi4__DOT__axi4yank__DOT__Queue1_BundleMap_17__DOT__do_enq) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__mbus__DOT__coupler_to_memory_controller_port_named_axi4__DOT__axi4yank__DOT__Queue1_BundleMap_17__DOT__ram 
            = (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__mbus__DOT__coupler_to_memory_controller_port_named_axi4__DOT___tl2axi4_auto_out_aw_bits_echo_tl_state_size) 
                << 4U) | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__mbus__DOT__coupler_to_memory_controller_port_named_axi4__DOT___tl2axi4_auto_out_aw_bits_echo_tl_state_source));
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__mbus__DOT__coupler_to_memory_controller_port_named_axi4__DOT__axi4yank__DOT__Queue1_BundleMap_18__DOT__do_enq) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__mbus__DOT__coupler_to_memory_controller_port_named_axi4__DOT__axi4yank__DOT__Queue1_BundleMap_18__DOT__ram 
            = (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__mbus__DOT__coupler_to_memory_controller_port_named_axi4__DOT___tl2axi4_auto_out_aw_bits_echo_tl_state_size) 
                << 4U) | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__mbus__DOT__coupler_to_memory_controller_port_named_axi4__DOT___tl2axi4_auto_out_aw_bits_echo_tl_state_source));
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__mbus__DOT__coupler_to_memory_controller_port_named_axi4__DOT__axi4yank__DOT__Queue1_BundleMap_19__DOT__do_enq) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__mbus__DOT__coupler_to_memory_controller_port_named_axi4__DOT__axi4yank__DOT__Queue1_BundleMap_19__DOT__ram 
            = (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__mbus__DOT__coupler_to_memory_controller_port_named_axi4__DOT___tl2axi4_auto_out_aw_bits_echo_tl_state_size) 
                << 4U) | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__mbus__DOT__coupler_to_memory_controller_port_named_axi4__DOT___tl2axi4_auto_out_aw_bits_echo_tl_state_source));
    }
    if ((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__cbus__DOT__atomics__DOT___GEN_5) 
          & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__cbus__DOT__atomics__DOT__d_cam_sel_0)) 
         & (1U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__cbus__DOT___buffer_auto_in_d_bits_opcode)))) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__cbus__DOT__atomics__DOT__cam_d_0_data 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__cbus__DOT___buffer_auto_in_d_bits_data;
    }
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__lcam_stq_idx_reg 
        = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___retry_queue_io_deq_bits_uop_stq_idx;
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__slots_5__DOT__slot_uop_iw_issued 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__issue_slots_5_in_uop_valid)
            ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT___slots_6_io_out_uop_iw_issued)
            : (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT___slots_5_io_out_uop_iw_issued));
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__654(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__654\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__retry_queue__DOT___GEN_112) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__retry_queue__DOT__uops_0_mem_cmd 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT____Vcellinp__retry_queue__io_enq_bits_uop_mem_cmd;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__retry_queue__DOT___GEN_120) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__retry_queue__DOT__uops_4_mem_cmd 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT____Vcellinp__retry_queue__io_enq_bits_uop_mem_cmd;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__retry_queue__DOT___GEN_118) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__retry_queue__DOT__uops_3_mem_cmd 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT____Vcellinp__retry_queue__io_enq_bits_uop_mem_cmd;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__retry_queue__DOT___GEN_114) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__retry_queue__DOT__uops_1_mem_cmd 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT____Vcellinp__retry_queue__io_enq_bits_uop_mem_cmd;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__retry_queue__DOT___GEN_116) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__retry_queue__DOT__uops_2_mem_cmd 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT____Vcellinp__retry_queue__io_enq_bits_uop_mem_cmd;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__retry_queue__DOT___GEN_122) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__retry_queue__DOT__uops_5_mem_cmd 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT____Vcellinp__retry_queue__io_enq_bits_uop_mem_cmd;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__retry_queue__DOT___GEN_124) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__retry_queue__DOT__uops_6_mem_cmd 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT____Vcellinp__retry_queue__io_enq_bits_uop_mem_cmd;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__retry_queue__DOT___GEN_125) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__retry_queue__DOT__uops_7_mem_cmd 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT____Vcellinp__retry_queue__io_enq_bits_uop_mem_cmd;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__chipyard_prcictrl_domain__DOT__fragmenter_1__DOT__repeater__DOT___GEN) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__chipyard_prcictrl_domain__DOT__fragmenter_1__DOT__repeater__DOT__saved_size 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__chipyard_prcictrl_domain__DOT___xbar_auto_anon_out_1_a_bits_size;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__ftq__DOT___GEN_39) {
        if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__ftq__DOT___GEN_8) {
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__ftq__DOT__ram_0_br_mask 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__ftq__DOT__new_entry_br_mask;
        }
    } else {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__ftq__DOT__ram_0_br_mask 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__ftq__DOT__ram_REG_br_mask;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__ftq__DOT___GEN_40) {
        if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__ftq__DOT___GEN_9) {
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__ftq__DOT__ram_1_br_mask 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__ftq__DOT__new_entry_br_mask;
        }
    } else {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__ftq__DOT__ram_1_br_mask 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__ftq__DOT__ram_REG_br_mask;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__ftq__DOT___GEN_41) {
        if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__ftq__DOT___GEN_10) {
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__ftq__DOT__ram_2_br_mask 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__ftq__DOT__new_entry_br_mask;
        }
    } else {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__ftq__DOT__ram_2_br_mask 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__ftq__DOT__ram_REG_br_mask;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__ftq__DOT___GEN_42) {
        if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__ftq__DOT___GEN_11) {
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__ftq__DOT__ram_3_br_mask 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__ftq__DOT__new_entry_br_mask;
        }
    } else {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__ftq__DOT__ram_3_br_mask 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__ftq__DOT__ram_REG_br_mask;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__ftq__DOT___GEN_43) {
        if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__ftq__DOT___GEN_12) {
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__ftq__DOT__ram_4_br_mask 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__ftq__DOT__new_entry_br_mask;
        }
    } else {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__ftq__DOT__ram_4_br_mask 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__ftq__DOT__ram_REG_br_mask;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__ftq__DOT___GEN_44) {
        if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__ftq__DOT___GEN_13) {
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__ftq__DOT__ram_5_br_mask 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__ftq__DOT__new_entry_br_mask;
        }
    } else {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__ftq__DOT__ram_5_br_mask 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__ftq__DOT__ram_REG_br_mask;
    }
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__655(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__655\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__ftq__DOT___GEN_45) {
        if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__ftq__DOT___GEN_14) {
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__ftq__DOT__ram_6_br_mask 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__ftq__DOT__new_entry_br_mask;
        }
    } else {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__ftq__DOT__ram_6_br_mask 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__ftq__DOT__ram_REG_br_mask;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__ftq__DOT___GEN_46) {
        if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__ftq__DOT___GEN_15) {
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__ftq__DOT__ram_7_br_mask 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__ftq__DOT__new_entry_br_mask;
        }
    } else {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__ftq__DOT__ram_7_br_mask 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__ftq__DOT__ram_REG_br_mask;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__ftq__DOT___GEN_47) {
        if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__ftq__DOT___GEN_16) {
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__ftq__DOT__ram_8_br_mask 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__ftq__DOT__new_entry_br_mask;
        }
    } else {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__ftq__DOT__ram_8_br_mask 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__ftq__DOT__ram_REG_br_mask;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__ftq__DOT___GEN_48) {
        if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__ftq__DOT___GEN_17) {
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__ftq__DOT__ram_9_br_mask 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__ftq__DOT__new_entry_br_mask;
        }
    } else {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__ftq__DOT__ram_9_br_mask 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__ftq__DOT__ram_REG_br_mask;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__ftq__DOT___GEN_49) {
        if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__ftq__DOT___GEN_18) {
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__ftq__DOT__ram_10_br_mask 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__ftq__DOT__new_entry_br_mask;
        }
    } else {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__ftq__DOT__ram_10_br_mask 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__ftq__DOT__ram_REG_br_mask;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__ftq__DOT___GEN_50) {
        if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__ftq__DOT___GEN_19) {
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__ftq__DOT__ram_11_br_mask 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__ftq__DOT__new_entry_br_mask;
        }
    } else {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__ftq__DOT__ram_11_br_mask 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__ftq__DOT__ram_REG_br_mask;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__ftq__DOT___GEN_51) {
        if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__ftq__DOT___GEN_20) {
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__ftq__DOT__ram_12_br_mask 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__ftq__DOT__new_entry_br_mask;
        }
    } else {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__ftq__DOT__ram_12_br_mask 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__ftq__DOT__ram_REG_br_mask;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__ftq__DOT___GEN_52) {
        if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__ftq__DOT___GEN_21) {
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__ftq__DOT__ram_13_br_mask 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__ftq__DOT__new_entry_br_mask;
        }
    } else {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__ftq__DOT__ram_13_br_mask 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__ftq__DOT__ram_REG_br_mask;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__ftq__DOT___GEN_53) {
        if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__ftq__DOT___GEN_22) {
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__ftq__DOT__ram_14_br_mask 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__ftq__DOT__new_entry_br_mask;
        }
    } else {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__ftq__DOT__ram_14_br_mask 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__ftq__DOT__ram_REG_br_mask;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__ftq__DOT___GEN_54) {
        if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__ftq__DOT___GEN_23) {
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__ftq__DOT__ram_15_br_mask 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__ftq__DOT__new_entry_br_mask;
        }
    } else {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__ftq__DOT__ram_15_br_mask 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__ftq__DOT__ram_REG_br_mask;
    }
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__656(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__656\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT____Vcellinp__mshrs_0__io_allocate_valid) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_0__DOT__request_param 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT____Vcellinp__mshrs_0__io_allocate_bits_param;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT____Vcellinp__mshrs_1__io_allocate_valid) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_1__DOT__request_param 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT____Vcellinp__mshrs_1__io_allocate_bits_param;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT____Vcellinp__mshrs_2__io_allocate_valid) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_2__DOT__request_param 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT____Vcellinp__mshrs_2__io_allocate_bits_param;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT____Vcellinp__mshrs_3__io_allocate_valid) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_3__DOT__request_param 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT____Vcellinp__mshrs_3__io_allocate_bits_param;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT____Vcellinp__mshrs_4__io_allocate_valid) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_4__DOT__request_param 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT____Vcellinp__mshrs_4__io_allocate_bits_param;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT____Vcellinp__mshrs_6__io_allocate_valid) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_6__DOT__request_param 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT____Vcellinp__mshrs_6__io_allocate_bits_param;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT____Vcellinp__mshrs_5__io_allocate_valid) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_5__DOT__request_param 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT____Vcellinp__mshrs_5__io_allocate_bits_param;
    }
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__mem_ldq_wakeup_e_bits_next_stq_idx 
        = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_267;
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__cbus__DOT__coupler_to_debug__DOT__fragmenter__DOT__repeater__DOT___GEN) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__cbus__DOT__coupler_to_debug__DOT__fragmenter__DOT__repeater__DOT__saved_address 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__cbus__DOT___out_xbar_auto_anon_out_5_a_bits_address;
    }
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3_bpd_queue_io_enq_valid_REG 
        = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___f3_io_enq_ready;
    if (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___csr_wen_T_4) 
         & (0xfffU == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___decoded_addr_decoded_decoded_andMatrixOutputs_T_16)))) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__reg_medeleg 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__wdata;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sourceD__DOT__s3_latch) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sourceD__DOT__s3_retires 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sourceD__DOT__s2_retires;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sourceD__DOT__s1_latch_bypass) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sourceD__DOT__s1_bypass_r 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sourceD__DOT__s1_x_bypass;
    }
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__block_commit_REG 
        = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__exception_thrown;
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__block_commit_REG_2 
        = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__block_commit_REG_1;
    if (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___csr_wen_T_4) 
         & (0xfffU == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___decoded_addr_decoded_decoded_andMatrixOutputs_T_9)))) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__reg_sepc 
            = (0xfffffffffeULL & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__wdata);
    } else if ((1U & (~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___GEN_39)))) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__reg_sepc 
            = (0xfffffffffeULL & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT____Vcellinp__csr__io_pc);
    }
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__REG_11 
        = (0U != (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__logic_io_matches));
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_570) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__ldq_addr_is_uncacheable_1 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___ldq_addr_is_uncacheable_T_1;
    }
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__657(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__657\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_569) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__ldq_addr_is_uncacheable_0 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___ldq_addr_is_uncacheable_T_1;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_572) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__ldq_addr_is_uncacheable_3 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___ldq_addr_is_uncacheable_T_1;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_573) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__ldq_addr_is_uncacheable_4 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___ldq_addr_is_uncacheable_T_1;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_571) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__ldq_addr_is_uncacheable_2 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___ldq_addr_is_uncacheable_T_1;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_576) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__ldq_addr_is_uncacheable_7 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___ldq_addr_is_uncacheable_T_1;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_574) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__ldq_addr_is_uncacheable_5 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___ldq_addr_is_uncacheable_T_1;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_575) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__ldq_addr_is_uncacheable_6 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___ldq_addr_is_uncacheable_T_1;
    }
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__can_fire_load_wakeup_REG 
        = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__store_needs_order;
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__issue_slots_4_in_uop_valid) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__slots_4__DOT__slot_uop_prs2_busy 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT___slots_5_io_out_uop_prs2_busy;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__slots_4__DOT__slot_uop_iw_issued 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT___slots_5_io_out_uop_iw_issued;
    } else {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__slots_4__DOT__slot_uop_prs2_busy 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT___slots_4_io_out_uop_prs2_busy;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__slots_4__DOT__slot_uop_iw_issued 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT___slots_4_io_out_uop_iw_issued;
    }
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__mem_ldq_retry_e_bits_next_stq_idx 
        = (0xfU & (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_138 
                   >> (0x1fU & VL_SHIFTL_III(5,32,32, 
                                             (7U & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___retry_queue_io_deq_bits_uop_ldq_idx)), 2U))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_exe_unit_0__DOT__rrd_uop_bits_prs1 
        = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_exe_unit_0__DOT__arb_uop_bits_prs1;
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rename_stage__DOT__busytable__DOT__wakeups_wu_valid_REG_4 
        = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___alu_exe_unit_0_io_fast_wakeup_valid;
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__alu_exe_unit_0__DOT__exe_uop_bits_dst_rtype 
        = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__alu_exe_unit_0__DOT__rrd_uop_bits_dst_rtype;
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__io_com_load_is_at_rob_head_REG 
        = (1U & ((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___rob_compact_uop_bypassed_WIRE 
                  >> 0x15U) & (~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___rob_io_commit_valids_0))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_compact_uop_bypassed_REG_1 
        = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT___core_io_lsu_dis_uops_0_valid;
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__slots_6__DOT__slot_uop_prs1_busy 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__issue_slots_6_in_uop_valid)
            ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT___slots_7_io_out_uop_prs1_busy)
            : (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT___slots_6_io_out_uop_prs1_busy));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_compact_uop_bypassed_r_3 
        = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_compact_uop_bypassed_r_2;
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__issue_slots_3_in_uop_valid) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__slots_3__DOT__slot_uop_prs2_busy 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT___slots_4_io_out_uop_prs2_busy;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__slots_3__DOT__slot_uop_iw_issued 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT___slots_4_io_out_uop_iw_issued;
    } else {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__slots_3__DOT__slot_uop_prs2_busy 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT___slots_3_io_out_uop_prs2_busy;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__slots_3__DOT__slot_uop_iw_issued 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT___slots_3_io_out_uop_iw_issued;
    }
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__658(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__658\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT____Vcellinp__mshrs_0__io_allocate_valid) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_0__DOT__request_opcode 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT____Vcellinp__mshrs_0__io_allocate_bits_opcode;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT____Vcellinp__mshrs_1__io_allocate_valid) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_1__DOT__request_opcode 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT____Vcellinp__mshrs_1__io_allocate_bits_opcode;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT____Vcellinp__mshrs_2__io_allocate_valid) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_2__DOT__request_opcode 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT____Vcellinp__mshrs_2__io_allocate_bits_opcode;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT____Vcellinp__mshrs_3__io_allocate_valid) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_3__DOT__request_opcode 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT____Vcellinp__mshrs_3__io_allocate_bits_opcode;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT____Vcellinp__mshrs_4__io_allocate_valid) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_4__DOT__request_opcode 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT____Vcellinp__mshrs_4__io_allocate_bits_opcode;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT____Vcellinp__mshrs_6__io_allocate_valid) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_6__DOT__request_opcode 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT____Vcellinp__mshrs_6__io_allocate_bits_opcode;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT____Vcellinp__mshrs_5__io_allocate_valid) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_5__DOT__request_opcode 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT____Vcellinp__mshrs_5__io_allocate_bits_opcode;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__issue_slots_0_in_uop_valid) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__slots_0__DOT__slot_uop_lrs1_rtype 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__slots_1__DOT__slot_uop_lrs1_rtype;
    }
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__s3_req_REG_uop_mem_size 
        = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__s2_req_0_uop_mem_size;
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT___system_auto_cbus_fixedClockNode_anon_out_reset) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__serial_tl_domain__DOT__phy__DOT__out_phits_out_async_io_enq_q__DOT__enq_ptr_value = 0U;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__serial_tl_domain__DOT__phy__DOT__out_phits_out_async_io_enq_q_2__DOT__enq_ptr_value = 0U;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__serial_tl_domain__DOT__phy__DOT__out_phits_out_async_io_enq_q_4__DOT__enq_ptr_value = 0U;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__buffer__DOT__nodeIn_b_q__DOT__maybe_full = 0U;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__buffer__DOT__nodeOut_e_q__DOT__maybe_full = 0U;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f4_btb_corrections__DOT__maybe_full = 0U;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__serial_tl_domain__DOT__phy__DOT__out_phits_out_async_io_enq_q__DOT__maybe_full = 0U;
    } else {
        if (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__buffer__DOT__nodeIn_b_q__DOT__do_enq) 
             != (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__buffer__DOT__nodeIn_b_q__DOT__do_deq))) {
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__buffer__DOT__nodeIn_b_q__DOT__maybe_full 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__buffer__DOT__nodeIn_b_q__DOT__do_enq;
        }
        if (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__buffer__DOT__nodeOut_e_q__DOT__do_enq) 
             != (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT___InclusiveCache_inner_TLBuffer_auto_out_e_valid))) {
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__buffer__DOT__nodeOut_e_q__DOT__maybe_full 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__buffer__DOT__nodeOut_e_q__DOT__do_enq;
        }
        if (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f4_btb_corrections__DOT__do_enq) 
             != (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f4_btb_corrections__DOT__do_deq))) {
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f4_btb_corrections__DOT__maybe_full 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f4_btb_corrections__DOT__do_enq;
        }
        if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__serial_tl_domain__DOT__phy__DOT__out_phits_out_async__DOT__source__DOT___widx_T_1) {
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__serial_tl_domain__DOT__phy__DOT__out_phits_out_async_io_enq_q__DOT__maybe_full = 0U;
        }
    }
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__659(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__659\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT___system_auto_cbus_fixedClockNode_anon_out_reset) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__serial_tl_domain__DOT__phy__DOT__out_phits_out_async_io_enq_q_2__DOT__maybe_full = 0U;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__serial_tl_domain__DOT__phy__DOT__out_phits_out_async_io_enq_q_4__DOT__maybe_full = 0U;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__buffer__DOT__nodeOut_c_q__DOT__maybe_full = 0U;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__buffer__DOT__nodeOut_e_q__DOT__maybe_full = 0U;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__buffer__DOT__nodeOut_c_q__DOT__maybe_full = 0U;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__buffer__DOT__nodeIn_b_q__DOT__maybe_full = 0U;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__buffer__DOT__nodeIn_d_q__DOT__maybe_full = 0U;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__buffer_1__DOT__nodeOut_e_q__DOT__maybe_full = 0U;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__serial_tl_domain__DOT__phy__DOT__out_phits_out_async_io_enq_q_3__DOT__maybe_full = 0U;
    } else {
        if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__serial_tl_domain__DOT__phy__DOT__out_phits_out_async_2__DOT__source__DOT___widx_T_1) {
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__serial_tl_domain__DOT__phy__DOT__out_phits_out_async_io_enq_q_2__DOT__maybe_full = 0U;
        }
        if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__serial_tl_domain__DOT__phy__DOT__out_phits_out_async_4__DOT__source__DOT___widx_T_1) {
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__serial_tl_domain__DOT__phy__DOT__out_phits_out_async_io_enq_q_4__DOT__maybe_full = 0U;
        }
        if (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__buffer__DOT__nodeOut_c_q__DOT__do_enq) 
             != (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__buffer__DOT__nodeOut_c_q__DOT__do_deq))) {
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__buffer__DOT__nodeOut_c_q__DOT__maybe_full 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__buffer__DOT__nodeOut_c_q__DOT__do_enq;
        }
        if (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__buffer__DOT__nodeOut_e_q__DOT__do_enq) 
             != (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__buffer__DOT__nodeOut_e_q__DOT__do_deq))) {
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__buffer__DOT__nodeOut_e_q__DOT__maybe_full 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__buffer__DOT__nodeOut_e_q__DOT__do_enq;
        }
        if (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__buffer__DOT__nodeOut_c_q__DOT__do_enq) 
             != (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__buffer__DOT__nodeOut_c_q__DOT__do_deq))) {
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__buffer__DOT__nodeOut_c_q__DOT__maybe_full 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__buffer__DOT__nodeOut_c_q__DOT__do_enq;
        }
        if (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__buffer__DOT__nodeIn_b_q__DOT__do_enq) 
             != (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__buffer__DOT__nodeIn_b_q__DOT__do_deq))) {
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__buffer__DOT__nodeIn_b_q__DOT__maybe_full 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__buffer__DOT__nodeIn_b_q__DOT__do_enq;
        }
        if (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__buffer__DOT__nodeIn_d_q__DOT__do_enq) 
             != (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__buffer__DOT__nodeIn_d_q__DOT__do_deq))) {
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__buffer__DOT__nodeIn_d_q__DOT__maybe_full 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__buffer__DOT__nodeIn_d_q__DOT__do_enq;
        }
        if (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__buffer_1__DOT__nodeOut_e_q__DOT__do_enq) 
             != (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__buffer_1__DOT__nodeOut_e_q__DOT__do_deq))) {
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__buffer_1__DOT__nodeOut_e_q__DOT__maybe_full 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__buffer_1__DOT__nodeOut_e_q__DOT__do_enq;
        }
        if (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__serial_tl_domain__DOT__phy__DOT__out_phits_out_async_io_enq_q_3__DOT__do_enq) 
             != (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__serial_tl_domain__DOT__phy__DOT__out_phits_out_async_3__DOT__source__DOT___widx_T_1))) {
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__serial_tl_domain__DOT__phy__DOT__out_phits_out_async_io_enq_q_3__DOT__maybe_full 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__serial_tl_domain__DOT__phy__DOT__out_phits_out_async_io_enq_q_3__DOT__do_enq;
        }
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__issue_slots_0_in_uop_valid) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__slots_0__DOT__slot_uop_lrs2_rtype 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__slots_1__DOT__slot_uop_lrs2_rtype;
    }
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__660(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__660\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT___system_auto_cbus_fixedClockNode_anon_out_reset) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__buffer__DOT__nodeOut_a_q__DOT__maybe_full = 0U;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__cbus__DOT__wrapped_error_device__DOT__buffer__DOT__nodeOut_a_q__DOT__maybe_full = 0U;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__fbus__DOT__coupler_from_port_named_serial_tl_0_in__DOT__buffer__DOT__nodeIn_d_q__DOT__maybe_full = 0U;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__mbus__DOT__buffer_1__DOT__nodeOut_a_q__DOT__maybe_full = 0U;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__buffer_1__DOT__nodeIn_b_q__DOT__maybe_full = 0U;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__buffer__DOT__nodeIn_d_q__DOT__maybe_full = 0U;
    } else {
        if (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__buffer__DOT__nodeOut_a_q__DOT__do_enq) 
             != (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__buffer__DOT__nodeOut_a_q__DOT__do_deq))) {
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__buffer__DOT__nodeOut_a_q__DOT__maybe_full 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__buffer__DOT__nodeOut_a_q__DOT__do_enq;
        }
        if (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__cbus__DOT__wrapped_error_device__DOT__buffer__DOT__nodeOut_a_q__DOT__do_enq) 
             != (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__cbus__DOT__wrapped_error_device__DOT__buffer__DOT__nodeOut_a_q__DOT__do_deq))) {
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__cbus__DOT__wrapped_error_device__DOT__buffer__DOT__nodeOut_a_q__DOT__maybe_full 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__cbus__DOT__wrapped_error_device__DOT__buffer__DOT__nodeOut_a_q__DOT__do_enq;
        }
        if (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__fbus__DOT__coupler_from_port_named_serial_tl_0_in__DOT__buffer__DOT__nodeIn_d_q__DOT__do_enq) 
             != (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__fbus__DOT__coupler_from_port_named_serial_tl_0_in__DOT__buffer__DOT__nodeIn_d_q__DOT__do_deq))) {
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__fbus__DOT__coupler_from_port_named_serial_tl_0_in__DOT__buffer__DOT__nodeIn_d_q__DOT__maybe_full 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__fbus__DOT__coupler_from_port_named_serial_tl_0_in__DOT__buffer__DOT__nodeIn_d_q__DOT__do_enq;
        }
        if (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__mbus__DOT__buffer_1__DOT__nodeOut_a_q__DOT__do_enq) 
             != (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__mbus__DOT__buffer_1__DOT__nodeOut_a_q__DOT__do_deq))) {
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__mbus__DOT__buffer_1__DOT__nodeOut_a_q__DOT__maybe_full 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__mbus__DOT__buffer_1__DOT__nodeOut_a_q__DOT__do_enq;
        }
        if (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__buffer_1__DOT__nodeIn_b_q__DOT__do_enq) 
             != (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__buffer_1__DOT__nodeIn_b_q__DOT__do_deq))) {
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__buffer_1__DOT__nodeIn_b_q__DOT__maybe_full 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__buffer_1__DOT__nodeIn_b_q__DOT__do_enq;
        }
        if (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__buffer__DOT__nodeIn_d_q__DOT__do_enq) 
             != (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__buffer__DOT__nodeIn_d_q__DOT__do_deq))) {
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__buffer__DOT__nodeIn_d_q__DOT__maybe_full 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__buffer__DOT__nodeIn_d_q__DOT__do_enq;
        }
    }
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__ftq__DOT__io_com_pc_REG 
        = ((0x27fU >= (0x3ffU & ((IData)(0x28U) * ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT___core_io_ifu_commit_valid)
                                                    ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT____Vcellinp__ftq__io_deq_bits)
                                                    : (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__ftq__DOT__deq_ptr)))))
            ? (0xffffffffffULL & (((QData)((IData)(
                                                   vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__ftq__DOT___GEN_30[
                                                   (((IData)(0x27U) 
                                                     + 
                                                     (0x3ffU 
                                                      & ((IData)(0x28U) 
                                                         * 
                                                         ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT___core_io_ifu_commit_valid)
                                                           ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT____Vcellinp__ftq__io_deq_bits)
                                                           : (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__ftq__DOT__deq_ptr))))) 
                                                    >> 5U)])) 
                                   << ((0U == (0x1fU 
                                               & ((IData)(0x28U) 
                                                  * 
                                                  ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT___core_io_ifu_commit_valid)
                                                    ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT____Vcellinp__ftq__io_deq_bits)
                                                    : (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__ftq__DOT__deq_ptr)))))
                                        ? 0x20U : ((IData)(0x40U) 
                                                   - 
                                                   (0x1fU 
                                                    & ((IData)(0x28U) 
                                                       * 
                                                       ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT___core_io_ifu_commit_valid)
                                                         ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT____Vcellinp__ftq__io_deq_bits)
                                                         : (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__ftq__DOT__deq_ptr))))))) 
                                  | (((0U == (0x1fU 
                                              & ((IData)(0x28U) 
                                                 * 
                                                 ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT___core_io_ifu_commit_valid)
                                                   ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT____Vcellinp__ftq__io_deq_bits)
                                                   : (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__ftq__DOT__deq_ptr)))))
                                       ? 0ULL : ((QData)((IData)(
                                                                 vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__ftq__DOT___GEN_30[
                                                                 (((IData)(0x1fU) 
                                                                   + 
                                                                   (0x3ffU 
                                                                    & ((IData)(0x28U) 
                                                                       * 
                                                                       ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT___core_io_ifu_commit_valid)
                                                                         ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT____Vcellinp__ftq__io_deq_bits)
                                                                         : (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__ftq__DOT__deq_ptr))))) 
                                                                  >> 5U)])) 
                                                 << 
                                                 ((IData)(0x20U) 
                                                  - 
                                                  (0x1fU 
                                                   & ((IData)(0x28U) 
                                                      * 
                                                      ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT___core_io_ifu_commit_valid)
                                                        ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT____Vcellinp__ftq__io_deq_bits)
                                                        : (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__ftq__DOT__deq_ptr))))))) 
                                     | ((QData)((IData)(
                                                        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__ftq__DOT___GEN_30[
                                                        (0x1fU 
                                                         & (((IData)(0x28U) 
                                                             * 
                                                             ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT___core_io_ifu_commit_valid)
                                                               ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT____Vcellinp__ftq__io_deq_bits)
                                                               : (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__ftq__DOT__deq_ptr))) 
                                                            >> 5U))])) 
                                        >> (0x1fU & 
                                            ((IData)(0x28U) 
                                             * ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT___core_io_ifu_commit_valid)
                                                 ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT____Vcellinp__ftq__io_deq_bits)
                                                 : (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__ftq__DOT__deq_ptr))))))))
            : 0ULL);
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__ldq_succeeded_7 
        = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__ldq_will_succeed_7;
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__661(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__661\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT___system_auto_cbus_fixedClockNode_anon_out_reset) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__serial_tl_domain__DOT__phy__DOT__in_phits_io_inner_ser_0_in_q__DOT__maybe_full = 0U;
    } else if (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__serial_tl_domain__DOT__phy__DOT__in_phits_io_inner_ser_0_in_q__DOT__do_enq) 
                != (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__serial_tl_domain__DOT__phy__DOT__in_phits_io_inner_ser_0_in_q__DOT__do_deq))) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__serial_tl_domain__DOT__phy__DOT__in_phits_io_inner_ser_0_in_q__DOT__maybe_full 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__serial_tl_domain__DOT__phy__DOT__in_phits_io_inner_ser_0_in_q__DOT__do_enq;
    }
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__pred_rename_stage__DOT__busy_table_13 
        = ((1U & (~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT___system_auto_cbus_fixedClockNode_anon_out_reset))) 
           && (1U & (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__pred_rename_stage__DOT___GEN_22) 
                      & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__pred_rename_stage__DOT___GEN_19)) 
                     >> 0xdU)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__pred_rename_stage__DOT__busy_table_10 
        = ((1U & (~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT___system_auto_cbus_fixedClockNode_anon_out_reset))) 
           && (1U & (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__pred_rename_stage__DOT___GEN_22) 
                      & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__pred_rename_stage__DOT___GEN_19)) 
                     >> 0xaU)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__pred_rename_stage__DOT__busy_table_6 
        = ((1U & (~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT___system_auto_cbus_fixedClockNode_anon_out_reset))) 
           && (1U & (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__pred_rename_stage__DOT___GEN_22) 
                      & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__pred_rename_stage__DOT___GEN_19)) 
                     >> 6U)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__pred_rename_stage__DOT__busy_table_15 
        = ((1U & (~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT___system_auto_cbus_fixedClockNode_anon_out_reset))) 
           && (1U & (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__pred_rename_stage__DOT___GEN_22) 
                      & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__pred_rename_stage__DOT___GEN_19)) 
                     >> 0xfU)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__pred_rename_stage__DOT__busy_table_4 
        = ((1U & (~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT___system_auto_cbus_fixedClockNode_anon_out_reset))) 
           && (1U & (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__pred_rename_stage__DOT___GEN_22) 
                      & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__pred_rename_stage__DOT___GEN_19)) 
                     >> 4U)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__pred_rename_stage__DOT__busy_table_14 
        = ((1U & (~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT___system_auto_cbus_fixedClockNode_anon_out_reset))) 
           && (1U & (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__pred_rename_stage__DOT___GEN_22) 
                      & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__pred_rename_stage__DOT___GEN_19)) 
                     >> 0xeU)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__pred_rename_stage__DOT__busy_table_12 
        = ((1U & (~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT___system_auto_cbus_fixedClockNode_anon_out_reset))) 
           && (1U & (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__pred_rename_stage__DOT___GEN_22) 
                      & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__pred_rename_stage__DOT___GEN_19)) 
                     >> 0xcU)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__pred_rename_stage__DOT__busy_table_11 
        = ((1U & (~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT___system_auto_cbus_fixedClockNode_anon_out_reset))) 
           && (1U & (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__pred_rename_stage__DOT___GEN_22) 
                      & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__pred_rename_stage__DOT___GEN_19)) 
                     >> 0xbU)));
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__662(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__662\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__pred_rename_stage__DOT__busy_table_8 
        = ((1U & (~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT___system_auto_cbus_fixedClockNode_anon_out_reset))) 
           && (1U & (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__pred_rename_stage__DOT___GEN_22) 
                      & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__pred_rename_stage__DOT___GEN_19)) 
                     >> 8U)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__pred_rename_stage__DOT__busy_table_3 
        = ((1U & (~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT___system_auto_cbus_fixedClockNode_anon_out_reset))) 
           && (1U & (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__pred_rename_stage__DOT___GEN_22) 
                      & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__pred_rename_stage__DOT___GEN_19)) 
                     >> 3U)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__pred_rename_stage__DOT__busy_table_0 
        = ((1U & (~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT___system_auto_cbus_fixedClockNode_anon_out_reset))) 
           && (1U & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__pred_rename_stage__DOT___GEN_22) 
                     & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__pred_rename_stage__DOT___GEN_19))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__pred_rename_stage__DOT__busy_table_1 
        = ((1U & (~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT___system_auto_cbus_fixedClockNode_anon_out_reset))) 
           && (1U & (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__pred_rename_stage__DOT___GEN_22) 
                      & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__pred_rename_stage__DOT___GEN_19)) 
                     >> 1U)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__pred_rename_stage__DOT__busy_table_2 
        = ((1U & (~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT___system_auto_cbus_fixedClockNode_anon_out_reset))) 
           && (1U & (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__pred_rename_stage__DOT___GEN_22) 
                      & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__pred_rename_stage__DOT___GEN_19)) 
                     >> 2U)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__pred_rename_stage__DOT__busy_table_5 
        = ((1U & (~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT___system_auto_cbus_fixedClockNode_anon_out_reset))) 
           && (1U & (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__pred_rename_stage__DOT___GEN_22) 
                      & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__pred_rename_stage__DOT___GEN_19)) 
                     >> 5U)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__pred_rename_stage__DOT__busy_table_7 
        = ((1U & (~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT___system_auto_cbus_fixedClockNode_anon_out_reset))) 
           && (1U & (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__pred_rename_stage__DOT___GEN_22) 
                      & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__pred_rename_stage__DOT___GEN_19)) 
                     >> 7U)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__pred_rename_stage__DOT__busy_table_9 
        = ((1U & (~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT___system_auto_cbus_fixedClockNode_anon_out_reset))) 
           && (1U & (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__pred_rename_stage__DOT___GEN_22) 
                      & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__pred_rename_stage__DOT___GEN_19)) 
                     >> 9U)));
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT___system_auto_cbus_fixedClockNode_anon_out_reset) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__serial_tl_domain__DOT__phy__DOT__out_phits_out_async_io_enq_q_1__DOT__maybe_full = 0U;
    } else if (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__serial_tl_domain__DOT__serdesser__DOT__ser_1__DOT___GEN_2) 
                != (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__serial_tl_domain__DOT__phy__DOT__out_phits_out_async_1__DOT__source__DOT___widx_T_1))) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__serial_tl_domain__DOT__phy__DOT__out_phits_out_async_io_enq_q_1__DOT__maybe_full 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__serial_tl_domain__DOT__serdesser__DOT__ser_1__DOT___GEN_2;
    }
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__663(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__663\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT___system_auto_cbus_fixedClockNode_anon_out_reset) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__sbus__DOT__system_bus_xbar__DOT__state_2_1 = 0U;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__sbus__DOT__system_bus_xbar__DOT__state_3_1 = 0U;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tlDM__DOT__dmInner__DOT__dmInner__DOT__sb2tlOpt__DOT__d_q__DOT__maybe_full = 0U;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__serial_tl_domain__DOT__phy__DOT__in_phits_io_inner_ser_1_in_q__DOT__maybe_full = 0U;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__serial_tl_domain__DOT__phy__DOT__in_phits_io_inner_ser_2_in_q__DOT__maybe_full = 0U;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__serial_tl_domain__DOT__phy__DOT__in_phits_io_inner_ser_3_in_q__DOT__maybe_full = 0U;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__buffer_1__DOT__nodeOut_c_q__DOT__maybe_full = 0U;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__bank__DOT__buffer__DOT__nodeOut_a_q__DOT__maybe_full = 0U;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__sbus__DOT__system_bus_xbar__DOT__state_2_0 = 0U;
    } else {
        if ((0U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__sbus__DOT__system_bus_xbar__DOT__beatsLeft_2))) {
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__sbus__DOT__system_bus_xbar__DOT__state_2_1 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__sbus__DOT__system_bus_xbar__DOT__winner_2_1;
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__sbus__DOT__system_bus_xbar__DOT__state_2_0 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__sbus__DOT__system_bus_xbar__DOT__winner_2_0;
        }
        if ((0U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__sbus__DOT__system_bus_xbar__DOT__beatsLeft_3))) {
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__sbus__DOT__system_bus_xbar__DOT__state_3_1 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__sbus__DOT__system_bus_xbar__DOT__winner_3_1;
        }
        if (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tlDM__DOT__dmInner__DOT__dmInner__DOT__sb2tlOpt__DOT__d_q__DOT__do_enq) 
             != (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tlDM__DOT__dmInner__DOT__dmInner__DOT__sb2tlOpt__DOT__d_q__DOT__do_deq))) {
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tlDM__DOT__dmInner__DOT__dmInner__DOT__sb2tlOpt__DOT__d_q__DOT__maybe_full 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tlDM__DOT__dmInner__DOT__dmInner__DOT__sb2tlOpt__DOT__d_q__DOT__do_enq;
        }
        if (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__serial_tl_domain__DOT__phy__DOT__in_phits_io_inner_ser_1_in_q__DOT__do_enq) 
             != (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__serial_tl_domain__DOT__serdesser__DOT__des_1__DOT___GEN))) {
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__serial_tl_domain__DOT__phy__DOT__in_phits_io_inner_ser_1_in_q__DOT__maybe_full 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__serial_tl_domain__DOT__phy__DOT__in_phits_io_inner_ser_1_in_q__DOT__do_enq;
        }
        if (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__serial_tl_domain__DOT__phy__DOT__in_phits_io_inner_ser_2_in_q__DOT__do_enq) 
             != (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__serial_tl_domain__DOT__serdesser__DOT__des_2__DOT___GEN))) {
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__serial_tl_domain__DOT__phy__DOT__in_phits_io_inner_ser_2_in_q__DOT__maybe_full 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__serial_tl_domain__DOT__phy__DOT__in_phits_io_inner_ser_2_in_q__DOT__do_enq;
        }
        if (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__serial_tl_domain__DOT__phy__DOT__in_phits_io_inner_ser_3_in_q__DOT__do_enq) 
             != (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__serial_tl_domain__DOT__serdesser__DOT__des_3__DOT___GEN))) {
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__serial_tl_domain__DOT__phy__DOT__in_phits_io_inner_ser_3_in_q__DOT__maybe_full 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__serial_tl_domain__DOT__phy__DOT__in_phits_io_inner_ser_3_in_q__DOT__do_enq;
        }
        if (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT___io_lsu_perf_release_T) 
             != (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__buffer_1__DOT__nodeOut_c_q__DOT__do_deq))) {
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__buffer_1__DOT__nodeOut_c_q__DOT__maybe_full 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT___io_lsu_perf_release_T;
        }
        if (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__bank__DOT__buffer__DOT__nodeOut_a_q__DOT__do_enq) 
             != (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__bank__DOT__buffer__DOT__nodeOut_a_q__DOT__do_deq))) {
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__bank__DOT__buffer__DOT__nodeOut_a_q__DOT__maybe_full 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__bank__DOT__buffer__DOT__nodeOut_a_q__DOT__do_enq;
        }
    }
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__664(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__664\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT___system_auto_cbus_fixedClockNode_anon_out_reset) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__sbus__DOT__system_bus_xbar__DOT__state_3_0 = 0U;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__buffer_1__DOT__nodeIn_d_q__DOT__maybe_full = 0U;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__tlMasterXbar__DOT__state_0 = 0U;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__tlMasterXbar__DOT__state_1 = 0U;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__fbus__DOT__buffer__DOT__nodeIn_d_q__DOT__maybe_full = 0U;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__serial_tl_domain__DOT__phy__DOT__in_phits_io_inner_ser_4_in_q__DOT__maybe_full = 0U;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__pbus__DOT__buffer__DOT__nodeOut_a_q__DOT__maybe_full = 0U;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__pbus__DOT__buffer__DOT__nodeIn_d_q__DOT__maybe_full = 0U;
    } else {
        if ((0U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__sbus__DOT__system_bus_xbar__DOT__beatsLeft_3))) {
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__sbus__DOT__system_bus_xbar__DOT__state_3_0 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__sbus__DOT__system_bus_xbar__DOT__winner_3_0;
        }
        if (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__buffer_1__DOT__nodeIn_d_q__DOT__do_enq) 
             != (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__buffer_1__DOT__nodeIn_d_q__DOT__do_deq))) {
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__buffer_1__DOT__nodeIn_d_q__DOT__maybe_full 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__buffer_1__DOT__nodeIn_d_q__DOT__do_enq;
        }
        if ((0U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__tlMasterXbar__DOT__beatsLeft))) {
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__tlMasterXbar__DOT__state_0 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__tlMasterXbar__DOT__winner_0;
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__tlMasterXbar__DOT__state_1 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__tlMasterXbar__DOT__winner_1;
        }
        if (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__fbus__DOT__buffer__DOT__nodeIn_d_q__DOT__do_enq) 
             != (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__fbus__DOT__buffer__DOT__nodeIn_d_q__DOT__do_deq))) {
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__fbus__DOT__buffer__DOT__nodeIn_d_q__DOT__maybe_full 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__fbus__DOT__buffer__DOT__nodeIn_d_q__DOT__do_enq;
        }
        if (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__serial_tl_domain__DOT__phy__DOT__in_phits_io_inner_ser_4_in_q__DOT__do_enq) 
             != (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__serial_tl_domain__DOT__serdesser__DOT__des_4__DOT___GEN))) {
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__serial_tl_domain__DOT__phy__DOT__in_phits_io_inner_ser_4_in_q__DOT__maybe_full 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__serial_tl_domain__DOT__phy__DOT__in_phits_io_inner_ser_4_in_q__DOT__do_enq;
        }
        if (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__pbus__DOT__buffer__DOT__nodeOut_a_q__DOT__do_enq) 
             != (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__pbus__DOT__buffer__DOT__nodeOut_a_q__DOT__do_deq))) {
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__pbus__DOT__buffer__DOT__nodeOut_a_q__DOT__maybe_full 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__pbus__DOT__buffer__DOT__nodeOut_a_q__DOT__do_enq;
        }
        if (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__pbus__DOT__buffer__DOT__nodeIn_d_q__DOT__do_enq) 
             != (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__pbus__DOT__buffer__DOT__nodeIn_d_q__DOT__do_deq))) {
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__pbus__DOT__buffer__DOT__nodeIn_d_q__DOT__maybe_full 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__pbus__DOT__buffer__DOT__nodeIn_d_q__DOT__do_enq;
        }
    }
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__ldq_succeeded_0 
        = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__ldq_will_succeed_0;
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__665(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__665\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT___system_auto_cbus_fixedClockNode_anon_out_reset) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__chipyard_prcictrl_domain__DOT__xbar__DOT__state_0 = 0U;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__chipyard_prcictrl_domain__DOT__xbar__DOT__state_1 = 0U;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__bank__DOT__buffer__DOT__nodeIn_d_q__DOT__maybe_full = 0U;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__buffer_2__DOT__nodeIn_d_q__DOT__maybe_full = 0U;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__fbus__DOT__fbus_xbar__DOT__state_1 = 0U;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__pbus__DOT__buffer_1__DOT__nodeOut_a_q__DOT__maybe_full = 0U;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__state_1 = 0U;
    } else {
        if ((0U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__chipyard_prcictrl_domain__DOT__xbar__DOT__beatsLeft))) {
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__chipyard_prcictrl_domain__DOT__xbar__DOT__state_0 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__chipyard_prcictrl_domain__DOT__xbar__DOT__winner_0;
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__chipyard_prcictrl_domain__DOT__xbar__DOT__state_1 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__chipyard_prcictrl_domain__DOT__xbar__DOT__winner_1;
        }
        if (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__bank__DOT__buffer__DOT__nodeIn_d_q__DOT__do_enq) 
             != (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__bank__DOT__buffer__DOT__nodeIn_d_q__DOT__do_deq))) {
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__bank__DOT__buffer__DOT__nodeIn_d_q__DOT__maybe_full 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__bank__DOT__buffer__DOT__nodeIn_d_q__DOT__do_enq;
        }
        if (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__buffer_2__DOT__nodeIn_d_q__DOT__do_enq) 
             != (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT___buffer_2_auto_in_d_valid))) {
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__buffer_2__DOT__nodeIn_d_q__DOT__maybe_full 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__buffer_2__DOT__nodeIn_d_q__DOT__do_enq;
        }
        if ((0U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__fbus__DOT__fbus_xbar__DOT__beatsLeft))) {
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__fbus__DOT__fbus_xbar__DOT__state_1 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__fbus__DOT__fbus_xbar__DOT__winner_1;
        }
        if (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__pbus__DOT__buffer_1__DOT__nodeOut_a_q__DOT__do_enq) 
             != (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__pbus__DOT__buffer_1__DOT__nodeOut_a_q__DOT__do_deq))) {
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__pbus__DOT__buffer_1__DOT__nodeOut_a_q__DOT__maybe_full 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__pbus__DOT__buffer_1__DOT__nodeOut_a_q__DOT__do_enq;
        }
        if ((0U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__beatsLeft))) {
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__state_1 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__winner_1;
        }
    }
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__ldq_succeeded_6 
        = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__ldq_will_succeed_6;
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__ldq_succeeded_5 
        = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__ldq_will_succeed_5;
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__ldq_succeeded_4 
        = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__ldq_will_succeed_4;
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__ldq_succeeded_2 
        = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__ldq_will_succeed_2;
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__ldq_succeeded_3 
        = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__ldq_will_succeed_3;
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__ldq_succeeded_1 
        = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__ldq_will_succeed_1;
}

extern const VlUnpacked<CData/*2:0*/, 128> VTestDriver__ConstPool__TABLE_h1127d7aa_0;
extern const VlUnpacked<CData/*1:0*/, 128> VTestDriver__ConstPool__TABLE_h57b64589_0;
extern const VlUnpacked<CData/*1:0*/, 128> VTestDriver__ConstPool__TABLE_h72df3708_0;
extern const VlUnpacked<CData/*0:0*/, 128> VTestDriver__ConstPool__TABLE_hd9cc75c2_0;

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__666(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__666\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Init
    CData/*6:0*/ __Vtableidx1;
    __Vtableidx1 = 0;
    // Body
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT___system_auto_cbus_fixedClockNode_anon_out_reset) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__buffer_1__DOT__nodeOut_a_q__DOT__maybe_full = 0U;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__fbus__DOT__fbus_xbar__DOT__state_0 = 0U;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__tlMasterXbar__DOT__readys_mask = 3U;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__state_0 = 0U;
    } else {
        if (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT___io_lsu_perf_acquire_T) 
             != (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__buffer_1__DOT__nodeOut_a_q__DOT__do_deq))) {
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__buffer_1__DOT__nodeOut_a_q__DOT__maybe_full 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT___io_lsu_perf_acquire_T;
        }
        if ((0U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__fbus__DOT__fbus_xbar__DOT__beatsLeft))) {
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__fbus__DOT__fbus_xbar__DOT__state_0 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__fbus__DOT__fbus_xbar__DOT__winner_0;
        }
        if (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__tlMasterXbar__DOT__latch) 
             & (0U != (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__tlMasterXbar__DOT__readys_valid)))) {
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__tlMasterXbar__DOT__readys_mask 
                = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__tlMasterXbar__DOT___readys_mask_T) 
                   | (2U & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__tlMasterXbar__DOT___readys_mask_T) 
                            << 1U)));
        }
        if ((0U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__beatsLeft))) {
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__state_0 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT___wb_io_release_valid;
        }
    }
    __Vtableidx1 = ((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sourceD__DOT__queue__DOT__deq_ptr_value) 
                      << 5U) | (((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sourceD__DOT__queue__DOT__empty)) 
                                 & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sourceD__DOT____Vcellinp__queue__io_deq_ready) 
                                    & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sourceD__DOT___queue_io_deq_valid))) 
                                << 4U)) | (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sourceD__DOT__queue__DOT__enq_ptr_value) 
                                            << 2U) 
                                           | (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sourceD__DOT__queue__DOT__do_enq) 
                                               << 1U) 
                                              | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT___system_auto_cbus_fixedClockNode_anon_out_reset))));
    if ((1U & VTestDriver__ConstPool__TABLE_h1127d7aa_0
         [__Vtableidx1])) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sourceD__DOT__queue__DOT__enq_ptr_value 
            = VTestDriver__ConstPool__TABLE_h57b64589_0
            [__Vtableidx1];
    }
    if ((2U & VTestDriver__ConstPool__TABLE_h1127d7aa_0
         [__Vtableidx1])) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sourceD__DOT__queue__DOT__deq_ptr_value 
            = VTestDriver__ConstPool__TABLE_h72df3708_0
            [__Vtableidx1];
    }
    if ((4U & VTestDriver__ConstPool__TABLE_h1127d7aa_0
         [__Vtableidx1])) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sourceD__DOT__queue__DOT__maybe_full 
            = VTestDriver__ConstPool__TABLE_hd9cc75c2_0
            [__Vtableidx1];
    }
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__667(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__667\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT___system_auto_cbus_fixedClockNode_anon_out_reset) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__sbus__DOT__system_bus_xbar__DOT__readys_mask_2 = 3U;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__sbus__DOT__system_bus_xbar__DOT__readys_mask_3 = 3U;
        vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_0_1__DOT__wrbypass_enq_idx = 0U;
    } else {
        if (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__sbus__DOT__system_bus_xbar__DOT__latch_2) 
             & (0U != (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__sbus__DOT__system_bus_xbar__DOT__readys_valid_2)))) {
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__sbus__DOT__system_bus_xbar__DOT__readys_mask_2 
                = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__sbus__DOT__system_bus_xbar__DOT___readys_mask_T_10) 
                   | (2U & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__sbus__DOT__system_bus_xbar__DOT___readys_mask_T_10) 
                            << 1U)));
        }
        if (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__sbus__DOT__system_bus_xbar__DOT__latch_3) 
             & (0U != (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__sbus__DOT__system_bus_xbar__DOT__readys_valid_3)))) {
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__sbus__DOT__system_bus_xbar__DOT__readys_mask_3 
                = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__sbus__DOT__system_bus_xbar__DOT___readys_mask_T_15) 
                   | (2U & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__sbus__DOT__system_bus_xbar__DOT___readys_mask_T_15) 
                            << 1U)));
        }
        if ((1U & (~ ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_0_1__DOT___GEN_5)) 
                      | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_0_1__DOT__wrbypass_hit))))) {
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_0_1__DOT__wrbypass_enq_idx 
                = (1U & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_0_1__DOT__wrbypass_enq_idx) 
                         - (IData)(1U)));
        }
    }
    if ((0U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__cork__DOT__d_first_counter))) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__cork__DOT__nodeIn_d_bits_sink_r 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__cork__DOT__pool__DOT__select;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_0_1__DOT___GEN_5) {
        if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_0_1__DOT__wrbypass_hit) {
            if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_0_1__DOT__wrbypass_hits_0) {
                vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_0_1__DOT__wrbypass_0_0 
                    = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_0_1__DOT__update_wdata_0_ctr;
                vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_0_1__DOT__wrbypass_0_1 
                    = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_0_1__DOT__update_wdata_1_ctr;
                vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_0_1__DOT__wrbypass_0_2 
                    = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_0_1__DOT__update_wdata_2_ctr;
                vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_0_1__DOT__wrbypass_0_3 
                    = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_0_1__DOT__update_wdata_3_ctr;
            } else {
                vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_0_1__DOT__wrbypass_1_0 
                    = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_0_1__DOT__update_wdata_0_ctr;
                vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_0_1__DOT__wrbypass_1_1 
                    = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_0_1__DOT__update_wdata_1_ctr;
                vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_0_1__DOT__wrbypass_1_2 
                    = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_0_1__DOT__update_wdata_2_ctr;
                vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_0_1__DOT__wrbypass_1_3 
                    = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_0_1__DOT__update_wdata_3_ctr;
            }
        } else if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_0_1__DOT__wrbypass_enq_idx) {
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_0_1__DOT__wrbypass_1_0 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_0_1__DOT__update_wdata_0_ctr;
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_0_1__DOT__wrbypass_1_1 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_0_1__DOT__update_wdata_1_ctr;
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_0_1__DOT__wrbypass_1_2 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_0_1__DOT__update_wdata_2_ctr;
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_0_1__DOT__wrbypass_1_3 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_0_1__DOT__update_wdata_3_ctr;
        } else {
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_0_1__DOT__wrbypass_0_0 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_0_1__DOT__update_wdata_0_ctr;
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_0_1__DOT__wrbypass_0_1 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_0_1__DOT__update_wdata_1_ctr;
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_0_1__DOT__wrbypass_0_2 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_0_1__DOT__update_wdata_2_ctr;
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_0_1__DOT__wrbypass_0_3 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_0_1__DOT__update_wdata_3_ctr;
        }
    }
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__668(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__668\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT___system_auto_cbus_fixedClockNode_anon_out_reset) {
        vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_1_1__DOT__wrbypass_enq_idx = 0U;
        vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_2_1__DOT__wrbypass_enq_idx = 0U;
    } else {
        if ((1U & (~ ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_1_1__DOT___GEN_5)) 
                      | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_1_1__DOT__wrbypass_hit))))) {
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_1_1__DOT__wrbypass_enq_idx 
                = (1U & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_1_1__DOT__wrbypass_enq_idx) 
                         - (IData)(1U)));
        }
        if ((1U & (~ ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_2_1__DOT___GEN_3)) 
                      | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_2_1__DOT__wrbypass_hit))))) {
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_2_1__DOT__wrbypass_enq_idx 
                = (1U & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_2_1__DOT__wrbypass_enq_idx) 
                         - (IData)(1U)));
        }
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_1_1__DOT___GEN_5) {
        if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_1_1__DOT__wrbypass_hit) {
            if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_1_1__DOT__wrbypass_hits_0) {
                vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_1_1__DOT__wrbypass_0_0 
                    = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_1_1__DOT__update_wdata_0_ctr;
                vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_1_1__DOT__wrbypass_0_1 
                    = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_1_1__DOT__update_wdata_1_ctr;
                vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_1_1__DOT__wrbypass_0_2 
                    = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_1_1__DOT__update_wdata_2_ctr;
                vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_1_1__DOT__wrbypass_0_3 
                    = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_1_1__DOT__update_wdata_3_ctr;
            } else {
                vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_1_1__DOT__wrbypass_1_0 
                    = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_1_1__DOT__update_wdata_0_ctr;
                vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_1_1__DOT__wrbypass_1_1 
                    = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_1_1__DOT__update_wdata_1_ctr;
                vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_1_1__DOT__wrbypass_1_2 
                    = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_1_1__DOT__update_wdata_2_ctr;
                vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_1_1__DOT__wrbypass_1_3 
                    = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_1_1__DOT__update_wdata_3_ctr;
            }
        } else if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_1_1__DOT__wrbypass_enq_idx) {
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_1_1__DOT__wrbypass_1_0 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_1_1__DOT__update_wdata_0_ctr;
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_1_1__DOT__wrbypass_1_1 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_1_1__DOT__update_wdata_1_ctr;
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_1_1__DOT__wrbypass_1_2 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_1_1__DOT__update_wdata_2_ctr;
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_1_1__DOT__wrbypass_1_3 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_1_1__DOT__update_wdata_3_ctr;
        } else {
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_1_1__DOT__wrbypass_0_0 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_1_1__DOT__update_wdata_0_ctr;
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_1_1__DOT__wrbypass_0_1 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_1_1__DOT__update_wdata_1_ctr;
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_1_1__DOT__wrbypass_0_2 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_1_1__DOT__update_wdata_2_ctr;
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_1_1__DOT__wrbypass_0_3 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_1_1__DOT__update_wdata_3_ctr;
        }
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_2_1__DOT___GEN_3) {
        if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_2_1__DOT__wrbypass_hit) {
            if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_2_1__DOT__wrbypass_hits_0) {
                vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_2_1__DOT__wrbypass_0_0 
                    = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_2_1__DOT__update_wdata_0_ctr;
                vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_2_1__DOT__wrbypass_0_1 
                    = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_2_1__DOT__update_wdata_1_ctr;
                vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_2_1__DOT__wrbypass_0_2 
                    = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_2_1__DOT__update_wdata_2_ctr;
                vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_2_1__DOT__wrbypass_0_3 
                    = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_2_1__DOT__update_wdata_3_ctr;
            } else {
                vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_2_1__DOT__wrbypass_1_0 
                    = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_2_1__DOT__update_wdata_0_ctr;
                vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_2_1__DOT__wrbypass_1_1 
                    = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_2_1__DOT__update_wdata_1_ctr;
                vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_2_1__DOT__wrbypass_1_2 
                    = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_2_1__DOT__update_wdata_2_ctr;
                vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_2_1__DOT__wrbypass_1_3 
                    = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_2_1__DOT__update_wdata_3_ctr;
            }
        } else if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_2_1__DOT__wrbypass_enq_idx) {
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_2_1__DOT__wrbypass_1_0 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_2_1__DOT__update_wdata_0_ctr;
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_2_1__DOT__wrbypass_1_1 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_2_1__DOT__update_wdata_1_ctr;
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_2_1__DOT__wrbypass_1_2 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_2_1__DOT__update_wdata_2_ctr;
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_2_1__DOT__wrbypass_1_3 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_2_1__DOT__update_wdata_3_ctr;
        } else {
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_2_1__DOT__wrbypass_0_0 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_2_1__DOT__update_wdata_0_ctr;
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_2_1__DOT__wrbypass_0_1 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_2_1__DOT__update_wdata_1_ctr;
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_2_1__DOT__wrbypass_0_2 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_2_1__DOT__update_wdata_2_ctr;
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_2_1__DOT__wrbypass_0_3 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_2_1__DOT__update_wdata_3_ctr;
        }
    }
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__669(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__669\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT___system_auto_cbus_fixedClockNode_anon_out_reset) {
        vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_3_1__DOT__wrbypass_enq_idx = 0U;
        vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_4_1__DOT__wrbypass_enq_idx = 0U;
    } else {
        if ((1U & (~ ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_3_1__DOT___GEN_3)) 
                      | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_3_1__DOT__wrbypass_hit))))) {
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_3_1__DOT__wrbypass_enq_idx 
                = (1U & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_3_1__DOT__wrbypass_enq_idx) 
                         - (IData)(1U)));
        }
        if ((1U & (~ ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_4_1__DOT___GEN_3)) 
                      | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_4_1__DOT__wrbypass_hit))))) {
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_4_1__DOT__wrbypass_enq_idx 
                = (1U & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_4_1__DOT__wrbypass_enq_idx) 
                         - (IData)(1U)));
        }
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_3_1__DOT___GEN_3) {
        if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_3_1__DOT__wrbypass_hit) {
            if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_3_1__DOT__wrbypass_hits_0) {
                vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_3_1__DOT__wrbypass_0_0 
                    = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_3_1__DOT__update_wdata_0_ctr;
                vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_3_1__DOT__wrbypass_0_1 
                    = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_3_1__DOT__update_wdata_1_ctr;
                vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_3_1__DOT__wrbypass_0_2 
                    = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_3_1__DOT__update_wdata_2_ctr;
                vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_3_1__DOT__wrbypass_0_3 
                    = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_3_1__DOT__update_wdata_3_ctr;
            } else {
                vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_3_1__DOT__wrbypass_1_0 
                    = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_3_1__DOT__update_wdata_0_ctr;
                vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_3_1__DOT__wrbypass_1_1 
                    = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_3_1__DOT__update_wdata_1_ctr;
                vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_3_1__DOT__wrbypass_1_2 
                    = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_3_1__DOT__update_wdata_2_ctr;
                vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_3_1__DOT__wrbypass_1_3 
                    = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_3_1__DOT__update_wdata_3_ctr;
            }
        } else if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_3_1__DOT__wrbypass_enq_idx) {
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_3_1__DOT__wrbypass_1_0 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_3_1__DOT__update_wdata_0_ctr;
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_3_1__DOT__wrbypass_1_1 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_3_1__DOT__update_wdata_1_ctr;
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_3_1__DOT__wrbypass_1_2 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_3_1__DOT__update_wdata_2_ctr;
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_3_1__DOT__wrbypass_1_3 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_3_1__DOT__update_wdata_3_ctr;
        } else {
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_3_1__DOT__wrbypass_0_0 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_3_1__DOT__update_wdata_0_ctr;
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_3_1__DOT__wrbypass_0_1 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_3_1__DOT__update_wdata_1_ctr;
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_3_1__DOT__wrbypass_0_2 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_3_1__DOT__update_wdata_2_ctr;
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_3_1__DOT__wrbypass_0_3 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_3_1__DOT__update_wdata_3_ctr;
        }
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_4_1__DOT___GEN_3) {
        if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_4_1__DOT__wrbypass_hit) {
            if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_4_1__DOT__wrbypass_hits_0) {
                vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_4_1__DOT__wrbypass_0_0 
                    = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_4_1__DOT__update_wdata_0_ctr;
                vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_4_1__DOT__wrbypass_0_1 
                    = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_4_1__DOT__update_wdata_1_ctr;
                vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_4_1__DOT__wrbypass_0_2 
                    = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_4_1__DOT__update_wdata_2_ctr;
                vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_4_1__DOT__wrbypass_0_3 
                    = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_4_1__DOT__update_wdata_3_ctr;
            } else {
                vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_4_1__DOT__wrbypass_1_0 
                    = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_4_1__DOT__update_wdata_0_ctr;
                vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_4_1__DOT__wrbypass_1_1 
                    = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_4_1__DOT__update_wdata_1_ctr;
                vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_4_1__DOT__wrbypass_1_2 
                    = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_4_1__DOT__update_wdata_2_ctr;
                vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_4_1__DOT__wrbypass_1_3 
                    = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_4_1__DOT__update_wdata_3_ctr;
            }
        } else if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_4_1__DOT__wrbypass_enq_idx) {
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_4_1__DOT__wrbypass_1_0 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_4_1__DOT__update_wdata_0_ctr;
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_4_1__DOT__wrbypass_1_1 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_4_1__DOT__update_wdata_1_ctr;
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_4_1__DOT__wrbypass_1_2 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_4_1__DOT__update_wdata_2_ctr;
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_4_1__DOT__wrbypass_1_3 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_4_1__DOT__update_wdata_3_ctr;
        } else {
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_4_1__DOT__wrbypass_0_0 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_4_1__DOT__update_wdata_0_ctr;
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_4_1__DOT__wrbypass_0_1 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_4_1__DOT__update_wdata_1_ctr;
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_4_1__DOT__wrbypass_0_2 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_4_1__DOT__update_wdata_2_ctr;
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_4_1__DOT__wrbypass_0_3 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_4_1__DOT__update_wdata_3_ctr;
        }
    }
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__670(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__670\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT___system_auto_cbus_fixedClockNode_anon_out_reset) {
        vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_5_1__DOT__wrbypass_enq_idx = 0U;
    } else if ((1U & (~ ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_5_1__DOT___GEN_3)) 
                         | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_5_1__DOT__wrbypass_hit))))) {
        vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_5_1__DOT__wrbypass_enq_idx 
            = (1U & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_5_1__DOT__wrbypass_enq_idx) 
                     - (IData)(1U)));
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_5_1__DOT___GEN_3) {
        if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_5_1__DOT__wrbypass_hit) {
            if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_5_1__DOT__wrbypass_hits_0) {
                vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_5_1__DOT__wrbypass_0_0 
                    = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_5_1__DOT__update_wdata_0_ctr;
                vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_5_1__DOT__wrbypass_0_1 
                    = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_5_1__DOT__update_wdata_1_ctr;
                vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_5_1__DOT__wrbypass_0_2 
                    = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_5_1__DOT__update_wdata_2_ctr;
                vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_5_1__DOT__wrbypass_0_3 
                    = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_5_1__DOT__update_wdata_3_ctr;
            } else {
                vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_5_1__DOT__wrbypass_1_0 
                    = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_5_1__DOT__update_wdata_0_ctr;
                vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_5_1__DOT__wrbypass_1_1 
                    = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_5_1__DOT__update_wdata_1_ctr;
                vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_5_1__DOT__wrbypass_1_2 
                    = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_5_1__DOT__update_wdata_2_ctr;
                vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_5_1__DOT__wrbypass_1_3 
                    = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_5_1__DOT__update_wdata_3_ctr;
            }
        } else if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_5_1__DOT__wrbypass_enq_idx) {
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_5_1__DOT__wrbypass_1_0 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_5_1__DOT__update_wdata_0_ctr;
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_5_1__DOT__wrbypass_1_1 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_5_1__DOT__update_wdata_1_ctr;
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_5_1__DOT__wrbypass_1_2 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_5_1__DOT__update_wdata_2_ctr;
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_5_1__DOT__wrbypass_1_3 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_5_1__DOT__update_wdata_3_ctr;
        } else {
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_5_1__DOT__wrbypass_0_0 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_5_1__DOT__update_wdata_0_ctr;
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_5_1__DOT__wrbypass_0_1 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_5_1__DOT__update_wdata_1_ctr;
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_5_1__DOT__wrbypass_0_2 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_5_1__DOT__update_wdata_2_ctr;
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_5_1__DOT__wrbypass_0_3 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_5_1__DOT__update_wdata_3_ctr;
        }
    }
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rename_stage__DOT__REG 
        = (3U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_state));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_rename_stage__DOT__REG 
        = (3U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_state));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__imm_rename_stage__DOT__REG 
        = (3U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_state));
    if (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___csr_wen_T_4) 
         & (0xfffU == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___decoded_addr_decoded_decoded_andMatrixOutputs_T_10)))) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__reg_scause 
            = (0x800000000000001fULL & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__wdata);
    } else if ((1U & (~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___GEN_39)))) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__reg_scause 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__cause;
    }
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__671(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__671\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT___system_auto_cbus_fixedClockNode_anon_out_reset) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__pbus__DOT__atomics__DOT__state_1 = 0U;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__chipyard_prcictrl_domain__DOT__xbar__DOT__readys_mask = 3U;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__buffer_2__DOT__nodeOut_a_q__DOT__maybe_full = 0U;
    } else {
        if ((0U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__pbus__DOT__atomics__DOT__beatsLeft))) {
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__pbus__DOT__atomics__DOT__state_1 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__pbus__DOT__atomics__DOT__winner_1;
        }
        if (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__chipyard_prcictrl_domain__DOT__xbar__DOT__latch) 
             & (0U != (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__chipyard_prcictrl_domain__DOT__xbar__DOT__readys_valid)))) {
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__chipyard_prcictrl_domain__DOT__xbar__DOT__readys_mask 
                = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__chipyard_prcictrl_domain__DOT__xbar__DOT___readys_mask_T) 
                   | (2U & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__chipyard_prcictrl_domain__DOT__xbar__DOT___readys_mask_T) 
                            << 1U)));
        }
        if (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT___frontend_io_cpu_perf_acquire) 
             != (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__buffer_2__DOT__nodeOut_a_q__DOT__do_deq))) {
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__buffer_2__DOT__nodeOut_a_q__DOT__maybe_full 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT___frontend_io_cpu_perf_acquire;
        }
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__issue_slots_2_in_uop_valid) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__slots_2__DOT__slot_uop_prs2_busy 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT___slots_3_io_out_uop_prs2_busy;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__slots_2__DOT__slot_uop_iw_issued 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT___slots_3_io_out_uop_iw_issued;
    } else {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__slots_2__DOT__slot_uop_prs2_busy 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT___slots_2_io_out_uop_prs2_busy;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__slots_2__DOT__slot_uop_iw_issued 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT___slots_2_io_out_uop_iw_issued;
    }
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__icache__DOT__s2_hit 
        = ((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__icache__DOT__s1_tag_hit_0) 
             | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__icache__DOT__s1_tag_hit_1)) 
            | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__icache__DOT__s1_tag_hit_2)) 
           | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__icache__DOT__s1_tag_hit_3));
    if (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___csr_wen_T_4) 
         & (0xfffU == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___decoded_addr_decoded_decoded_andMatrixOutputs_T_5)))) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__reg_stvec 
            = (0x7fffffffffULL & (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___wdata_T_2 
                                  & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___wdata_T_6));
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_542) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_0_debug_tsrc 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_debug_tsrc;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_544) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_1_debug_tsrc 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_debug_tsrc;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_546) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_2_debug_tsrc 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_debug_tsrc;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_548) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_3_debug_tsrc 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_debug_tsrc;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_550) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_4_debug_tsrc 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_debug_tsrc;
    }
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__672(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__672\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_552) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_5_debug_tsrc 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_debug_tsrc;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_5_rxq_idx 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_rxq_idx;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_5_iw_p2_bypass_hint 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_iw_p2_bypass_hint;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_554) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_6_debug_tsrc 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_debug_tsrc;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_6_rxq_idx 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_rxq_idx;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_6_iw_p2_bypass_hint 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_iw_p2_bypass_hint;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_556) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_7_debug_tsrc 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_debug_tsrc;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_7_rxq_idx 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_rxq_idx;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_7_iw_p2_bypass_hint 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_iw_p2_bypass_hint;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_542) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_0_rxq_idx 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_rxq_idx;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_0_iw_p2_bypass_hint 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_iw_p2_bypass_hint;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_0_iw_issued 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_iw_issued;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_544) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_1_rxq_idx 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_rxq_idx;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_1_iw_p2_bypass_hint 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_iw_p2_bypass_hint;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_546) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_2_rxq_idx 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_rxq_idx;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_2_iw_p2_bypass_hint 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_iw_p2_bypass_hint;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_548) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_3_rxq_idx 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_rxq_idx;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_3_iw_p2_bypass_hint 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_iw_p2_bypass_hint;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_550) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_4_rxq_idx 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_rxq_idx;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_4_iw_p2_bypass_hint 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_iw_p2_bypass_hint;
    }
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__673(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__673\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_544) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_1_iw_issued 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_iw_issued;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_1_xcpt_ma_if 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_xcpt_ma_if;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_1_iw_p1_bypass_hint 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_iw_p1_bypass_hint;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_546) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_2_iw_issued 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_iw_issued;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_2_xcpt_ma_if 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_xcpt_ma_if;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_2_iw_p1_bypass_hint 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_iw_p1_bypass_hint;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_548) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_3_iw_issued 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_iw_issued;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_3_xcpt_ma_if 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_xcpt_ma_if;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_3_iw_p1_bypass_hint 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_iw_p1_bypass_hint;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_550) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_4_iw_issued 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_iw_issued;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_4_xcpt_ma_if 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_xcpt_ma_if;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_4_iw_p1_bypass_hint 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_iw_p1_bypass_hint;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_552) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_5_iw_issued 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_iw_issued;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_5_xcpt_ma_if 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_xcpt_ma_if;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_554) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_6_iw_issued 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_iw_issued;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_6_xcpt_ma_if 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_xcpt_ma_if;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_556) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_7_iw_issued 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_iw_issued;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_7_xcpt_ma_if 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_xcpt_ma_if;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_542) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_0_xcpt_ma_if 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_xcpt_ma_if;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_0_iw_p1_bypass_hint 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_iw_p1_bypass_hint;
    }
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__674(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__674\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_552) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_5_iw_p1_bypass_hint 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_iw_p1_bypass_hint;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_5_iw_issued_partial_dgen 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_iw_issued_partial_dgen;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_5_iw_issued_partial_agen 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_iw_issued_partial_agen;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_554) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_6_iw_p1_bypass_hint 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_iw_p1_bypass_hint;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_6_iw_issued_partial_dgen 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_iw_issued_partial_dgen;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_6_iw_issued_partial_agen 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_iw_issued_partial_agen;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_556) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_7_iw_p1_bypass_hint 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_iw_p1_bypass_hint;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_7_iw_issued_partial_dgen 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_iw_issued_partial_dgen;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_7_iw_issued_partial_agen 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_iw_issued_partial_agen;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_542) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_0_iw_issued_partial_dgen 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_iw_issued_partial_dgen;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_0_iw_issued_partial_agen 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_iw_issued_partial_agen;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_0_iw_p3_bypass_hint 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_iw_p3_bypass_hint;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_544) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_1_iw_issued_partial_dgen 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_iw_issued_partial_dgen;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_1_iw_issued_partial_agen 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_iw_issued_partial_agen;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_546) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_2_iw_issued_partial_dgen 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_iw_issued_partial_dgen;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_2_iw_issued_partial_agen 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_iw_issued_partial_agen;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_548) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_3_iw_issued_partial_dgen 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_iw_issued_partial_dgen;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_3_iw_issued_partial_agen 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_iw_issued_partial_agen;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_550) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_4_iw_issued_partial_dgen 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_iw_issued_partial_dgen;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_4_iw_issued_partial_agen 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_iw_issued_partial_agen;
    }
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__675(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__675\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_544) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_1_iw_p3_bypass_hint 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_iw_p3_bypass_hint;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_1_fp_ctrl_vec 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fp_ctrl_vec;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_1_fp_ctrl_ldst 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fp_ctrl_ldst;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_546) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_2_iw_p3_bypass_hint 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_iw_p3_bypass_hint;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_2_fp_ctrl_vec 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fp_ctrl_vec;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_2_fp_ctrl_ldst 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fp_ctrl_ldst;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_548) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_3_iw_p3_bypass_hint 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_iw_p3_bypass_hint;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_3_fp_ctrl_vec 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fp_ctrl_vec;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_3_fp_ctrl_ldst 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fp_ctrl_ldst;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_550) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_4_iw_p3_bypass_hint 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_iw_p3_bypass_hint;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_4_fp_ctrl_vec 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fp_ctrl_vec;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_4_fp_ctrl_ldst 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fp_ctrl_ldst;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_552) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_5_iw_p3_bypass_hint 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_iw_p3_bypass_hint;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_5_fp_ctrl_vec 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fp_ctrl_vec;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_554) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_6_iw_p3_bypass_hint 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_iw_p3_bypass_hint;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_6_fp_ctrl_vec 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fp_ctrl_vec;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_556) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_7_iw_p3_bypass_hint 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_iw_p3_bypass_hint;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_7_fp_ctrl_vec 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fp_ctrl_vec;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_542) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_0_fp_ctrl_vec 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fp_ctrl_vec;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_0_fp_ctrl_ldst 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fp_ctrl_ldst;
    }
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__676(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__676\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_552) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_5_fp_ctrl_ldst 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fp_ctrl_ldst;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_5_fp_ctrl_wen 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fp_ctrl_wen;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_5_fp_ctrl_swap12 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fp_ctrl_swap12;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_554) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_6_fp_ctrl_ldst 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fp_ctrl_ldst;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_6_fp_ctrl_wen 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fp_ctrl_wen;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_6_fp_ctrl_swap12 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fp_ctrl_swap12;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_556) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_7_fp_ctrl_ldst 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fp_ctrl_ldst;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_7_fp_ctrl_wen 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fp_ctrl_wen;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_7_fp_ctrl_swap12 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fp_ctrl_swap12;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_542) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_0_fp_ctrl_wen 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fp_ctrl_wen;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_0_fp_ctrl_swap12 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fp_ctrl_swap12;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_0_prs3_busy 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_prs3_busy;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_544) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_1_fp_ctrl_wen 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fp_ctrl_wen;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_1_fp_ctrl_swap12 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fp_ctrl_swap12;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_546) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_2_fp_ctrl_wen 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fp_ctrl_wen;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_2_fp_ctrl_swap12 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fp_ctrl_swap12;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_548) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_3_fp_ctrl_wen 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fp_ctrl_wen;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_3_fp_ctrl_swap12 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fp_ctrl_swap12;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_550) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_4_fp_ctrl_wen 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fp_ctrl_wen;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_4_fp_ctrl_swap12 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fp_ctrl_swap12;
    }
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_exe_unit_1__DOT__io_agen_pause_mem_REG 
        = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_exe_unit_1__DOT__io_agen_loads_saturating;
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__677(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__677\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_544) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_1_prs3_busy 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_prs3_busy;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_1_pimm 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_pimm;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_1_stale_pdst 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_stale_pdst;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_546) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_2_prs3_busy 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_prs3_busy;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_2_pimm 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_pimm;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_2_stale_pdst 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_stale_pdst;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_548) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_3_prs3_busy 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_prs3_busy;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_3_pimm 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_pimm;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_3_stale_pdst 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_stale_pdst;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_550) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_4_prs3_busy 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_prs3_busy;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_4_pimm 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_pimm;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_4_stale_pdst 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_stale_pdst;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_552) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_5_prs3_busy 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_prs3_busy;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_5_pimm 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_pimm;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_554) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_6_prs3_busy 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_prs3_busy;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_6_pimm 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_pimm;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_556) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_7_prs3_busy 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_prs3_busy;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_7_pimm 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_pimm;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_542) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_0_pimm 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_pimm;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_0_stale_pdst 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_stale_pdst;
    }
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__678(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__678\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_552) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_5_stale_pdst 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_stale_pdst;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_5_iw_p1_speculative_child 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_iw_p1_speculative_child;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_5_iw_p2_speculative_child 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_iw_p2_speculative_child;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_554) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_6_stale_pdst 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_stale_pdst;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_6_iw_p1_speculative_child 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_iw_p1_speculative_child;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_6_iw_p2_speculative_child 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_iw_p2_speculative_child;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_556) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_7_stale_pdst 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_stale_pdst;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_7_iw_p1_speculative_child 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_iw_p1_speculative_child;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_7_iw_p2_speculative_child 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_iw_p2_speculative_child;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_542) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_0_iw_p1_speculative_child 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_iw_p1_speculative_child;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_0_iw_p2_speculative_child 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_iw_p2_speculative_child;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_0_ppred_busy 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_ppred_busy;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_544) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_1_iw_p1_speculative_child 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_iw_p1_speculative_child;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_1_iw_p2_speculative_child 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_iw_p2_speculative_child;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_546) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_2_iw_p1_speculative_child 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_iw_p1_speculative_child;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_2_iw_p2_speculative_child 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_iw_p2_speculative_child;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_548) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_3_iw_p1_speculative_child 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_iw_p1_speculative_child;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_3_iw_p2_speculative_child 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_iw_p2_speculative_child;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_550) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_4_iw_p1_speculative_child 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_iw_p1_speculative_child;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_4_iw_p2_speculative_child 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_iw_p2_speculative_child;
    }
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__679(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__679\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_544) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_1_ppred_busy 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_ppred_busy;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_1_prs1_busy 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_prs1_busy;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_1_prs2_busy 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_prs2_busy;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_546) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_2_ppred_busy 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_ppred_busy;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_2_prs1_busy 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_prs1_busy;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_2_prs2_busy 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_prs2_busy;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_548) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_3_ppred_busy 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_ppred_busy;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_3_prs1_busy 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_prs1_busy;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_3_prs2_busy 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_prs2_busy;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_550) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_4_ppred_busy 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_ppred_busy;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_4_prs1_busy 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_prs1_busy;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_4_prs2_busy 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_prs2_busy;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_552) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_5_ppred_busy 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_ppred_busy;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_5_prs1_busy 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_prs1_busy;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_554) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_6_ppred_busy 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_ppred_busy;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_6_prs1_busy 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_prs1_busy;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_556) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_7_ppred_busy 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_ppred_busy;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_7_prs1_busy 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_prs1_busy;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_542) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_0_prs1_busy 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_prs1_busy;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_0_prs2_busy 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_prs2_busy;
    }
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__680(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__680\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_552) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_5_prs2_busy 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_prs2_busy;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_5_prs2 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_prs2;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_554) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_6_prs2_busy 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_prs2_busy;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_6_prs2 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_prs2;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_556) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_7_prs2_busy 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_prs2_busy;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT___system_auto_cbus_fixedClockNode_anon_out_reset) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__cbus__DOT__atomics__DOT__state_1 = 0U;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__fbus__DOT__fbus_xbar__DOT__readys_mask = 3U;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__mbus__DOT__coupler_to_memory_controller_port_named_axi4__DOT__tl2axi4__DOT__doneAW = 0U;
    } else {
        if ((0U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__cbus__DOT__atomics__DOT__beatsLeft))) {
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__cbus__DOT__atomics__DOT__state_1 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__cbus__DOT__atomics__DOT__winner_1;
        }
        if (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__fbus__DOT__fbus_xbar__DOT__latch) 
             & (0U != (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__fbus__DOT__fbus_xbar__DOT__readys_valid)))) {
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__fbus__DOT__fbus_xbar__DOT__readys_mask 
                = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__fbus__DOT__fbus_xbar__DOT___readys_mask_T) 
                   | (2U & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__fbus__DOT__fbus_xbar__DOT___readys_mask_T) 
                            << 1U)));
        }
        if (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__mbus__DOT___coupler_to_memory_controller_port_named_axi4_auto_widget_anon_in_a_ready) 
             & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__mbus__DOT___coupler_to_memory_controller_port_named_axi4_auto_tl_out_a_valid))) {
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__mbus__DOT__coupler_to_memory_controller_port_named_axi4__DOT__tl2axi4__DOT__doneAW 
                = (1U & (~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__mbus__DOT__coupler_to_memory_controller_port_named_axi4__DOT__tl2axi4__DOT__a_last)));
        }
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sourceD__DOT__s4_latch) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sourceD__DOT__s4_pdata_data 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sourceD__DOT__s3_pdata_data;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_542) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_0_prs2 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_prs2;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_544) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_1_prs2 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_prs2;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_546) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_2_prs2 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_prs2;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_548) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_3_prs2 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_prs2;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_550) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_4_prs2 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_prs2;
    }
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__681(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__681\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_556) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_7_prs2 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_prs2;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_7_prs1 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_prs1;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_542) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_0_prs1 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_prs1;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_0_imm_rename 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_imm_rename;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_544) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_1_prs1 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_prs1;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_1_imm_rename 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_imm_rename;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_546) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_2_prs1 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_prs1;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_2_imm_rename 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_imm_rename;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_548) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_3_prs1 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_prs1;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_3_imm_rename 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_imm_rename;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_550) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_4_prs1 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_prs1;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_552) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_5_prs1 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_prs1;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_554) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_6_prs1 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_prs1;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT___system_auto_cbus_fixedClockNode_anon_out_reset) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__cork__DOT__q_1__DOT__maybe_full = 0U;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__fbus__DOT__coupler_from_port_named_serial_tl_0_in__DOT__buffer__DOT__nodeOut_a_q__DOT__maybe_full = 0U;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__ras_read_idx = 0U;
    } else {
        if (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__cork__DOT__q_1__DOT__do_enq) 
             != (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__cork__DOT__q_1__DOT__do_deq))) {
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__cork__DOT__q_1__DOT__maybe_full 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__cork__DOT__q_1__DOT__do_enq;
        }
        if (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__fbus__DOT__coupler_from_port_named_serial_tl_0_in__DOT__buffer__DOT__nodeOut_a_q__DOT__do_enq) 
             != (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__fbus__DOT__coupler_from_port_named_serial_tl_0_in__DOT__buffer__DOT__nodeOut_a_q__DOT__do_deq))) {
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__fbus__DOT__coupler_from_port_named_serial_tl_0_in__DOT__buffer__DOT__nodeOut_a_q__DOT__maybe_full 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__fbus__DOT__coupler_from_port_named_serial_tl_0_in__DOT__buffer__DOT__nodeOut_a_q__DOT__do_enq;
        }
        if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___f4_btb_corrections_io_enq_valid_T) {
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__ras_read_idx 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f4_io_enq_bits_ghist_ras_idx;
        }
    }
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__682(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__682\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_550) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_4_imm_rename 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_imm_rename;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_4_fu_code_9 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fu_code_9;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_4_fp_ctrl_div 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fp_ctrl_div;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_552) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_5_imm_rename 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_imm_rename;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_5_fu_code_9 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fu_code_9;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_5_fp_ctrl_div 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fp_ctrl_div;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_554) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_6_imm_rename 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_imm_rename;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_6_fu_code_9 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fu_code_9;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_6_fp_ctrl_div 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fp_ctrl_div;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_556) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_7_imm_rename 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_imm_rename;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_7_fu_code_9 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fu_code_9;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_7_fp_ctrl_div 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fp_ctrl_div;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_542) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_0_fu_code_9 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fu_code_9;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_0_fp_ctrl_div 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fp_ctrl_div;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_544) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_1_fu_code_9 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fu_code_9;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_1_fp_ctrl_div 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fp_ctrl_div;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_546) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_2_fu_code_9 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fu_code_9;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_2_fp_ctrl_div 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fp_ctrl_div;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_548) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_3_fu_code_9 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fu_code_9;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_3_fp_ctrl_div 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fp_ctrl_div;
    }
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__683(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__683\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_542) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_0_fp_ctrl_fastpipe 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fp_ctrl_fastpipe;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_0_fp_ctrl_toint 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fp_ctrl_toint;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_0_fp_ctrl_swap23 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fp_ctrl_swap23;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_544) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_1_fp_ctrl_fastpipe 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fp_ctrl_fastpipe;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_1_fp_ctrl_toint 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fp_ctrl_toint;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_1_fp_ctrl_swap23 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fp_ctrl_swap23;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_546) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_2_fp_ctrl_fastpipe 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fp_ctrl_fastpipe;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_2_fp_ctrl_toint 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fp_ctrl_toint;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_2_fp_ctrl_swap23 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fp_ctrl_swap23;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_548) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_3_fp_ctrl_fastpipe 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fp_ctrl_fastpipe;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_3_fp_ctrl_toint 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fp_ctrl_toint;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_3_fp_ctrl_swap23 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fp_ctrl_swap23;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_550) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_4_fp_ctrl_fastpipe 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fp_ctrl_fastpipe;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_4_fp_ctrl_toint 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fp_ctrl_toint;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_552) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_5_fp_ctrl_fastpipe 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fp_ctrl_fastpipe;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_5_fp_ctrl_toint 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fp_ctrl_toint;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_554) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_6_fp_ctrl_fastpipe 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fp_ctrl_fastpipe;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_6_fp_ctrl_toint 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fp_ctrl_toint;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_556) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_7_fp_ctrl_fastpipe 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fp_ctrl_fastpipe;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_7_fp_ctrl_toint 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fp_ctrl_toint;
    }
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__684(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__684\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_550) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_4_fp_ctrl_swap23 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fp_ctrl_swap23;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_4_fu_code_2 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fu_code_2;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_4_fp_ctrl_typeTagIn 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fp_ctrl_typeTagIn;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_552) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_5_fp_ctrl_swap23 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fp_ctrl_swap23;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_5_fu_code_2 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fu_code_2;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_5_fp_ctrl_typeTagIn 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fp_ctrl_typeTagIn;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_554) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_6_fp_ctrl_swap23 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fp_ctrl_swap23;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_6_fu_code_2 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fu_code_2;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_6_fp_ctrl_typeTagIn 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fp_ctrl_typeTagIn;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_556) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_7_fp_ctrl_swap23 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fp_ctrl_swap23;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_7_fu_code_2 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fu_code_2;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_7_fp_ctrl_typeTagIn 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fp_ctrl_typeTagIn;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_542) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_0_fu_code_2 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fu_code_2;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_0_fp_ctrl_typeTagIn 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fp_ctrl_typeTagIn;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_544) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_1_fu_code_2 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fu_code_2;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_1_fp_ctrl_typeTagIn 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fp_ctrl_typeTagIn;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_546) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_2_fu_code_2 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fu_code_2;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_2_fp_ctrl_typeTagIn 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fp_ctrl_typeTagIn;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_548) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_3_fu_code_2 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fu_code_2;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_3_fp_ctrl_typeTagIn 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fp_ctrl_typeTagIn;
    }
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__685(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__685\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_542) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_0_fu_code_3 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fu_code_3;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_0_lrs2 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_lrs2;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_0_fp_ctrl_ren1 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fp_ctrl_ren1;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_544) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_1_fu_code_3 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fu_code_3;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_1_lrs2 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_lrs2;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_1_fp_ctrl_ren1 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fp_ctrl_ren1;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_546) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_2_fu_code_3 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fu_code_3;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_2_lrs2 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_lrs2;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_2_fp_ctrl_ren1 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fp_ctrl_ren1;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_548) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_3_fu_code_3 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fu_code_3;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_3_lrs2 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_lrs2;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_3_fp_ctrl_ren1 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fp_ctrl_ren1;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_550) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_4_fu_code_3 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fu_code_3;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_4_lrs2 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_lrs2;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_552) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_5_fu_code_3 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fu_code_3;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_5_lrs2 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_lrs2;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_554) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_6_fu_code_3 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fu_code_3;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_6_lrs2 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_lrs2;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_556) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_7_fu_code_3 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fu_code_3;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_7_lrs2 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_lrs2;
    }
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__686(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__686\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_550) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_4_fp_ctrl_ren1 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fp_ctrl_ren1;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_4_fcn_dw 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fcn_dw;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_4_fu_code_0 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fu_code_0;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_552) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_5_fp_ctrl_ren1 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fp_ctrl_ren1;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_5_fcn_dw 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fcn_dw;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_5_fu_code_0 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fu_code_0;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_554) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_6_fp_ctrl_ren1 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fp_ctrl_ren1;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_6_fcn_dw 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fcn_dw;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_6_fu_code_0 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fu_code_0;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_556) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_7_fp_ctrl_ren1 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fp_ctrl_ren1;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_7_fcn_dw 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fcn_dw;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_7_fu_code_0 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fu_code_0;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_542) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_0_fcn_dw 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fcn_dw;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_0_fu_code_0 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fu_code_0;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_544) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_1_fcn_dw 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fcn_dw;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_1_fu_code_0 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fu_code_0;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_546) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_2_fcn_dw 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fcn_dw;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_2_fu_code_0 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fu_code_0;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_548) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_3_fcn_dw 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fcn_dw;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_3_fu_code_0 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fu_code_0;
    }
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__687(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__687\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_542) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_0_iq_type_0 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_iq_type_0;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_0_iq_type_1 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_iq_type_1;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_0_imm_packed 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_imm_packed;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_544) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_1_iq_type_0 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_iq_type_0;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_1_iq_type_1 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_iq_type_1;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_1_imm_packed 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_imm_packed;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_546) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_2_iq_type_0 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_iq_type_0;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_2_iq_type_1 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_iq_type_1;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_2_imm_packed 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_imm_packed;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_548) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_3_iq_type_0 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_iq_type_0;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_3_iq_type_1 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_iq_type_1;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_3_imm_packed 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_imm_packed;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_550) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_4_iq_type_0 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_iq_type_0;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_4_iq_type_1 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_iq_type_1;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_552) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_5_iq_type_0 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_iq_type_0;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_5_iq_type_1 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_iq_type_1;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_554) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_6_iq_type_0 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_iq_type_0;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_6_iq_type_1 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_iq_type_1;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_556) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_7_iq_type_0 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_iq_type_0;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_7_iq_type_1 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_iq_type_1;
    }
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__688(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__688\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_550) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_4_imm_packed 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_imm_packed;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_4_fcn_op 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fcn_op;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_4_ftq_idx 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_ftq_idx;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_552) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_5_imm_packed 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_imm_packed;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_5_fcn_op 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fcn_op;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_5_ftq_idx 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_ftq_idx;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_554) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_6_imm_packed 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_imm_packed;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_6_fcn_op 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fcn_op;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_6_ftq_idx 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_ftq_idx;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_556) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_7_imm_packed 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_imm_packed;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_7_fcn_op 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fcn_op;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_7_ftq_idx 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_ftq_idx;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_542) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_0_fcn_op 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fcn_op;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_0_ftq_idx 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_ftq_idx;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_544) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_1_fcn_op 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fcn_op;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_1_ftq_idx 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_ftq_idx;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_546) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_2_fcn_op 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fcn_op;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_2_ftq_idx 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_ftq_idx;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_548) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_3_fcn_op 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fcn_op;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_3_ftq_idx 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_ftq_idx;
    }
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__689(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__689\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_542) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_0_iq_type_2 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_iq_type_2;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_0_fp_ctrl_fromint 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fp_ctrl_fromint;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_0_fu_code_8 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fu_code_8;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_544) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_1_iq_type_2 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_iq_type_2;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_1_fp_ctrl_fromint 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fp_ctrl_fromint;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_1_fu_code_8 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fu_code_8;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_546) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_2_iq_type_2 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_iq_type_2;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_2_fp_ctrl_fromint 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fp_ctrl_fromint;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_2_fu_code_8 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fu_code_8;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_548) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_3_iq_type_2 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_iq_type_2;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_3_fp_ctrl_fromint 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fp_ctrl_fromint;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_3_fu_code_8 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fu_code_8;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_550) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_4_iq_type_2 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_iq_type_2;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_4_fp_ctrl_fromint 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fp_ctrl_fromint;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_552) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_5_iq_type_2 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_iq_type_2;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_5_fp_ctrl_fromint 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fp_ctrl_fromint;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_554) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_6_iq_type_2 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_iq_type_2;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_6_fp_ctrl_fromint 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fp_ctrl_fromint;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_556) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_7_iq_type_2 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_iq_type_2;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_7_fp_ctrl_fromint 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fp_ctrl_fromint;
    }
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__690(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__690\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_550) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_4_fu_code_8 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fu_code_8;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_4_is_rocc 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_is_rocc;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_4_is_sfence 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_is_sfence;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_552) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_5_fu_code_8 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fu_code_8;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_5_is_rocc 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_is_rocc;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_5_is_sfence 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_is_sfence;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_554) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_6_fu_code_8 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fu_code_8;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_6_is_rocc 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_is_rocc;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_6_is_sfence 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_is_sfence;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_556) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_7_fu_code_8 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fu_code_8;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_7_is_rocc 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_is_rocc;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_7_is_sfence 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_is_sfence;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_542) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_0_is_rocc 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_is_rocc;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_0_is_sfence 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_is_sfence;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_544) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_1_is_rocc 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_is_rocc;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_1_is_sfence 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_is_sfence;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_546) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_2_is_rocc 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_is_rocc;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_2_is_sfence 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_is_sfence;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_548) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_3_is_rocc 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_is_rocc;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_3_is_sfence 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_is_sfence;
    }
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__691(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__691\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_542) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_0_bp_debug_if 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_bp_debug_if;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_0_xcpt_ae_if 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_xcpt_ae_if;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_0_xcpt_pf_if 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_xcpt_pf_if;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_544) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_1_bp_debug_if 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_bp_debug_if;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_1_xcpt_ae_if 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_xcpt_ae_if;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_1_xcpt_pf_if 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_xcpt_pf_if;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_546) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_2_bp_debug_if 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_bp_debug_if;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_2_xcpt_ae_if 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_xcpt_ae_if;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_2_xcpt_pf_if 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_xcpt_pf_if;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_548) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_3_bp_debug_if 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_bp_debug_if;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_3_xcpt_ae_if 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_xcpt_ae_if;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_3_xcpt_pf_if 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_xcpt_pf_if;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_550) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_4_bp_debug_if 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_bp_debug_if;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_4_xcpt_ae_if 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_xcpt_ae_if;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_552) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_5_bp_debug_if 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_bp_debug_if;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_5_xcpt_ae_if 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_xcpt_ae_if;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_554) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_6_bp_debug_if 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_bp_debug_if;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_6_xcpt_ae_if 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_xcpt_ae_if;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_556) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_7_bp_debug_if 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_bp_debug_if;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_7_xcpt_ae_if 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_xcpt_ae_if;
    }
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__692(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__692\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_550) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_4_xcpt_pf_if 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_xcpt_pf_if;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_4_bp_xcpt_if 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_bp_xcpt_if;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_4_is_mov 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_is_mov;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_552) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_5_xcpt_pf_if 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_xcpt_pf_if;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_5_bp_xcpt_if 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_bp_xcpt_if;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_5_is_mov 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_is_mov;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_554) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_6_xcpt_pf_if 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_xcpt_pf_if;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_6_bp_xcpt_if 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_bp_xcpt_if;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_556) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_7_xcpt_pf_if 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_xcpt_pf_if;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_7_bp_xcpt_if 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_bp_xcpt_if;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_542) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_0_bp_xcpt_if 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_bp_xcpt_if;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_0_is_mov 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_is_mov;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_544) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_1_bp_xcpt_if 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_bp_xcpt_if;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_1_is_mov 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_is_mov;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_546) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_2_bp_xcpt_if 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_bp_xcpt_if;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_2_is_mov 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_is_mov;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_548) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_3_bp_xcpt_if 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_bp_xcpt_if;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_3_is_mov 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_is_mov;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT___system_auto_cbus_fixedClockNode_anon_out_reset) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__cbus__DOT__coupler_to_prci_ctrl__DOT__buffer__DOT__nodeOut_a_q__DOT__maybe_full = 0U;
    } else if (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__cbus__DOT__coupler_to_prci_ctrl__DOT__buffer__DOT__nodeOut_a_q__DOT__do_enq) 
                != (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__cbus__DOT__coupler_to_prci_ctrl__DOT__buffer__DOT__nodeOut_a_q__DOT__do_deq))) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__cbus__DOT__coupler_to_prci_ctrl__DOT__buffer__DOT__nodeOut_a_q__DOT__maybe_full 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__cbus__DOT__coupler_to_prci_ctrl__DOT__buffer__DOT__nodeOut_a_q__DOT__do_enq;
    }
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__693(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__693\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_554) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_6_is_mov 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_is_mov;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_6_fp_val 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fp_val;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_556) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_7_is_mov 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_is_mov;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_7_fp_val 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fp_val;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT___system_auto_cbus_fixedClockNode_anon_out_reset) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__reg_senvcfg_fiom = 0U;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__cbus__DOT__out_xbar__DOT__state_7 = 0U;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__cbus__DOT__out_xbar__DOT__state_2 = 0U;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__cbus__DOT__out_xbar__DOT__state_0 = 0U;
    } else {
        if (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___csr_wen_T_4) 
             & (0x1ffU == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___decoded_addr_decoded_decoded_andMatrixOutputs_T_7)))) {
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__reg_senvcfg_fiom 
                = (1U & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___wdata_T_2) 
                         & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___wdata_T_6)));
        }
        if ((0U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__cbus__DOT__out_xbar__DOT__beatsLeft))) {
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__cbus__DOT__out_xbar__DOT__state_7 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__cbus__DOT__out_xbar__DOT__winner_7;
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__cbus__DOT__out_xbar__DOT__state_2 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__cbus__DOT__out_xbar__DOT__winner_2;
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__cbus__DOT__out_xbar__DOT__state_0 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__cbus__DOT__out_xbar__DOT__winner_0;
        }
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_542) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_0_fp_val 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fp_val;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_544) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_1_fp_val 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fp_val;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_546) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_2_fp_val 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fp_val;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_548) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_3_fp_val 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fp_val;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_550) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_4_fp_val 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fp_val;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_552) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_5_fp_val 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fp_val;
    }
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__694(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__694\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT___system_auto_cbus_fixedClockNode_anon_out_reset) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_0__DOT__rpq__DOT__main__DOT__maybe_full = 0U;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_1__DOT__rpq__DOT__main__DOT__maybe_full = 0U;
    } else {
        if (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_0__DOT__rpq__DOT__main__DOT__do_enq) 
             != (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_0__DOT__rpq__DOT__main__DOT__do_deq))) {
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_0__DOT__rpq__DOT__main__DOT__maybe_full 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_0__DOT__rpq__DOT__main__DOT__do_enq;
        }
        if (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_1__DOT__rpq__DOT__main__DOT__do_enq) 
             != (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_1__DOT__rpq__DOT__main__DOT__do_deq))) {
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_1__DOT__rpq__DOT__main__DOT__maybe_full 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_1__DOT__rpq__DOT__main__DOT__do_enq;
        }
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_542) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_0_fp_ctrl_ren3 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fp_ctrl_ren3;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_0_fu_code_4 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fu_code_4;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_544) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_1_fp_ctrl_ren3 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fp_ctrl_ren3;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_1_fu_code_4 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fu_code_4;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_546) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_2_fp_ctrl_ren3 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fp_ctrl_ren3;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_2_fu_code_4 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fu_code_4;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_548) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_3_fp_ctrl_ren3 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fp_ctrl_ren3;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_3_fu_code_4 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fu_code_4;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_550) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_4_fp_ctrl_ren3 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fp_ctrl_ren3;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_4_fu_code_4 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fu_code_4;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_552) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_5_fp_ctrl_ren3 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fp_ctrl_ren3;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_5_fu_code_4 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fu_code_4;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_554) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_6_fp_ctrl_ren3 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fp_ctrl_ren3;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_6_fu_code_4 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fu_code_4;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_556) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_7_fp_ctrl_ren3 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fp_ctrl_ren3;
    }
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__695(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__695\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_556) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_7_fu_code_4 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fu_code_4;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_7_fp_ctrl_fma 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fp_ctrl_fma;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT___system_auto_cbus_fixedClockNode_anon_out_reset) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__cbus__DOT__out_xbar__DOT__state_1 = 0U;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__cbus__DOT__out_xbar__DOT__state_4 = 0U;
    } else if ((0U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__cbus__DOT__out_xbar__DOT__beatsLeft))) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__cbus__DOT__out_xbar__DOT__state_1 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__cbus__DOT__out_xbar__DOT__winner_1;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__cbus__DOT__out_xbar__DOT__state_4 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__cbus__DOT__out_xbar__DOT__winner_4;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_542) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_0_fp_ctrl_fma 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fp_ctrl_fma;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_0_frs3_en 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_frs3_en;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_544) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_1_fp_ctrl_fma 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fp_ctrl_fma;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_1_frs3_en 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_frs3_en;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_546) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_2_fp_ctrl_fma 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fp_ctrl_fma;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_2_frs3_en 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_frs3_en;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_548) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_3_fp_ctrl_fma 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fp_ctrl_fma;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_3_frs3_en 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_frs3_en;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_550) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_4_fp_ctrl_fma 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fp_ctrl_fma;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_4_frs3_en 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_frs3_en;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_552) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_5_fp_ctrl_fma 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fp_ctrl_fma;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_5_frs3_en 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_frs3_en;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_554) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_6_fp_ctrl_fma 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fp_ctrl_fma;
    }
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__696(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__696\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_554) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_6_frs3_en 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_frs3_en;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_6_fu_code_6 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fu_code_6;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_556) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_7_frs3_en 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_frs3_en;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_7_fu_code_6 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fu_code_6;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_542) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_0_fu_code_6 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fu_code_6;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_544) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_1_fu_code_6 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fu_code_6;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_546) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_2_fu_code_6 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fu_code_6;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_548) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_3_fu_code_6 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fu_code_6;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_550) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_4_fu_code_6 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fu_code_6;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_552) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_5_fu_code_6 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fu_code_6;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT___system_auto_cbus_fixedClockNode_anon_out_reset) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__cbus__DOT__out_xbar__DOT__state_6 = 0U;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__reg_menvcfg_fiom = 0U;
    } else {
        if ((0U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__cbus__DOT__out_xbar__DOT__beatsLeft))) {
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__cbus__DOT__out_xbar__DOT__state_6 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__cbus__DOT__out_xbar__DOT__winner_6;
        }
        if (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___csr_wen_T_4) 
             & (0x1ffU == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___decoded_addr_decoded_decoded_andMatrixOutputs_T_21)))) {
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__reg_menvcfg_fiom 
                = (1U & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___wdata_T_2) 
                         & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___wdata_T_6)));
        }
    }
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__slots_5__DOT__slot_uop_prs1_busy 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__issue_slots_5_in_uop_valid)
            ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT___slots_6_io_out_uop_prs1_busy)
            : (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT___slots_5_io_out_uop_prs1_busy));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_0_1_io_update_hist_REG 
        = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__s1_update_bits_ghist;
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_1_1_io_update_hist_REG 
        = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__s1_update_bits_ghist;
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_2_1_io_update_hist_REG 
        = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__s1_update_bits_ghist;
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_3_1_io_update_hist_REG 
        = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__s1_update_bits_ghist;
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__697(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__697\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_4_1_io_update_hist_REG 
        = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__s1_update_bits_ghist;
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_5_1_io_update_hist_REG 
        = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__s1_update_bits_ghist;
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__io_core_clr_unsafe_0_valid_REG 
        = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__do_st_search_0;
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_542) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_0_ppred 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_ppred;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_0_fp_ctrl_sqrt 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fp_ctrl_sqrt;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_544) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_1_ppred 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_ppred;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_1_fp_ctrl_sqrt 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fp_ctrl_sqrt;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_546) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_2_ppred 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_ppred;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_548) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_3_ppred 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_ppred;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_550) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_4_ppred 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_ppred;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_552) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_5_ppred 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_ppred;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_554) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_6_ppred 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_ppred;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_556) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_7_ppred 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_ppred;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT___system_auto_cbus_fixedClockNode_anon_out_reset) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__cbus__DOT__out_xbar__DOT__state_3 = 0U;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__cbus__DOT__out_xbar__DOT__state_5 = 0U;
    } else if ((0U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__cbus__DOT__out_xbar__DOT__beatsLeft))) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__cbus__DOT__out_xbar__DOT__state_3 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__cbus__DOT__out_xbar__DOT__winner_3;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__cbus__DOT__out_xbar__DOT__state_5 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__cbus__DOT__out_xbar__DOT__winner_5;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__issue_slots_1_in_uop_valid) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__slots_1__DOT__slot_uop_prs2_busy 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT___slots_2_io_out_uop_prs2_busy;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__slots_1__DOT__slot_uop_iw_issued 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT___slots_2_io_out_uop_iw_issued;
    } else {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__slots_1__DOT__slot_uop_prs2_busy 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT___slots_1_io_out_uop_prs2_busy;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__slots_1__DOT__slot_uop_iw_issued 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT___slots_1_io_out_uop_iw_issued;
    }
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__immregfile__DOT__io_rrd_read_resps_2_REG 
        = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_exe_unit_1__DOT__arb_uop_bits_pimm;
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_valid 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_ld_val) 
           | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_st_val));
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__698(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__698\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_546) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_2_fp_ctrl_sqrt 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fp_ctrl_sqrt;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_2_fu_code_7 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fu_code_7;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_2_is_sfb 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_is_sfb;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_548) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_3_fp_ctrl_sqrt 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fp_ctrl_sqrt;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_3_fu_code_7 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fu_code_7;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_3_is_sfb 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_is_sfb;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_550) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_4_fp_ctrl_sqrt 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fp_ctrl_sqrt;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_4_fu_code_7 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fu_code_7;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_4_is_sfb 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_is_sfb;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_552) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_5_fp_ctrl_sqrt 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fp_ctrl_sqrt;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_5_fu_code_7 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fu_code_7;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_5_is_sfb 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_is_sfb;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_554) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_6_fp_ctrl_sqrt 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fp_ctrl_sqrt;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_6_fu_code_7 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fu_code_7;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_556) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_7_fp_ctrl_sqrt 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fp_ctrl_sqrt;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_7_fu_code_7 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fu_code_7;
    }
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__imm_rename_stage__DOT__freelist__DOT__com_deallocs_REG_2_bits 
        = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_exe_unit_1__DOT__rrd_uop_bits_pimm;
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_542) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_0_fu_code_7 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fu_code_7;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_0_is_sfb 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_is_sfb;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_544) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_1_fu_code_7 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fu_code_7;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_1_is_sfb 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_is_sfb;
    }
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__699(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__699\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_554) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_6_is_sfb 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_is_sfb;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_6_ldst_is_rs1 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_ldst_is_rs1;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_6_lrs1_rtype 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_lrs1_rtype;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_556) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_7_is_sfb 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_is_sfb;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_7_ldst_is_rs1 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_ldst_is_rs1;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_7_lrs1_rtype 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_lrs1_rtype;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_542) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_0_ldst_is_rs1 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_ldst_is_rs1;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_0_lrs1_rtype 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_lrs1_rtype;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_0_br_tag 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_br_tag;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_544) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_1_ldst_is_rs1 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_ldst_is_rs1;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_1_lrs1_rtype 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_lrs1_rtype;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_1_br_tag 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_br_tag;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_546) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_2_ldst_is_rs1 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_ldst_is_rs1;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_2_lrs1_rtype 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_lrs1_rtype;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_548) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_3_ldst_is_rs1 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_ldst_is_rs1;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_3_lrs1_rtype 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_lrs1_rtype;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_550) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_4_ldst_is_rs1 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_ldst_is_rs1;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_4_lrs1_rtype 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_lrs1_rtype;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_552) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_5_ldst_is_rs1 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_ldst_is_rs1;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_5_lrs1_rtype 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_lrs1_rtype;
    }
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__700(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__700\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_546) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_2_br_tag 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_br_tag;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_2_lrs2_rtype 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_lrs2_rtype;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_2_lrs1 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_lrs1;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_548) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_3_br_tag 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_br_tag;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_3_lrs2_rtype 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_lrs2_rtype;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_3_lrs1 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_lrs1;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_550) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_4_br_tag 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_br_tag;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_4_lrs2_rtype 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_lrs2_rtype;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_4_lrs1 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_lrs1;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_552) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_5_br_tag 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_br_tag;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_5_lrs2_rtype 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_lrs2_rtype;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_5_lrs1 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_lrs1;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_554) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_6_br_tag 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_br_tag;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_6_lrs2_rtype 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_lrs2_rtype;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_556) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_7_br_tag 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_br_tag;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_7_lrs2_rtype 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_lrs2_rtype;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_542) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_0_lrs2_rtype 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_lrs2_rtype;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_0_lrs1 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_lrs1;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_544) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_1_lrs2_rtype 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_lrs2_rtype;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_1_lrs1 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_lrs1;
    }
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__701(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__701\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_554) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_6_lrs1 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_lrs1;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_6_exc_cause 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_exc_cause;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_556) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_7_lrs1 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_lrs1;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_7_exc_cause 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_exc_cause;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT___system_auto_cbus_fixedClockNode_anon_out_reset) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__cbus__DOT__buffer__DOT__nodeIn_d_q__DOT__maybe_full = 0U;
    } else if (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__cbus__DOT__buffer__DOT__nodeIn_d_q__DOT__do_enq) 
                != (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__cbus__DOT__buffer__DOT__nodeIn_d_q__DOT__do_deq))) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__cbus__DOT__buffer__DOT__nodeIn_d_q__DOT__maybe_full 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__cbus__DOT__buffer__DOT__nodeIn_d_q__DOT__do_enq;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_542) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_0_exc_cause 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_exc_cause;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_0_fp_ctrl_typeTagOut 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fp_ctrl_typeTagOut;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_544) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_1_exc_cause 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_exc_cause;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_1_fp_ctrl_typeTagOut 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fp_ctrl_typeTagOut;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_546) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_2_exc_cause 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_exc_cause;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_2_fp_ctrl_typeTagOut 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fp_ctrl_typeTagOut;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_548) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_3_exc_cause 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_exc_cause;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_550) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_4_exc_cause 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_exc_cause;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_552) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_5_exc_cause 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_exc_cause;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__issue_slots_0_in_uop_valid) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__slots_0__DOT__slot_uop_prs1 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__slots_1__DOT__slot_uop_prs1;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__slots_0__DOT__slot_uop_prs2 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__slots_1__DOT__slot_uop_prs2;
    }
    if ((1U & (~ ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_6__DOT___GEN_96)) 
                  | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_6__DOT___new_meta_T))))) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_6__DOT__meta_way 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT___directory_io_result_bits_way;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__issue_slots_0_in_uop_valid) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_0__DOT__slot_uop_ppred_busy 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_1__DOT__slot_uop_ppred_busy;
    }
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__702(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__702\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_548) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_3_fp_ctrl_typeTagOut 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fp_ctrl_typeTagOut;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_550) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_4_fp_ctrl_typeTagOut 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fp_ctrl_typeTagOut;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_552) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_5_fp_ctrl_typeTagOut 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fp_ctrl_typeTagOut;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_554) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_6_fp_ctrl_typeTagOut 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fp_ctrl_typeTagOut;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_556) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_7_fp_ctrl_typeTagOut 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fp_ctrl_typeTagOut;
    }
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__p2_block_load_mask_7 
        = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__p1_block_load_mask_7;
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__p2_block_load_mask_6 
        = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__p1_block_load_mask_6;
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__p2_block_load_mask_5 
        = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__p1_block_load_mask_5;
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__p2_block_load_mask_4 
        = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__p1_block_load_mask_4;
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__p2_block_load_mask_3 
        = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__p1_block_load_mask_3;
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__p2_block_load_mask_2 
        = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__p1_block_load_mask_2;
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__p2_block_load_mask_1 
        = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__p1_block_load_mask_1;
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__p2_block_load_mask_0 
        = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__p1_block_load_mask_0;
    if (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___csr_wen_T_4) 
         & (0x7ffU == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___decoded_addr_decoded_decoded_andMatrixOutputs_T_81)))) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__reg_dscratch0 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__wdata;
    }
    if ((1U & (~ (((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__bim__DOT___GEN_0)) 
                   | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__bim__DOT__wrbypass_hit)) 
                  | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__bim__DOT__wrbypass_enq_idx))))) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__bim__DOT__wrbypass_idxs_0 
            = (0x7ffU & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__bim__DOT__s1_update_idx));
    }
    if ((1U & (~ (((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__bim__DOT___GEN_0)) 
                   | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__bim__DOT__wrbypass_hit)) 
                  | (~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__bim__DOT__wrbypass_enq_idx)))))) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__bim__DOT__wrbypass_idxs_1 
            = (0x7ffU & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__bim__DOT__s1_update_idx));
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__bim__DOT___GEN_0) {
        if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__bim__DOT__wrbypass_hit) {
            if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__bim__DOT__wrbypass_hits_0) {
                vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__bim__DOT__wrbypass_0_0 
                    = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__bim__DOT__s1_update_wdata_0;
                vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__bim__DOT__wrbypass_0_1 
                    = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__bim__DOT__s1_update_wdata_1;
                vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__bim__DOT__wrbypass_0_2 
                    = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__bim__DOT__s1_update_wdata_2;
                vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__bim__DOT__wrbypass_0_3 
                    = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__bim__DOT__s1_update_wdata_3;
            } else {
                vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__bim__DOT__wrbypass_1_0 
                    = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__bim__DOT__s1_update_wdata_0;
                vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__bim__DOT__wrbypass_1_1 
                    = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__bim__DOT__s1_update_wdata_1;
                vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__bim__DOT__wrbypass_1_2 
                    = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__bim__DOT__s1_update_wdata_2;
                vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__bim__DOT__wrbypass_1_3 
                    = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__bim__DOT__s1_update_wdata_3;
            }
        } else if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__bim__DOT__wrbypass_enq_idx) {
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__bim__DOT__wrbypass_1_0 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__bim__DOT__s1_update_wdata_0;
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__bim__DOT__wrbypass_1_1 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__bim__DOT__s1_update_wdata_1;
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__bim__DOT__wrbypass_1_2 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__bim__DOT__s1_update_wdata_2;
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__bim__DOT__wrbypass_1_3 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__bim__DOT__s1_update_wdata_3;
        } else {
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__bim__DOT__wrbypass_0_0 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__bim__DOT__s1_update_wdata_0;
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__bim__DOT__wrbypass_0_1 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__bim__DOT__s1_update_wdata_1;
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__bim__DOT__wrbypass_0_2 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__bim__DOT__s1_update_wdata_2;
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__bim__DOT__wrbypass_0_3 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__bim__DOT__s1_update_wdata_3;
        }
    }
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__703(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__703\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT___system_auto_cbus_fixedClockNode_anon_out_reset) {
        vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__bim__DOT__wrbypass_enq_idx = 0U;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__cork__DOT__state_1_2 = 0U;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__cork__DOT__state_1_1 = 0U;
    } else {
        if ((1U & (~ ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__bim__DOT___GEN_0)) 
                      | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__bim__DOT__wrbypass_hit))))) {
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__bim__DOT__wrbypass_enq_idx 
                = (1U & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__bim__DOT__wrbypass_enq_idx) 
                         - (IData)(1U)));
        }
        if ((0U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__cork__DOT__beatsLeft_1))) {
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__cork__DOT__state_1_2 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__cork__DOT__winner_1_2;
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__cork__DOT__state_1_1 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__cork__DOT__winner_1_1;
        }
    }
    if (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___csr_wen_T_4) 
         & (0xfffU == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___decoded_addr_decoded_decoded_andMatrixOutputs_T_55)))) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__reg_mtval 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___GEN_43;
    } else if ((1U & (~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___GEN_40)))) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__reg_mtval 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__tval;
    }
    if (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___csr_wen_T_4) 
         & (0xfffU == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___decoded_addr_decoded_decoded_andMatrixOutputs_T_52)))) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__reg_mscratch 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__wdata;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_542) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_0_fp_ctrl_ren2 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fp_ctrl_ren2;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_544) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_1_fp_ctrl_ren2 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fp_ctrl_ren2;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_546) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_2_fp_ctrl_ren2 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fp_ctrl_ren2;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_548) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_3_fp_ctrl_ren2 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fp_ctrl_ren2;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_550) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_4_fp_ctrl_ren2 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fp_ctrl_ren2;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_552) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_5_fp_ctrl_ren2 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fp_ctrl_ren2;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_554) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_6_fp_ctrl_ren2 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fp_ctrl_ren2;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_556) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_7_fp_ctrl_ren2 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fp_ctrl_ren2;
    }
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__704(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__704\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT___system_auto_cbus_fixedClockNode_anon_out_reset) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__cork__DOT__q__DOT__maybe_full = 0U;
    } else if (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__cork__DOT__q__DOT__do_enq) 
                != (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__cork__DOT__q__DOT__do_deq))) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__cork__DOT__q__DOT__maybe_full 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__cork__DOT__q__DOT__do_enq;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sourceD__DOT__s4_latch) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sourceD__DOT__s4_pdata_mask 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sourceD__DOT__s3_pdata_mask;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_134) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_uop_14_flush_on_commit 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rename_stage__DOT__r_uop_flush_on_commit;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_124) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_uop_4_flush_on_commit 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rename_stage__DOT__r_uop_flush_on_commit;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_145) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_uop_25_flush_on_commit 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rename_stage__DOT__r_uop_flush_on_commit;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_138) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_uop_18_flush_on_commit 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rename_stage__DOT__r_uop_flush_on_commit;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_123) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_uop_3_flush_on_commit 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rename_stage__DOT__r_uop_flush_on_commit;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_144) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_uop_24_flush_on_commit 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rename_stage__DOT__r_uop_flush_on_commit;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_129) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_uop_9_flush_on_commit 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rename_stage__DOT__r_uop_flush_on_commit;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_122) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_uop_2_flush_on_commit 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rename_stage__DOT__r_uop_flush_on_commit;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_143) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_uop_23_flush_on_commit 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rename_stage__DOT__r_uop_flush_on_commit;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_136) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_uop_16_flush_on_commit 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rename_stage__DOT__r_uop_flush_on_commit;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_128) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_uop_8_flush_on_commit 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rename_stage__DOT__r_uop_flush_on_commit;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_135) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_uop_15_flush_on_commit 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rename_stage__DOT__r_uop_flush_on_commit;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_120) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_uop_0_flush_on_commit 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rename_stage__DOT__r_uop_flush_on_commit;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_127) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_uop_7_flush_on_commit 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rename_stage__DOT__r_uop_flush_on_commit;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_148) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_uop_28_flush_on_commit 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rename_stage__DOT__r_uop_flush_on_commit;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_130) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_uop_10_flush_on_commit 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rename_stage__DOT__r_uop_flush_on_commit;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_141) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_uop_21_flush_on_commit 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rename_stage__DOT__r_uop_flush_on_commit;
    }
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__705(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__705\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_149) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_uop_29_flush_on_commit 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rename_stage__DOT__r_uop_flush_on_commit;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_132) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_uop_12_flush_on_commit 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rename_stage__DOT__r_uop_flush_on_commit;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_146) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_uop_26_flush_on_commit 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rename_stage__DOT__r_uop_flush_on_commit;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_151) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_uop_31_flush_on_commit 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rename_stage__DOT__r_uop_flush_on_commit;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_126) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_uop_6_flush_on_commit 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rename_stage__DOT__r_uop_flush_on_commit;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_147) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_uop_27_flush_on_commit 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rename_stage__DOT__r_uop_flush_on_commit;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_137) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_uop_17_flush_on_commit 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rename_stage__DOT__r_uop_flush_on_commit;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_131) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_uop_11_flush_on_commit 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rename_stage__DOT__r_uop_flush_on_commit;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_121) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_uop_1_flush_on_commit 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rename_stage__DOT__r_uop_flush_on_commit;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_142) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_uop_22_flush_on_commit 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rename_stage__DOT__r_uop_flush_on_commit;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_150) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_uop_30_flush_on_commit 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rename_stage__DOT__r_uop_flush_on_commit;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_139) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_uop_19_flush_on_commit 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rename_stage__DOT__r_uop_flush_on_commit;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_125) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_uop_5_flush_on_commit 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rename_stage__DOT__r_uop_flush_on_commit;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_140) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_uop_20_flush_on_commit 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rename_stage__DOT__r_uop_flush_on_commit;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_133) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_uop_13_flush_on_commit 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rename_stage__DOT__r_uop_flush_on_commit;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__issue_slots_0_in_uop_valid) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__slots_0__DOT__slot_uop_prs2_busy 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT___slots_1_io_out_uop_prs2_busy;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__slots_0__DOT__slot_uop_iw_issued 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT___slots_1_io_out_uop_iw_issued;
    } else {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__slots_0__DOT__slot_uop_prs2_busy 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__slots_0__DOT__io_out_uop_prs2_busy;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__slots_0__DOT__slot_uop_iw_issued 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__slots_0__DOT__io_out_uop_iw_issued;
    }
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr_io_counters_1_inc_REG 
        = (((3U == (3U & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__reg_hpmevent_1))) 
            | (2U == (3U & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__reg_hpmevent_1))))
            ? (0U != ((IData)((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__reg_hpmevent_1 
                               >> 8U)) & ((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT___ptw_io_dpath_perf_l2miss) 
                                            << 5U) 
                                           | (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT___lsu_io_core_perf_tlbMiss) 
                                               << 4U) 
                                              | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT___frontend_io_cpu_perf_tlbMiss) 
                                                 << 3U))) 
                                          | (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT___lsu_io_core_perf_release) 
                                              << 2U) 
                                             | (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT___lsu_io_core_perf_acquire) 
                                                 << 1U) 
                                                | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT___frontend_io_cpu_perf_acquire))))))
            : ((1U == (3U & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__reg_hpmevent_1)))
                ? (0U != ((IData)((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__reg_hpmevent_1 
                                   >> 9U)) & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___GEN_10)))
                : ((IData)((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__reg_hpmevent_1 
                            >> 8U)) & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___rob_io_com_xcpt_valid))));
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__706(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__706\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT__io_resp_f2_2_is_br_REG 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT__s1_resp_2_valid) 
           & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT___GEN_9));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT__io_resp_f2_1_is_br_REG 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT__s1_resp_1_valid) 
           & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT___GEN_7));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT__io_resp_f2_0_is_br_REG 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT__s1_resp_0_valid) 
           & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT___GEN_5));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT__io_resp_f2_3_is_br_REG 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT__s1_resp_3_valid) 
           & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT___GEN_11));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr_io_counters_0_inc_REG 
        = (((3U == (3U & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__reg_hpmevent_0))) 
            | (2U == (3U & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__reg_hpmevent_0))))
            ? (0U != ((IData)((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__reg_hpmevent_0 
                               >> 8U)) & ((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT___ptw_io_dpath_perf_l2miss) 
                                            << 5U) 
                                           | (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT___lsu_io_core_perf_tlbMiss) 
                                               << 4U) 
                                              | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT___frontend_io_cpu_perf_tlbMiss) 
                                                 << 3U))) 
                                          | (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT___lsu_io_core_perf_release) 
                                              << 2U) 
                                             | (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT___lsu_io_core_perf_acquire) 
                                                 << 1U) 
                                                | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT___frontend_io_cpu_perf_acquire))))))
            : ((1U == (3U & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__reg_hpmevent_0)))
                ? (0U != ((IData)((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__reg_hpmevent_0 
                                   >> 9U)) & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___GEN_10)))
                : ((IData)((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__reg_hpmevent_0 
                            >> 8U)) & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___rob_io_com_xcpt_valid))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__s3_provider_3 
        = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT___GEN_83;
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__s3_provider_2 
        = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT___GEN_67;
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__s3_provider_1 
        = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT___GEN_51;
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__s3_provider 
        = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT___GEN_34;
    if (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___csr_wen_T_4) 
         & (0x3ffU == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___decoded_addr_decoded_decoded_andMatrixOutputs_T_56)))) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__reg_mip_stip 
            = (1U & (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___new_mip_T_3) 
                      & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___new_mip_T_7)) 
                     >> 4U));
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__reg_mip_seip 
            = (1U & (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___new_mip_T_3) 
                      & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___new_mip_T_7)) 
                     >> 8U));
    }
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__707(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__707\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_542) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_0_iq_type_3 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_iq_type_3;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_0_fu_code_1 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fu_code_1;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_544) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_1_iq_type_3 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_iq_type_3;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_1_fu_code_1 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fu_code_1;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_546) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_2_iq_type_3 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_iq_type_3;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_2_fu_code_1 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fu_code_1;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_548) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_3_iq_type_3 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_iq_type_3;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_3_fu_code_1 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fu_code_1;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_550) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_4_iq_type_3 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_iq_type_3;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_4_fu_code_1 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fu_code_1;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_552) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_5_iq_type_3 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_iq_type_3;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_5_fu_code_1 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fu_code_1;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_554) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_6_iq_type_3 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_iq_type_3;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_556) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_7_iq_type_3 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_iq_type_3;
    }
    if ((1U & (~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__pred_rename_stage__DOT___GEN_20)))) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_rename_stage__DOT__r_uop_dst_rtype 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_dst_rtype;
    }
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__imm_rename_stage__DOT__freelist__DOT__com_deallocs_REG_1_bits 
        = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_exe_unit_0__DOT__rrd_uop_bits_pimm;
    if (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___csr_wen_T_4) 
         & (0xfffU == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___decoded_addr_decoded_decoded_andMatrixOutputs_T_80)))) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__reg_dpc 
            = (0xfffffffffeULL & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__wdata);
    } else if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___GEN_37) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__reg_dpc 
            = (0xfffffffffeULL & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT____Vcellinp__csr__io_pc);
    }
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__708(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__708\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_554) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_6_fu_code_1 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fu_code_1;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_556) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_7_fu_code_1 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fu_code_1;
    }
    if (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___csr_wen_T_4) 
         & (0xfffU == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___decoded_addr_decoded_decoded_andMatrixOutputs_T_53)))) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__reg_mepc 
            = (0xfffffffffeULL & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__wdata);
    } else if ((1U & (~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___GEN_40)))) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__reg_mepc 
            = (0xfffffffffeULL & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT____Vcellinp__csr__io_pc);
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT___system_auto_cbus_fixedClockNode_anon_out_reset) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__cork__DOT__state_1_0 = 0U;
    } else if ((0U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__cork__DOT__beatsLeft_1))) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__cork__DOT__state_1_0 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT___binder_auto_in_d_valid;
    }
    if ((1U & (~ (IData)(vlSelfRef.__VdfgRegularize_h36cfaf1a_0_20)))) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sinkD__DOT__io_bs_adr_bits_beat_r 
            = (7U & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sinkD__DOT__beat) 
                     + (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT___bankedStore_io_sinkD_adr_ready)));
    }
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__slots_4__DOT__slot_uop_prs1_busy 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__issue_slots_4_in_uop_valid)
            ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT___slots_5_io_out_uop_prs1_busy)
            : (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT___slots_4_io_out_uop_prs1_busy));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__wb_ldst_forward_e_REG_uop_stq_idx 
        = (0xfU & (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_90 
                   >> (0x1fU & VL_SHIFTL_III(5,32,32, 
                                             (7U & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__lcam_ldq_idx_0)), 2U))));
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_542) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_0_br_type 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_br_type;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_544) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_1_br_type 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_br_type;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_546) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_2_br_type 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_br_type;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_548) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_3_br_type 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_br_type;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_550) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_4_br_type 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_br_type;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_552) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_5_br_type 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_br_type;
    }
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__709(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__709\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_554) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_6_br_type 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_br_type;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_6_is_fencei 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_is_fencei;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_556) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_7_br_type 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_br_type;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_7_is_fencei 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_is_fencei;
    }
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__wb_ldst_forward_e_REG_observed 
        = (1U & ((((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__ldq_observed_7) 
                     << 7U) | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__ldq_observed_6) 
                               << 6U)) | (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__ldq_observed_5) 
                                           << 5U) | 
                                          ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__ldq_observed_4) 
                                           << 4U))) 
                  | ((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__ldq_observed_3) 
                       << 3U) | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__ldq_observed_2) 
                                 << 2U)) | (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__ldq_observed_1) 
                                             << 1U) 
                                            | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__ldq_observed_0)))) 
                 >> (7U & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__lcam_ldq_idx_0))));
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT___system_auto_cbus_fixedClockNode_anon_out_reset) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__reg_mstatus_tw = 0U;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__reg_mstatus_tsr = 0U;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__reg_mstatus_tvm = 0U;
    } else if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___GEN_34) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__reg_mstatus_tw 
            = (1U & (IData)((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__wdata 
                             >> 0x15U)));
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__reg_mstatus_tsr 
            = (1U & (IData)((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__wdata 
                             >> 0x16U)));
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__reg_mstatus_tvm 
            = (1U & (IData)((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__wdata 
                             >> 0x14U)));
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_542) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_0_is_fencei 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_is_fencei;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_544) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_1_is_fencei 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_is_fencei;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_546) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_2_is_fencei 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_is_fencei;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_548) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_3_is_fencei 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_is_fencei;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_550) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_4_is_fencei 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_is_fencei;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_552) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_5_is_fencei 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_is_fencei;
    }
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__710(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__710\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_542) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_0_fu_code_5 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fu_code_5;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_544) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_1_fu_code_5 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fu_code_5;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_546) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_2_fu_code_5 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fu_code_5;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_548) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_3_fu_code_5 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fu_code_5;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_550) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_4_fu_code_5 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fu_code_5;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_552) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_5_fu_code_5 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fu_code_5;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_554) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_6_fu_code_5 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fu_code_5;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_556) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_7_fu_code_5 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fu_code_5;
    }
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr_io_cause_REG 
        = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__r_xcpt_uop_exc_cause;
    if ((0U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__pbus__DOT__coupler_to_bootaddressreg__DOT__fragmenter__DOT__gennum))) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__pbus__DOT__coupler_to_bootaddressreg__DOT__fragmenter__DOT__aToggle_r 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__pbus__DOT__coupler_to_bootaddressreg__DOT__fragmenter__DOT__dToggle;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT___system_auto_cbus_fixedClockNode_anon_out_reset) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__io_ifpu_resp_queue__DOT__maybe_full = 0U;
    } else if (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__io_ifpu_resp_queue__DOT__do_enq) 
                != (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__io_ifpu_resp_queue__DOT__do_deq))) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__io_ifpu_resp_queue__DOT__maybe_full 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__io_ifpu_resp_queue__DOT__do_enq;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__io_fdiv_resp_fdivsqrt__DOT___GEN) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__io_fdiv_resp_fdivsqrt__DOT__r_req_bits_uop_pdst 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__exe_uop_bits_pdst;
    }
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__wb_ldst_forward_e_REG_next_stq_idx 
        = (0xfU & (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_138 
                   >> (0x1fU & VL_SHIFTL_III(5,32,32, 
                                             (7U & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__lcam_ldq_idx_0)), 2U))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT__io_resp_f2_0_predicted_pc_REG_bits 
        = (0xffffffffffULL & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT__s1_hit_ohs_0_0)
                               ? ((1U & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT___btb_data_way_0_R0_data))
                                   ? vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT___btb_ebtb_R0_data
                                   : (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT__s1_pc 
                                      + (((QData)((IData)(
                                                          (0x7ffffffU 
                                                           & (- (IData)(
                                                                        (1U 
                                                                         & (IData)(
                                                                                (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT___btb_data_way_0_R0_data 
                                                                                >> 0xdU)))))))) 
                                          << 0xdU) 
                                         | (QData)((IData)(
                                                           (0x1fffU 
                                                            & (IData)(
                                                                      (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT___btb_data_way_0_R0_data 
                                                                       >> 1U))))))))
                               : ((1U & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT___btb_data_way_1_R0_data))
                                   ? vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT___btb_ebtb_R0_data
                                   : (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT__s1_pc 
                                      + (((QData)((IData)(
                                                          (0x7ffffffU 
                                                           & (- (IData)(
                                                                        (1U 
                                                                         & (IData)(
                                                                                (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT___btb_data_way_1_R0_data 
                                                                                >> 0xdU)))))))) 
                                          << 0xdU) 
                                         | (QData)((IData)(
                                                           (0x1fffU 
                                                            & (IData)(
                                                                      (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT___btb_data_way_1_R0_data 
                                                                       >> 1U))))))))));
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__711(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__711\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT__io_resp_f2_1_predicted_pc_REG_bits 
        = (0xffffffffffULL & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT__s1_hit_ohs_1_0)
                               ? ((1U & (IData)((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT___btb_data_way_0_R0_data 
                                                 >> 0xeU)))
                                   ? vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT___btb_ebtb_R0_data
                                   : (2ULL + (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT__s1_pc 
                                              + (((QData)((IData)(
                                                                  (0x7ffffffU 
                                                                   & (- (IData)(
                                                                                (1U 
                                                                                & (IData)(
                                                                                (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT___btb_data_way_0_R0_data 
                                                                                >> 0x1bU)))))))) 
                                                  << 0xdU) 
                                                 | (QData)((IData)(
                                                                   (0x1fffU 
                                                                    & (IData)(
                                                                              (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT___btb_data_way_0_R0_data 
                                                                               >> 0xfU)))))))))
                               : ((1U & (IData)((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT___btb_data_way_1_R0_data 
                                                 >> 0xeU)))
                                   ? vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT___btb_ebtb_R0_data
                                   : (2ULL + (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT__s1_pc 
                                              + (((QData)((IData)(
                                                                  (0x7ffffffU 
                                                                   & (- (IData)(
                                                                                (1U 
                                                                                & (IData)(
                                                                                (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT___btb_data_way_1_R0_data 
                                                                                >> 0x1bU)))))))) 
                                                  << 0xdU) 
                                                 | (QData)((IData)(
                                                                   (0x1fffU 
                                                                    & (IData)(
                                                                              (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT___btb_data_way_1_R0_data 
                                                                               >> 0xfU)))))))))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT__io_resp_f2_2_predicted_pc_REG_bits 
        = (0xffffffffffULL & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT__s1_hit_ohs_2_0)
                               ? ((1U & (IData)((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT___btb_data_way_0_R0_data 
                                                 >> 0x1cU)))
                                   ? vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT___btb_ebtb_R0_data
                                   : (4ULL + (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT__s1_pc 
                                              + (((QData)((IData)(
                                                                  (0x7ffffffU 
                                                                   & (- (IData)(
                                                                                (1U 
                                                                                & (IData)(
                                                                                (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT___btb_data_way_0_R0_data 
                                                                                >> 0x29U)))))))) 
                                                  << 0xdU) 
                                                 | (QData)((IData)(
                                                                   (0x1fffU 
                                                                    & (IData)(
                                                                              (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT___btb_data_way_0_R0_data 
                                                                               >> 0x1dU)))))))))
                               : ((1U & (IData)((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT___btb_data_way_1_R0_data 
                                                 >> 0x1cU)))
                                   ? vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT___btb_ebtb_R0_data
                                   : (4ULL + (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT__s1_pc 
                                              + (((QData)((IData)(
                                                                  (0x7ffffffU 
                                                                   & (- (IData)(
                                                                                (1U 
                                                                                & (IData)(
                                                                                (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT___btb_data_way_1_R0_data 
                                                                                >> 0x29U)))))))) 
                                                  << 0xdU) 
                                                 | (QData)((IData)(
                                                                   (0x1fffU 
                                                                    & (IData)(
                                                                              (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT___btb_data_way_1_R0_data 
                                                                               >> 0x1dU)))))))))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT__io_resp_f2_3_predicted_pc_REG_bits 
        = (0xffffffffffULL & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT__s1_hit_ohs_3_0)
                               ? ((1U & (IData)((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT___btb_data_way_0_R0_data 
                                                 >> 0x2aU)))
                                   ? vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT___btb_ebtb_R0_data
                                   : (6ULL + (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT__s1_pc 
                                              + (((QData)((IData)(
                                                                  (0x7ffffffU 
                                                                   & (- (IData)(
                                                                                (1U 
                                                                                & (IData)(
                                                                                (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT___btb_data_way_0_R0_data 
                                                                                >> 0x37U)))))))) 
                                                  << 0xdU) 
                                                 | (QData)((IData)(
                                                                   (0x1fffU 
                                                                    & (IData)(
                                                                              (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT___btb_data_way_0_R0_data 
                                                                               >> 0x2bU)))))))))
                               : ((1U & (IData)((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT___btb_data_way_1_R0_data 
                                                 >> 0x2aU)))
                                   ? vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT___btb_ebtb_R0_data
                                   : (6ULL + (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT__s1_pc 
                                              + (((QData)((IData)(
                                                                  (0x7ffffffU 
                                                                   & (- (IData)(
                                                                                (1U 
                                                                                & (IData)(
                                                                                (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT___btb_data_way_1_R0_data 
                                                                                >> 0x37U)))))))) 
                                                  << 0xdU) 
                                                 | (QData)((IData)(
                                                                   (0x1fffU 
                                                                    & (IData)(
                                                                              (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT___btb_data_way_1_R0_data 
                                                                               >> 0x2bU)))))))))));
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__712(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__712\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__wakeupArbs_0_io_in_1_valid_REG 
        = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dmem_req_fire_0;
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_stq_oh_6 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_st_val) 
           & (6U == (7U & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_tail))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_stq_oh_5 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_st_val) 
           & (5U == (7U & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_tail))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_stq_oh_4 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_st_val) 
           & (4U == (7U & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_tail))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_stq_oh_2 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_st_val) 
           & (2U == (7U & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_tail))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_stq_oh_0 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_st_val) 
           & (0U == (7U & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_tail))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_stq_oh_3 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_st_val) 
           & (3U == (7U & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_tail))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_stq_oh_1 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_st_val) 
           & (1U == (7U & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_tail))));
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__io_ifpu_resp_queue__DOT___GEN_15) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__io_ifpu_resp_queue__DOT__uops_5_pdst 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__io_ifpu_resp_ifpu__DOT__pipe__DOT__uops_1_bits_uop_pdst;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__io_ifpu_resp_queue__DOT___GEN_9) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__io_ifpu_resp_queue__DOT__uops_2_pdst 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__io_ifpu_resp_ifpu__DOT__pipe__DOT__uops_1_bits_uop_pdst;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__io_ifpu_resp_queue__DOT___GEN_11) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__io_ifpu_resp_queue__DOT__uops_3_pdst 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__io_ifpu_resp_ifpu__DOT__pipe__DOT__uops_1_bits_uop_pdst;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__io_ifpu_resp_queue__DOT___GEN_13) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__io_ifpu_resp_queue__DOT__uops_4_pdst 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__io_ifpu_resp_ifpu__DOT__pipe__DOT__uops_1_bits_uop_pdst;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__io_ifpu_resp_queue__DOT___GEN_5) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__io_ifpu_resp_queue__DOT__uops_0_pdst 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__io_ifpu_resp_ifpu__DOT__pipe__DOT__uops_1_bits_uop_pdst;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__io_ifpu_resp_queue__DOT___GEN_7) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__io_ifpu_resp_queue__DOT__uops_1_pdst 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__io_ifpu_resp_ifpu__DOT__pipe__DOT__uops_1_bits_uop_pdst;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__io_ifpu_resp_queue__DOT___GEN_17) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__io_ifpu_resp_queue__DOT__uops_6_pdst 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__io_ifpu_resp_ifpu__DOT__pipe__DOT__uops_1_bits_uop_pdst;
    }
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__713(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__713\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__io_ifpu_resp_queue__DOT___GEN_18) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__io_ifpu_resp_queue__DOT__uops_7_pdst 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__io_ifpu_resp_ifpu__DOT__pipe__DOT__uops_1_bits_uop_pdst;
    }
    if ((0U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__chipyard_prcictrl_domain__DOT__fragmenter__DOT__gennum))) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__chipyard_prcictrl_domain__DOT__fragmenter__DOT__aToggle_r 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__chipyard_prcictrl_domain__DOT__fragmenter__DOT__dToggle;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT___system_auto_cbus_fixedClockNode_anon_out_reset) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__cbus__DOT__in_xbar__DOT__state_1 = 0U;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__cbus__DOT__wrapped_error_device__DOT__buffer__DOT__nodeIn_d_q__DOT__maybe_full = 0U;
    } else {
        if ((0U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__cbus__DOT__in_xbar__DOT__beatsLeft))) {
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__cbus__DOT__in_xbar__DOT__state_1 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__cbus__DOT__in_xbar__DOT__winner_1;
        }
        if (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__cbus__DOT__wrapped_error_device__DOT__buffer__DOT__nodeIn_d_q__DOT__do_enq) 
             != (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__cbus__DOT__wrapped_error_device__DOT__buffer__DOT__nodeIn_d_q__DOT__do_deq))) {
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__cbus__DOT__wrapped_error_device__DOT__buffer__DOT__nodeIn_d_q__DOT__maybe_full 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__cbus__DOT__wrapped_error_device__DOT__buffer__DOT__nodeIn_d_q__DOT__do_enq;
        }
    }
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT__io_resp_f3_2_predicted_pc_REG_bits 
        = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___bpd_io_resp_f2_preds_2_predicted_pc_bits;
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT__io_resp_f3_1_predicted_pc_REG_bits 
        = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___bpd_io_resp_f2_preds_1_predicted_pc_bits;
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT__io_resp_f3_3_predicted_pc_REG_bits 
        = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___bpd_io_resp_f2_preds_3_predicted_pc_bits;
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT__io_resp_f3_0_predicted_pc_REG_bits 
        = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___bpd_io_resp_f2_preds_0_predicted_pc_bits;
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__ftq__DOT__do_commit_update_REG 
        = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT___core_io_ifu_redirect_val;
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__ftq__DOT__io_ras_update_REG 
        = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT___core_io_ifu_redirect_val;
    if ((0U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__chipyard_prcictrl_domain__DOT__fragmenter_1__DOT__gennum))) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__chipyard_prcictrl_domain__DOT__fragmenter_1__DOT__aToggle_r 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__chipyard_prcictrl_domain__DOT__fragmenter_1__DOT__dToggle;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT___core_io_ifu_redirect_val) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__ftq__DOT__io_ras_update_pc_REG 
            = ((0x27fU >= (0x3ffU & ((IData)(0x28U) 
                                     * (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT___core_io_ifu_redirect_ftq_idx))))
                ? (0xffffffffffULL & (((QData)((IData)(
                                                       vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__ftq__DOT___GEN_34[
                                                       (((IData)(0x27U) 
                                                         + 
                                                         (0x3ffU 
                                                          & ((IData)(0x28U) 
                                                             * (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT___core_io_ifu_redirect_ftq_idx)))) 
                                                        >> 5U)])) 
                                       << ((0U == (0x1fU 
                                                   & ((IData)(0x28U) 
                                                      * (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT___core_io_ifu_redirect_ftq_idx))))
                                            ? 0x20U
                                            : ((IData)(0x40U) 
                                               - (0x1fU 
                                                  & ((IData)(0x28U) 
                                                     * (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT___core_io_ifu_redirect_ftq_idx)))))) 
                                      | (((0U == (0x1fU 
                                                  & ((IData)(0x28U) 
                                                     * (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT___core_io_ifu_redirect_ftq_idx))))
                                           ? 0ULL : 
                                          ((QData)((IData)(
                                                           vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__ftq__DOT___GEN_34[
                                                           (((IData)(0x1fU) 
                                                             + 
                                                             (0x3ffU 
                                                              & ((IData)(0x28U) 
                                                                 * (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT___core_io_ifu_redirect_ftq_idx)))) 
                                                            >> 5U)])) 
                                           << ((IData)(0x20U) 
                                               - (0x1fU 
                                                  & ((IData)(0x28U) 
                                                     * (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT___core_io_ifu_redirect_ftq_idx)))))) 
                                         | ((QData)((IData)(
                                                            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__ftq__DOT___GEN_34[
                                                            (0x1fU 
                                                             & (((IData)(0x28U) 
                                                                 * (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT___core_io_ifu_redirect_ftq_idx)) 
                                                                >> 5U))])) 
                                            >> (0x1fU 
                                                & ((IData)(0x28U) 
                                                   * (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT___core_io_ifu_redirect_ftq_idx)))))))
                : 0ULL);
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__ftq__DOT__io_ras_update_idx_REG 
            = ((0x4fU >= (0x7fU & ((IData)(5U) * (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT___core_io_ifu_redirect_ftq_idx))))
                ? (0x1fU & (((0U == (0x1fU & ((IData)(5U) 
                                              * (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT___core_io_ifu_redirect_ftq_idx))))
                              ? 0U : (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__ftq__DOT___GEN_35[
                                      (((IData)(4U) 
                                        + (0x7fU & 
                                           ((IData)(5U) 
                                            * (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT___core_io_ifu_redirect_ftq_idx)))) 
                                       >> 5U)] << ((IData)(0x20U) 
                                                   - 
                                                   (0x1fU 
                                                    & ((IData)(5U) 
                                                       * (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT___core_io_ifu_redirect_ftq_idx)))))) 
                            | (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__ftq__DOT___GEN_35[
                               (3U & (((IData)(5U) 
                                       * (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT___core_io_ifu_redirect_ftq_idx)) 
                                      >> 5U))] >> (0x1fU 
                                                   & ((IData)(5U) 
                                                      * (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT___core_io_ifu_redirect_ftq_idx))))))
                : 0U);
    } else {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__ftq__DOT__io_ras_update_pc_REG = 0ULL;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__ftq__DOT__io_ras_update_idx_REG = 0U;
    }
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__714(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__714\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__io_fdiv_resp_fdivsqrt__DOT___GEN) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__io_fdiv_resp_fdivsqrt__DOT__r_sigs_div 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__exe_uop_bits_fp_ctrl_div;
    }
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__mem_ldq_wakeup_e_bits_uop_mem_size 
        = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_257;
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_542) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_0_flush_on_commit 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_flush_on_commit;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_544) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_1_flush_on_commit 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_flush_on_commit;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_546) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_2_flush_on_commit 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_flush_on_commit;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_548) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_3_flush_on_commit 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_flush_on_commit;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_550) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_4_flush_on_commit 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_flush_on_commit;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_552) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_5_flush_on_commit 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_flush_on_commit;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_554) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_6_flush_on_commit 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_flush_on_commit;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_556) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_7_flush_on_commit 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_flush_on_commit;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__issue_slots_0_in_uop_valid) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__slots_0__DOT__slot_uop_iw_issued_partial_agen 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT___slots_1_io_out_uop_iw_issued_partial_agen;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__slots_0__DOT__slot_uop_iw_issued_partial_dgen 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT___slots_1_io_out_uop_iw_issued_partial_dgen;
    } else {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__slots_0__DOT__slot_uop_iw_issued_partial_agen 
            = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__slots_0__DOT___GEN_3) 
               & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__slots_0__DOT__agen_ready) 
                  & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__slots_0__DOT__io_out_uop_iw_issued)));
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__slots_0__DOT__slot_uop_iw_issued_partial_dgen 
            = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__slots_0__DOT___GEN_3) 
               & ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__slots_0__DOT__agen_ready)) 
                  & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__slots_0__DOT__io_out_uop_iw_issued)));
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT___system_auto_cbus_fixedClockNode_anon_out_reset) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__reg_dcsr_step = 0U;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__reg_dcsr_cause = 0U;
    } else {
        if (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___csr_wen_T_4) 
             & (0xfffU == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___decoded_addr_decoded_decoded_andMatrixOutputs_T_79)))) {
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__reg_dcsr_step 
                = (1U & ((IData)((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___wdata_T_2 
                                  >> 2U)) & (IData)(
                                                    (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___wdata_T_6 
                                                     >> 2U))));
        }
        if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___GEN_37) {
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__reg_dcsr_cause 
                = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__reg_singleStepped)
                    ? 4U : ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__causeIsDebugInt)
                             ? 3U : ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__causeIsDebugTrigger)
                                      ? 2U : 1U)));
        }
    }
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__715(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__715\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__reg_singleStepped 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___csr_io_singleStep) 
           & (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr_io_retire_REG) 
               | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__exception)) 
              | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__reg_singleStepped)));
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__fpu__DOT__fpu__DOT____Vcellinp__dfma__io_in_valid) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__fpu__DOT__fpu__DOT__dfma__DOT__in_fmaCmd 
            = (3U & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__exe_uop_bits_fcn_op));
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__fpu__DOT__fpu__DOT____Vcellinp__sfma__io_in_valid) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__fpu__DOT__fpu__DOT__sfma__DOT__in_fmaCmd 
            = (3U & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__exe_uop_bits_fcn_op));
    }
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__slots_3__DOT__slot_uop_prs1_busy 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__issue_slots_3_in_uop_valid)
            ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT___slots_4_io_out_uop_prs1_busy)
            : (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT___slots_3_io_out_uop_prs1_busy));
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_13) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__ldq_uop_0_is_amo 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_is_amo;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_14) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__ldq_uop_1_is_amo 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_is_amo;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_15) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__ldq_uop_2_is_amo 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_is_amo;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_16) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__ldq_uop_3_is_amo 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_is_amo;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_17) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__ldq_uop_4_is_amo 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_is_amo;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_18) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__ldq_uop_5_is_amo 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_is_amo;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_19) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__ldq_uop_6_is_amo 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_is_amo;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_20) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__ldq_uop_7_is_amo 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_is_amo;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_542) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_0_is_amo 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_is_amo;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_544) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_1_is_amo 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_is_amo;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_546) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_2_is_amo 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_is_amo;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_548) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_3_is_amo 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_is_amo;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_550) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_4_is_amo 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_is_amo;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_552) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_5_is_amo 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_is_amo;
    }
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__716(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__716\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_554) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_6_is_amo 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_is_amo;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_556) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_7_is_amo 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_is_amo;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT___system_auto_cbus_fixedClockNode_anon_out_reset) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__cbus__DOT__in_xbar__DOT__state_0 = 0U;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__reg_mstatus_mxr = 0U;
    } else {
        if ((0U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__cbus__DOT__in_xbar__DOT__beatsLeft))) {
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__cbus__DOT__in_xbar__DOT__state_0 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__cbus__DOT__in_xbar__DOT__winner_0;
        }
        if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___csr_wen_T_4) {
            if ((0x3ffU == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___decoded_addr_decoded_decoded_andMatrixOutputs_T_3))) {
                vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__reg_mstatus_mxr 
                    = (1U & (IData)((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__wdata 
                                     >> 0x13U)));
            } else if ((0xfffU == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___decoded_addr_decoded_decoded_andMatrixOutputs_T_14))) {
                vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__reg_mstatus_mxr 
                    = (1U & (IData)((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__wdata 
                                     >> 0x13U)));
            }
        }
    }
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__reg_mstatus_spie 
        = ((1U & (~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT___system_auto_cbus_fixedClockNode_anon_out_reset))) 
           && (1U & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___csr_wen_T_4)
                      ? ((0x3ffU == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___decoded_addr_decoded_decoded_andMatrixOutputs_T_3))
                          ? (IData)((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__wdata 
                                     >> 5U)) : ((0xfffU 
                                                 == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___decoded_addr_decoded_decoded_andMatrixOutputs_T_14))
                                                 ? (IData)(
                                                           (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__wdata 
                                                            >> 5U))
                                                 : (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___GEN_57)))
                      : (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___GEN_57))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__reg_mstatus_spp 
        = ((1U & (~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT___system_auto_cbus_fixedClockNode_anon_out_reset))) 
           && (1U & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___csr_wen_T_4)
                      ? ((0x3ffU == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___decoded_addr_decoded_decoded_andMatrixOutputs_T_3))
                          ? (IData)((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__wdata 
                                     >> 8U)) : ((0xfffU 
                                                 == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___decoded_addr_decoded_decoded_andMatrixOutputs_T_14))
                                                 ? (IData)(
                                                           (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__wdata 
                                                            >> 8U))
                                                 : (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___GEN_58)))
                      : (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___GEN_58))));
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_576) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__ldq_ld_byte_mask_7 
            = (0xffU & (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_577 
                        >> (0x1fU & VL_SHIFTL_III(5,32,32, (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__exe_tlb_uop_0_mem_size), 3U))));
    }
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__717(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__717\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__loop__DOT__columns_3__DOT__f4_fire 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__loop__DOT__s3_valid) 
           & (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__loop__DOT__s3_mask) 
               >> 3U) & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__loop__DOT__columns_3_io_f3_req_fire_REG) 
                         & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT____Vcellinp__bpd__io_f3_fire))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__reg_mstatus_sie 
        = ((1U & (~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT___system_auto_cbus_fixedClockNode_anon_out_reset))) 
           && (1U & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___csr_wen_T_4)
                      ? ((0x3ffU == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___decoded_addr_decoded_decoded_andMatrixOutputs_T_3))
                          ? (IData)((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__wdata 
                                     >> 1U)) : ((0xfffU 
                                                 == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___decoded_addr_decoded_decoded_andMatrixOutputs_T_14))
                                                 ? (IData)(
                                                           (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__wdata 
                                                            >> 1U))
                                                 : (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___GEN_56)))
                      : (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___GEN_56))));
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_569) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__ldq_ld_byte_mask_0 
            = (0xffU & (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_577 
                        >> (0x1fU & VL_SHIFTL_III(5,32,32, (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__exe_tlb_uop_0_mem_size), 3U))));
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_575) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__ldq_ld_byte_mask_6 
            = (0xffU & (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_577 
                        >> (0x1fU & VL_SHIFTL_III(5,32,32, (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__exe_tlb_uop_0_mem_size), 3U))));
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_574) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__ldq_ld_byte_mask_5 
            = (0xffU & (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_577 
                        >> (0x1fU & VL_SHIFTL_III(5,32,32, (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__exe_tlb_uop_0_mem_size), 3U))));
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_573) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__ldq_ld_byte_mask_4 
            = (0xffU & (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_577 
                        >> (0x1fU & VL_SHIFTL_III(5,32,32, (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__exe_tlb_uop_0_mem_size), 3U))));
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_125) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_uop_5_dst_rtype 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rename_stage__DOT__r_uop_dst_rtype;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_122) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_uop_2_dst_rtype 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rename_stage__DOT__r_uop_dst_rtype;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_121) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_uop_1_dst_rtype 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rename_stage__DOT__r_uop_dst_rtype;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_134) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_uop_14_dst_rtype 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rename_stage__DOT__r_uop_dst_rtype;
    }
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__718(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__718\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_124) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_uop_4_dst_rtype 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rename_stage__DOT__r_uop_dst_rtype;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_143) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_uop_23_dst_rtype 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rename_stage__DOT__r_uop_dst_rtype;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_150) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_uop_30_dst_rtype 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rename_stage__DOT__r_uop_dst_rtype;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_142) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_uop_22_dst_rtype 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rename_stage__DOT__r_uop_dst_rtype;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_135) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_uop_15_dst_rtype 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rename_stage__DOT__r_uop_dst_rtype;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_149) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_uop_29_dst_rtype 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rename_stage__DOT__r_uop_dst_rtype;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_127) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_uop_7_dst_rtype 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rename_stage__DOT__r_uop_dst_rtype;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_137) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_uop_17_dst_rtype 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rename_stage__DOT__r_uop_dst_rtype;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_120) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_uop_0_dst_rtype 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rename_stage__DOT__r_uop_dst_rtype;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_139) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_uop_19_dst_rtype 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rename_stage__DOT__r_uop_dst_rtype;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_123) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_uop_3_dst_rtype 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rename_stage__DOT__r_uop_dst_rtype;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_144) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_uop_24_dst_rtype 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rename_stage__DOT__r_uop_dst_rtype;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_148) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_uop_28_dst_rtype 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rename_stage__DOT__r_uop_dst_rtype;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_138) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_uop_18_dst_rtype 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rename_stage__DOT__r_uop_dst_rtype;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_151) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_uop_31_dst_rtype 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rename_stage__DOT__r_uop_dst_rtype;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_145) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_uop_25_dst_rtype 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rename_stage__DOT__r_uop_dst_rtype;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_131) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_uop_11_dst_rtype 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rename_stage__DOT__r_uop_dst_rtype;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_136) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_uop_16_dst_rtype 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rename_stage__DOT__r_uop_dst_rtype;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_146) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_uop_26_dst_rtype 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rename_stage__DOT__r_uop_dst_rtype;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_140) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_uop_20_dst_rtype 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rename_stage__DOT__r_uop_dst_rtype;
    }
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__719(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__719\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_126) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_uop_6_dst_rtype 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rename_stage__DOT__r_uop_dst_rtype;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_147) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_uop_27_dst_rtype 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rename_stage__DOT__r_uop_dst_rtype;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_141) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_uop_21_dst_rtype 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rename_stage__DOT__r_uop_dst_rtype;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_128) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_uop_8_dst_rtype 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rename_stage__DOT__r_uop_dst_rtype;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_129) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_uop_9_dst_rtype 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rename_stage__DOT__r_uop_dst_rtype;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_130) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_uop_10_dst_rtype 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rename_stage__DOT__r_uop_dst_rtype;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_132) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_uop_12_dst_rtype 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rename_stage__DOT__r_uop_dst_rtype;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_133) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_uop_13_dst_rtype 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rename_stage__DOT__r_uop_dst_rtype;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_571) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__ldq_ld_byte_mask_2 
            = (0xffU & (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_577 
                        >> (0x1fU & VL_SHIFTL_III(5,32,32, (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__exe_tlb_uop_0_mem_size), 3U))));
    }
    if ((1U & (~ (IData)(vlSelfRef.__VdfgRegularize_h36cfaf1a_0_20)))) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sinkD__DOT__io_source_r 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT___sinkD_io_resp_bits_source;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_572) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__ldq_ld_byte_mask_3 
            = (0xffU & (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_577 
                        >> (0x1fU & VL_SHIFTL_III(5,32,32, (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__exe_tlb_uop_0_mem_size), 3U))));
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_570) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__ldq_ld_byte_mask_1 
            = (0xffU & (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_577 
                        >> (0x1fU & VL_SHIFTL_III(5,32,32, (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__exe_tlb_uop_0_mem_size), 3U))));
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT___system_auto_cbus_fixedClockNode_anon_out_reset) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__reg_mtvec = 0U;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__reg_mstatus_sum = 0U;
    } else {
        if (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___csr_wen_T_4) 
             & (0xfffU == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___decoded_addr_decoded_decoded_andMatrixOutputs_T_19)))) {
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__reg_mtvec 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___GEN_42;
        }
        if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___csr_wen_T_4) {
            if ((0x3ffU == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___decoded_addr_decoded_decoded_andMatrixOutputs_T_3))) {
                vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__reg_mstatus_sum 
                    = (1U & (IData)((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__wdata 
                                     >> 0x12U)));
            } else if ((0xfffU == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___decoded_addr_decoded_decoded_andMatrixOutputs_T_14))) {
                vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__reg_mstatus_sum 
                    = (1U & (IData)((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__wdata 
                                     >> 0x12U)));
            }
        }
    }
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__720(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__720\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_0_1_io_update_old_ctr_0_REG 
        = (7U & (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__s1_update_bits_meta[0U] 
                 >> 0x10U));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_0_1_io_update_old_ctr_1_REG 
        = (7U & (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__s1_update_bits_meta[0U] 
                 >> 0x13U));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_0_1_io_update_old_ctr_2_REG 
        = (7U & (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__s1_update_bits_meta[0U] 
                 >> 0x16U));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_0_1_io_update_old_ctr_3_REG 
        = (7U & (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__s1_update_bits_meta[0U] 
                 >> 0x19U));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_1_1_io_update_old_ctr_0_REG 
        = (7U & (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__s1_update_bits_meta[0U] 
                 >> 0x10U));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_1_1_io_update_old_ctr_1_REG 
        = (7U & (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__s1_update_bits_meta[0U] 
                 >> 0x13U));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_1_1_io_update_old_ctr_2_REG 
        = (7U & (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__s1_update_bits_meta[0U] 
                 >> 0x16U));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_1_1_io_update_old_ctr_3_REG 
        = (7U & (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__s1_update_bits_meta[0U] 
                 >> 0x19U));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_2_1_io_update_old_ctr_0_REG 
        = (7U & (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__s1_update_bits_meta[0U] 
                 >> 0x10U));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_2_1_io_update_old_ctr_1_REG 
        = (7U & (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__s1_update_bits_meta[0U] 
                 >> 0x13U));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_2_1_io_update_old_ctr_2_REG 
        = (7U & (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__s1_update_bits_meta[0U] 
                 >> 0x16U));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_2_1_io_update_old_ctr_3_REG 
        = (7U & (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__s1_update_bits_meta[0U] 
                 >> 0x19U));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_3_1_io_update_old_ctr_0_REG 
        = (7U & (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__s1_update_bits_meta[0U] 
                 >> 0x10U));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_3_1_io_update_old_ctr_1_REG 
        = (7U & (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__s1_update_bits_meta[0U] 
                 >> 0x13U));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_3_1_io_update_old_ctr_2_REG 
        = (7U & (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__s1_update_bits_meta[0U] 
                 >> 0x16U));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_3_1_io_update_old_ctr_3_REG 
        = (7U & (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__s1_update_bits_meta[0U] 
                 >> 0x19U));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_4_1_io_update_old_ctr_0_REG 
        = (7U & (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__s1_update_bits_meta[0U] 
                 >> 0x10U));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_4_1_io_update_old_ctr_1_REG 
        = (7U & (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__s1_update_bits_meta[0U] 
                 >> 0x13U));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_4_1_io_update_old_ctr_2_REG 
        = (7U & (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__s1_update_bits_meta[0U] 
                 >> 0x16U));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_4_1_io_update_old_ctr_3_REG 
        = (7U & (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__s1_update_bits_meta[0U] 
                 >> 0x19U));
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__721(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__721\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_5_1_io_update_old_ctr_0_REG 
        = (7U & (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__s1_update_bits_meta[0U] 
                 >> 0x10U));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_5_1_io_update_old_ctr_1_REG 
        = (7U & (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__s1_update_bits_meta[0U] 
                 >> 0x13U));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_5_1_io_update_old_ctr_2_REG 
        = (7U & (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__s1_update_bits_meta[0U] 
                 >> 0x16U));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_5_1_io_update_old_ctr_3_REG 
        = (7U & (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__s1_update_bits_meta[0U] 
                 >> 0x19U));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_0_1_io_update_alloc_1_REG 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT___GEN_157) 
           & (1U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__s1_update_bits_cfi_idx_bits)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_2_1_io_update_alloc_1_REG 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT___GEN_159) 
           & (1U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__s1_update_bits_cfi_idx_bits)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_0_1_io_update_alloc_2_REG 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT___GEN_157) 
           & (2U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__s1_update_bits_cfi_idx_bits)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_1_1_io_update_alloc_2_REG 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT___GEN_158) 
           & (2U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__s1_update_bits_cfi_idx_bits)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_4_1_io_update_alloc_1_REG 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT___GEN_161) 
           & (1U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__s1_update_bits_cfi_idx_bits)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_3_1_io_update_alloc_2_REG 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT___GEN_160) 
           & (2U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__s1_update_bits_cfi_idx_bits)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_1_1_io_update_alloc_1_REG 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT___GEN_158) 
           & (1U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__s1_update_bits_cfi_idx_bits)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_4_1_io_update_alloc_2_REG 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT___GEN_161) 
           & (2U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__s1_update_bits_cfi_idx_bits)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_2_1_io_update_alloc_2_REG 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT___GEN_159) 
           & (2U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__s1_update_bits_cfi_idx_bits)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_5_1_io_update_alloc_1_REG 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT___GEN_162) 
           & (1U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__s1_update_bits_cfi_idx_bits)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_5_1_io_update_alloc_2_REG 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT___GEN_162) 
           & (2U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__s1_update_bits_cfi_idx_bits)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_3_1_io_update_alloc_1_REG 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT___GEN_160) 
           & (1U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__s1_update_bits_cfi_idx_bits)));
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__722(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__722\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__c_bits_uop_REG_pdst 
        = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__exe_uop_bits_pdst;
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__io_div_resp_div__DOT___GEN) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__io_div_resp_div__DOT__req_bits_pdst 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__exe_uop_bits_pdst;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__queue__DOT___GEN_6) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__queue__DOT__uops_0_pdst 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__fpu__DOT__pipe__DOT__uops_3_bits_uop_pdst;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__queue__DOT___GEN_10) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__queue__DOT__uops_2_pdst 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__fpu__DOT__pipe__DOT__uops_3_bits_uop_pdst;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__queue__DOT___GEN_8) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__queue__DOT__uops_1_pdst 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__fpu__DOT__pipe__DOT__uops_3_bits_uop_pdst;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__queue__DOT___GEN_12) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__queue__DOT__uops_3_pdst 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__fpu__DOT__pipe__DOT__uops_3_bits_uop_pdst;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__queue__DOT___GEN_14) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__queue__DOT__uops_4_pdst 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__fpu__DOT__pipe__DOT__uops_3_bits_uop_pdst;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__queue__DOT___GEN_22) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__queue__DOT__uops_8_pdst 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__fpu__DOT__pipe__DOT__uops_3_bits_uop_pdst;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__queue__DOT___GEN_16) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__queue__DOT__uops_5_pdst 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__fpu__DOT__pipe__DOT__uops_3_bits_uop_pdst;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__queue__DOT___GEN_18) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__queue__DOT__uops_6_pdst 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__fpu__DOT__pipe__DOT__uops_3_bits_uop_pdst;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__queue__DOT___GEN_20) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__queue__DOT__uops_7_pdst 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__fpu__DOT__pipe__DOT__uops_3_bits_uop_pdst;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__queue__DOT___GEN_24) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__queue__DOT__uops_9_pdst 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__fpu__DOT__pipe__DOT__uops_3_bits_uop_pdst;
    }
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__io_mul_resp_imul__DOT__pipe__DOT__uops_2_bits_uop_pdst 
        = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__io_mul_resp_imul__DOT__pipe__DOT__uops_1_bits_uop_pdst;
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT___system_auto_cbus_fixedClockNode_anon_out_reset) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__reg_dcsr_ebreaku = 0U;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__reg_dcsr_ebreakm = 0U;
    } else if (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___csr_wen_T_4) 
                & (0xfffU == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___decoded_addr_decoded_decoded_andMatrixOutputs_T_79)))) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__reg_dcsr_ebreaku 
            = (1U & ((IData)((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___wdata_T_2 
                              >> 0xcU)) & (IData)((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___wdata_T_6 
                                                   >> 0xcU))));
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__reg_dcsr_ebreakm 
            = (1U & ((IData)((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___wdata_T_2 
                              >> 0xfU)) & (IData)((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___wdata_T_6 
                                                   >> 0xfU))));
    }
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__723(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__723\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT___system_auto_cbus_fixedClockNode_anon_out_reset) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__reg_dcsr_ebreaks = 0U;
    } else if (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___csr_wen_T_4) 
                & (0xfffU == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___decoded_addr_decoded_decoded_andMatrixOutputs_T_79)))) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__reg_dcsr_ebreaks 
            = (1U & ((IData)((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___wdata_T_2 
                              >> 0xdU)) & (IData)((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___wdata_T_6 
                                                   >> 0xdU))));
    }
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_0_1_io_update_alloc_0_REG 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT___GEN_157) 
           & (~ (0U != (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__s1_update_bits_cfi_idx_bits))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_0_1_io_update_alloc_3_REG 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT___GEN_157) 
           & (3U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__s1_update_bits_cfi_idx_bits)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_1_1_io_update_alloc_0_REG 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT___GEN_158) 
           & (~ (0U != (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__s1_update_bits_cfi_idx_bits))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_1_1_io_update_alloc_3_REG 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT___GEN_158) 
           & (3U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__s1_update_bits_cfi_idx_bits)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_2_1_io_update_alloc_0_REG 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT___GEN_159) 
           & (~ (0U != (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__s1_update_bits_cfi_idx_bits))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_2_1_io_update_alloc_3_REG 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT___GEN_159) 
           & (3U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__s1_update_bits_cfi_idx_bits)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_3_1_io_update_alloc_0_REG 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT___GEN_160) 
           & (~ (0U != (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__s1_update_bits_cfi_idx_bits))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_3_1_io_update_alloc_3_REG 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT___GEN_160) 
           & (3U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__s1_update_bits_cfi_idx_bits)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_4_1_io_update_alloc_0_REG 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT___GEN_161) 
           & (~ (0U != (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__s1_update_bits_cfi_idx_bits))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_4_1_io_update_alloc_3_REG 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT___GEN_161) 
           & (3U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__s1_update_bits_cfi_idx_bits)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_5_1_io_update_alloc_0_REG 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT___GEN_162) 
           & (~ (0U != (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__s1_update_bits_cfi_idx_bits))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_5_1_io_update_alloc_3_REG 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT___GEN_162) 
           & (3U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__s1_update_bits_cfi_idx_bits)));
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__cbus__DOT__coupler_to_plic__DOT__fragmenter__DOT__repeater__DOT___GEN) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__cbus__DOT__coupler_to_plic__DOT__fragmenter__DOT__repeater__DOT__saved_opcode 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT___cbus_auto_coupler_to_bus_named_pbus_bus_xing_out_a_bits_opcode;
    }
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__724(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__724\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__cbus__DOT__coupler_to_l2_ctrl__DOT__fragmenter__DOT__repeater__DOT___GEN) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__cbus__DOT__coupler_to_l2_ctrl__DOT__fragmenter__DOT__repeater__DOT__saved_opcode 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT___cbus_auto_coupler_to_bus_named_pbus_bus_xing_out_a_bits_opcode;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__fpu__DOT__fpu__DOT__sfma__DOT__valid) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__fpu__DOT__fpu__DOT__sfma__DOT__fma__DOT__mulAddRecFNToRaw_postMul_io_mulAddResult_pipe_b 
            = (0x1ffffffffffffULL & ((0xffffffffffffULL 
                                      & ((QData)((IData)(
                                                         (((0U 
                                                            != 
                                                            (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__fpu__DOT__fpu__DOT__sfma__DOT__in_in1[0U] 
                                                             >> 0x1dU)) 
                                                           << 0x17U) 
                                                          | (0x7fffffU 
                                                             & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__fpu__DOT__fpu__DOT__sfma__DOT__in_in1[0U])))) 
                                         * (QData)((IData)(
                                                           (((0U 
                                                              != 
                                                              (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__fpu__DOT__fpu__DOT__sfma__DOT__in_in2[0U] 
                                                               >> 0x1dU)) 
                                                             << 0x17U) 
                                                            | (0x7fffffU 
                                                               & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__fpu__DOT__fpu__DOT__sfma__DOT__in_in2[0U])))))) 
                                     + (0xffffffffffffULL 
                                        & (((QData)((IData)(
                                                            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__fpu__DOT__fpu__DOT__sfma__DOT__fma__DOT__mulAddRecFNToRaw_preMul__DOT__mainAlignedSigC[1U])) 
                                            << 0x1dU) 
                                           | ((QData)((IData)(
                                                              vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__fpu__DOT__fpu__DOT__sfma__DOT__fma__DOT__mulAddRecFNToRaw_preMul__DOT__mainAlignedSigC[0U])) 
                                              >> 3U)))));
    }
    if (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__directory__DOT____Vcellinp__cc_dir__RW0_en) 
         & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT____Vcellinp__directory__io_read_valid))) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__directory__DOT__cc_dir__DOT__cc_dir_ext__DOT__mem_0_0__DOT__ram_RW_0_r_addr_pipe_0 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__directory__DOT____Vcellinp__cc_dir__RW0_addr;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__directory__DOT__cc_dir__DOT__cc_dir_ext__DOT__mem_0_4__DOT__ram_RW_0_r_addr_pipe_0 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__directory__DOT____Vcellinp__cc_dir__RW0_addr;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__directory__DOT__cc_dir__DOT__cc_dir_ext__DOT__mem_0_1__DOT__ram_RW_0_r_addr_pipe_0 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__directory__DOT____Vcellinp__cc_dir__RW0_addr;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__directory__DOT__cc_dir__DOT__cc_dir_ext__DOT__mem_0_2__DOT__ram_RW_0_r_addr_pipe_0 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__directory__DOT____Vcellinp__cc_dir__RW0_addr;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__directory__DOT__cc_dir__DOT__cc_dir_ext__DOT__mem_0_3__DOT__ram_RW_0_r_addr_pipe_0 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__directory__DOT____Vcellinp__cc_dir__RW0_addr;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__directory__DOT__cc_dir__DOT__cc_dir_ext__DOT__mem_0_5__DOT__ram_RW_0_r_addr_pipe_0 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__directory__DOT____Vcellinp__cc_dir__RW0_addr;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__directory__DOT__cc_dir__DOT__cc_dir_ext__DOT__mem_0_6__DOT__ram_RW_0_r_addr_pipe_0 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__directory__DOT____Vcellinp__cc_dir__RW0_addr;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__directory__DOT__cc_dir__DOT__cc_dir_ext__DOT__mem_0_7__DOT__ram_RW_0_r_addr_pipe_0 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__directory__DOT____Vcellinp__cc_dir__RW0_addr;
    }
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT__io_resp_f2_3_predicted_pc_REG_valid 
        = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT__s1_resp_3_valid;
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__wb_ldst_forward_ld_addr_0 
        = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__lcam_addr_0;
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__io_ifpu_resp_ifpu_ready_REG 
        = (2U > (7U & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__io_ifpu_resp_queue__DOT__enq_ptr_value) 
                       - (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__io_ifpu_resp_queue__DOT__deq_ptr_value))));
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__725(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__725\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT___system_auto_cbus_fixedClockNode_anon_out_reset) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__reg_pmp_0_cfg_a = 0U;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__reg_pmp_7_cfg_a = 0U;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__cork__DOT__state_1 = 0U;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__small_1 = 0U;
    } else {
        if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___GEN_46) {
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__reg_pmp_0_cfg_a 
                = (3U & ((IData)((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___wdata_T_2 
                                  >> 3U)) & (IData)(
                                                    (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___wdata_T_6 
                                                     >> 3U))));
        }
        if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___GEN_55) {
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__reg_pmp_7_cfg_a 
                = (3U & ((IData)((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___wdata_T_2 
                                  >> 0x3bU)) & (IData)(
                                                       (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___wdata_T_6 
                                                        >> 0x3bU))));
        }
        if ((0U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__cork__DOT__beatsLeft))) {
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__cork__DOT__state_1 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__cork__DOT__winner_1;
        }
        if (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___csr_wen_T_4) 
             & (0x7ffU == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___decoded_addr_decoded_decoded_andMatrixOutputs_T_85)))) {
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__small_1 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___GEN_30;
        } else if ((1U & (~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__reg_mcountinhibit)))) {
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__small_1 
                = (0x3fU & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__nextSmall_1));
        }
    }
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__exe_uop_bits_fp_ctrl_fma 
        = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__rrd_uop_bits_fp_ctrl_fma;
    if ((1U & (~ ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT___core_io_ifu_redirect_flush) 
                  | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__dis_stalls_0))))) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__imm_rename_stage__DOT__r_uop_br_type 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_br_type;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__imm_rename_stage__DOT__r_uop_is_sfb 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_is_sfb;
    }
    if ((1U & (~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT___fp_exe_unit_0_io_squash_iss)))) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__arb_uop_bits_frs3_en 
            = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__issue_slots_7_grant)
                ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_7__DOT__slot_uop_frs3_en)
                : ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__issue_slots_6_grant)
                    ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_6__DOT__slot_uop_frs3_en)
                    : ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__issue_slots_5_grant)
                        ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_5__DOT__slot_uop_frs3_en)
                        : ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__issue_slots_4_grant)
                            ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_4__DOT__slot_uop_frs3_en)
                            : ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__issue_slots_3_grant)
                                ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_3__DOT__slot_uop_frs3_en)
                                : ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__issue_slots_2_grant)
                                    ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_2__DOT__slot_uop_frs3_en)
                                    : ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__issue_slots_1_grant)
                                        ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_1__DOT__slot_uop_frs3_en)
                                        : (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_0__DOT__slot_uop_frs3_en))))))));
    }
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__726(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__726\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Init
    VlWide<4>/*127:0*/ __Vtemp_3;
    VlWide<4>/*127:0*/ __Vtemp_4;
    VlWide<4>/*127:0*/ __Vtemp_5;
    VlWide<4>/*127:0*/ __Vtemp_7;
    VlWide<4>/*127:0*/ __Vtemp_11;
    VlWide<4>/*127:0*/ __Vtemp_12;
    // Body
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT___system_auto_cbus_fixedClockNode_anon_out_reset) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sinkD__DOT__d_q__DOT__maybe_full = 0U;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__reg_mcause = 0ULL;
        vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__mshr_head = 0U;
    } else {
        if (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sinkD__DOT__d_q__DOT__do_enq) 
             != (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sinkD__DOT__d_q__DOT__do_deq))) {
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sinkD__DOT__d_q__DOT__maybe_full 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sinkD__DOT__d_q__DOT__do_enq;
        }
        if (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___csr_wen_T_4) 
             & (0xfffU == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___decoded_addr_decoded_decoded_andMatrixOutputs_T_54)))) {
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__reg_mcause 
                = (0x800000000000000fULL & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__wdata);
        } else if ((1U & (~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___GEN_40)))) {
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__reg_mcause 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__cause;
        }
        if (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__pri_rdy) 
             & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__pri_val))) {
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__mshr_head 
                = (1U & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__mshr_head) 
                         - (IData)(1U)));
        }
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__fpu__DOT__fpu__DOT__dfma__DOT__valid) {
        __Vtemp_3[0U] = (IData)((((QData)((IData)((0U 
                                                   != 
                                                   (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__fpu__DOT__fpu__DOT__dfma__DOT__in_in1[1U] 
                                                    >> 0x1dU)))) 
                                  << 0x34U) | (0xfffffffffffffULL 
                                               & (((QData)((IData)(
                                                                   vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__fpu__DOT__fpu__DOT__dfma__DOT__in_in1[1U])) 
                                                   << 0x20U) 
                                                  | (QData)((IData)(
                                                                    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__fpu__DOT__fpu__DOT__dfma__DOT__in_in1[0U]))))));
        __Vtemp_3[1U] = (IData)(((((QData)((IData)(
                                                   (0U 
                                                    != 
                                                    (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__fpu__DOT__fpu__DOT__dfma__DOT__in_in1[1U] 
                                                     >> 0x1dU)))) 
                                   << 0x34U) | (0xfffffffffffffULL 
                                                & (((QData)((IData)(
                                                                    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__fpu__DOT__fpu__DOT__dfma__DOT__in_in1[1U])) 
                                                    << 0x20U) 
                                                   | (QData)((IData)(
                                                                     vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__fpu__DOT__fpu__DOT__dfma__DOT__in_in1[0U]))))) 
                                 >> 0x20U));
        __Vtemp_3[2U] = 0U;
        __Vtemp_3[3U] = 0U;
        __Vtemp_4[0U] = (IData)((((QData)((IData)((0U 
                                                   != 
                                                   (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__fpu__DOT__fpu__DOT__dfma__DOT__in_in2[1U] 
                                                    >> 0x1dU)))) 
                                  << 0x34U) | (0xfffffffffffffULL 
                                               & (((QData)((IData)(
                                                                   vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__fpu__DOT__fpu__DOT__dfma__DOT__in_in2[1U])) 
                                                   << 0x20U) 
                                                  | (QData)((IData)(
                                                                    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__fpu__DOT__fpu__DOT__dfma__DOT__in_in2[0U]))))));
        __Vtemp_4[1U] = (IData)(((((QData)((IData)(
                                                   (0U 
                                                    != 
                                                    (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__fpu__DOT__fpu__DOT__dfma__DOT__in_in2[1U] 
                                                     >> 0x1dU)))) 
                                   << 0x34U) | (0xfffffffffffffULL 
                                                & (((QData)((IData)(
                                                                    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__fpu__DOT__fpu__DOT__dfma__DOT__in_in2[1U])) 
                                                    << 0x20U) 
                                                   | (QData)((IData)(
                                                                     vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__fpu__DOT__fpu__DOT__dfma__DOT__in_in2[0U]))))) 
                                 >> 0x20U));
        __Vtemp_4[2U] = 0U;
        __Vtemp_4[3U] = 0U;
        VL_MUL_W(4, __Vtemp_5, __Vtemp_3, __Vtemp_4);
        __Vtemp_7[0U] = __Vtemp_5[0U];
        __Vtemp_7[1U] = __Vtemp_5[1U];
        __Vtemp_7[2U] = __Vtemp_5[2U];
        __Vtemp_7[3U] = (0x3ffU & __Vtemp_5[3U]);
        __Vtemp_11[0U] = ((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__fpu__DOT__fpu__DOT__dfma__DOT__fma__DOT__mulAddRecFNToRaw_preMul__DOT__mainAlignedSigC[1U] 
                           << 0x1dU) | (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__fpu__DOT__fpu__DOT__dfma__DOT__fma__DOT__mulAddRecFNToRaw_preMul__DOT__mainAlignedSigC[0U] 
                                        >> 3U));
        __Vtemp_11[1U] = ((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__fpu__DOT__fpu__DOT__dfma__DOT__fma__DOT__mulAddRecFNToRaw_preMul__DOT__mainAlignedSigC[2U] 
                           << 0x1dU) | (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__fpu__DOT__fpu__DOT__dfma__DOT__fma__DOT__mulAddRecFNToRaw_preMul__DOT__mainAlignedSigC[1U] 
                                        >> 3U));
        __Vtemp_11[2U] = ((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__fpu__DOT__fpu__DOT__dfma__DOT__fma__DOT__mulAddRecFNToRaw_preMul__DOT__mainAlignedSigC[3U] 
                           << 0x1dU) | (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__fpu__DOT__fpu__DOT__dfma__DOT__fma__DOT__mulAddRecFNToRaw_preMul__DOT__mainAlignedSigC[2U] 
                                        >> 3U));
        __Vtemp_11[3U] = (0x3ffU & (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__fpu__DOT__fpu__DOT__dfma__DOT__fma__DOT__mulAddRecFNToRaw_preMul__DOT__mainAlignedSigC[3U] 
                                    >> 3U));
        VL_ADD_W(4, __Vtemp_12, __Vtemp_7, __Vtemp_11);
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__fpu__DOT__fpu__DOT__dfma__DOT__fma__DOT__mulAddRecFNToRaw_postMul_io_mulAddResult_pipe_b[0U] 
            = __Vtemp_12[0U];
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__fpu__DOT__fpu__DOT__dfma__DOT__fma__DOT__mulAddRecFNToRaw_postMul_io_mulAddResult_pipe_b[1U] 
            = __Vtemp_12[1U];
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__fpu__DOT__fpu__DOT__dfma__DOT__fma__DOT__mulAddRecFNToRaw_postMul_io_mulAddResult_pipe_b[2U] 
            = __Vtemp_12[2U];
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__fpu__DOT__fpu__DOT__dfma__DOT__fma__DOT__mulAddRecFNToRaw_postMul_io_mulAddResult_pipe_b[3U] 
            = (0x7ffU & __Vtemp_12[3U]);
    }
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_exe_unit_1__DOT__exe_uop_bits_fu_code_2 
        = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_exe_unit_1__DOT__rrd_uop_bits_fu_code_2;
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__mshr_alloc_idx_REG 
        = (1U & ((~ ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT___mshrs_0_io_req_pri_rdy) 
                     & (~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__mshr_head)))) 
                 & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT___mshrs_1_io_req_pri_rdy) 
                    | (~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT___mshrs_0_io_req_pri_rdy)))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__io_resp_f3_3_REG_predicted_pc_bits 
        = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__io_resp_f2_3_REG_predicted_pc_bits;
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__io_resp_f3_2_REG_predicted_pc_bits 
        = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__io_resp_f2_2_REG_predicted_pc_bits;
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__io_resp_f3_1_REG_predicted_pc_bits 
        = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__io_resp_f2_1_REG_predicted_pc_bits;
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__727(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__727\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__io_resp_f3_0_REG_predicted_pc_bits 
        = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__io_resp_f2_0_REG_predicted_pc_bits;
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__cbus__DOT__coupler_to_plic__DOT__fragmenter__DOT__repeater__DOT___GEN) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__cbus__DOT__coupler_to_plic__DOT__fragmenter__DOT__repeater__DOT__saved_size 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT___cbus_auto_coupler_to_bus_named_pbus_bus_xing_out_a_bits_size;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__cbus__DOT__coupler_to_l2_ctrl__DOT__fragmenter__DOT__repeater__DOT___GEN) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__cbus__DOT__coupler_to_l2_ctrl__DOT__fragmenter__DOT__repeater__DOT__saved_size 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT___cbus_auto_coupler_to_bus_named_pbus_bus_xing_out_a_bits_size;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT___system_auto_cbus_fixedClockNode_anon_out_reset) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__cork__DOT__state_0 = 0U;
    } else if ((0U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__cork__DOT__beatsLeft))) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__cork__DOT__state_0 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__cork__DOT__c_a_valid;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__issue_slots_0_in_uop_valid) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__slots_0__DOT__slot_uop_imm_sel 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__slots_1__DOT__slot_uop_imm_sel;
    }
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__slots_2__DOT__slot_uop_prs1_busy 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__issue_slots_2_in_uop_valid)
            ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT___slots_3_io_out_uop_prs1_busy)
            : (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT___slots_2_io_out_uop_prs1_busy));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_ldq_oh_6 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_ld_val) 
           & (6U == (7U & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__ldq_tail))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_ldq_oh_5 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_ld_val) 
           & (5U == (7U & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__ldq_tail))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_ldq_oh_3 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_ld_val) 
           & (3U == (7U & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__ldq_tail))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_ldq_oh_2 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_ld_val) 
           & (2U == (7U & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__ldq_tail))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_ldq_oh_1 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_ld_val) 
           & (1U == (7U & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__ldq_tail))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_ldq_oh_4 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_ld_val) 
           & (4U == (7U & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__ldq_tail))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_ldq_oh_0 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_ld_val) 
           & (0U == (7U & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__ldq_tail))));
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__728(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__728\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__ll_wbarb_io_in_0_bits_REG_uop_pdst 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_462)
            ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT____VdfgRegularize_h94b53d93_0_211)
            : (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__wb_ldst_forward_e_REG_uop_pdst));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__loop__DOT__columns_3__DOT__f4_scnt 
        = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__loop__DOT___columns_3_io_f3_meta_s_cnt;
    if ((0U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__cbus__DOT__coupler_to_bootrom__DOT__fragmenter__DOT__gennum))) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__cbus__DOT__coupler_to_bootrom__DOT__fragmenter__DOT__aToggle_r 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__cbus__DOT__coupler_to_bootrom__DOT__fragmenter__DOT__dToggle;
    }
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__rrd_uop_bits_prs2 
        = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__arb_uop_bits_prs2;
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__rrd_uop_bits_prs1 
        = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__arb_uop_bits_prs1;
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__cbus__DOT__coupler_to_bootrom__DOT__fragmenter__DOT__repeater__DOT___GEN) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__cbus__DOT__coupler_to_bootrom__DOT__fragmenter__DOT__repeater__DOT__saved_size 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT___cbus_auto_coupler_to_bus_named_pbus_bus_xing_out_a_bits_size;
    }
    if (((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__fb__DOT___GEN_36) 
           | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__fb__DOT___GEN_27)) 
          | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__fb__DOT___GEN_18)) 
         | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__fb__DOT___GEN_9))) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__fb__DOT__fb_uop_ram_5_ftq_idx 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__ftq__DOT__enq_ptr;
    }
    if (((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__fb__DOT___GEN_35) 
           | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__fb__DOT___GEN_26)) 
          | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__fb__DOT___GEN_17)) 
         | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__fb__DOT___GEN_8))) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__fb__DOT__fb_uop_ram_4_ftq_idx 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__ftq__DOT__enq_ptr;
    }
    if (((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__fb__DOT___GEN_33) 
           | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__fb__DOT___GEN_24)) 
          | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__fb__DOT___GEN_15)) 
         | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__fb__DOT___GEN_6))) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__fb__DOT__fb_uop_ram_2_ftq_idx 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__ftq__DOT__enq_ptr;
    }
    if (((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__fb__DOT___GEN_32) 
           | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__fb__DOT___GEN_23)) 
          | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__fb__DOT___GEN_14)) 
         | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__fb__DOT___GEN_5))) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__fb__DOT__fb_uop_ram_1_ftq_idx 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__ftq__DOT__enq_ptr;
    }
    if (((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__fb__DOT___GEN_38) 
           | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__fb__DOT___GEN_29)) 
          | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__fb__DOT___GEN_20)) 
         | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__fb__DOT___GEN_11))) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__fb__DOT__fb_uop_ram_7_ftq_idx 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__ftq__DOT__enq_ptr;
    }
    if (((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__fb__DOT___GEN_37) 
           | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__fb__DOT___GEN_28)) 
          | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__fb__DOT___GEN_19)) 
         | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__fb__DOT___GEN_10))) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__fb__DOT__fb_uop_ram_6_ftq_idx 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__ftq__DOT__enq_ptr;
    }
    if (((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__fb__DOT___GEN_34) 
           | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__fb__DOT___GEN_25)) 
          | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__fb__DOT___GEN_16)) 
         | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__fb__DOT___GEN_7))) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__fb__DOT__fb_uop_ram_3_ftq_idx 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__ftq__DOT__enq_ptr;
    }
}
