// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See VTestDriver.h for the primary calling header

#include "VTestDriver__pch.h"
#include "VTestDriver___024root.h"

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__2350(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__2350\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Init
    VlWide<8>/*255:0*/ __Vtemp_4;
    // Body
    __Vtemp_4[0U] = (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__alu__DOT____Vcellinp__alu__io_in1);
    __Vtemp_4[1U] = (IData)((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__alu__DOT____Vcellinp__alu__io_in1 
                             >> 0x20U));
    __Vtemp_4[2U] = (IData)(((0x5555555555555555ULL 
                              & (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__alu__DOT__alu__DOT___tz_in_T_52 
                                 >> 1U)) | (0xaaaaaaaaaaaaaaaaULL 
                                            & (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__alu__DOT__alu__DOT___tz_in_T_52 
                                               << 1U))));
    __Vtemp_4[3U] = (IData)((((0x5555555555555555ULL 
                               & (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__alu__DOT__alu__DOT___tz_in_T_52 
                                  >> 1U)) | (0xaaaaaaaaaaaaaaaaULL 
                                             & (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__alu__DOT__alu__DOT___tz_in_T_52 
                                                << 1U))) 
                             >> 0x20U));
    __Vtemp_4[4U] = (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__alu__DOT____Vcellinp__alu__io_in1);
    __Vtemp_4[5U] = 1U;
    __Vtemp_4[6U] = (IData)((0x100000000ULL | (QData)((IData)(
                                                              ((0x55555555U 
                                                                & (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__alu__DOT__alu__DOT___tz_in_T_104 
                                                                   >> 1U)) 
                                                               | (0xaaaaaaaaU 
                                                                  & (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__alu__DOT__alu__DOT___tz_in_T_104 
                                                                     << 1U)))))));
    __Vtemp_4[7U] = (IData)(((0x100000000ULL | (QData)((IData)(
                                                               ((0x55555555U 
                                                                 & (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__alu__DOT__alu__DOT___tz_in_T_104 
                                                                    >> 1U)) 
                                                                | (0xaaaaaaaaU 
                                                                   & (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__alu__DOT__alu__DOT___tz_in_T_104 
                                                                      << 1U)))))) 
                             >> 0x20U));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__alu__DOT__alu__DOT__tz_in 
        = (((QData)((IData)(__Vtemp_4[(((IData)(0x3fU) 
                                        + (0xffU & 
                                           VL_SHIFTL_III(8,8,32, 
                                                         (3U 
                                                          & (~ 
                                                             (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__alu__DOT____Vcellinp__alu__io_dw) 
                                                               << 1U) 
                                                              | (1U 
                                                                 & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__alu__DOT____Vcellinp__alu__io_in2))))), 6U))) 
                                       >> 5U)])) << 
            ((0U == (0x1fU & VL_SHIFTL_III(8,8,32, 
                                           (3U & (~ 
                                                  (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__alu__DOT____Vcellinp__alu__io_dw) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__alu__DOT____Vcellinp__alu__io_in2))))), 6U)))
              ? 0x20U : ((IData)(0x40U) - (0x1fU & 
                                           VL_SHIFTL_III(8,8,32, 
                                                         (3U 
                                                          & (~ 
                                                             (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__alu__DOT____Vcellinp__alu__io_dw) 
                                                               << 1U) 
                                                              | (1U 
                                                                 & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__alu__DOT____Vcellinp__alu__io_in2))))), 6U))))) 
           | (((0U == (0x1fU & VL_SHIFTL_III(8,8,32, 
                                             (3U & 
                                              (~ (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__alu__DOT____Vcellinp__alu__io_dw) 
                                                   << 1U) 
                                                  | (1U 
                                                     & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__alu__DOT____Vcellinp__alu__io_in2))))), 6U)))
                ? 0ULL : ((QData)((IData)(__Vtemp_4[
                                          (((IData)(0x1fU) 
                                            + (0xffU 
                                               & VL_SHIFTL_III(8,8,32, 
                                                               (3U 
                                                                & (~ 
                                                                   (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__alu__DOT____Vcellinp__alu__io_dw) 
                                                                     << 1U) 
                                                                    | (1U 
                                                                       & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__alu__DOT____Vcellinp__alu__io_in2))))), 6U))) 
                                           >> 5U)])) 
                          << ((IData)(0x20U) - (0x1fU 
                                                & VL_SHIFTL_III(8,8,32, 
                                                                (3U 
                                                                 & (~ 
                                                                    (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__alu__DOT____Vcellinp__alu__io_dw) 
                                                                      << 1U) 
                                                                     | (1U 
                                                                        & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__alu__DOT____Vcellinp__alu__io_in2))))), 6U))))) 
              | ((QData)((IData)(__Vtemp_4[(7U & (VL_SHIFTL_III(8,8,32, 
                                                                (3U 
                                                                 & (~ 
                                                                    (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__alu__DOT____Vcellinp__alu__io_dw) 
                                                                      << 1U) 
                                                                     | (1U 
                                                                        & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__alu__DOT____Vcellinp__alu__io_in2))))), 6U) 
                                                  >> 5U))])) 
                 >> (0x1fU & VL_SHIFTL_III(8,8,32, 
                                           (3U & (~ 
                                                  (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__alu__DOT____Vcellinp__alu__io_dw) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__alu__DOT____Vcellinp__alu__io_in2))))), 6U)))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__alu__DOT__alu__DOT___shin_T_56 
        = ((0x3333333333333333ULL & (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__alu__DOT__alu__DOT___shin_T_46 
                                     >> 2U)) | (0xccccccccccccccccULL 
                                                & (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__alu__DOT__alu__DOT___shin_T_46 
                                                   << 2U)));
    if ((1U & (~ ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT___core_io_ifu_redirect_flush) 
                  | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__dis_stalls_0))))) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__imm_rename_stage__DOT__r_uop_imm_sel 
            = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT__short_imm)
                ? 5U : (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT__cs_imm_sel));
    }
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fregfile__DOT__rfs_0__DOT__use_port_4 
        = ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fregfile__DOT__rfs_0__DOT__use_port_3)) 
           & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT___fp_exe_unit_0_io_arb_frf_reqs_1_valid));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fregfile__DOT__rfs_0__DOT___GEN_0 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fregfile__DOT__rfs_0__DOT__use_port_3) 
           | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT___fp_exe_unit_0_io_arb_frf_reqs_0_valid));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__queue__DOT__do_enq 
        = ((~ (IData)(vlSelfRef.__VdfgRegularize_h36cfaf1a_0_115)) 
           & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__queue_io_enq_valid) 
              & ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline_io_flush_pipeline_REG)) 
                 & (0U == ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT___lsu_io_dmem_brupdate_b1_mispredict_mask) 
                           & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__fpu__DOT__pipe__DOT__uops_3_bits_uop_br_mask))))));
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__2351(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__2351\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_7__DOT__killed 
        = ((0U != ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT___lsu_io_dmem_brupdate_b1_mispredict_mask) 
                   & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_7__DOT__slot_uop_br_mask))) 
           | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline_io_flush_pipeline_REG));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_6__DOT__killed 
        = ((0U != ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT___lsu_io_dmem_brupdate_b1_mispredict_mask) 
                   & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_6__DOT__slot_uop_br_mask))) 
           | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline_io_flush_pipeline_REG));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_5__DOT__killed 
        = ((0U != ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT___lsu_io_dmem_brupdate_b1_mispredict_mask) 
                   & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_5__DOT__slot_uop_br_mask))) 
           | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline_io_flush_pipeline_REG));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_4__DOT__killed 
        = ((0U != ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT___lsu_io_dmem_brupdate_b1_mispredict_mask) 
                   & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_4__DOT__slot_uop_br_mask))) 
           | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline_io_flush_pipeline_REG));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_3__DOT__killed 
        = ((0U != ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT___lsu_io_dmem_brupdate_b1_mispredict_mask) 
                   & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_3__DOT__slot_uop_br_mask))) 
           | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline_io_flush_pipeline_REG));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_2__DOT__killed 
        = ((0U != ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT___lsu_io_dmem_brupdate_b1_mispredict_mask) 
                   & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_2__DOT__slot_uop_br_mask))) 
           | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline_io_flush_pipeline_REG));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_1__DOT__killed 
        = ((0U != ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT___lsu_io_dmem_brupdate_b1_mispredict_mask) 
                   & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_1__DOT__slot_uop_br_mask))) 
           | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline_io_flush_pipeline_REG));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_0__DOT__killed 
        = ((0U != ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT___lsu_io_dmem_brupdate_b1_mispredict_mask) 
                   & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_0__DOT__slot_uop_br_mask))) 
           | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline_io_flush_pipeline_REG));
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__2352(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__2352\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__cbus__DOT___atomics_auto_in_a_ready 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__cbus__DOT__atomics__DOT__source_i_ready) 
           & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__cbus__DOT__atomics__DOT__a_allow));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__cbus__DOT__atomics__DOT__source_i_valid 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__cbus__DOT___in_xbar_auto_anon_out_a_valid) 
           & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__cbus__DOT__atomics__DOT__a_allow));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__queue 
        = ((~ ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__nestC) 
               | ((((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_0__DOT__meta_valid)) 
                    & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT___nestC_T)) 
                   | (((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_1__DOT__meta_valid)) 
                       & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT___nestC_T_1)) 
                      | (((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_2__DOT__meta_valid)) 
                          & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT___nestC_T_2)) 
                         | (((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_3__DOT__meta_valid)) 
                             & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT___nestC_T_3)) 
                            | (((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_4__DOT__meta_valid)) 
                                & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT___nestC_T_4)) 
                               | (((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_5__DOT__meta_valid)) 
                                   & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT___nestC_T_5)) 
                                  | ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_6__DOT__meta_valid)) 
                                     & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT___nestC_T_6)))))))) 
                  & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT___sinkC_io_req_valid)))) 
           & (0U != (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__lowerMatches)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__lowerMatches1 
        = (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT___nestC_T_6) 
            & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT___sinkC_io_req_valid))
            ? 0x40U : (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT___nestC_T_5) 
                        & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT___sinkC_io_req_valid))
                        ? 0x20U : (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__lowerMatches)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT___GEN 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__prs1_wakeups_0) 
           | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___fp_pipeline_io_wakeups_1_valid) 
              & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___dispatcher_io_dis_uops_3_0_bits_prs1) 
                 == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___fp_pipeline_io_wakeups_1_bits_uop_pdst))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__prs1_wakeups_0 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT___lsu_io_core_iwakeups_0_valid) 
           & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__prs1_matches_0));
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__2353(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__2353\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT___GEN_23 
        = (0x1fU & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT___GEN_22) 
                    | ((0x10U & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshr_selectOH) 
                                 >> 2U)) | (0xfU & 
                                            ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT___GEN_22) 
                                             >> 2U)))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__nestedwb_c_set_dirty 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT____VdfgRegularize_hd1f689b4_0_8) 
           & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT___mshrs_6_io_schedule_bits_dir_bits_data_dirty));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sourceB__DOT___param_T_1 
        = ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sourceB__DOT__remain)) 
           & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT____Vcellinp__sourceB__io_req_valid));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT___l2_auto_in_b_valid 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT____Vcellinp__sourceB__io_req_valid) 
           | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sourceB__DOT__remain));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__nestedwb_b_toN 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__nestedwb_b_clr_dirty) 
           & (0U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT___mshrs_5_io_schedule_bits_dir_bits_data_state)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__nestedwb_b_toB 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__nestedwb_b_clr_dirty) 
           & (1U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT___mshrs_5_io_schedule_bits_dir_bits_data_state)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__directory__DOT__write_q__DOT__do_enq 
        = ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__directory__DOT__write_q__DOT__maybe_full)) 
           & (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshr_selectOH) 
               & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT___mshrs_0_io_schedule_bits_dir_valid)) 
              | ((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshr_selectOH) 
                   >> 1U) & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT___mshrs_1_io_schedule_bits_dir_valid)) 
                 | ((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshr_selectOH) 
                      >> 2U) & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT___mshrs_2_io_schedule_bits_dir_valid)) 
                    | ((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshr_selectOH) 
                         >> 3U) & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT___mshrs_3_io_schedule_bits_dir_valid)) 
                       | ((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshr_selectOH) 
                            >> 4U) & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT___mshrs_4_io_schedule_bits_dir_valid)) 
                          | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__nestedwb_b_clr_dirty) 
                             | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT____VdfgRegularize_hd1f689b4_0_8))))))));
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__2354(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__2354\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sourceB__DOT__tag 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sourceB__DOT__remain)
            ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sourceB__DOT__tag_r)
            : (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT____Vcellinp__sourceB__io_req_bits_tag));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshr_select 
        = (((0U != (7U & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshr_selectOH) 
                          >> 4U))) << 2U) | (((0U != 
                                               (3U 
                                                & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT___mshr_select_T_1) 
                                                   >> 1U))) 
                                              << 1U) 
                                             | (IData)(
                                                       (0U 
                                                        != 
                                                        (5U 
                                                         & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT___mshr_select_T_1))))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_0__DOT___GEN_106 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_0__DOT__meta_valid) 
           & ((0U != (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_0__DOT__meta_state)) 
              & (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__nestedwb_set) 
                  == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_0__DOT__request_set)) 
                 & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__nestedwb_tag) 
                    == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_0__DOT__meta_tag)))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_1__DOT___GEN_106 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_1__DOT__meta_valid) 
           & ((0U != (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_1__DOT__meta_state)) 
              & (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__nestedwb_set) 
                  == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_1__DOT__request_set)) 
                 & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__nestedwb_tag) 
                    == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_1__DOT__meta_tag)))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_2__DOT___GEN_106 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_2__DOT__meta_valid) 
           & ((0U != (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_2__DOT__meta_state)) 
              & (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__nestedwb_set) 
                  == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_2__DOT__request_set)) 
                 & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__nestedwb_tag) 
                    == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_2__DOT__meta_tag)))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_3__DOT___GEN_106 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_3__DOT__meta_valid) 
           & ((0U != (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_3__DOT__meta_state)) 
              & (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__nestedwb_set) 
                  == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_3__DOT__request_set)) 
                 & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__nestedwb_tag) 
                    == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_3__DOT__meta_tag)))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_4__DOT___GEN_106 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_4__DOT__meta_valid) 
           & ((0U != (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_4__DOT__meta_state)) 
              & (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__nestedwb_set) 
                  == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_4__DOT__request_set)) 
                 & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__nestedwb_tag) 
                    == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_4__DOT__meta_tag)))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_5__DOT___GEN_106 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_5__DOT__meta_valid) 
           & ((0U != (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_5__DOT__meta_state)) 
              & (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__nestedwb_set) 
                  == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_5__DOT__request_set)) 
                 & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__nestedwb_tag) 
                    == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_5__DOT__meta_tag)))));
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__2355(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__2355\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_6__DOT___GEN_106 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_6__DOT__meta_valid) 
           & ((0U != (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_6__DOT__meta_state)) 
              & (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__nestedwb_set) 
                  == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_6__DOT__request_set)) 
                 & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__nestedwb_tag) 
                    == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_6__DOT__meta_tag)))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sourceD__DOT___s1_valid_T 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sourceD__DOT__busy) 
           | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT____Vcellinp__sourceD__io_req_valid));
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sourceD__DOT__busy) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sourceD__DOT__s1_req_size 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sourceD__DOT__s1_req_reg_size;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sourceD__DOT__s1_req_prio_0 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sourceD__DOT__s1_req_reg_prio_0;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sourceD__DOT__s1_req_param 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sourceD__DOT__s1_req_reg_param;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sourceD__DOT__s1_req_opcode 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sourceD__DOT__s1_req_reg_opcode;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT___sourceD_io_bs_radr_bits_way 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sourceD__DOT__s1_req_reg_way;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT___sourceD_io_bs_radr_bits_set 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sourceD__DOT__s1_req_reg_set;
    } else {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sourceD__DOT__s1_req_size 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT____Vcellinp__sourceD__io_req_bits_size;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sourceD__DOT__s1_req_prio_0 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT____Vcellinp__sourceD__io_req_bits_prio_0;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sourceD__DOT__s1_req_param 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT____Vcellinp__sourceD__io_req_bits_param;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sourceD__DOT__s1_req_opcode 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT____Vcellinp__sourceD__io_req_bits_opcode;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT___sourceD_io_bs_radr_bits_way 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT____Vcellinp__directory__io_write_bits_way;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT___sourceD_io_bs_radr_bits_set 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT____Vcellinp__directory__io_write_bits_set;
    }
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT___sourceD_io_bs_radr_bits_beat 
        = (7U & (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sourceD__DOT__busy)
                   ? ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sourceD__DOT__s1_req_reg_offset) 
                      >> 3U) : ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT____Vcellinp__sourceD__io_req_bits_offset) 
                                >> 3U)) | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sourceD__DOT__s1_counter)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sourceC__DOT___want_data_T 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT____Vcellinp__sourceC__io_req_valid) 
           & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sourceC__DOT__room));
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sourceC__DOT__busy) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT___sourceC_io_bs_adr_bits_way 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sourceC__DOT__req_r_way;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT___sourceC_io_bs_adr_bits_set 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sourceC__DOT__req_r_set;
    } else {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT___sourceC_io_bs_adr_bits_way 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT____Vcellinp__directory__io_write_bits_way;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT___sourceC_io_bs_adr_bits_set 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT____Vcellinp__directory__io_write_bits_set;
    }
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT____VdfgRegularize_hd1f689b4_0_10 
        = ((0U != (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT___a_pop_T)) 
           | ((0U != (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT___b_pop_T)) 
              | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT____VdfgRegularize_hd1f689b4_0_9)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__schedule_reload 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_0__DOT___GEN_98) 
           | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_1__DOT___GEN_98) 
              | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_2__DOT___GEN_98) 
                 | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_3__DOT___GEN_98) 
                    | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_4__DOT___GEN_98) 
                       | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_5__DOT___GEN_98) 
                          | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_6__DOT___GEN_98)))))));
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__2356(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__2356\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT___pop_index_T_3 
        = (0x7fffU & ((0xfU & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__pop_index_hi_1) 
                               >> 1U)) | (0x7fffU & 
                                          (((0x7fffe000U 
                                             & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshr_selectOH) 
                                                << 0xdU)) 
                                            | ((0x7fffffc0U 
                                                & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshr_selectOH) 
                                                   << 6U)) 
                                               | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshr_selectOH) 
                                                  >> 1U))) 
                                           & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__prio_requests))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT___GEN_10 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__wb_fire) 
           | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__prober_fire) 
              | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT___s0_type_T_1)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT____VdfgRegularize_h94b53d93_0_193 
        = (1U & ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_327)) 
                 | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__lcam_younger_load_mask_0_0)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_343 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__lcam_younger_load_mask_0_1) 
           | (1U == (7U & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__lcam_ldq_idx_0))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_351 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__lcam_younger_load_mask_0_2) 
           | (2U == (7U & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__lcam_ldq_idx_0))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_359 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__lcam_younger_load_mask_0_3) 
           | (3U == (7U & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__lcam_ldq_idx_0))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_367 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__lcam_younger_load_mask_0_4) 
           | (4U == (7U & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__lcam_ldq_idx_0))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_375 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__lcam_younger_load_mask_0_5) 
           | (5U == (7U & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__lcam_ldq_idx_0))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_383 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__lcam_younger_load_mask_0_6) 
           | (6U == (7U & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__lcam_ldq_idx_0))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT____VdfgRegularize_h8a2d4d8d_0_0 
        = (((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__iss_ready_0_7) 
              << 7U) | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__iss_ready_0_6) 
                        << 6U)) | (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__iss_ready_0_5) 
                                    << 5U) | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__iss_ready_0_4) 
                                              << 4U))) 
           | ((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__iss_ready_0_3) 
                << 3U) | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__iss_ready_0_2) 
                          << 2U)) | (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__iss_ready_0_1) 
                                      << 1U) | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__iss_ready_0_0))));
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__2357(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__2357\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__slots_0__DOT__next_uop_iw_issued 
        = ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT____Vcellinp__mem_iss_unit__io_squash_grant)) 
           & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__issue_slots_0_grant));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__slots_1__DOT__next_uop_iw_issued 
        = ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT____Vcellinp__mem_iss_unit__io_squash_grant)) 
           & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__issue_slots_1_grant));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__slots_2__DOT__next_uop_iw_issued 
        = ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT____Vcellinp__mem_iss_unit__io_squash_grant)) 
           & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__issue_slots_2_grant));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__slots_3__DOT__next_uop_iw_issued 
        = ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT____Vcellinp__mem_iss_unit__io_squash_grant)) 
           & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__issue_slots_3_grant));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__slots_4__DOT__next_uop_iw_issued 
        = ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT____Vcellinp__mem_iss_unit__io_squash_grant)) 
           & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__issue_slots_4_grant));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__slots_5__DOT__next_uop_iw_issued 
        = ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT____Vcellinp__mem_iss_unit__io_squash_grant)) 
           & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__issue_slots_5_grant));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__slots_6__DOT__next_uop_iw_issued 
        = ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT____Vcellinp__mem_iss_unit__io_squash_grant)) 
           & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__issue_slots_6_grant));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__slots_7__DOT__next_uop_iw_issued 
        = ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT____Vcellinp__mem_iss_unit__io_squash_grant)) 
           & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__issue_slots_7_grant));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__io_fdiv_resp_fdivsqrt__DOT___divSqrt_io_out 
        = (((QData)((IData)(((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__io_fdiv_resp_fdivsqrt__DOT__divSqrt__DOT__roundRawFNToRecFN__DOT__roundAnyRawFNToRecFN__DOT__isNaNOut)) 
                             & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__io_fdiv_resp_fdivsqrt__DOT__divSqrt__DOT__divSqrtRecFNToRaw__DOT__divSqrtRawFN__DOT__sign_Z)))) 
            << 0x20U) | (QData)((IData)((((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__io_fdiv_resp_fdivsqrt__DOT__divSqrt__DOT__roundRawFNToRecFN__DOT__roundAnyRawFNToRecFN__DOT__sRoundedExp) 
                                            << 0x17U) 
                                           & ((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__io_fdiv_resp_fdivsqrt__DOT__divSqrt__DOT__roundRawFNToRecFN__DOT__roundAnyRawFNToRecFN__DOT____VdfgRegularize_ha36442bc_0_10)
                                                 ? 0x3fU
                                                 : 0x1ffU) 
                                               << 0x17U) 
                                              & ((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__io_fdiv_resp_fdivsqrt__DOT__divSqrt__DOT__roundRawFNToRecFN__DOT__roundAnyRawFNToRecFN__DOT__pegMinNonzeroMagOut)
                                                    ? 0x6bU
                                                    : 0x1ffU) 
                                                  << 0x17U) 
                                                 & ((0xbf800000U 
                                                     | (0x40000000U 
                                                        & ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__io_fdiv_resp_fdivsqrt__DOT__divSqrt__DOT__roundRawFNToRecFN__DOT__roundAnyRawFNToRecFN__DOT__pegMaxFiniteMagOut)) 
                                                           << 0x1eU))) 
                                                    & (0xdf800000U 
                                                       | (0x20000000U 
                                                          & ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__io_fdiv_resp_fdivsqrt__DOT__divSqrt__DOT__roundRawFNToRecFN__DOT__roundAnyRawFNToRecFN__DOT__notNaN_isInfOut)) 
                                                             << 0x1dU))))))) 
                                          | ((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__io_fdiv_resp_fdivsqrt__DOT__divSqrt__DOT__roundRawFNToRecFN__DOT__roundAnyRawFNToRecFN__DOT__pegMinNonzeroMagOut)
                                                ? 0x6bU
                                                : 0U) 
                                              | (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__io_fdiv_resp_fdivsqrt__DOT__divSqrt__DOT__roundRawFNToRecFN__DOT__roundAnyRawFNToRecFN__DOT__pegMaxFiniteMagOut)
                                                   ? 0x17fU
                                                   : 0U) 
                                                 | (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__io_fdiv_resp_fdivsqrt__DOT__divSqrt__DOT__roundRawFNToRecFN__DOT__roundAnyRawFNToRecFN__DOT__notNaN_isInfOut)
                                                      ? 0x180U
                                                      : 0U) 
                                                    | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__io_fdiv_resp_fdivsqrt__DOT__divSqrt__DOT__roundRawFNToRecFN__DOT__roundAnyRawFNToRecFN__DOT__isNaNOut)
                                                        ? 0x1c0U
                                                        : 0U)))) 
                                             << 0x17U)) 
                                         | (0x7fffffU 
                                            & ((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__io_fdiv_resp_fdivsqrt__DOT__divSqrt__DOT__roundRawFNToRecFN__DOT__roundAnyRawFNToRecFN__DOT__isNaNOut) 
                                                 | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__io_fdiv_resp_fdivsqrt__DOT__divSqrt__DOT__roundRawFNToRecFN__DOT__roundAnyRawFNToRecFN__DOT____VdfgRegularize_ha36442bc_0_10))
                                                 ? 
                                                ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__io_fdiv_resp_fdivsqrt__DOT__divSqrt__DOT__roundRawFNToRecFN__DOT__roundAnyRawFNToRecFN__DOT__isNaNOut) 
                                                 << 0x16U)
                                                 : 
                                                ((0x2000000U 
                                                  & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__io_fdiv_resp_fdivsqrt__DOT__divSqrt__DOT__divSqrtRecFNToRaw__DOT__divSqrtRawFN__DOT__sigX_Z)
                                                  ? 
                                                 (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__io_fdiv_resp_fdivsqrt__DOT__divSqrt__DOT__roundRawFNToRecFN__DOT__roundAnyRawFNToRecFN__DOT__roundedSig 
                                                  >> 1U)
                                                  : vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__io_fdiv_resp_fdivsqrt__DOT__divSqrt__DOT__roundRawFNToRecFN__DOT__roundAnyRawFNToRecFN__DOT__roundedSig)) 
                                               | (- (IData)((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__io_fdiv_resp_fdivsqrt__DOT__divSqrt__DOT__roundRawFNToRecFN__DOT__roundAnyRawFNToRecFN__DOT__pegMaxFiniteMagOut)))))))));
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__2358(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__2358\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__io_fdiv_resp_fdivsqrt__DOT__divSqrt_1__DOT__roundRawFNToRecFN__DOT__roundAnyRawFNToRecFN__DOT__notNaN_isInfOut 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__io_fdiv_resp_fdivsqrt__DOT__divSqrt_1__DOT__roundRawFNToRecFN__DOT__roundAnyRawFNToRecFN__DOT__notNaN_isSpecialInfOut) 
           | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__io_fdiv_resp_fdivsqrt__DOT__divSqrt_1__DOT__roundRawFNToRecFN__DOT__roundAnyRawFNToRecFN__DOT__overflow) 
              & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__io_fdiv_resp_fdivsqrt__DOT__divSqrt_1__DOT__roundRawFNToRecFN__DOT__roundAnyRawFNToRecFN__DOT__overflow_roundMagUp)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__io_fdiv_resp_fdivsqrt__DOT__divSqrt_1__DOT__roundRawFNToRecFN__DOT__roundAnyRawFNToRecFN__DOT__pegMaxFiniteMagOut 
        = ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__io_fdiv_resp_fdivsqrt__DOT__divSqrt_1__DOT__roundRawFNToRecFN__DOT__roundAnyRawFNToRecFN__DOT__overflow_roundMagUp)) 
           & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__io_fdiv_resp_fdivsqrt__DOT__divSqrt_1__DOT__roundRawFNToRecFN__DOT__roundAnyRawFNToRecFN__DOT__overflow));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT___cork_auto_in_d_bits_opcode 
        = (7U & (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__cork__DOT__muxState_1_0)
                   ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__cork__DOT__d_d_bits_opcode)
                   : 0U) | (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__cork__DOT__muxState_1_1)
                              ? ((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__cork__DOT__q__DOT__ram_ext__DOT__Memory
                                  [vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__cork__DOT__q__DOT__deq_ptr_value][2U] 
                                  << 0x13U) | (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__cork__DOT__q__DOT__ram_ext__DOT__Memory
                                               [vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__cork__DOT__q__DOT__deq_ptr_value][2U] 
                                               >> 0xdU))
                              : 0U) | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__cork__DOT__muxState_1_2)
                                        ? ((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__cork__DOT__q_1__DOT__ram_ext__DOT__Memory
                                            [vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__cork__DOT__q_1__DOT__deq_ptr_value][2U] 
                                            << 0x13U) 
                                           | (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__cork__DOT__q_1__DOT__ram_ext__DOT__Memory
                                              [vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__cork__DOT__q_1__DOT__deq_ptr_value][2U] 
                                              >> 0xdU))
                                        : 0U))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__fpu__DOT__fpu__DOT__dfma__DOT__fma__DOT__roundRawFNToRecFN__DOT__roundAnyRawFNToRecFN__DOT__pegMaxFiniteMagOut 
        = ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__fpu__DOT__fpu__DOT__dfma__DOT__fma__DOT__roundRawFNToRecFN__DOT__roundAnyRawFNToRecFN__DOT__overflow_roundMagUp)) 
           & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__fpu__DOT__fpu__DOT__dfma__DOT__fma__DOT__roundRawFNToRecFN__DOT__roundAnyRawFNToRecFN__DOT__overflow));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__fpu__DOT__fpu__DOT__dfma__DOT__fma__DOT__roundRawFNToRecFN__DOT__roundAnyRawFNToRecFN__DOT__notNaN_isInfOut 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__fpu__DOT__fpu__DOT__dfma__DOT__fma__DOT__roundRawFNToRecFN_io_in_pipe_b_isInf) 
           | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__fpu__DOT__fpu__DOT__dfma__DOT__fma__DOT__roundRawFNToRecFN__DOT__roundAnyRawFNToRecFN__DOT__overflow) 
              & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__fpu__DOT__fpu__DOT__dfma__DOT__fma__DOT__roundRawFNToRecFN__DOT__roundAnyRawFNToRecFN__DOT__overflow_roundMagUp)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__fpu__DOT__fpu__DOT__fpmu__DOT__narrower__DOT__roundAnyRawFNToRecFN__DOT__sRoundedExp 
        = (0x7fffU & (((0x4000U & (((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__fpu__DOT__fpu__DOT__fpmu__DOT__in_pipe_b_in1[1U] 
                                     >> 0x14U) - (IData)(0x700U)) 
                                   << 1U)) | (0x3fffU 
                                              & ((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__fpu__DOT__fpu__DOT__fpmu__DOT__in_pipe_b_in1[1U] 
                                                  >> 0x14U) 
                                                 - (IData)(0x700U)))) 
                      + (3U & (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__fpu__DOT__fpu__DOT__fpmu__DOT__narrower__DOT__roundAnyRawFNToRecFN__DOT__roundedSig 
                               >> 0x18U))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__mmios_0__DOT___GEN_5 
        = ((0U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__mmios_0__DOT__state)) 
           & ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__cacheable)) 
              & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs_io_req_0_valid)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT___mshr_io_req_sec_val_T_4 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs_io_req_0_valid) 
           & (0x1ffffU != vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__sdq_val));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT___dcache_io_lsu_resp_0_valid 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__s2_valid_REG) 
           & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__s2_send_resp_0));
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__2359(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__2359\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___ldq_idx_T 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__will_fire_load_agen_exec_0) 
           | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__will_fire_load_agen_0));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___will_fire_store_agen_0_will_fire_T_6 
        = (1U & ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__will_fire_load_agen_exec_0)) 
                 & (~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__will_fire_load_agen_0))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___will_fire_store_agen_0_will_fire_T_2 
        = ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__will_fire_load_agen_0)) 
           & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___will_fire_load_agen_0_will_fire_T_2));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst 
        = (((1U & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__fb__DOT__head))
             ? vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__fb__DOT__fb_uop_ram_0_inst
             : 0U) | (((2U & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__fb__DOT__head))
                        ? vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__fb__DOT__fb_uop_ram_1_inst
                        : 0U) | (((4U & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__fb__DOT__head))
                                   ? vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__fb__DOT__fb_uop_ram_2_inst
                                   : 0U) | (((8U & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__fb__DOT__head))
                                              ? vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__fb__DOT__fb_uop_ram_3_inst
                                              : 0U) 
                                            | (((0x10U 
                                                 & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__fb__DOT__head))
                                                 ? vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__fb__DOT__fb_uop_ram_4_inst
                                                 : 0U) 
                                               | (((0x20U 
                                                    & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__fb__DOT__head))
                                                    ? vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__fb__DOT__fb_uop_ram_5_inst
                                                    : 0U) 
                                                  | (((0x40U 
                                                       & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__fb__DOT__head))
                                                       ? vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__fb__DOT__fb_uop_ram_6_inst
                                                       : 0U) 
                                                     | ((0x80U 
                                                         & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__fb__DOT__head))
                                                         ? vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__fb__DOT__fb_uop_ram_7_inst
                                                         : 0U))))))));
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__2360(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__2360\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___tlb_io_resp_ae_inst 
        = (0U != ((~ ((~ ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__tlb__DOT____VdfgRegularize_hbd8e0bb6_0_23) 
                          | (((((0x1000U & ((IData)(
                                                    (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__tlb__DOT__special_entry_data_0 
                                                     >> 0x12U)) 
                                            << 0xcU)) 
                                | (0x800U & ((IData)(
                                                     (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__tlb__DOT__superpage_entries_3_data_0 
                                                      >> 0x12U)) 
                                             << 0xbU))) 
                               | ((0x400U & ((IData)(
                                                     (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__tlb__DOT__superpage_entries_2_data_0 
                                                      >> 0x12U)) 
                                             << 0xaU)) 
                                  | (0x200U & ((IData)(
                                                       (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__tlb__DOT__superpage_entries_1_data_0 
                                                        >> 0x12U)) 
                                               << 9U)))) 
                              | ((0x100U & ((IData)(
                                                    (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__tlb__DOT__superpage_entries_0_data_0 
                                                     >> 0x12U)) 
                                            << 8U)) 
                                 | ((0x80U & ((IData)(
                                                      (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__tlb__DOT___GEN_22 
                                                       >> 0x12U)) 
                                              << 7U)) 
                                    | (0x40U & ((IData)(
                                                        (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__tlb__DOT___GEN_20 
                                                         >> 0x12U)) 
                                                << 6U))))) 
                             | (((0x20U & ((IData)(
                                                   (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__tlb__DOT___GEN_18 
                                                    >> 0x12U)) 
                                           << 5U)) 
                                 | ((0x10U & ((IData)(
                                                      (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__tlb__DOT___GEN_16 
                                                       >> 0x12U)) 
                                              << 4U)) 
                                    | (8U & ((IData)(
                                                     (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__tlb__DOT___GEN_14 
                                                      >> 0x12U)) 
                                             << 3U)))) 
                                | ((4U & ((IData)((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__tlb__DOT___GEN_12 
                                                   >> 0x12U)) 
                                          << 2U)) | 
                                   ((2U & ((IData)(
                                                   (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__tlb__DOT___GEN_10 
                                                    >> 0x12U)) 
                                           << 1U)) 
                                    | (1U & (IData)(
                                                    (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__tlb__DOT___GEN_8 
                                                     >> 0x12U))))))))) 
                      & ((((0x3000U & ((- (IData)((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__tlb__DOT__prot_x))) 
                                       << 0xcU)) | 
                           ((0x800U & ((IData)((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__tlb__DOT__superpage_entries_3_data_0 
                                                >> 7U)) 
                                       << 0xbU)) | 
                            (0x400U & ((IData)((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__tlb__DOT__superpage_entries_2_data_0 
                                                >> 7U)) 
                                       << 0xaU)))) 
                          | ((0x200U & ((IData)((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__tlb__DOT__superpage_entries_1_data_0 
                                                 >> 7U)) 
                                        << 9U)) | (
                                                   (0x100U 
                                                    & ((IData)(
                                                               (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__tlb__DOT__superpage_entries_0_data_0 
                                                                >> 7U)) 
                                                       << 8U)) 
                                                   | (0x80U 
                                                      & ((IData)(
                                                                 (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__tlb__DOT___GEN_22 
                                                                  >> 7U)) 
                                                         << 7U))))) 
                         | ((((0x40U & ((IData)((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__tlb__DOT___GEN_20 
                                                 >> 7U)) 
                                        << 6U)) | (0x20U 
                                                   & ((IData)(
                                                              (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__tlb__DOT___GEN_18 
                                                               >> 7U)) 
                                                      << 5U))) 
                             | ((0x10U & ((IData)((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__tlb__DOT___GEN_16 
                                                   >> 7U)) 
                                          << 4U)) | 
                                (8U & ((IData)((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__tlb__DOT___GEN_14 
                                                >> 7U)) 
                                       << 3U)))) | 
                            ((4U & ((IData)((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__tlb__DOT___GEN_12 
                                             >> 7U)) 
                                    << 2U)) | ((2U 
                                                & ((IData)(
                                                           (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__tlb__DOT___GEN_10 
                                                            >> 7U)) 
                                                   << 1U)) 
                                               | (1U 
                                                  & (IData)(
                                                            (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__tlb__DOT___GEN_8 
                                                             >> 7U))))))))) 
                  & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__tlb__DOT__hits)));
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__2361(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__2361\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__tlb__DOT___sectored_entries_0_0_data_T 
        = (((QData)((IData)(((0x1ffffeU & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__r_pte_ppn) 
                                           << 1U)) 
                             | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__r_pte_u)))) 
            << 0x15U) | (QData)((IData)((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__tlb__DOT__newEntry_g) 
                                          << 0x14U) 
                                         | (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__resp_ae_ptw) 
                                             << 0x13U) 
                                            | (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__resp_ae_final) 
                                                << 0x12U) 
                                               | ((((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__resp_pf) 
                                                      << 0x10U) 
                                                     | (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__resp_gf) 
                                                         << 0xfU) 
                                                        | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__tlb__DOT__newEntry_sw) 
                                                           << 0xeU))) 
                                                    | (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__tlb__DOT__newEntry_sx) 
                                                        << 0xdU) 
                                                       | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__tlb__DOT__newEntry_sr) 
                                                          << 0xcU))) 
                                                   | ((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__resp_hw) 
                                                        << 0xbU) 
                                                       | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__resp_hx) 
                                                          << 0xaU)) 
                                                      | (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__resp_hr) 
                                                          << 9U) 
                                                         | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__tlb__DOT__prot_w) 
                                                            << 8U)))) 
                                                  | ((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__tlb__DOT__prot_x) 
                                                       << 7U) 
                                                      | (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__tlb__DOT__prot_r) 
                                                          << 6U) 
                                                         | (0x30U 
                                                            & ((- (IData)((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__tlb__DOT___pma_io_resp_w))) 
                                                               << 4U)))) 
                                                     | ((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__tlb__DOT___pma_io_resp_w) 
                                                          << 3U) 
                                                         | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__tlb__DOT___pma_io_resp_eff) 
                                                            << 2U)) 
                                                        | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__tlb__DOT___pma_io_resp_cacheable) 
                                                           << 1U))))))))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_67 
        = (0xfffffU & (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_66 
                       | (((IData)(1U) << (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__b2_uop_rob_idx)) 
                          >> 0xcU)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__iregfile__DOT__rfs_0__DOT___GEN_8 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__iregfile__DOT__rfs_0__DOT__use_port_8) 
           | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__iregfile__DOT__rfs_0__DOT__use_port_5));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__iregfile__DOT__rfs_0__DOT___GEN_14 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__iregfile__DOT__rfs_0__DOT__use_port_10) 
           | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__iregfile__DOT__rfs_0__DOT__use_port_9));
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__2362(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__2362\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__iregfile__DOT__rfs_0__DOT___GEN_13 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__iregfile__DOT__rfs_0__DOT__use_port_10) 
           | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__iregfile__DOT__rfs_0__DOT___GEN_6));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___rob_io_flush_valid 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__exception_thrown) 
           | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__flush_commit_mask_0));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___iregfile_io_arb_read_reqs_5_ready 
        = (3U > (7U & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__iregfile__DOT__rfs_0__DOT___io_arb_read_reqs_5_ready_T_1) 
                       + (3U & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__iregfile__DOT__rfs_0__DOT____VdfgRegularize_h1a867a07_0_4) 
                                + (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___unique_exe_unit_0_io_arb_irf_reqs_0_valid))))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__iregfile__DOT__rfs_0__DOT__use_port_12 
        = ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__iregfile__DOT__rfs_0__DOT___GEN_12)) 
           & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___unique_exe_unit_0_io_arb_irf_reqs_0_valid));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unq_iss_unit__DOT__iss_ready_0_0 
        = (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unq_iss_unit__DOT__slots_0__DOT__slot_uop_fu_code_3) 
            | (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unq_iss_unit__DOT__slots_0__DOT__slot_uop_fu_code_4) 
                & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___unique_exe_unit_0_io_ready_fu_types_4)) 
               | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unq_iss_unit__DOT__slots_0__DOT__slot_uop_fu_code_5) 
                  | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__io_ifpu_resp_ifpu_ready_REG) 
                     & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unq_iss_unit__DOT__slots_0__DOT__slot_uop_fu_code_8))))) 
           & ((~ ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unq_iss_unit__DOT__slots_0__DOT__slot_uop_ppred_busy) 
                  | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unq_iss_unit__DOT__slots_0__DOT__slot_uop_prs2_busy) 
                     | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unq_iss_unit__DOT__slots_0__DOT__slot_uop_iw_issued) 
                        | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unq_iss_unit__DOT__slots_0__DOT__slot_uop_prs1_busy))))) 
              & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unq_iss_unit__DOT__slots_0__DOT__slot_valid)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unq_iss_unit__DOT__iss_ready_0_1 
        = (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unq_iss_unit__DOT__slots_1__DOT__slot_uop_fu_code_3) 
            | (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unq_iss_unit__DOT__slots_1__DOT__slot_uop_fu_code_4) 
                & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___unique_exe_unit_0_io_ready_fu_types_4)) 
               | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unq_iss_unit__DOT__slots_1__DOT__slot_uop_fu_code_5) 
                  | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__io_ifpu_resp_ifpu_ready_REG) 
                     & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unq_iss_unit__DOT__slots_1__DOT__slot_uop_fu_code_8))))) 
           & ((~ ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unq_iss_unit__DOT__slots_1__DOT__slot_uop_ppred_busy) 
                  | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unq_iss_unit__DOT__slots_1__DOT__slot_uop_prs2_busy) 
                     | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unq_iss_unit__DOT__slots_1__DOT__slot_uop_iw_issued) 
                        | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unq_iss_unit__DOT__slots_1__DOT__slot_uop_prs1_busy))))) 
              & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unq_iss_unit__DOT__slots_1__DOT__slot_valid)));
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__2363(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__2363\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unq_iss_unit__DOT__iss_ready_0_2 
        = (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unq_iss_unit__DOT__slots_2__DOT__slot_uop_fu_code_3) 
            | (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unq_iss_unit__DOT__slots_2__DOT__slot_uop_fu_code_4) 
                & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___unique_exe_unit_0_io_ready_fu_types_4)) 
               | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unq_iss_unit__DOT__slots_2__DOT__slot_uop_fu_code_5) 
                  | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__io_ifpu_resp_ifpu_ready_REG) 
                     & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unq_iss_unit__DOT__slots_2__DOT__slot_uop_fu_code_8))))) 
           & ((~ ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unq_iss_unit__DOT__slots_2__DOT__slot_uop_ppred_busy) 
                  | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unq_iss_unit__DOT__slots_2__DOT__slot_uop_prs2_busy) 
                     | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unq_iss_unit__DOT__slots_2__DOT__slot_uop_iw_issued) 
                        | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unq_iss_unit__DOT__slots_2__DOT__slot_uop_prs1_busy))))) 
              & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unq_iss_unit__DOT__slots_2__DOT__slot_valid)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unq_iss_unit__DOT__iss_ready_0_3 
        = (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unq_iss_unit__DOT__slots_3__DOT__slot_uop_fu_code_3) 
            | (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unq_iss_unit__DOT__slots_3__DOT__slot_uop_fu_code_4) 
                & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___unique_exe_unit_0_io_ready_fu_types_4)) 
               | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unq_iss_unit__DOT__slots_3__DOT__slot_uop_fu_code_5) 
                  | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__io_ifpu_resp_ifpu_ready_REG) 
                     & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unq_iss_unit__DOT__slots_3__DOT__slot_uop_fu_code_8))))) 
           & ((~ ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unq_iss_unit__DOT__slots_3__DOT__slot_uop_ppred_busy) 
                  | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unq_iss_unit__DOT__slots_3__DOT__slot_uop_prs2_busy) 
                     | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unq_iss_unit__DOT__slots_3__DOT__slot_uop_iw_issued) 
                        | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unq_iss_unit__DOT__slots_3__DOT__slot_uop_prs1_busy))))) 
              & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unq_iss_unit__DOT__slots_3__DOT__slot_valid)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unq_iss_unit__DOT__iss_ready_0_4 
        = (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unq_iss_unit__DOT__slots_4__DOT__slot_uop_fu_code_3) 
            | (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unq_iss_unit__DOT__slots_4__DOT__slot_uop_fu_code_4) 
                & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___unique_exe_unit_0_io_ready_fu_types_4)) 
               | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unq_iss_unit__DOT__slots_4__DOT__slot_uop_fu_code_5) 
                  | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__io_ifpu_resp_ifpu_ready_REG) 
                     & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unq_iss_unit__DOT__slots_4__DOT__slot_uop_fu_code_8))))) 
           & ((~ ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unq_iss_unit__DOT__slots_4__DOT__slot_uop_ppred_busy) 
                  | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unq_iss_unit__DOT__slots_4__DOT__slot_uop_prs2_busy) 
                     | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unq_iss_unit__DOT__slots_4__DOT__slot_uop_iw_issued) 
                        | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unq_iss_unit__DOT__slots_4__DOT__slot_uop_prs1_busy))))) 
              & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unq_iss_unit__DOT__slots_4__DOT__slot_valid)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unq_iss_unit__DOT__iss_ready_0_5 
        = (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unq_iss_unit__DOT__slots_5__DOT__slot_uop_fu_code_3) 
            | (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unq_iss_unit__DOT__slots_5__DOT__slot_uop_fu_code_4) 
                & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___unique_exe_unit_0_io_ready_fu_types_4)) 
               | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unq_iss_unit__DOT__slots_5__DOT__slot_uop_fu_code_5) 
                  | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__io_ifpu_resp_ifpu_ready_REG) 
                     & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unq_iss_unit__DOT__slots_5__DOT__slot_uop_fu_code_8))))) 
           & ((~ ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unq_iss_unit__DOT__slots_5__DOT__slot_uop_ppred_busy) 
                  | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unq_iss_unit__DOT__slots_5__DOT__slot_uop_prs2_busy) 
                     | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unq_iss_unit__DOT__slots_5__DOT__slot_uop_iw_issued) 
                        | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unq_iss_unit__DOT__slots_5__DOT__slot_uop_prs1_busy))))) 
              & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unq_iss_unit__DOT__slots_5__DOT__slot_valid)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unq_iss_unit__DOT__iss_ready_0_6 
        = (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unq_iss_unit__DOT__slots_6__DOT__slot_uop_fu_code_3) 
            | (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unq_iss_unit__DOT__slots_6__DOT__slot_uop_fu_code_4) 
                & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___unique_exe_unit_0_io_ready_fu_types_4)) 
               | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unq_iss_unit__DOT__slots_6__DOT__slot_uop_fu_code_5) 
                  | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__io_ifpu_resp_ifpu_ready_REG) 
                     & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unq_iss_unit__DOT__slots_6__DOT__slot_uop_fu_code_8))))) 
           & ((~ ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unq_iss_unit__DOT__slots_6__DOT__slot_uop_ppred_busy) 
                  | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unq_iss_unit__DOT__slots_6__DOT__slot_uop_prs2_busy) 
                     | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unq_iss_unit__DOT__slots_6__DOT__slot_uop_iw_issued) 
                        | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unq_iss_unit__DOT__slots_6__DOT__slot_uop_prs1_busy))))) 
              & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unq_iss_unit__DOT__slots_6__DOT__slot_valid)));
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__2364(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__2364\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unq_iss_unit__DOT__iss_ready_0_7 
        = (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unq_iss_unit__DOT__slots_7__DOT__slot_uop_fu_code_3) 
            | (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unq_iss_unit__DOT__slots_7__DOT__slot_uop_fu_code_4) 
                & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___unique_exe_unit_0_io_ready_fu_types_4)) 
               | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unq_iss_unit__DOT__slots_7__DOT__slot_uop_fu_code_5) 
                  | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__io_ifpu_resp_ifpu_ready_REG) 
                     & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unq_iss_unit__DOT__slots_7__DOT__slot_uop_fu_code_8))))) 
           & ((~ ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unq_iss_unit__DOT__slots_7__DOT__slot_uop_ppred_busy) 
                  | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unq_iss_unit__DOT__slots_7__DOT__slot_uop_prs2_busy) 
                     | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unq_iss_unit__DOT__slots_7__DOT__slot_uop_iw_issued) 
                        | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unq_iss_unit__DOT__slots_7__DOT__slot_uop_prs1_busy))))) 
              & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unq_iss_unit__DOT__slots_7__DOT__slot_valid)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__io_fdiv_resp_fdivsqrt__DOT__kill 
        = ((0U != (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__io_fdiv_resp_fdivsqrt__DOT___r_req_out_valid_T)) 
           | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline_io_flush_pipeline_REG));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__respq__DOT___GEN_7 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__respq__DOT__do_enq) 
           & (0U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__respq__DOT__enq_ptr_value)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__respq__DOT___GEN_9 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__respq__DOT__do_enq) 
           & (1U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__respq__DOT__enq_ptr_value)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__respq__DOT___GEN_11 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__respq__DOT__do_enq) 
           & (2U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__respq__DOT__enq_ptr_value)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__respq__DOT___GEN_12 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__respq__DOT__do_enq) 
           & (3U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__respq__DOT__enq_ptr_value)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__retry_queue__DOT___GEN_112 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__retry_queue__DOT__do_enq) 
           & (0U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__retry_queue__DOT__enq_ptr_value)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__retry_queue__DOT___GEN_114 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__retry_queue__DOT__do_enq) 
           & (1U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__retry_queue__DOT__enq_ptr_value)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__retry_queue__DOT___GEN_116 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__retry_queue__DOT__do_enq) 
           & (2U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__retry_queue__DOT__enq_ptr_value)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__retry_queue__DOT___GEN_118 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__retry_queue__DOT__do_enq) 
           & (3U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__retry_queue__DOT__enq_ptr_value)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__retry_queue__DOT___GEN_120 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__retry_queue__DOT__do_enq) 
           & (4U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__retry_queue__DOT__enq_ptr_value)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__retry_queue__DOT___GEN_122 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__retry_queue__DOT__do_enq) 
           & (5U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__retry_queue__DOT__enq_ptr_value)));
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__2365(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__2365\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__retry_queue__DOT___GEN_124 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__retry_queue__DOT__do_enq) 
           & (6U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__retry_queue__DOT__enq_ptr_value)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__retry_queue__DOT___GEN_125 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__retry_queue__DOT__do_enq) 
           & (7U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__retry_queue__DOT__enq_ptr_value)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_525 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_13)
            ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT____VdfgRegularize_h94b53d93_0_137)
            : (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__ldq_valid_0));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_526 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_14)
            ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT____VdfgRegularize_h94b53d93_0_137)
            : (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__ldq_valid_1));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_527 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_15)
            ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT____VdfgRegularize_h94b53d93_0_137)
            : (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__ldq_valid_2));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_528 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_16)
            ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT____VdfgRegularize_h94b53d93_0_137)
            : (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__ldq_valid_3));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_529 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_17)
            ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT____VdfgRegularize_h94b53d93_0_137)
            : (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__ldq_valid_4));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_530 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_18)
            ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT____VdfgRegularize_h94b53d93_0_137)
            : (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__ldq_valid_5));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_531 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_19)
            ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT____VdfgRegularize_h94b53d93_0_137)
            : (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__ldq_valid_6));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_532 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_20)
            ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT____VdfgRegularize_h94b53d93_0_137)
            : (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__ldq_valid_7));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_543 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_542)
            ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT____VdfgRegularize_h94b53d93_0_137)
            : (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_valid_0));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_545 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_544)
            ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT____VdfgRegularize_h94b53d93_0_137)
            : (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_valid_1));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_547 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_546)
            ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT____VdfgRegularize_h94b53d93_0_137)
            : (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_valid_2));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_549 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_548)
            ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT____VdfgRegularize_h94b53d93_0_137)
            : (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_valid_3));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_551 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_550)
            ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT____VdfgRegularize_h94b53d93_0_137)
            : (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_valid_4));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_553 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_552)
            ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT____VdfgRegularize_h94b53d93_0_137)
            : (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_valid_5));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_555 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_554)
            ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT____VdfgRegularize_h94b53d93_0_137)
            : (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_valid_6));
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__2366(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__2366\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_557 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_556)
            ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT____VdfgRegularize_h94b53d93_0_137)
            : (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_valid_7));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT___slots_7_io_will_be_valid 
        = ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__slots_7__DOT__killed)) 
           & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__slots_7__DOT__next_valid));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unq_iss_unit__DOT___slots_7_io_will_be_valid 
        = ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unq_iss_unit__DOT__slots_7__DOT__killed)) 
           & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unq_iss_unit__DOT__slots_7__DOT__next_valid));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__alu_iss_unit__DOT___slots_7_io_will_be_valid 
        = ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__alu_iss_unit__DOT__slots_7__DOT__killed)) 
           & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__alu_iss_unit__DOT__slots_7__DOT__next_valid));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT___slots_6_io_will_be_valid 
        = ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__slots_6__DOT__killed)) 
           & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__slots_6__DOT__next_valid));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unq_iss_unit__DOT___slots_6_io_will_be_valid 
        = ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unq_iss_unit__DOT__slots_6__DOT__killed)) 
           & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unq_iss_unit__DOT__slots_6__DOT__next_valid));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__alu_iss_unit__DOT___slots_6_io_will_be_valid 
        = ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__alu_iss_unit__DOT__slots_6__DOT__killed)) 
           & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__alu_iss_unit__DOT__slots_6__DOT__next_valid));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT___slots_5_io_will_be_valid 
        = ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__slots_5__DOT__killed)) 
           & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__slots_5__DOT__next_valid));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unq_iss_unit__DOT___slots_5_io_will_be_valid 
        = ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unq_iss_unit__DOT__slots_5__DOT__killed)) 
           & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unq_iss_unit__DOT__slots_5__DOT__next_valid));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__alu_iss_unit__DOT___slots_5_io_will_be_valid 
        = ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__alu_iss_unit__DOT__slots_5__DOT__killed)) 
           & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__alu_iss_unit__DOT__slots_5__DOT__next_valid));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT___slots_4_io_will_be_valid 
        = ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__slots_4__DOT__killed)) 
           & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__slots_4__DOT__next_valid));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unq_iss_unit__DOT___slots_4_io_will_be_valid 
        = ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unq_iss_unit__DOT__slots_4__DOT__killed)) 
           & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unq_iss_unit__DOT__slots_4__DOT__next_valid));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__alu_iss_unit__DOT___slots_4_io_will_be_valid 
        = ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__alu_iss_unit__DOT__slots_4__DOT__killed)) 
           & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__alu_iss_unit__DOT__slots_4__DOT__next_valid));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT___slots_3_io_will_be_valid 
        = ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__slots_3__DOT__killed)) 
           & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__slots_3__DOT__next_valid));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unq_iss_unit__DOT___slots_3_io_will_be_valid 
        = ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unq_iss_unit__DOT__slots_3__DOT__killed)) 
           & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unq_iss_unit__DOT__slots_3__DOT__next_valid));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__alu_iss_unit__DOT___slots_3_io_will_be_valid 
        = ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__alu_iss_unit__DOT__slots_3__DOT__killed)) 
           & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__alu_iss_unit__DOT__slots_3__DOT__next_valid));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT___slots_2_io_will_be_valid 
        = ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__slots_2__DOT__killed)) 
           & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__slots_2__DOT__next_valid));
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__2367(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__2367\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unq_iss_unit__DOT___slots_2_io_will_be_valid 
        = ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unq_iss_unit__DOT__slots_2__DOT__killed)) 
           & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unq_iss_unit__DOT__slots_2__DOT__next_valid));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__alu_iss_unit__DOT___slots_2_io_will_be_valid 
        = ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__alu_iss_unit__DOT__slots_2__DOT__killed)) 
           & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__alu_iss_unit__DOT__slots_2__DOT__next_valid));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT___slots_1_io_will_be_valid 
        = ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__slots_1__DOT__killed)) 
           & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__slots_1__DOT__next_valid));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unq_iss_unit__DOT___slots_1_io_will_be_valid 
        = ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unq_iss_unit__DOT__slots_1__DOT__killed)) 
           & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unq_iss_unit__DOT__slots_1__DOT__next_valid));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__alu_iss_unit__DOT___slots_1_io_will_be_valid 
        = ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__alu_iss_unit__DOT__slots_1__DOT__killed)) 
           & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__alu_iss_unit__DOT__slots_1__DOT__next_valid));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT___slots_0_io_will_be_valid 
        = ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__slots_0__DOT__killed)) 
           & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__slots_0__DOT__next_valid));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unq_iss_unit__DOT___slots_0_io_will_be_valid 
        = ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unq_iss_unit__DOT__slots_0__DOT__killed)) 
           & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unq_iss_unit__DOT__slots_0__DOT__next_valid));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__alu_iss_unit__DOT___slots_0_io_will_be_valid 
        = ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__alu_iss_unit__DOT__slots_0__DOT__killed)) 
           & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__alu_iss_unit__DOT__slots_0__DOT__next_valid));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__alu_exe_unit_0__DOT__alu__DOT__alu__DOT___rotout_l_T_18 
        = ((0xffff0000ffffULL & (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__alu_exe_unit_0__DOT__alu__DOT__alu__DOT___rotout_l_T_8 
                                 >> 0x10U)) | (0xffff0000ffff0000ULL 
                                               & (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__alu_exe_unit_0__DOT__alu__DOT__alu__DOT___rotout_l_T_8 
                                                  << 0x10U)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__alu_exe_unit_0__DOT__alu__DOT__alu__DOT___shout_l_T_8 
        = (((QData)((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__alu_exe_unit_0__DOT__alu__DOT__alu__DOT___shout_r_T_5[0U])) 
            << 0x20U) | (QData)((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__alu_exe_unit_0__DOT__alu__DOT__alu__DOT___shout_r_T_5[1U])));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3__DOT__ram[0U] 
        = vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3__DOT__ram[0U];
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3__DOT__ram[1U] 
        = vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3__DOT__ram[1U];
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3__DOT__ram[2U] 
        = vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3__DOT__ram[2U];
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3__DOT__ram[3U] 
        = vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3__DOT__ram[3U];
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3__DOT__ram[4U] 
        = vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3__DOT__ram[4U];
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3__DOT__ram[5U] 
        = vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3__DOT__ram[5U];
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3__DOT__ram[6U] 
        = vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3__DOT__ram[6U];
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3__DOT__ram[7U] 
        = vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3__DOT__ram[7U];
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3__DOT__ram[8U] 
        = vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3__DOT__ram[8U];
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3__DOT__ram[9U] 
        = vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3__DOT__ram[9U];
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3__DOT__ram[0xaU] 
        = vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3__DOT__ram[0xaU];
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3__DOT__ram[0xbU] 
        = vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3__DOT__ram[0xbU];
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3__DOT__ram[0xcU] 
        = vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3__DOT__ram[0xcU];
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3__DOT__ram[0xdU] 
        = vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3__DOT__ram[0xdU];
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3__DOT__ram[0xeU] 
        = vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3__DOT__ram[0xeU];
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3__DOT__ram[0xfU] 
        = vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3__DOT__ram[0xfU];
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3__DOT__ram[0x10U] 
        = vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3__DOT__ram[0x10U];
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3__DOT__ram[0x11U] 
        = vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3__DOT__ram[0x11U];
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3__DOT__ram[0x12U] 
        = vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3__DOT__ram[0x12U];
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3__DOT__ram[0x13U] 
        = vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3__DOT__ram[0x13U];
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3__DOT__ram[0x14U] 
        = vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3__DOT__ram[0x14U];
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3__DOT__ram[0x15U] 
        = vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3__DOT__ram[0x15U];
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3__DOT__ram[0x16U] 
        = vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3__DOT__ram[0x16U];
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3__DOT__ram[0x17U] 
        = vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3__DOT__ram[0x17U];
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3_bpd_queue__DOT__maybe_full 
        = vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3_bpd_queue__DOT__maybe_full;
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__alu__DOT__alu__DOT___popc_in_T_137 
        = ((1U & (IData)((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__alu__DOT____Vcellinp__alu__io_in2 
                          >> 1U))) ? ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__alu__DOT____Vcellinp__alu__io_dw)
                                       ? vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__alu__DOT____Vcellinp__alu__io_in1
                                       : (QData)((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__alu__DOT____Vcellinp__alu__io_in1)))
            : (((1U & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__alu__DOT__alu__DOT__tz_in))
                 ? 1ULL : ((1U & (IData)((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__alu__DOT__alu__DOT__tz_in 
                                          >> 1U))) ? 2ULL
                            : ((1U & (IData)((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__alu__DOT__alu__DOT__tz_in 
                                              >> 2U)))
                                ? 4ULL : ((1U & (IData)(
                                                        (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__alu__DOT__alu__DOT__tz_in 
                                                         >> 3U)))
                                           ? 8ULL : 
                                          ((1U & (IData)(
                                                         (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__alu__DOT__alu__DOT__tz_in 
                                                          >> 4U)))
                                            ? 0x10ULL
                                            : ((1U 
                                                & (IData)(
                                                          (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__alu__DOT__alu__DOT__tz_in 
                                                           >> 5U)))
                                                ? 0x20ULL
                                                : (
                                                   (1U 
                                                    & (IData)(
                                                              (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__alu__DOT__alu__DOT__tz_in 
                                                               >> 6U)))
                                                    ? 0x40ULL
                                                    : 
                                                   ((1U 
                                                     & (IData)(
                                                               (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__alu__DOT__alu__DOT__tz_in 
                                                                >> 7U)))
                                                     ? 0x80ULL
                                                     : 
                                                    ((1U 
                                                      & (IData)(
                                                                (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__alu__DOT__alu__DOT__tz_in 
                                                                 >> 8U)))
                                                      ? 0x100ULL
                                                      : 
                                                     ((1U 
                                                       & (IData)(
                                                                 (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__alu__DOT__alu__DOT__tz_in 
                                                                  >> 9U)))
                                                       ? 0x200ULL
                                                       : 
                                                      ((1U 
                                                        & (IData)(
                                                                  (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__alu__DOT__alu__DOT__tz_in 
                                                                   >> 0xaU)))
                                                        ? 0x400ULL
                                                        : 
                                                       ((1U 
                                                         & (IData)(
                                                                   (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__alu__DOT__alu__DOT__tz_in 
                                                                    >> 0xbU)))
                                                         ? 0x800ULL
                                                         : 
                                                        ((1U 
                                                          & (IData)(
                                                                    (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__alu__DOT__alu__DOT__tz_in 
                                                                     >> 0xcU)))
                                                          ? 0x1000ULL
                                                          : 
                                                         ((1U 
                                                           & (IData)(
                                                                     (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__alu__DOT__alu__DOT__tz_in 
                                                                      >> 0xdU)))
                                                           ? 0x2000ULL
                                                           : 
                                                          ((1U 
                                                            & (IData)(
                                                                      (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__alu__DOT__alu__DOT__tz_in 
                                                                       >> 0xeU)))
                                                            ? 0x4000ULL
                                                            : 
                                                           ((1U 
                                                             & (IData)(
                                                                       (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__alu__DOT__alu__DOT__tz_in 
                                                                        >> 0xfU)))
                                                             ? 0x8000ULL
                                                             : 
                                                            ((1U 
                                                              & (IData)(
                                                                        (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__alu__DOT__alu__DOT__tz_in 
                                                                         >> 0x10U)))
                                                              ? 0x10000ULL
                                                              : 
                                                             ((1U 
                                                               & (IData)(
                                                                         (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__alu__DOT__alu__DOT__tz_in 
                                                                          >> 0x11U)))
                                                               ? 0x20000ULL
                                                               : 
                                                              ((1U 
                                                                & (IData)(
                                                                          (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__alu__DOT__alu__DOT__tz_in 
                                                                           >> 0x12U)))
                                                                ? 0x40000ULL
                                                                : 
                                                               ((1U 
                                                                 & (IData)(
                                                                           (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__alu__DOT__alu__DOT__tz_in 
                                                                            >> 0x13U)))
                                                                 ? 0x80000ULL
                                                                 : 
                                                                ((1U 
                                                                  & (IData)(
                                                                            (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__alu__DOT__alu__DOT__tz_in 
                                                                             >> 0x14U)))
                                                                  ? 0x100000ULL
                                                                  : 
                                                                 ((1U 
                                                                   & (IData)(
                                                                             (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__alu__DOT__alu__DOT__tz_in 
                                                                              >> 0x15U)))
                                                                   ? 0x200000ULL
                                                                   : 
                                                                  ((1U 
                                                                    & (IData)(
                                                                              (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__alu__DOT__alu__DOT__tz_in 
                                                                               >> 0x16U)))
                                                                    ? 0x400000ULL
                                                                    : 
                                                                   ((1U 
                                                                     & (IData)(
                                                                               (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__alu__DOT__alu__DOT__tz_in 
                                                                                >> 0x17U)))
                                                                     ? 0x800000ULL
                                                                     : 
                                                                    ((1U 
                                                                      & (IData)(
                                                                                (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__alu__DOT__alu__DOT__tz_in 
                                                                                >> 0x18U)))
                                                                      ? 0x1000000ULL
                                                                      : 
                                                                     ((1U 
                                                                       & (IData)(
                                                                                (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__alu__DOT__alu__DOT__tz_in 
                                                                                >> 0x19U)))
                                                                       ? 0x2000000ULL
                                                                       : 
                                                                      ((1U 
                                                                        & (IData)(
                                                                                (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__alu__DOT__alu__DOT__tz_in 
                                                                                >> 0x1aU)))
                                                                        ? 0x4000000ULL
                                                                        : 
                                                                       ((1U 
                                                                         & (IData)(
                                                                                (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__alu__DOT__alu__DOT__tz_in 
                                                                                >> 0x1bU)))
                                                                         ? 0x8000000ULL
                                                                         : 
                                                                        ((1U 
                                                                          & (IData)(
                                                                                (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__alu__DOT__alu__DOT__tz_in 
                                                                                >> 0x1cU)))
                                                                          ? 0x10000000ULL
                                                                          : 
                                                                         ((1U 
                                                                           & (IData)(
                                                                                (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__alu__DOT__alu__DOT__tz_in 
                                                                                >> 0x1dU)))
                                                                           ? 0x20000000ULL
                                                                           : 
                                                                          ((1U 
                                                                            & (IData)(
                                                                                (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__alu__DOT__alu__DOT__tz_in 
                                                                                >> 0x1eU)))
                                                                            ? 0x40000000ULL
                                                                            : 
                                                                           ((1U 
                                                                             & (IData)(
                                                                                (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__alu__DOT__alu__DOT__tz_in 
                                                                                >> 0x1fU)))
                                                                             ? 0x80000000ULL
                                                                             : 
                                                                            ((1U 
                                                                              & (IData)(
                                                                                (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__alu__DOT__alu__DOT__tz_in 
                                                                                >> 0x20U)))
                                                                              ? 0x100000000ULL
                                                                              : 
                                                                             ((1U 
                                                                               & (IData)(
                                                                                (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__alu__DOT__alu__DOT__tz_in 
                                                                                >> 0x21U)))
                                                                               ? 0x200000000ULL
                                                                               : 
                                                                              ((1U 
                                                                                & (IData)(
                                                                                (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__alu__DOT__alu__DOT__tz_in 
                                                                                >> 0x22U)))
                                                                                ? 0x400000000ULL
                                                                                : 
                                                                               ((1U 
                                                                                & (IData)(
                                                                                (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__alu__DOT__alu__DOT__tz_in 
                                                                                >> 0x23U)))
                                                                                 ? 0x800000000ULL
                                                                                 : 
                                                                                ((1U 
                                                                                & (IData)(
                                                                                (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__alu__DOT__alu__DOT__tz_in 
                                                                                >> 0x24U)))
                                                                                 ? 0x1000000000ULL
                                                                                 : 
                                                                                ((1U 
                                                                                & (IData)(
                                                                                (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__alu__DOT__alu__DOT__tz_in 
                                                                                >> 0x25U)))
                                                                                 ? 0x2000000000ULL
                                                                                 : 
                                                                                ((1U 
                                                                                & (IData)(
                                                                                (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__alu__DOT__alu__DOT__tz_in 
                                                                                >> 0x26U)))
                                                                                 ? 0x4000000000ULL
                                                                                 : 
                                                                                ((1U 
                                                                                & (IData)(
                                                                                (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__alu__DOT__alu__DOT__tz_in 
                                                                                >> 0x27U)))
                                                                                 ? 0x8000000000ULL
                                                                                 : 
                                                                                ((1U 
                                                                                & (IData)(
                                                                                (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__alu__DOT__alu__DOT__tz_in 
                                                                                >> 0x28U)))
                                                                                 ? 0x10000000000ULL
                                                                                 : 
                                                                                ((1U 
                                                                                & (IData)(
                                                                                (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__alu__DOT__alu__DOT__tz_in 
                                                                                >> 0x29U)))
                                                                                 ? 0x20000000000ULL
                                                                                 : 
                                                                                ((1U 
                                                                                & (IData)(
                                                                                (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__alu__DOT__alu__DOT__tz_in 
                                                                                >> 0x2aU)))
                                                                                 ? 0x40000000000ULL
                                                                                 : 
                                                                                ((1U 
                                                                                & (IData)(
                                                                                (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__alu__DOT__alu__DOT__tz_in 
                                                                                >> 0x2bU)))
                                                                                 ? 0x80000000000ULL
                                                                                 : 
                                                                                ((1U 
                                                                                & (IData)(
                                                                                (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__alu__DOT__alu__DOT__tz_in 
                                                                                >> 0x2cU)))
                                                                                 ? 0x100000000000ULL
                                                                                 : 
                                                                                ((1U 
                                                                                & (IData)(
                                                                                (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__alu__DOT__alu__DOT__tz_in 
                                                                                >> 0x2dU)))
                                                                                 ? 0x200000000000ULL
                                                                                 : 
                                                                                ((1U 
                                                                                & (IData)(
                                                                                (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__alu__DOT__alu__DOT__tz_in 
                                                                                >> 0x2eU)))
                                                                                 ? 0x400000000000ULL
                                                                                 : 
                                                                                ((1U 
                                                                                & (IData)(
                                                                                (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__alu__DOT__alu__DOT__tz_in 
                                                                                >> 0x2fU)))
                                                                                 ? 0x800000000000ULL
                                                                                 : 
                                                                                ((1U 
                                                                                & (IData)(
                                                                                (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__alu__DOT__alu__DOT__tz_in 
                                                                                >> 0x30U)))
                                                                                 ? 0x1000000000000ULL
                                                                                 : 
                                                                                ((1U 
                                                                                & (IData)(
                                                                                (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__alu__DOT__alu__DOT__tz_in 
                                                                                >> 0x31U)))
                                                                                 ? 0x2000000000000ULL
                                                                                 : 
                                                                                ((1U 
                                                                                & (IData)(
                                                                                (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__alu__DOT__alu__DOT__tz_in 
                                                                                >> 0x32U)))
                                                                                 ? 0x4000000000000ULL
                                                                                 : 
                                                                                ((1U 
                                                                                & (IData)(
                                                                                (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__alu__DOT__alu__DOT__tz_in 
                                                                                >> 0x33U)))
                                                                                 ? 0x8000000000000ULL
                                                                                 : 
                                                                                ((1U 
                                                                                & (IData)(
                                                                                (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__alu__DOT__alu__DOT__tz_in 
                                                                                >> 0x34U)))
                                                                                 ? 0x10000000000000ULL
                                                                                 : 
                                                                                ((1U 
                                                                                & (IData)(
                                                                                (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__alu__DOT__alu__DOT__tz_in 
                                                                                >> 0x35U)))
                                                                                 ? 0x20000000000000ULL
                                                                                 : 
                                                                                ((1U 
                                                                                & (IData)(
                                                                                (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__alu__DOT__alu__DOT__tz_in 
                                                                                >> 0x36U)))
                                                                                 ? 0x40000000000000ULL
                                                                                 : 
                                                                                ((1U 
                                                                                & (IData)(
                                                                                (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__alu__DOT__alu__DOT__tz_in 
                                                                                >> 0x37U)))
                                                                                 ? 0x80000000000000ULL
                                                                                 : 
                                                                                ((1U 
                                                                                & (IData)(
                                                                                (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__alu__DOT__alu__DOT__tz_in 
                                                                                >> 0x38U)))
                                                                                 ? 0x100000000000000ULL
                                                                                 : 
                                                                                ((1U 
                                                                                & (IData)(
                                                                                (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__alu__DOT__alu__DOT__tz_in 
                                                                                >> 0x39U)))
                                                                                 ? 0x200000000000000ULL
                                                                                 : 
                                                                                ((1U 
                                                                                & (IData)(
                                                                                (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__alu__DOT__alu__DOT__tz_in 
                                                                                >> 0x3aU)))
                                                                                 ? 0x400000000000000ULL
                                                                                 : 
                                                                                ((1U 
                                                                                & (IData)(
                                                                                (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__alu__DOT__alu__DOT__tz_in 
                                                                                >> 0x3bU)))
                                                                                 ? 0x800000000000000ULL
                                                                                 : 
                                                                                ((1U 
                                                                                & (IData)(
                                                                                (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__alu__DOT__alu__DOT__tz_in 
                                                                                >> 0x3cU)))
                                                                                 ? 0x1000000000000000ULL
                                                                                 : 
                                                                                ((1U 
                                                                                & (IData)(
                                                                                (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__alu__DOT__alu__DOT__tz_in 
                                                                                >> 0x3dU)))
                                                                                 ? 0x2000000000000000ULL
                                                                                 : 
                                                                                ((1U 
                                                                                & (IData)(
                                                                                (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__alu__DOT__alu__DOT__tz_in 
                                                                                >> 0x3eU)))
                                                                                 ? 0x4000000000000000ULL
                                                                                 : 
                                                                                ((QData)((IData)(
                                                                                (1U 
                                                                                & (IData)(
                                                                                (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__alu__DOT__alu__DOT__tz_in 
                                                                                >> 0x3fU))))) 
                                                                                << 0x3fU)))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))) 
               - 1ULL));
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__2368(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__2368\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__alu__DOT__alu__DOT____VdfgRegularize_h50534096_0_6 
        = ((0x5555555555555555ULL & (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__alu__DOT__alu__DOT___shin_T_56 
                                     >> 1U)) | (0xaaaaaaaaaaaaaaaaULL 
                                                & (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__alu__DOT__alu__DOT___shin_T_56 
                                                   << 1U)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT___core_io_ifu_redirect_flush 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT___core_io_ifu_redirect_val) 
           | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__r_xcpt_val) 
              | (0U != (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT___lsu_io_dmem_brupdate_b1_mispredict_mask))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fregfile__DOT__rfs_0__DOT___GEN_1 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fregfile__DOT__rfs_0__DOT__use_port_4) 
           | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fregfile__DOT__rfs_0__DOT__use_port_3));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fregfile__DOT__rfs_0__DOT__use_port_6 
        = ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fregfile__DOT__rfs_0__DOT___GEN_0)) 
           & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT___fp_exe_unit_0_io_arb_frf_reqs_2_valid));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__queue__DOT___GEN_6 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__queue__DOT__do_enq) 
           & (0U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__queue__DOT__enq_ptr_value)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__queue__DOT___GEN_8 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__queue__DOT__do_enq) 
           & (1U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__queue__DOT__enq_ptr_value)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__queue__DOT___GEN_10 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__queue__DOT__do_enq) 
           & (2U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__queue__DOT__enq_ptr_value)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__queue__DOT___GEN_12 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__queue__DOT__do_enq) 
           & (3U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__queue__DOT__enq_ptr_value)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__queue__DOT___GEN_14 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__queue__DOT__do_enq) 
           & (4U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__queue__DOT__enq_ptr_value)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__queue__DOT___GEN_16 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__queue__DOT__do_enq) 
           & (5U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__queue__DOT__enq_ptr_value)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__queue__DOT___GEN_18 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__queue__DOT__do_enq) 
           & (6U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__queue__DOT__enq_ptr_value)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__queue__DOT___GEN_20 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__queue__DOT__do_enq) 
           & (7U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__queue__DOT__enq_ptr_value)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__queue__DOT___GEN_22 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__queue__DOT__do_enq) 
           & (8U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__queue__DOT__enq_ptr_value)));
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__2369(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__2369\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__queue__DOT___GEN_24 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__queue__DOT__do_enq) 
           & (9U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__queue__DOT__enq_ptr_value)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT___slots_7_io_will_be_valid 
        = ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_7__DOT__killed)) 
           & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_7__DOT__next_valid));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT___slots_6_io_will_be_valid 
        = ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_6__DOT__killed)) 
           & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_6__DOT__next_valid));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT___slots_5_io_will_be_valid 
        = ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_5__DOT__killed)) 
           & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_5__DOT__next_valid));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT___slots_4_io_will_be_valid 
        = ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_4__DOT__killed)) 
           & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_4__DOT__next_valid));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT___slots_3_io_will_be_valid 
        = ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_3__DOT__killed)) 
           & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_3__DOT__next_valid));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT___slots_2_io_will_be_valid 
        = ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_2__DOT__killed)) 
           & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_2__DOT__next_valid));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT___slots_1_io_will_be_valid 
        = ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_1__DOT__killed)) 
           & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_1__DOT__next_valid));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT___slots_0_io_will_be_valid 
        = ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_0__DOT__killed)) 
           & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_0__DOT__next_valid));
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT___system_auto_cbus_fixedClockNode_anon_out_reset) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__icache__DOT__repl_way_prng__DOT__state_2 = 0U;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__lfsr_prng__DOT__state_2 = 0U;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__directory__DOT__victimLFSR_prng__DOT__state_2 = 0U;
    } else {
        if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT___frontend_io_cpu_perf_acquire) {
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__icache__DOT__repl_way_prng__DOT__state_2 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__icache__DOT__repl_way_prng__DOT__state_1;
        }
        if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__replace) {
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__lfsr_prng__DOT__state_2 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__lfsr_prng__DOT__state_1;
        }
        if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT____Vcellinp__directory__io_read_valid) {
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__directory__DOT__victimLFSR_prng__DOT__state_2 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__directory__DOT__victimLFSR_prng__DOT__state_1;
        }
    }
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__s1_update_write_way_prng__DOT__state_2 
        = ((1U & (~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT___system_auto_cbus_fixedClockNode_anon_out_reset))) 
           && (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__s1_update_write_way_prng__DOT__state_1));
    if ((1U & (~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__pred_rename_stage__DOT___GEN_20)))) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rename_stage__DOT__r_uop_ftq_idx 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_ftq_idx;
    }
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__cbus__DOT__in_xbar__DOT__latch 
        = ((0U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__cbus__DOT__in_xbar__DOT__beatsLeft)) 
           & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__cbus__DOT___atomics_auto_in_a_ready));
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__2370(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__2370\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__cbus__DOT___GEN_0 
        = (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__cbus__DOT___atomics_auto_in_a_ready) 
            & ((0U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__cbus__DOT__in_xbar__DOT__beatsLeft))
                ? ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__cbus__DOT__in_xbar__DOT__readys_readys) 
                   >> 1U) : (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__cbus__DOT__in_xbar__DOT__state_1))) 
           & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__cbus__DOT__nodeOut_a_valid));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT___cbus_auto_bus_xing_in_a_ready 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__cbus__DOT___atomics_auto_in_a_ready) 
           & ((0U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__cbus__DOT__in_xbar__DOT__beatsLeft))
               ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__cbus__DOT__in_xbar__DOT__readys_readys)
               : (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__cbus__DOT__in_xbar__DOT__state_0)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__cbus__DOT__atomics__DOT___GEN_5 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__cbus__DOT__atomics__DOT__source_i_ready) 
           & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__cbus__DOT__atomics__DOT__source_i_valid) 
              & ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__cbus__DOT__atomics__DOT__a_isSupported)) 
                 & (0U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__cbus__DOT__atomics__DOT__cam_s_0_state)))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__cbus__DOT__atomics__DOT___nodeOut_a_valid_T 
        = ((2U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__cbus__DOT__atomics__DOT__cam_s_0_state)) 
           | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__cbus__DOT__atomics__DOT__source_i_valid));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__cbus__DOT__atomics__DOT__winner_1 
        = ((2U != (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__cbus__DOT__atomics__DOT__cam_s_0_state)) 
           & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__cbus__DOT__atomics__DOT__source_i_valid));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT___requests_io_push_valid_T 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__request_valid) 
           & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__queue));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT___requests_io_push_bits_index_T_2 
        = (7U & ((3U & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__lowerMatches1) 
                        >> 5U)) | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__lowerMatches1) 
                                   >> 1U)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT___requests_io_push_bits_index_T_21 
        = ((0xfU & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__lowerMatches1) 
                    >> 3U)) | (0x6000U & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__lowerMatches1) 
                                          << 0xdU)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__bypassMatches 
        = ((0U != ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshr_selectOH) 
                   & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__lowerMatches1))) 
           & (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT____VdfgRegularize_hd1f689b4_0_9) 
               | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT___sinkC_io_req_valid))
               ? (~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT____VdfgRegularize_hd1f689b4_0_9))
               : ((0U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT___b_pop_T)) 
                  & (0U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT___a_pop_T)))));
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__2371(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__2371\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__issue_slots_7_in_uop_bits_iw_p1_bypass_hint 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT___GEN) 
           & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__prs1_wakeups_0));
    if ((1U & (~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__pred_rename_stage__DOT___GEN_20)))) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rename_stage__DOT__r_uop_is_sfence 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_is_sfence;
    }
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__buffer__DOT__nodeIn_b_q__DOT__do_enq 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT___InclusiveCache_inner_TLBuffer_auto_out_b_ready) 
           & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT___l2_auto_in_b_valid));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT____Vcellinp__sourceC__io_req_bits_source 
        = ((2U & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__schedule_c_bits_opcode))
            ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshr_select)
            : 0U);
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sourceA__DOT__io_a_q__DOT____Vcellinp__ram_ext__W0_data[0U] = 0U;
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sourceA__DOT__io_a_q__DOT____Vcellinp__ram_ext__W0_data[1U] = 0U;
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sourceA__DOT__io_a_q__DOT____Vcellinp__ram_ext__W0_data[2U] 
        = (0x1feU | (0xfffffe00U & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sourceA__DOT__io_a_q__DOT____Vcellinp__ram_ext__W0_data[2U]));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sourceA__DOT__io_a_q__DOT____Vcellinp__ram_ext__W0_data[2U] 
        = ((0x1ffU & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sourceA__DOT__io_a_q__DOT____Vcellinp__ram_ext__W0_data[2U]) 
           | (0xfffffe00U & (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT____Vcellinp__sourceA__io_req_bits_tag) 
                              << 0x19U) | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT____Vcellinp__directory__io_write_bits_set) 
                                           << 0xfU))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sourceA__DOT__io_a_q__DOT____Vcellinp__ram_ext__W0_data[3U] 
        = ((0x1fff00U & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sourceA__DOT__io_a_q__DOT____Vcellinp__ram_ext__W0_data[3U]) 
           | (0x1ffU & ((0x1fU & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT____Vcellinp__sourceA__io_req_bits_tag) 
                                  >> 7U)) | (0x1ffU 
                                             & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT____Vcellinp__directory__io_write_bits_set) 
                                                >> 0x11U)))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sourceA__DOT__io_a_q__DOT____Vcellinp__ram_ext__W0_data[3U] 
        = ((0xffU & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sourceA__DOT__io_a_q__DOT____Vcellinp__ram_ext__W0_data[3U]) 
           | (0x1fff00U & (0x186000U | (((0x40000U 
                                          & ((~ (((~ 
                                                   (((0U 
                                                      == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_0__DOT__request_opcode)) 
                                                     | (7U 
                                                        == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_0__DOT__request_opcode))) 
                                                    & (6U 
                                                       == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_0__DOT__request_size)))) 
                                                  & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshr_selectOH)) 
                                                 | (((~ 
                                                      (((0U 
                                                         == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_1__DOT__request_opcode)) 
                                                        | (7U 
                                                           == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_1__DOT__request_opcode))) 
                                                       & (6U 
                                                          == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_1__DOT__request_size)))) 
                                                     & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshr_selectOH) 
                                                        >> 1U)) 
                                                    | (((~ 
                                                         (((0U 
                                                            == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_2__DOT__request_opcode)) 
                                                           | (7U 
                                                              == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_2__DOT__request_opcode))) 
                                                          & (6U 
                                                             == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_2__DOT__request_size)))) 
                                                        & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshr_selectOH) 
                                                           >> 2U)) 
                                                       | (((~ 
                                                            (((0U 
                                                               == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_3__DOT__request_opcode)) 
                                                              | (7U 
                                                                 == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_3__DOT__request_opcode))) 
                                                             & (6U 
                                                                == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_3__DOT__request_size)))) 
                                                           & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshr_selectOH) 
                                                              >> 3U)) 
                                                          | (((~ 
                                                               (((0U 
                                                                  == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_4__DOT__request_opcode)) 
                                                                 | (7U 
                                                                    == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_4__DOT__request_opcode))) 
                                                                & (6U 
                                                                   == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_4__DOT__request_size)))) 
                                                              & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshr_selectOH) 
                                                                 >> 4U)) 
                                                             | (((~ 
                                                                  (((0U 
                                                                     == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_5__DOT__request_opcode)) 
                                                                    | (7U 
                                                                       == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_5__DOT__request_opcode))) 
                                                                   & (6U 
                                                                      == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_5__DOT__request_size)))) 
                                                                 & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshr_selectOH) 
                                                                    >> 5U)) 
                                                                | ((~ 
                                                                    (((0U 
                                                                       == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_6__DOT__request_opcode)) 
                                                                      | (7U 
                                                                         == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_6__DOT__request_opcode))) 
                                                                     & (6U 
                                                                        == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_6__DOT__request_size)))) 
                                                                   & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshr_selectOH) 
                                                                      >> 6U))))))))) 
                                             << 0x12U)) 
                                         | ((((1U & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshr_selectOH))
                                               ? ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_0__DOT__req_needT)
                                                   ? 
                                                  ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_0__DOT__meta_hit)
                                                    ? 2U
                                                    : 1U)
                                                   : 0U)
                                               : 0U) 
                                             | (((2U 
                                                  & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshr_selectOH))
                                                  ? 
                                                 ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_1__DOT__req_needT)
                                                   ? 
                                                  ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_1__DOT__meta_hit)
                                                    ? 2U
                                                    : 1U)
                                                   : 0U)
                                                  : 0U) 
                                                | (((4U 
                                                     & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshr_selectOH))
                                                     ? 
                                                    ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_2__DOT__req_needT)
                                                      ? 
                                                     ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_2__DOT__meta_hit)
                                                       ? 2U
                                                       : 1U)
                                                      : 0U)
                                                     : 0U) 
                                                   | (((8U 
                                                        & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshr_selectOH))
                                                        ? 
                                                       ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_3__DOT__req_needT)
                                                         ? 
                                                        ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_3__DOT__meta_hit)
                                                          ? 2U
                                                          : 1U)
                                                         : 0U)
                                                        : 0U) 
                                                      | (((0x10U 
                                                           & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshr_selectOH))
                                                           ? 
                                                          ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_4__DOT__req_needT)
                                                            ? 
                                                           ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_4__DOT__meta_hit)
                                                             ? 2U
                                                             : 1U)
                                                            : 0U)
                                                           : 0U) 
                                                         | (((0x20U 
                                                              & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshr_selectOH))
                                                              ? 
                                                             ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_5__DOT__req_needT)
                                                               ? 
                                                              ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_5__DOT__meta_hit)
                                                                ? 2U
                                                                : 1U)
                                                               : 0U)
                                                              : 0U) 
                                                            | ((0x40U 
                                                                & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshr_selectOH))
                                                                ? 
                                                               ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_6__DOT__req_needT)
                                                                 ? 
                                                                ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_6__DOT__meta_hit)
                                                                  ? 2U
                                                                  : 1U)
                                                                 : 0U)
                                                                : 0U))))))) 
                                            << 0xfU)) 
                                        | (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshr_select) 
                                            << 9U) 
                                           | (0x100U 
                                              & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT____Vcellinp__sourceA__io_req_bits_tag) 
                                                 >> 4U)))))));
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__2372(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__2372\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sourceD__DOT__s1_need_pb 
        = (1U & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sourceD__DOT__s1_req_prio_0)
                  ? (~ ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sourceD__DOT__s1_req_opcode) 
                        >> 2U)) : (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sourceD__DOT__s1_req_opcode)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sourceD__DOT__s1_grant 
        = (((6U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sourceD__DOT__s1_req_opcode)) 
            & (2U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sourceD__DOT__s1_req_param))) 
           | (7U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sourceD__DOT__s1_req_opcode)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sourceC__DOT__want_data 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sourceC__DOT__busy) 
           | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sourceC__DOT___want_data_T) 
              & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT____Vcellinp__sourceC__io_req_bits_dirty)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__bankedStore__DOT__sourceD_rreq_index 
        = (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT___sourceD_io_bs_radr_bits_way) 
            << 0xbU) | (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT___sourceD_io_bs_radr_bits_set) 
                         << 1U) | (1U & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT___sourceD_io_bs_radr_bits_beat) 
                                         >> 2U))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sourceD__DOT__s1_x_bypass 
        = ((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sourceD__DOT__s2_req_set) 
             == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT___sourceD_io_bs_radr_bits_set)) 
            & (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sourceD__DOT__s2_req_way) 
                == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT___sourceD_io_bs_radr_bits_way)) 
               & (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sourceD__DOT__s2_beat) 
                   == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT___sourceD_io_bs_radr_bits_beat)) 
                  & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sourceD__DOT__s2_full) 
                     & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sourceD__DOT__s2_retires))))) 
           | ((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sourceD__DOT__s3_req_set) 
                == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT___sourceD_io_bs_radr_bits_set)) 
               & (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sourceD__DOT__s3_req_way) 
                   == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT___sourceD_io_bs_radr_bits_way)) 
                  & (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sourceD__DOT__s3_beat) 
                      == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT___sourceD_io_bs_radr_bits_beat)) 
                     & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sourceD__DOT__s3_full) 
                        & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sourceD__DOT__s3_retires))))) 
              | (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sourceD__DOT__s4_req_set) 
                  == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT___sourceD_io_bs_radr_bits_set)) 
                 & (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sourceD__DOT__s4_req_way) 
                     == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT___sourceD_io_bs_radr_bits_way)) 
                    & (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sourceD__DOT__s4_beat) 
                        == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT___sourceD_io_bs_radr_bits_beat)) 
                       & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sourceD__DOT__s4_full))))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__bankedStore__DOT__sourceC_req_index 
        = (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT___sourceC_io_bs_adr_bits_way) 
            << 0xbU) | (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT___sourceC_io_bs_adr_bits_set) 
                         << 1U) | (1U & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sourceC__DOT__beat) 
                                         >> 2U))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT___mshr_uses_directory_assuming_no_bypass_T 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__schedule_reload) 
           & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT____VdfgRegularize_hd1f689b4_0_10));
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__2373(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__2373\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT___pop_index_T_5 
        = (0x7fU & (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT___pop_index_T_3) 
                     >> 8U) | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT___pop_index_T_3)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT____VdfgRegularize_h94b53d93_0_192 
        = (1U & ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_340)) 
                 | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_343)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT____VdfgRegularize_h94b53d93_0_191 
        = (1U & ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_348)) 
                 | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_351)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT____VdfgRegularize_h94b53d93_0_190 
        = (1U & ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_356)) 
                 | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_359)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT____VdfgRegularize_h94b53d93_0_189 
        = (1U & ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_364)) 
                 | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_367)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT____VdfgRegularize_h94b53d93_0_188 
        = (1U & ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_372)) 
                 | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_375)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT____VdfgRegularize_h94b53d93_0_187 
        = (1U & ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_380)) 
                 | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_383)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT___GEN_29 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__iss_ready_0_6) 
           & (0U == ((((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_age_matrix_6_7) 
                         << 7U) | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_age_matrix_6_6) 
                                   << 6U)) | (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_age_matrix_6_5) 
                                               << 5U) 
                                              | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_age_matrix_6_4) 
                                                 << 4U))) 
                      | ((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_age_matrix_6_3) 
                           << 3U) | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_age_matrix_6_2) 
                                     << 2U)) | (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_age_matrix_6_1) 
                                                 << 1U) 
                                                | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_age_matrix_6_0)))) 
                     & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT____VdfgRegularize_h8a2d4d8d_0_0))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT___GEN_28 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__iss_ready_0_5) 
           & (0U == ((((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_age_matrix_5_7) 
                         << 7U) | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_age_matrix_5_6) 
                                   << 6U)) | (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_age_matrix_5_5) 
                                               << 5U) 
                                              | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_age_matrix_5_4) 
                                                 << 4U))) 
                      | ((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_age_matrix_5_3) 
                           << 3U) | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_age_matrix_5_2) 
                                     << 2U)) | (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_age_matrix_5_1) 
                                                 << 1U) 
                                                | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_age_matrix_5_0)))) 
                     & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT____VdfgRegularize_h8a2d4d8d_0_0))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT___GEN_27 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__iss_ready_0_4) 
           & (0U == ((((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_age_matrix_4_7) 
                         << 7U) | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_age_matrix_4_6) 
                                   << 6U)) | (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_age_matrix_4_5) 
                                               << 5U) 
                                              | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_age_matrix_4_4) 
                                                 << 4U))) 
                      | ((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_age_matrix_4_3) 
                           << 3U) | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_age_matrix_4_2) 
                                     << 2U)) | (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_age_matrix_4_1) 
                                                 << 1U) 
                                                | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_age_matrix_4_0)))) 
                     & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT____VdfgRegularize_h8a2d4d8d_0_0))));
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__2374(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__2374\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT___GEN_26 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__iss_ready_0_3) 
           & (0U == ((((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_age_matrix_3_7) 
                         << 7U) | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_age_matrix_3_6) 
                                   << 6U)) | (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_age_matrix_3_5) 
                                               << 5U) 
                                              | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_age_matrix_3_4) 
                                                 << 4U))) 
                      | ((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_age_matrix_3_3) 
                           << 3U) | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_age_matrix_3_2) 
                                     << 2U)) | (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_age_matrix_3_1) 
                                                 << 1U) 
                                                | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_age_matrix_3_0)))) 
                     & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT____VdfgRegularize_h8a2d4d8d_0_0))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT___GEN_25 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__iss_ready_0_2) 
           & (0U == ((((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_age_matrix_2_7) 
                         << 7U) | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_age_matrix_2_6) 
                                   << 6U)) | (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_age_matrix_2_5) 
                                               << 5U) 
                                              | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_age_matrix_2_4) 
                                                 << 4U))) 
                      | ((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_age_matrix_2_3) 
                           << 3U) | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_age_matrix_2_2) 
                                     << 2U)) | (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_age_matrix_2_1) 
                                                 << 1U) 
                                                | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_age_matrix_2_0)))) 
                     & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT____VdfgRegularize_h8a2d4d8d_0_0))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT___GEN_24 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__iss_ready_0_1) 
           & (0U == ((((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_age_matrix_1_7) 
                         << 7U) | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_age_matrix_1_6) 
                                   << 6U)) | (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_age_matrix_1_5) 
                                               << 5U) 
                                              | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_age_matrix_1_4) 
                                                 << 4U))) 
                      | ((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_age_matrix_1_3) 
                           << 3U) | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_age_matrix_1_2) 
                                     << 2U)) | (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_age_matrix_1_1) 
                                                 << 1U) 
                                                | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_age_matrix_1_0)))) 
                     & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT____VdfgRegularize_h8a2d4d8d_0_0))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT___GEN_30 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__iss_ready_0_7) 
           & (0U == ((((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_age_matrix_7_7) 
                         << 7U) | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_age_matrix_7_6) 
                                   << 6U)) | (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_age_matrix_7_5) 
                                               << 5U) 
                                              | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_age_matrix_7_4) 
                                                 << 4U))) 
                      | ((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_age_matrix_7_3) 
                           << 3U) | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_age_matrix_7_2) 
                                     << 2U)) | (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_age_matrix_7_1) 
                                                 << 1U) 
                                                | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_age_matrix_7_0)))) 
                     & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT____VdfgRegularize_h8a2d4d8d_0_0))));
    if ((1U & (~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__pred_rename_stage__DOT___GEN_20)))) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rename_stage__DOT__r_uop_dst_rtype 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_dst_rtype;
    }
    vlSelfRef.__VdfgRegularize_h36cfaf1a_0_114 = (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__io_fdiv_resp_fdivsqrt__DOT__divSqrt_1__DOT__roundRawFNToRecFN__DOT__roundAnyRawFNToRecFN__DOT__sRoundedExp) 
                                                   & (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__io_fdiv_resp_fdivsqrt__DOT__divSqrt_1__DOT__roundRawFNToRecFN__DOT__roundAnyRawFNToRecFN__DOT____VdfgRegularize_haa14ed2b_0_12)
                                                        ? 0x1ffU
                                                        : 0xfffU) 
                                                      & (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__io_fdiv_resp_fdivsqrt__DOT__divSqrt_1__DOT__roundRawFNToRecFN__DOT__roundAnyRawFNToRecFN__DOT__pegMinNonzeroMagOut)
                                                           ? 0x3ceU
                                                           : 0xfffU) 
                                                         & ((0xbffU 
                                                             | (0x400U 
                                                                & ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__io_fdiv_resp_fdivsqrt__DOT__divSqrt_1__DOT__roundRawFNToRecFN__DOT__roundAnyRawFNToRecFN__DOT__pegMaxFiniteMagOut)) 
                                                                   << 0xaU))) 
                                                            & (0xdffU 
                                                               | (0x200U 
                                                                  & ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__io_fdiv_resp_fdivsqrt__DOT__divSqrt_1__DOT__roundRawFNToRecFN__DOT__roundAnyRawFNToRecFN__DOT__notNaN_isInfOut)) 
                                                                     << 9U))))))) 
                                                  | (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__io_fdiv_resp_fdivsqrt__DOT__divSqrt_1__DOT__roundRawFNToRecFN__DOT__roundAnyRawFNToRecFN__DOT__pegMinNonzeroMagOut)
                                                       ? 0x3ceU
                                                       : 0U) 
                                                     | (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__io_fdiv_resp_fdivsqrt__DOT__divSqrt_1__DOT__roundRawFNToRecFN__DOT__roundAnyRawFNToRecFN__DOT__pegMaxFiniteMagOut)
                                                          ? 0xbffU
                                                          : 0U) 
                                                        | (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__io_fdiv_resp_fdivsqrt__DOT__divSqrt_1__DOT__roundRawFNToRecFN__DOT__roundAnyRawFNToRecFN__DOT__notNaN_isInfOut)
                                                             ? 0xc00U
                                                             : 0U) 
                                                           | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__io_fdiv_resp_fdivsqrt__DOT__divSqrt_1__DOT__roundRawFNToRecFN__DOT__roundAnyRawFNToRecFN__DOT__isNaNOut)
                                                               ? 0xe00U
                                                               : 0U)))));
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__2375(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__2375\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sinkD__DOT__d_q__DOT____Vcellinp__ram_ext__W0_data[0U] 
        = ((0xfffffffeU & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sinkD__DOT__d_q__DOT____Vcellinp__ram_ext__W0_data[0U]) 
           | (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__cork__DOT__muxState_1_0) 
               & (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__mbus__DOT__mbus_xbar__DOT__muxState_0) 
                   & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__mbus__DOT__coupler_to_memory_controller_port_named_axi4__DOT__tl2axi4__DOT__r_wins) 
                      & ((0U != (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__simdram__DOT_____05Fr_resp_reg)) 
                         | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__mbus__DOT__coupler_to_memory_controller_port_named_axi4__DOT__tl2axi4__DOT__r_denied)))) 
                  | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__mbus__DOT__mbus_xbar__DOT__muxState_1) 
                     & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__mbus__DOT__buffer_1__DOT__nodeIn_d_q__DOT__ram_ext__DOT__Memory
                     [vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__mbus__DOT__buffer_1__DOT__nodeIn_d_q__DOT__deq_ptr_value][0U]))) 
              | (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__cork__DOT__muxState_1_1) 
                  & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__cork__DOT__q__DOT__ram_ext__DOT__Memory
                  [vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__cork__DOT__q__DOT__deq_ptr_value][0U]) 
                 | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__cork__DOT__muxState_1_2) 
                    & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__cork__DOT__q_1__DOT__ram_ext__DOT__Memory
                    [vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__cork__DOT__q_1__DOT__deq_ptr_value][0U]))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sinkD__DOT__d_q__DOT____Vcellinp__ram_ext__W0_data[0U] 
        = ((1U & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sinkD__DOT__d_q__DOT____Vcellinp__ram_ext__W0_data[0U]) 
           | ((IData)((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__cork__DOT__muxState_1_0)
                         ? (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__mbus__DOT__mbus_xbar__DOT__muxState_0)
                              ? vlSelfRef.TestDriver__DOT__testHarness__DOT__simdram__DOT_____05Fr_data_reg
                              : 0ULL) | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__mbus__DOT__mbus_xbar__DOT__muxState_1)
                                          ? (((QData)((IData)(
                                                              vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__mbus__DOT__buffer_1__DOT__nodeIn_d_q__DOT__ram_ext__DOT__Memory
                                                              [vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__mbus__DOT__buffer_1__DOT__nodeIn_d_q__DOT__deq_ptr_value][2U])) 
                                              << 0x3fU) 
                                             | (((QData)((IData)(
                                                                 vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__mbus__DOT__buffer_1__DOT__nodeIn_d_q__DOT__ram_ext__DOT__Memory
                                                                 [vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__mbus__DOT__buffer_1__DOT__nodeIn_d_q__DOT__deq_ptr_value][1U])) 
                                                 << 0x1fU) 
                                                | ((QData)((IData)(
                                                                   vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__mbus__DOT__buffer_1__DOT__nodeIn_d_q__DOT__ram_ext__DOT__Memory
                                                                   [vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__mbus__DOT__buffer_1__DOT__nodeIn_d_q__DOT__deq_ptr_value][0U])) 
                                                   >> 1U)))
                                          : 0ULL)) : 0ULL) 
                       | (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__cork__DOT__muxState_1_1)
                            ? (((QData)((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__cork__DOT__q__DOT__ram_ext__DOT__Memory
                                                [vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__cork__DOT__q__DOT__deq_ptr_value][2U])) 
                                << 0x3fU) | (((QData)((IData)(
                                                              vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__cork__DOT__q__DOT__ram_ext__DOT__Memory
                                                              [vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__cork__DOT__q__DOT__deq_ptr_value][1U])) 
                                              << 0x1fU) 
                                             | ((QData)((IData)(
                                                                vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__cork__DOT__q__DOT__ram_ext__DOT__Memory
                                                                [vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__cork__DOT__q__DOT__deq_ptr_value][0U])) 
                                                >> 1U)))
                            : 0ULL) | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__cork__DOT__muxState_1_2)
                                        ? (((QData)((IData)(
                                                            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__cork__DOT__q_1__DOT__ram_ext__DOT__Memory
                                                            [vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__cork__DOT__q_1__DOT__deq_ptr_value][2U])) 
                                            << 0x3fU) 
                                           | (((QData)((IData)(
                                                               vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__cork__DOT__q_1__DOT__ram_ext__DOT__Memory
                                                               [vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__cork__DOT__q_1__DOT__deq_ptr_value][1U])) 
                                               << 0x1fU) 
                                              | ((QData)((IData)(
                                                                 vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__cork__DOT__q_1__DOT__ram_ext__DOT__Memory
                                                                 [vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__cork__DOT__q_1__DOT__deq_ptr_value][0U])) 
                                                 >> 1U)))
                                        : 0ULL)))) 
              << 1U));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sinkD__DOT__d_q__DOT____Vcellinp__ram_ext__W0_data[1U] 
        = (((IData)((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__cork__DOT__muxState_1_0)
                       ? (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__mbus__DOT__mbus_xbar__DOT__muxState_0)
                            ? vlSelfRef.TestDriver__DOT__testHarness__DOT__simdram__DOT_____05Fr_data_reg
                            : 0ULL) | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__mbus__DOT__mbus_xbar__DOT__muxState_1)
                                        ? (((QData)((IData)(
                                                            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__mbus__DOT__buffer_1__DOT__nodeIn_d_q__DOT__ram_ext__DOT__Memory
                                                            [vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__mbus__DOT__buffer_1__DOT__nodeIn_d_q__DOT__deq_ptr_value][2U])) 
                                            << 0x3fU) 
                                           | (((QData)((IData)(
                                                               vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__mbus__DOT__buffer_1__DOT__nodeIn_d_q__DOT__ram_ext__DOT__Memory
                                                               [vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__mbus__DOT__buffer_1__DOT__nodeIn_d_q__DOT__deq_ptr_value][1U])) 
                                               << 0x1fU) 
                                              | ((QData)((IData)(
                                                                 vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__mbus__DOT__buffer_1__DOT__nodeIn_d_q__DOT__ram_ext__DOT__Memory
                                                                 [vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__mbus__DOT__buffer_1__DOT__nodeIn_d_q__DOT__deq_ptr_value][0U])) 
                                                 >> 1U)))
                                        : 0ULL)) : 0ULL) 
                     | (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__cork__DOT__muxState_1_1)
                          ? (((QData)((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__cork__DOT__q__DOT__ram_ext__DOT__Memory
                                              [vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__cork__DOT__q__DOT__deq_ptr_value][2U])) 
                              << 0x3fU) | (((QData)((IData)(
                                                            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__cork__DOT__q__DOT__ram_ext__DOT__Memory
                                                            [vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__cork__DOT__q__DOT__deq_ptr_value][1U])) 
                                            << 0x1fU) 
                                           | ((QData)((IData)(
                                                              vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__cork__DOT__q__DOT__ram_ext__DOT__Memory
                                                              [vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__cork__DOT__q__DOT__deq_ptr_value][0U])) 
                                              >> 1U)))
                          : 0ULL) | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__cork__DOT__muxState_1_2)
                                      ? (((QData)((IData)(
                                                          vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__cork__DOT__q_1__DOT__ram_ext__DOT__Memory
                                                          [vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__cork__DOT__q_1__DOT__deq_ptr_value][2U])) 
                                          << 0x3fU) 
                                         | (((QData)((IData)(
                                                             vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__cork__DOT__q_1__DOT__ram_ext__DOT__Memory
                                                             [vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__cork__DOT__q_1__DOT__deq_ptr_value][1U])) 
                                             << 0x1fU) 
                                            | ((QData)((IData)(
                                                               vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__cork__DOT__q_1__DOT__ram_ext__DOT__Memory
                                                               [vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__cork__DOT__q_1__DOT__deq_ptr_value][0U])) 
                                               >> 1U)))
                                      : 0ULL)))) >> 0x1fU) 
           | ((IData)(((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__cork__DOT__muxState_1_0)
                          ? (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__mbus__DOT__mbus_xbar__DOT__muxState_0)
                               ? vlSelfRef.TestDriver__DOT__testHarness__DOT__simdram__DOT_____05Fr_data_reg
                               : 0ULL) | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__mbus__DOT__mbus_xbar__DOT__muxState_1)
                                           ? (((QData)((IData)(
                                                               vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__mbus__DOT__buffer_1__DOT__nodeIn_d_q__DOT__ram_ext__DOT__Memory
                                                               [vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__mbus__DOT__buffer_1__DOT__nodeIn_d_q__DOT__deq_ptr_value][2U])) 
                                               << 0x3fU) 
                                              | (((QData)((IData)(
                                                                  vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__mbus__DOT__buffer_1__DOT__nodeIn_d_q__DOT__ram_ext__DOT__Memory
                                                                  [vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__mbus__DOT__buffer_1__DOT__nodeIn_d_q__DOT__deq_ptr_value][1U])) 
                                                  << 0x1fU) 
                                                 | ((QData)((IData)(
                                                                    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__mbus__DOT__buffer_1__DOT__nodeIn_d_q__DOT__ram_ext__DOT__Memory
                                                                    [vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__mbus__DOT__buffer_1__DOT__nodeIn_d_q__DOT__deq_ptr_value][0U])) 
                                                    >> 1U)))
                                           : 0ULL))
                          : 0ULL) | (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__cork__DOT__muxState_1_1)
                                       ? (((QData)((IData)(
                                                           vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__cork__DOT__q__DOT__ram_ext__DOT__Memory
                                                           [vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__cork__DOT__q__DOT__deq_ptr_value][2U])) 
                                           << 0x3fU) 
                                          | (((QData)((IData)(
                                                              vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__cork__DOT__q__DOT__ram_ext__DOT__Memory
                                                              [vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__cork__DOT__q__DOT__deq_ptr_value][1U])) 
                                              << 0x1fU) 
                                             | ((QData)((IData)(
                                                                vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__cork__DOT__q__DOT__ram_ext__DOT__Memory
                                                                [vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__cork__DOT__q__DOT__deq_ptr_value][0U])) 
                                                >> 1U)))
                                       : 0ULL) | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__cork__DOT__muxState_1_2)
                                                   ? 
                                                  (((QData)((IData)(
                                                                    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__cork__DOT__q_1__DOT__ram_ext__DOT__Memory
                                                                    [vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__cork__DOT__q_1__DOT__deq_ptr_value][2U])) 
                                                    << 0x3fU) 
                                                   | (((QData)((IData)(
                                                                       vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__cork__DOT__q_1__DOT__ram_ext__DOT__Memory
                                                                       [vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__cork__DOT__q_1__DOT__deq_ptr_value][1U])) 
                                                       << 0x1fU) 
                                                      | ((QData)((IData)(
                                                                         vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__cork__DOT__q_1__DOT__ram_ext__DOT__Memory
                                                                         [vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__cork__DOT__q_1__DOT__deq_ptr_value][0U])) 
                                                         >> 1U)))
                                                   : 0ULL))) 
                       >> 0x20U)) << 1U));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sinkD__DOT__d_q__DOT____Vcellinp__ram_ext__W0_data[2U] 
        = ((0xfffeU & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sinkD__DOT__d_q__DOT____Vcellinp__ram_ext__W0_data[2U]) 
           | (0xffffU & ((IData)(((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__cork__DOT__muxState_1_0)
                                     ? (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__mbus__DOT__mbus_xbar__DOT__muxState_0)
                                          ? vlSelfRef.TestDriver__DOT__testHarness__DOT__simdram__DOT_____05Fr_data_reg
                                          : 0ULL) | 
                                        ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__mbus__DOT__mbus_xbar__DOT__muxState_1)
                                          ? (((QData)((IData)(
                                                              vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__mbus__DOT__buffer_1__DOT__nodeIn_d_q__DOT__ram_ext__DOT__Memory
                                                              [vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__mbus__DOT__buffer_1__DOT__nodeIn_d_q__DOT__deq_ptr_value][2U])) 
                                              << 0x3fU) 
                                             | (((QData)((IData)(
                                                                 vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__mbus__DOT__buffer_1__DOT__nodeIn_d_q__DOT__ram_ext__DOT__Memory
                                                                 [vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__mbus__DOT__buffer_1__DOT__nodeIn_d_q__DOT__deq_ptr_value][1U])) 
                                                 << 0x1fU) 
                                                | ((QData)((IData)(
                                                                   vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__mbus__DOT__buffer_1__DOT__nodeIn_d_q__DOT__ram_ext__DOT__Memory
                                                                   [vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__mbus__DOT__buffer_1__DOT__nodeIn_d_q__DOT__deq_ptr_value][0U])) 
                                                   >> 1U)))
                                          : 0ULL)) : 0ULL) 
                                   | (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__cork__DOT__muxState_1_1)
                                        ? (((QData)((IData)(
                                                            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__cork__DOT__q__DOT__ram_ext__DOT__Memory
                                                            [vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__cork__DOT__q__DOT__deq_ptr_value][2U])) 
                                            << 0x3fU) 
                                           | (((QData)((IData)(
                                                               vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__cork__DOT__q__DOT__ram_ext__DOT__Memory
                                                               [vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__cork__DOT__q__DOT__deq_ptr_value][1U])) 
                                               << 0x1fU) 
                                              | ((QData)((IData)(
                                                                 vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__cork__DOT__q__DOT__ram_ext__DOT__Memory
                                                                 [vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__cork__DOT__q__DOT__deq_ptr_value][0U])) 
                                                 >> 1U)))
                                        : 0ULL) | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__cork__DOT__muxState_1_2)
                                                    ? 
                                                   (((QData)((IData)(
                                                                     vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__cork__DOT__q_1__DOT__ram_ext__DOT__Memory
                                                                     [vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__cork__DOT__q_1__DOT__deq_ptr_value][2U])) 
                                                     << 0x3fU) 
                                                    | (((QData)((IData)(
                                                                        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__cork__DOT__q_1__DOT__ram_ext__DOT__Memory
                                                                        [vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__cork__DOT__q_1__DOT__deq_ptr_value][1U])) 
                                                        << 0x1fU) 
                                                       | ((QData)((IData)(
                                                                          vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__cork__DOT__q_1__DOT__ram_ext__DOT__Memory
                                                                          [vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__cork__DOT__q_1__DOT__deq_ptr_value][0U])) 
                                                          >> 1U)))
                                                    : 0ULL))) 
                                  >> 0x20U)) >> 0x1fU)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sinkD__DOT__d_q__DOT____Vcellinp__ram_ext__W0_data[2U] 
        = ((1U & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sinkD__DOT__d_q__DOT____Vcellinp__ram_ext__W0_data[2U]) 
           | (0xfffeU & ((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT___cork_auto_in_d_bits_opcode) 
                           << 0xdU) | ((0x1800U & (
                                                   (((1U 
                                                      & ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__cork__DOT__muxState_1_0)) 
                                                         | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__cork__DOT___GEN_2)))
                                                      ? 0U
                                                      : 
                                                     ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__mbus__DOT__mbus_xbar__DOT__muxState_1)
                                                       ? 
                                                      ((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__mbus__DOT__buffer_1__DOT__nodeIn_d_q__DOT__ram_ext__DOT__Memory
                                                        [vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__mbus__DOT__buffer_1__DOT__nodeIn_d_q__DOT__deq_ptr_value][2U] 
                                                        << 0x16U) 
                                                       | (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__mbus__DOT__buffer_1__DOT__nodeIn_d_q__DOT__ram_ext__DOT__Memory
                                                          [vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__mbus__DOT__buffer_1__DOT__nodeIn_d_q__DOT__deq_ptr_value][2U] 
                                                          >> 0xaU))
                                                       : 0U)) 
                                                    | (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__cork__DOT__muxState_1_1)
                                                         ? 
                                                        ((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__cork__DOT__q__DOT__ram_ext__DOT__Memory
                                                          [vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__cork__DOT__q__DOT__deq_ptr_value][2U] 
                                                          << 0x15U) 
                                                         | (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__cork__DOT__q__DOT__ram_ext__DOT__Memory
                                                            [vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__cork__DOT__q__DOT__deq_ptr_value][2U] 
                                                            >> 0xbU))
                                                         : 0U) 
                                                       | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__cork__DOT__muxState_1_2)
                                                           ? 
                                                          ((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__cork__DOT__q_1__DOT__ram_ext__DOT__Memory
                                                            [vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__cork__DOT__q_1__DOT__deq_ptr_value][2U] 
                                                            << 0x15U) 
                                                           | (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__cork__DOT__q_1__DOT__ram_ext__DOT__Memory
                                                              [vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__cork__DOT__q_1__DOT__deq_ptr_value][2U] 
                                                              >> 0xbU))
                                                           : 0U))) 
                                                   << 0xbU)) 
                                       | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT___cork_auto_in_d_bits_size) 
                                          << 8U))) 
                         | ((0xe0U & ((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__cork__DOT__muxState_1_0)
                                         ? ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT___binder_auto_in_d_bits_source) 
                                            >> 1U) : 0U) 
                                       | (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__cork__DOT__muxState_1_1)
                                            ? ((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__cork__DOT__q__DOT__ram_ext__DOT__Memory
                                                [vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__cork__DOT__q__DOT__deq_ptr_value][2U] 
                                                << 0x1bU) 
                                               | (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__cork__DOT__q__DOT__ram_ext__DOT__Memory
                                                  [vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__cork__DOT__q__DOT__deq_ptr_value][2U] 
                                                  >> 5U))
                                            : 0U) | 
                                          ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__cork__DOT__muxState_1_2)
                                            ? ((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__cork__DOT__q_1__DOT__ram_ext__DOT__Memory
                                                [vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__cork__DOT__q_1__DOT__deq_ptr_value][2U] 
                                                << 0x1bU) 
                                               | (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__cork__DOT__q_1__DOT__ram_ext__DOT__Memory
                                                  [vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__cork__DOT__q_1__DOT__deq_ptr_value][2U] 
                                                  >> 5U))
                                            : 0U))) 
                                      << 5U)) | (((
                                                   (0U 
                                                    == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__cork__DOT__d_first_counter))
                                                    ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__cork__DOT__pool__DOT__select)
                                                    : (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__cork__DOT__nodeIn_d_bits_sink_r)) 
                                                  << 2U) 
                                                 | ((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__cork__DOT__muxState_1_0) 
                                                      << 1U) 
                                                     & ((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__mbus__DOT__mbus_xbar__DOT__muxState_0) 
                                                          & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__mbus__DOT__coupler_to_memory_controller_port_named_axi4__DOT__tl2axi4__DOT__r_wins)
                                                              ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__mbus__DOT__coupler_to_memory_controller_port_named_axi4__DOT__tl2axi4__DOT__r_denied)
                                                              : 
                                                             (0U 
                                                              != (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__simdram__DOT_____05Fb_resp_reg)))) 
                                                         << 1U) 
                                                        | (0xfffffffeU 
                                                           & (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__mbus__DOT__mbus_xbar__DOT__muxState_1) 
                                                               << 1U) 
                                                              & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__mbus__DOT__buffer_1__DOT__nodeIn_d_q__DOT__ram_ext__DOT__Memory
                                                              [vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__mbus__DOT__buffer_1__DOT__nodeIn_d_q__DOT__deq_ptr_value][2U])))) 
                                                    | (0xfffffffeU 
                                                       & ((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__cork__DOT__muxState_1_1) 
                                                            << 1U) 
                                                           & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__cork__DOT__q__DOT__ram_ext__DOT__Memory
                                                           [vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__cork__DOT__q__DOT__deq_ptr_value][2U]) 
                                                          | (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__cork__DOT__muxState_1_2) 
                                                              << 1U) 
                                                             & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__cork__DOT__q_1__DOT__ram_ext__DOT__Memory
                                                             [vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__cork__DOT__q_1__DOT__deq_ptr_value][2U])))))))));
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__2376(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__2376\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__cork__DOT__d_grant 
        = ((5U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT___cork_auto_in_d_bits_opcode)) 
           | (4U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT___cork_auto_in_d_bits_opcode)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__issue_slots_7_in_uop_bits_lrs1_rtype 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rename_stage__DOT__r_uop_uses_stq)
            ? 2U : (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rename_stage__DOT__r_uop_lrs1_rtype));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__issue_slots_7_in_uop_bits_prs1_busy 
        = ((~ ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rename_stage__DOT__r_uop_uses_stq) 
               | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT___GEN))) 
           & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___dispatcher_io_dis_uops_3_0_bits_prs1_busy));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT___GEN_1 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rename_stage__DOT__r_uop_uses_stq) 
           & (1U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rename_stage__DOT__r_uop_lrs2_rtype)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___rob_unsafe_T_16 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rename_stage__DOT__r_uop_uses_ldq) 
           | (((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rename_stage__DOT__r_uop_is_fence)) 
               & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rename_stage__DOT__r_uop_uses_stq)) 
              | ((1U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rename_stage__DOT__r_uop_br_type)) 
                 | ((2U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rename_stage__DOT__r_uop_br_type)) 
                    | ((3U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rename_stage__DOT__r_uop_br_type)) 
                       | ((4U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rename_stage__DOT__r_uop_br_type)) 
                          | ((5U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rename_stage__DOT__r_uop_br_type)) 
                             | ((6U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rename_stage__DOT__r_uop_br_type)) 
                                | (8U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rename_stage__DOT__r_uop_br_type))))))))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__fpu__DOT__fpu__DOT__dfma__DOT___fma_io_out[0U] 
        = (IData)((0xfffffffffffffULL & ((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__fpu__DOT__fpu__DOT__dfma__DOT__fma__DOT__roundRawFNToRecFN__DOT__roundAnyRawFNToRecFN__DOT__isNaNOut) 
                                           | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__fpu__DOT__fpu__DOT__dfma__DOT__fma__DOT__roundRawFNToRecFN__DOT__roundAnyRawFNToRecFN__DOT____VdfgRegularize_haa14ed2b_0_12))
                                           ? ((QData)((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__fpu__DOT__fpu__DOT__dfma__DOT__fma__DOT__roundRawFNToRecFN__DOT__roundAnyRawFNToRecFN__DOT__isNaNOut)) 
                                              << 0x33U)
                                           : ((1U & (IData)(
                                                            (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__fpu__DOT__fpu__DOT__dfma__DOT__fma__DOT__roundRawFNToRecFN_io_in_pipe_b_sig 
                                                             >> 0x37U)))
                                               ? (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__fpu__DOT__fpu__DOT__dfma__DOT__fma__DOT__roundRawFNToRecFN__DOT__roundAnyRawFNToRecFN__DOT__roundedSig 
                                                  >> 1U)
                                               : vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__fpu__DOT__fpu__DOT__dfma__DOT__fma__DOT__roundRawFNToRecFN__DOT__roundAnyRawFNToRecFN__DOT__roundedSig)) 
                                         | (- (QData)((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__fpu__DOT__fpu__DOT__dfma__DOT__fma__DOT__roundRawFNToRecFN__DOT__roundAnyRawFNToRecFN__DOT__pegMaxFiniteMagOut))))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__fpu__DOT__fpu__DOT__dfma__DOT___fma_io_out[1U] 
        = ((0xfff00000U & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__fpu__DOT__fpu__DOT__dfma__DOT___fma_io_out[1U]) 
           | (IData)(((0xfffffffffffffULL & ((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__fpu__DOT__fpu__DOT__dfma__DOT__fma__DOT__roundRawFNToRecFN__DOT__roundAnyRawFNToRecFN__DOT__isNaNOut) 
                                               | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__fpu__DOT__fpu__DOT__dfma__DOT__fma__DOT__roundRawFNToRecFN__DOT__roundAnyRawFNToRecFN__DOT____VdfgRegularize_haa14ed2b_0_12))
                                               ? ((QData)((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__fpu__DOT__fpu__DOT__dfma__DOT__fma__DOT__roundRawFNToRecFN__DOT__roundAnyRawFNToRecFN__DOT__isNaNOut)) 
                                                  << 0x33U)
                                               : ((1U 
                                                   & (IData)(
                                                             (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__fpu__DOT__fpu__DOT__dfma__DOT__fma__DOT__roundRawFNToRecFN_io_in_pipe_b_sig 
                                                              >> 0x37U)))
                                                   ? 
                                                  (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__fpu__DOT__fpu__DOT__dfma__DOT__fma__DOT__roundRawFNToRecFN__DOT__roundAnyRawFNToRecFN__DOT__roundedSig 
                                                   >> 1U)
                                                   : vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__fpu__DOT__fpu__DOT__dfma__DOT__fma__DOT__roundRawFNToRecFN__DOT__roundAnyRawFNToRecFN__DOT__roundedSig)) 
                                             | (- (QData)((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__fpu__DOT__fpu__DOT__dfma__DOT__fma__DOT__roundRawFNToRecFN__DOT__roundAnyRawFNToRecFN__DOT__pegMaxFiniteMagOut))))) 
                      >> 0x20U)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__fpu__DOT__fpu__DOT__dfma__DOT___fma_io_out[1U] 
        = ((0xfffffU & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__fpu__DOT__fpu__DOT__dfma__DOT___fma_io_out[1U]) 
           | (0xfff00000U & ((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__fpu__DOT__fpu__DOT__dfma__DOT__fma__DOT__roundRawFNToRecFN__DOT__roundAnyRawFNToRecFN__DOT__sRoundedExp) 
                               << 0x14U) & ((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__fpu__DOT__fpu__DOT__dfma__DOT__fma__DOT__roundRawFNToRecFN__DOT__roundAnyRawFNToRecFN__DOT____VdfgRegularize_haa14ed2b_0_12)
                                               ? 0x1ffU
                                               : 0xfffU) 
                                             << 0x14U) 
                                            & ((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__fpu__DOT__fpu__DOT__dfma__DOT__fma__DOT__roundRawFNToRecFN__DOT__roundAnyRawFNToRecFN__DOT__pegMinNonzeroMagOut)
                                                  ? 0x3ceU
                                                  : 0xfffU) 
                                                << 0x14U) 
                                               & ((0xbff00000U 
                                                   | (0x40000000U 
                                                      & ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__fpu__DOT__fpu__DOT__dfma__DOT__fma__DOT__roundRawFNToRecFN__DOT__roundAnyRawFNToRecFN__DOT__pegMaxFiniteMagOut)) 
                                                         << 0x1eU))) 
                                                  & (0xdff00000U 
                                                     | (0x20000000U 
                                                        & ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__fpu__DOT__fpu__DOT__dfma__DOT__fma__DOT__roundRawFNToRecFN__DOT__roundAnyRawFNToRecFN__DOT__notNaN_isInfOut)) 
                                                           << 0x1dU))))))) 
                             | ((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__fpu__DOT__fpu__DOT__dfma__DOT__fma__DOT__roundRawFNToRecFN__DOT__roundAnyRawFNToRecFN__DOT__pegMinNonzeroMagOut)
                                   ? 0x3ceU : 0U) | 
                                 (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__fpu__DOT__fpu__DOT__dfma__DOT__fma__DOT__roundRawFNToRecFN__DOT__roundAnyRawFNToRecFN__DOT__pegMaxFiniteMagOut)
                                    ? 0xbffU : 0U) 
                                  | (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__fpu__DOT__fpu__DOT__dfma__DOT__fma__DOT__roundRawFNToRecFN__DOT__roundAnyRawFNToRecFN__DOT__notNaN_isInfOut)
                                       ? 0xc00U : 0U) 
                                     | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__fpu__DOT__fpu__DOT__dfma__DOT__fma__DOT__roundRawFNToRecFN__DOT__roundAnyRawFNToRecFN__DOT__isNaNOut)
                                         ? 0xe00U : 0U)))) 
                                << 0x14U))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__fpu__DOT__fpu__DOT__dfma__DOT___fma_io_out[2U] 
        = ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__fpu__DOT__fpu__DOT__dfma__DOT__fma__DOT__roundRawFNToRecFN__DOT__roundAnyRawFNToRecFN__DOT__isNaNOut)) 
           & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__fpu__DOT__fpu__DOT__dfma__DOT__fma__DOT__roundRawFNToRecFN_io_in_pipe_b_sign));
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__2377(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__2377\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__fpu__DOT__fpu__DOT__fpmu__DOT__narrower__DOT__roundAnyRawFNToRecFN__DOT____VdfgRegularize_he36c650a_0_10 
        = (1U & ((~ (0U != (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__fpu__DOT__fpu__DOT__fpmu__DOT__in_pipe_b_in1[1U] 
                            >> 0x1dU))) | VL_GTS_III(15, 0x6bU, (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__fpu__DOT__fpu__DOT__fpmu__DOT__narrower__DOT__roundAnyRawFNToRecFN__DOT__sRoundedExp))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__fpu__DOT__fpu__DOT__fpmu__DOT__narrower__DOT__roundAnyRawFNToRecFN__DOT__pegMinNonzeroMagOut 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__fpu__DOT__fpu__DOT__fpmu__DOT__narrower__DOT__roundAnyRawFNToRecFN__DOT__commonCase) 
           & (VL_GTS_III(15, 0x6bU, (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__fpu__DOT__fpu__DOT__fpmu__DOT__narrower__DOT__roundAnyRawFNToRecFN__DOT__sRoundedExp)) 
              & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__fpu__DOT__fpu__DOT__fpmu__DOT__narrower__DOT__roundAnyRawFNToRecFN__DOT__roundMagUp) 
                 | (6U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__fpu__DOT__fpu__DOT__fpmu__DOT__in_pipe_b_rm)))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__fpu__DOT__fpu__DOT__fpmu__DOT__narrower__DOT__roundAnyRawFNToRecFN__DOT__overflow 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__fpu__DOT__fpu__DOT__fpmu__DOT__narrower__DOT__roundAnyRawFNToRecFN__DOT__commonCase) 
           & VL_LTS_III(8, 2U, (0xffU & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__fpu__DOT__fpu__DOT__fpmu__DOT__narrower__DOT__roundAnyRawFNToRecFN__DOT__sRoundedExp) 
                                         >> 7U))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__pri_val 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT___mshr_io_req_sec_val_T_4) 
           & ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__idx_match_0)) 
              & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__cacheable)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT____VdfgRegularize_h65b58d08_0_3 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT___mshr_io_req_sec_val_T_4) 
           & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__tag_match_0));
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT___dcache_io_lsu_resp_0_valid) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__resp_data 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT___dcache_io_lsu_resp_0_bits_data;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__resp_uop_stq_idx 
            = (7U & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__s2_req_0_uop_stq_idx));
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__resp_uop_ldq_idx 
            = (7U & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__s2_req_0_uop_ldq_idx));
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__resp_uop_uses_stq 
            = (1U & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__s2_req_0_uop_uses_stq));
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_506 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__s2_req_0_is_hella;
    } else {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__resp_data 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT___dcache_io_lsu_ll_resp_bits_data;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__resp_uop_stq_idx 
            = (7U & (((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__respq__DOT__uops_3_stq_idx) 
                        << 0xcU) | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__respq__DOT__uops_2_stq_idx) 
                                    << 8U)) | (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__respq__DOT__uops_1_stq_idx) 
                                                << 4U) 
                                               | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__respq__DOT__uops_0_stq_idx))) 
                     >> (0xfU & VL_SHIFTL_III(4,4,32, (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__respq__DOT__deq_ptr_value), 2U))));
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__resp_uop_ldq_idx 
            = (7U & (((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__respq__DOT__uops_3_ldq_idx) 
                        << 0xcU) | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__respq__DOT__uops_2_ldq_idx) 
                                    << 8U)) | (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__respq__DOT__uops_1_ldq_idx) 
                                                << 4U) 
                                               | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__respq__DOT__uops_0_ldq_idx))) 
                     >> (0xfU & VL_SHIFTL_III(4,4,32, (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__respq__DOT__deq_ptr_value), 2U))));
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__resp_uop_uses_stq 
            = (1U & (((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__respq__DOT__uops_3_uses_stq) 
                        << 3U) | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__respq__DOT__uops_2_uses_stq) 
                                  << 2U)) | (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__respq__DOT__uops_1_uses_stq) 
                                              << 1U) 
                                             | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__respq__DOT__uops_0_uses_stq))) 
                     >> (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__respq__DOT__deq_ptr_value)));
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_506 = 0U;
    }
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__2378(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__2378\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__resp_uop_uses_ldq 
        = (1U & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT___dcache_io_lsu_resp_0_valid)
                  ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__s2_req_0_uop_uses_ldq)
                  : (((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__respq__DOT__uops_3_uses_ldq) 
                        << 3U) | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__respq__DOT__uops_2_uses_ldq) 
                                  << 2U)) | (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__respq__DOT__uops_1_uses_ldq) 
                                              << 1U) 
                                             | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__respq__DOT__uops_0_uses_ldq))) 
                     >> (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__respq__DOT__deq_ptr_value))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT___lsu_io_dmem_ll_resp_ready 
        = (1U & (~ ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT___dcache_io_lsu_resp_0_valid) 
                    | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__w1_valid))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__ldq_idx 
        = (7U & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___ldq_idx_T)
                  ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_exe_unit_1__DOT__exe_uop_bits_ldq_idx)
                  : (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___retry_queue_io_deq_bits_uop_ldq_idx)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__will_fire_store_agen_0 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_exe_unit_1__DOT__exe_uop_bits_uses_stq) 
           & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT___core_io_lsu_agen_0_valid) 
              & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___will_fire_store_agen_0_will_fire_T_2) 
                 & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___will_fire_store_agen_0_will_fire_T_6))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unq_iss_unit__DOT__issue_slots_7_in_uop_bits_prs2 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rename_stage__DOT__r_uop_fu_code_8)
            ? (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rename_stage__DOT__r_uop_fp_rm) 
                << 2U) | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rename_stage__DOT__r_uop_fp_typ))
            : (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___dispatcher_io_dis_uops_3_0_bits_prs2));
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___csr_wen_T_4) {
        if ((0xfffU == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___decoded_addr_decoded_decoded_andMatrixOutputs_T_2))) {
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__reg_frm 
                = (7U & ((IData)((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___wdata_T_2 
                                  >> 5U)) & (IData)(
                                                    (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___wdata_T_6 
                                                     >> 5U))));
        } else if ((0xfffU == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___decoded_addr_decoded_decoded_andMatrixOutputs_T_1))) {
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__reg_frm 
                = (7U & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___wdata_T_2) 
                         & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___wdata_T_6)));
        }
    }
    vlSelfRef.__VdfgRegularize_h36cfaf1a_0_119 = ((0x10200073U 
                                                   == vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst) 
                                                  | ((0x30200073U 
                                                      == vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst) 
                                                     | (0x7b200073U 
                                                        == vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__io_decode_0_write_flush_addr_m 
        = ((0xc00U & (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst 
                      >> 0x14U)) | (0x3ffU & (0x300U 
                                              | (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst 
                                                 >> 0x14U))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_167 
        = (IData)((0x2000043U == (0x6000073U & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst)));
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__2379(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__2379\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.__VdfgRegularize_h787163e4_0_45 = (IData)(
                                                        (0xa0000000U 
                                                         == 
                                                         (0xfc004000U 
                                                          & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_186 
        = (IData)((0U == (0x6000U & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_188 
        = (IData)((0U == (0xbe000000U & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_64 
        = (IData)((0x63U == (0x207fU & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst)));
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__2380(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__2380\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_is_rocc 
        = (((0xbU == (0x7fU & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst)) 
            | ((0x2bU == (0x7fU & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst)) 
               | (0x7bU == (0x7fU & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst)))) 
           & ((0U == (7U & (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst 
                            >> 0xcU))) | ((2U == (7U 
                                                  & (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst 
                                                     >> 0xcU))) 
                                          | ((3U == 
                                              (7U & 
                                               (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst 
                                                >> 0xcU))) 
                                             | ((4U 
                                                 == 
                                                 (7U 
                                                  & (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst 
                                                     >> 0xcU))) 
                                                | ((6U 
                                                    == 
                                                    (7U 
                                                     & (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst 
                                                        >> 0xcU))) 
                                                   | (7U 
                                                      == 
                                                      (7U 
                                                       & (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst 
                                                          >> 0xcU)))))))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT____VdfgBinToOneHot_Tab_h51aa2a42_0_0[vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT____VdfgBinToOneHot_Pre_h51aa2a42_0_0] = 0U;
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT____VdfgBinToOneHot_Tab_h51aa2a42_0_0[(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst 
                                                                                >> 0x14U)] = 1U;
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT____VdfgBinToOneHot_Pre_h51aa2a42_0_0 
        = (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst 
           >> 0x14U);
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_103 
        = (IData)((0x6000U == (0x6000U & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_119 
        = (IData)((0xc0000000U == (0xc0000000U & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_52 
        = (IData)((0x202fU == (0x1800607fU & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst)));
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__2381(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__2381\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_fp_ctrl_ren3 
        = (IData)((0x43U == (0x73U & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___io_decode_0_system_illegal_T 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__reg_mstatus_prv) 
           < (3U & (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst 
                    >> 0x1cU)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_93 
        = (IData)((0x2000U == (0x6040U & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_124 
        = (IData)((0x1063U == (0x306fU & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_202 
        = (IData)((0x40U == (0x4000070U & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst)));
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__2382(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__2382\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_71 
        = (IData)((0x4063U == (0x407fU & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst)));
    vlSelfRef.__VdfgRegularize_h787163e4_0_22 = (IData)(
                                                        (0U 
                                                         == 
                                                         (0xbe000000U 
                                                          & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT___GEN_7 
        = ((0x380U & (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst 
                      >> 5U)) | (0x7fU & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst));
    vlSelfRef.__VdfgRegularize_h787163e4_0_15 = (IData)(
                                                        (0U 
                                                         == 
                                                         (0x4040U 
                                                          & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_111 
        = (IData)((3U == (0x207fU & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst)));
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__2383(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__2383\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_56 
        = (IData)((0x17U == (0x5fU & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_66 
        = (IData)((0x6fU == (0x7fU & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst)));
    vlSelfRef.__VdfgRegularize_h787163e4_0_14 = (IData)(
                                                        (0U 
                                                         == 
                                                         (0x1060U 
                                                          & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_69 
        = (IData)((0x2013U == (0x207fU & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst)));
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__2384(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__2384\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_190 
        = (IData)((0x40000000U == (0xc0000000U & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_114 
        = (IData)((0x1073U == (0x107fU & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_223 
        = ((4U & ((~ (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst 
                      >> 6U)) << 2U)) | ((2U & (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst 
                                                >> 0xcU)) 
                                         | (1U & (~ 
                                                  (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst 
                                                   >> 0xeU)))));
    vlSelfRef.__VdfgRegularize_h787163e4_0_28 = (IData)(
                                                        (0x28000000U 
                                                         == 
                                                         (0xbc000000U 
                                                          & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst)));
    vlSelfRef.__VdfgRegularize_h787163e4_0_41 = (IData)(
                                                        (0x40000000U 
                                                         == 
                                                         (0x7c000000U 
                                                          & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst)));
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__2385(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__2385\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_116 
        = (IData)((0x2073U == (0x207fU & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_233 
        = (((0x10U & ((~ (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst 
                          >> 0x1aU)) << 4U)) | ((8U 
                                                 & ((~ 
                                                     (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst 
                                                      >> 0x1bU)) 
                                                    << 3U)) 
                                                | (4U 
                                                   & ((~ 
                                                       (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst 
                                                        >> 0x1cU)) 
                                                      << 2U)))) 
           | ((2U & (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst 
                     >> 0x1cU)) | (1U & (~ (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst 
                                            >> 0x1eU)))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_261 
        = ((2U & (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst 
                  >> 0x1dU)) | (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst 
                                >> 0x1fU));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_209 
        = ((2U & ((~ (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst 
                      >> 0xdU)) << 1U)) | (1U & (~ 
                                                 (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst 
                                                  >> 0xeU))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT____VdfgRegularize_h51aa2a42_0_40 
        = (IData)((0U == (0xc0000000U & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_241 
        = ((2U & (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst 
                  >> 0x1dU)) | (1U & (~ (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst 
                                         >> 0x1fU))));
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__2386(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__2386\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_212 
        = ((2U & ((~ (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst 
                      >> 0x1eU)) << 1U)) | (1U & (~ 
                                                  (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst 
                                                   >> 0x1fU))));
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT____Vcellinp__slots_7__io_in_uop_valid) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_7__DOT__slot_uop_pdst 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___dispatcher_io_dis_uops_3_0_bits_pdst;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT____Vcellinp__slots_6__io_in_uop_valid) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_6__DOT__slot_uop_pdst 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___dispatcher_io_dis_uops_3_0_bits_pdst;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT____Vcellinp__slots_5__io_in_uop_valid) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_5__DOT__slot_uop_pdst 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___dispatcher_io_dis_uops_3_0_bits_pdst;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT____Vcellinp__slots_4__io_in_uop_valid) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_4__DOT__slot_uop_pdst 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___dispatcher_io_dis_uops_3_0_bits_pdst;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT____Vcellinp__slots_3__io_in_uop_valid) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_3__DOT__slot_uop_pdst 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___dispatcher_io_dis_uops_3_0_bits_pdst;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT____Vcellinp__slots_2__io_in_uop_valid) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_2__DOT__slot_uop_pdst 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___dispatcher_io_dis_uops_3_0_bits_pdst;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT____Vcellinp__slots_1__io_in_uop_valid) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_1__DOT__slot_uop_pdst 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___dispatcher_io_dis_uops_3_0_bits_pdst;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT____Vcellinp__slots_0__io_in_uop_valid) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_0__DOT__slot_uop_pdst 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___dispatcher_io_dis_uops_3_0_bits_pdst;
    }
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_68 
        = (0x7ffffU & (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_67 
                       | (((IData)(1U) << (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__b2_uop_rob_idx)) 
                          >> 0xdU)));
    if ((1U & (~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__alu_exe_unit_0__DOT___GEN_1)))) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__alu_exe_unit_0__DOT__arb_uop_bits_br_tag 
            = ((0x17U >= (0x1fU & ((IData)(3U) * (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__alu_iss_unit__DOT__iss_signals_0_bits))))
                ? (7U & ((((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__alu_iss_unit__DOT__slots_7__DOT__slot_uop_br_tag) 
                             << 0x15U) | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__alu_iss_unit__DOT__slots_6__DOT__slot_uop_br_tag) 
                                          << 0x12U)) 
                           | (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__alu_iss_unit__DOT__slots_5__DOT__slot_uop_br_tag) 
                               << 0xfU) | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__alu_iss_unit__DOT__slots_4__DOT__slot_uop_br_tag) 
                                           << 0xcU))) 
                          | ((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__alu_iss_unit__DOT__slots_3__DOT__slot_uop_br_tag) 
                               << 9U) | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__alu_iss_unit__DOT__slots_2__DOT__slot_uop_br_tag) 
                                         << 6U)) | 
                             (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__alu_iss_unit__DOT__slots_1__DOT__slot_uop_br_tag) 
                               << 3U) | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__alu_iss_unit__DOT__slots_0__DOT__slot_uop_br_tag)))) 
                         >> (0x1fU & ((IData)(3U) * (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__alu_iss_unit__DOT__iss_signals_0_bits)))))
                : 0U);
    }
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__2387(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__2387\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__iregfile__DOT__rfs_0__DOT__use_port_11 
        = ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__iregfile__DOT__rfs_0__DOT___GEN_14)) 
           & ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__iregfile__DOT__rfs_0__DOT___GEN_8)) 
              & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___mem_exe_unit_1_io_arb_irf_reqs_0_valid)));
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unq_iss_unit__DOT____Vcellinp__slots_7__io_in_uop_valid) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unq_iss_unit__DOT__slots_7__DOT__slot_uop_rob_idx 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_tail;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unq_iss_unit__DOT____Vcellinp__slots_6__io_in_uop_valid) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unq_iss_unit__DOT__slots_6__DOT__slot_uop_rob_idx 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_tail;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unq_iss_unit__DOT____Vcellinp__slots_5__io_in_uop_valid) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unq_iss_unit__DOT__slots_5__DOT__slot_uop_rob_idx 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_tail;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unq_iss_unit__DOT____Vcellinp__slots_4__io_in_uop_valid) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unq_iss_unit__DOT__slots_4__DOT__slot_uop_rob_idx 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_tail;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unq_iss_unit__DOT____Vcellinp__slots_3__io_in_uop_valid) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unq_iss_unit__DOT__slots_3__DOT__slot_uop_rob_idx 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_tail;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unq_iss_unit__DOT____Vcellinp__slots_2__io_in_uop_valid) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unq_iss_unit__DOT__slots_2__DOT__slot_uop_rob_idx 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_tail;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unq_iss_unit__DOT____Vcellinp__slots_1__io_in_uop_valid) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unq_iss_unit__DOT__slots_1__DOT__slot_uop_rob_idx 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_tail;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unq_iss_unit__DOT____Vcellinp__slots_0__io_in_uop_valid) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unq_iss_unit__DOT__slots_0__DOT__slot_uop_rob_idx 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_tail;
    }
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__rrd_uop_bits_rob_idx 
        = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__arb_uop_bits_rob_idx;
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__io_div_resp_div__DOT__div__DOT___GEN_5 
        = ((0U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__io_div_resp_div__DOT__div__DOT__state)) 
           & ((~ ((0U != ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT___lsu_io_dmem_brupdate_b1_mispredict_mask) 
                          & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__exe_uop_bits_br_mask))) 
                  | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0_io_kill_REG))) 
              & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__io_div_resp_div_io_req_valid)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__io_ifpu_resp_queue__DOT__do_enq 
        = ((~ (IData)(vlSelfRef.__VdfgRegularize_h36cfaf1a_0_94)) 
           & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__io_ifpu_resp_ifpu__DOT__pipe__DOT__uops_1_valid) 
              & ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0_io_kill_REG)) 
                 & (0U == ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT___lsu_io_dmem_brupdate_b1_mispredict_mask) 
                           & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__io_ifpu_resp_ifpu__DOT__pipe__DOT__uops_1_bits_uop_br_mask))))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___GEN_10 
        = (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___rob_io_flush_valid) 
            << 2U) | ((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__b2_mispredict) 
                        & (3U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__b2_cfi_type))) 
                       << 1U) | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__b2_mispredict)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___rob_io_flush_bits_flush_typ 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___rob_io_flush_valid)
            ? (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__flush_commit_mask_0) 
                & ((((((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_uop_31_is_eret) 
                         << 0x1fU) | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_uop_30_is_eret) 
                                      << 0x1eU)) | 
                       (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_uop_29_is_eret) 
                         << 0x1dU) | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_uop_28_is_eret) 
                                      << 0x1cU))) | 
                      ((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_uop_27_is_eret) 
                         << 0x1bU) | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_uop_26_is_eret) 
                                      << 0x1aU)) | 
                       (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_uop_25_is_eret) 
                         << 0x19U) | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_uop_24_is_eret) 
                                      << 0x18U)))) 
                     | (((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_uop_23_is_eret) 
                           << 0x17U) | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_uop_22_is_eret) 
                                        << 0x16U)) 
                         | (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_uop_21_is_eret) 
                             << 0x15U) | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_uop_20_is_eret) 
                                          << 0x14U))) 
                        | ((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_uop_19_is_eret) 
                             << 0x13U) | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_uop_18_is_eret) 
                                          << 0x12U)) 
                           | (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_uop_17_is_eret) 
                               << 0x11U) | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_uop_16_is_eret) 
                                            << 0x10U))))) 
                    | ((((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_uop_15_is_eret) 
                           << 0xfU) | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_uop_14_is_eret) 
                                       << 0xeU)) | 
                         (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_uop_13_is_eret) 
                           << 0xdU) | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_uop_12_is_eret) 
                                       << 0xcU))) | 
                        ((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_uop_11_is_eret) 
                           << 0xbU) | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_uop_10_is_eret) 
                                       << 0xaU)) | 
                         (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_uop_9_is_eret) 
                           << 9U) | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_uop_8_is_eret) 
                                     << 8U)))) | ((
                                                   (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_uop_7_is_eret) 
                                                     << 7U) 
                                                    | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_uop_6_is_eret) 
                                                       << 6U)) 
                                                   | (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_uop_5_is_eret) 
                                                       << 5U) 
                                                      | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_uop_4_is_eret) 
                                                         << 4U))) 
                                                  | ((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_uop_3_is_eret) 
                                                       << 3U) 
                                                      | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_uop_2_is_eret) 
                                                         << 2U)) 
                                                     | (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_uop_1_is_eret) 
                                                         << 1U) 
                                                        | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_uop_0_is_eret)))))) 
                   >> (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_head)))
                ? 3U : ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___rob_io_com_xcpt_valid)
                         ? 1U : (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__exception_thrown) 
                                  | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_12) 
                                     & ((((((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_uop_31_is_sys_pc2epc) 
                                              << 0x1fU) 
                                             | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_uop_30_is_sys_pc2epc) 
                                                << 0x1eU)) 
                                            | (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_uop_29_is_sys_pc2epc) 
                                                << 0x1dU) 
                                               | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_uop_28_is_sys_pc2epc) 
                                                  << 0x1cU))) 
                                           | ((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_uop_27_is_sys_pc2epc) 
                                                << 0x1bU) 
                                               | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_uop_26_is_sys_pc2epc) 
                                                  << 0x1aU)) 
                                              | (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_uop_25_is_sys_pc2epc) 
                                                  << 0x19U) 
                                                 | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_uop_24_is_sys_pc2epc) 
                                                    << 0x18U)))) 
                                          | (((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_uop_23_is_sys_pc2epc) 
                                                << 0x17U) 
                                               | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_uop_22_is_sys_pc2epc) 
                                                  << 0x16U)) 
                                              | (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_uop_21_is_sys_pc2epc) 
                                                  << 0x15U) 
                                                 | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_uop_20_is_sys_pc2epc) 
                                                    << 0x14U))) 
                                             | ((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_uop_19_is_sys_pc2epc) 
                                                  << 0x13U) 
                                                 | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_uop_18_is_sys_pc2epc) 
                                                    << 0x12U)) 
                                                | (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_uop_17_is_sys_pc2epc) 
                                                    << 0x11U) 
                                                   | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_uop_16_is_sys_pc2epc) 
                                                      << 0x10U))))) 
                                         | ((((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_uop_15_is_sys_pc2epc) 
                                                << 0xfU) 
                                               | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_uop_14_is_sys_pc2epc) 
                                                  << 0xeU)) 
                                              | (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_uop_13_is_sys_pc2epc) 
                                                  << 0xdU) 
                                                 | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_uop_12_is_sys_pc2epc) 
                                                    << 0xcU))) 
                                             | ((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_uop_11_is_sys_pc2epc) 
                                                  << 0xbU) 
                                                 | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_uop_10_is_sys_pc2epc) 
                                                    << 0xaU)) 
                                                | (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_uop_9_is_sys_pc2epc) 
                                                    << 9U) 
                                                   | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_uop_8_is_sys_pc2epc) 
                                                      << 8U)))) 
                                            | (((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_uop_7_is_sys_pc2epc) 
                                                  << 7U) 
                                                 | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_uop_6_is_sys_pc2epc) 
                                                    << 6U)) 
                                                | (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_uop_5_is_sys_pc2epc) 
                                                    << 5U) 
                                                   | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_uop_4_is_sys_pc2epc) 
                                                      << 4U))) 
                                               | ((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_uop_3_is_sys_pc2epc) 
                                                    << 3U) 
                                                   | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_uop_2_is_sys_pc2epc) 
                                                      << 2U)) 
                                                  | (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_uop_1_is_sys_pc2epc) 
                                                      << 1U) 
                                                     | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_uop_0_is_sys_pc2epc)))))) 
                                        >> (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_head))))
                                  ? 2U : 4U))) : 0U);
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__2388(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__2388\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___unique_exe_unit_0_io_squash_iss 
        = (((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___iregfile_io_arb_read_reqs_4_ready)) 
            & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___unique_exe_unit_0_io_arb_irf_reqs_0_valid)) 
           | ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___iregfile_io_arb_read_reqs_5_ready)) 
              & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___unique_exe_unit_0_io_arb_irf_reqs_1_valid)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__iregfile__DOT__rfs_0__DOT___GEN_18 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__iregfile__DOT__rfs_0__DOT__use_port_12) 
           | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__iregfile__DOT__rfs_0__DOT___GEN_12));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__iregfile__DOT__rfs_0__DOT__use_port_13 
        = ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__iregfile__DOT__rfs_0__DOT__use_port_12)) 
           & ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__iregfile__DOT__rfs_0__DOT___GEN_13)) 
              & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___unique_exe_unit_0_io_arb_irf_reqs_0_valid)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unq_iss_unit__DOT____VdfgRegularize_h34440c3b_0_0 
        = (((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unq_iss_unit__DOT__iss_ready_0_7) 
              << 7U) | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unq_iss_unit__DOT__iss_ready_0_6) 
                        << 6U)) | (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unq_iss_unit__DOT__iss_ready_0_5) 
                                    << 5U) | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unq_iss_unit__DOT__iss_ready_0_4) 
                                              << 4U))) 
           | ((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unq_iss_unit__DOT__iss_ready_0_3) 
                << 3U) | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unq_iss_unit__DOT__iss_ready_0_2) 
                          << 2U)) | (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unq_iss_unit__DOT__iss_ready_0_1) 
                                      << 1U) | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unq_iss_unit__DOT__iss_ready_0_0))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__slots_valid_dealloc_7 
        = ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT___slots_7_io_will_be_valid)) 
           & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__slots_7__DOT__slot_valid));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__slots_valid_alloc_7 
        = ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__slots_7__DOT__slot_valid)) 
           & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT___slots_7_io_will_be_valid));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unq_iss_unit__DOT__slots_valid_dealloc_7 
        = ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unq_iss_unit__DOT___slots_7_io_will_be_valid)) 
           & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unq_iss_unit__DOT__slots_7__DOT__slot_valid));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unq_iss_unit__DOT__slots_valid_alloc_7 
        = ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unq_iss_unit__DOT__slots_7__DOT__slot_valid)) 
           & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unq_iss_unit__DOT___slots_7_io_will_be_valid));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__alu_iss_unit__DOT__slots_valid_dealloc_7 
        = ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__alu_iss_unit__DOT___slots_7_io_will_be_valid)) 
           & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__alu_iss_unit__DOT__slots_7__DOT__slot_valid));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__alu_iss_unit__DOT__slots_valid_alloc_7 
        = ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__alu_iss_unit__DOT__slots_7__DOT__slot_valid)) 
           & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__alu_iss_unit__DOT___slots_7_io_will_be_valid));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__slots_valid_dealloc_6 
        = ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT___slots_6_io_will_be_valid)) 
           & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__slots_6__DOT__slot_valid));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__slots_valid_alloc_6 
        = ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__slots_6__DOT__slot_valid)) 
           & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT___slots_6_io_will_be_valid));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unq_iss_unit__DOT__slots_valid_dealloc_6 
        = ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unq_iss_unit__DOT___slots_6_io_will_be_valid)) 
           & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unq_iss_unit__DOT__slots_6__DOT__slot_valid));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unq_iss_unit__DOT__slots_valid_alloc_6 
        = ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unq_iss_unit__DOT__slots_6__DOT__slot_valid)) 
           & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unq_iss_unit__DOT___slots_6_io_will_be_valid));
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__2389(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__2389\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__alu_iss_unit__DOT__slots_valid_dealloc_6 
        = ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__alu_iss_unit__DOT___slots_6_io_will_be_valid)) 
           & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__alu_iss_unit__DOT__slots_6__DOT__slot_valid));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__alu_iss_unit__DOT__slots_valid_alloc_6 
        = ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__alu_iss_unit__DOT__slots_6__DOT__slot_valid)) 
           & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__alu_iss_unit__DOT___slots_6_io_will_be_valid));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__slots_valid_dealloc_5 
        = ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT___slots_5_io_will_be_valid)) 
           & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__slots_5__DOT__slot_valid));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__slots_valid_alloc_5 
        = ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__slots_5__DOT__slot_valid)) 
           & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT___slots_5_io_will_be_valid));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unq_iss_unit__DOT__slots_valid_dealloc_5 
        = ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unq_iss_unit__DOT___slots_5_io_will_be_valid)) 
           & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unq_iss_unit__DOT__slots_5__DOT__slot_valid));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unq_iss_unit__DOT__slots_valid_alloc_5 
        = ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unq_iss_unit__DOT__slots_5__DOT__slot_valid)) 
           & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unq_iss_unit__DOT___slots_5_io_will_be_valid));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__alu_iss_unit__DOT__slots_valid_dealloc_5 
        = ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__alu_iss_unit__DOT___slots_5_io_will_be_valid)) 
           & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__alu_iss_unit__DOT__slots_5__DOT__slot_valid));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__alu_iss_unit__DOT__slots_valid_alloc_5 
        = ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__alu_iss_unit__DOT__slots_5__DOT__slot_valid)) 
           & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__alu_iss_unit__DOT___slots_5_io_will_be_valid));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__slots_valid_dealloc_4 
        = ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT___slots_4_io_will_be_valid)) 
           & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__slots_4__DOT__slot_valid));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__slots_valid_alloc_4 
        = ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__slots_4__DOT__slot_valid)) 
           & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT___slots_4_io_will_be_valid));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unq_iss_unit__DOT__slots_valid_dealloc_4 
        = ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unq_iss_unit__DOT___slots_4_io_will_be_valid)) 
           & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unq_iss_unit__DOT__slots_4__DOT__slot_valid));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unq_iss_unit__DOT__slots_valid_alloc_4 
        = ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unq_iss_unit__DOT__slots_4__DOT__slot_valid)) 
           & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unq_iss_unit__DOT___slots_4_io_will_be_valid));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__alu_iss_unit__DOT__slots_valid_dealloc_4 
        = ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__alu_iss_unit__DOT___slots_4_io_will_be_valid)) 
           & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__alu_iss_unit__DOT__slots_4__DOT__slot_valid));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__alu_iss_unit__DOT__slots_valid_alloc_4 
        = ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__alu_iss_unit__DOT__slots_4__DOT__slot_valid)) 
           & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__alu_iss_unit__DOT___slots_4_io_will_be_valid));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__slots_valid_dealloc_3 
        = ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT___slots_3_io_will_be_valid)) 
           & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__slots_3__DOT__slot_valid));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__slots_valid_alloc_3 
        = ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__slots_3__DOT__slot_valid)) 
           & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT___slots_3_io_will_be_valid));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unq_iss_unit__DOT__slots_valid_dealloc_3 
        = ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unq_iss_unit__DOT___slots_3_io_will_be_valid)) 
           & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unq_iss_unit__DOT__slots_3__DOT__slot_valid));
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__2390(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__2390\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unq_iss_unit__DOT__slots_valid_alloc_3 
        = ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unq_iss_unit__DOT__slots_3__DOT__slot_valid)) 
           & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unq_iss_unit__DOT___slots_3_io_will_be_valid));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__alu_iss_unit__DOT__slots_valid_dealloc_3 
        = ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__alu_iss_unit__DOT___slots_3_io_will_be_valid)) 
           & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__alu_iss_unit__DOT__slots_3__DOT__slot_valid));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__alu_iss_unit__DOT__slots_valid_alloc_3 
        = ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__alu_iss_unit__DOT__slots_3__DOT__slot_valid)) 
           & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__alu_iss_unit__DOT___slots_3_io_will_be_valid));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__slots_valid_dealloc_2 
        = ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT___slots_2_io_will_be_valid)) 
           & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__slots_2__DOT__slot_valid));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__slots_valid_alloc_2 
        = ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__slots_2__DOT__slot_valid)) 
           & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT___slots_2_io_will_be_valid));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unq_iss_unit__DOT__slots_valid_dealloc_2 
        = ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unq_iss_unit__DOT___slots_2_io_will_be_valid)) 
           & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unq_iss_unit__DOT__slots_2__DOT__slot_valid));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unq_iss_unit__DOT__slots_valid_alloc_2 
        = ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unq_iss_unit__DOT__slots_2__DOT__slot_valid)) 
           & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unq_iss_unit__DOT___slots_2_io_will_be_valid));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__alu_iss_unit__DOT__slots_valid_dealloc_2 
        = ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__alu_iss_unit__DOT___slots_2_io_will_be_valid)) 
           & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__alu_iss_unit__DOT__slots_2__DOT__slot_valid));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__alu_iss_unit__DOT__slots_valid_alloc_2 
        = ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__alu_iss_unit__DOT__slots_2__DOT__slot_valid)) 
           & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__alu_iss_unit__DOT___slots_2_io_will_be_valid));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__slots_valid_dealloc_1 
        = ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT___slots_1_io_will_be_valid)) 
           & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__slots_1__DOT__slot_valid));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__slots_valid_alloc_1 
        = ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__slots_1__DOT__slot_valid)) 
           & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT___slots_1_io_will_be_valid));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unq_iss_unit__DOT__slots_valid_dealloc_1 
        = ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unq_iss_unit__DOT___slots_1_io_will_be_valid)) 
           & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unq_iss_unit__DOT__slots_1__DOT__slot_valid));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unq_iss_unit__DOT__slots_valid_alloc_1 
        = ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unq_iss_unit__DOT__slots_1__DOT__slot_valid)) 
           & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unq_iss_unit__DOT___slots_1_io_will_be_valid));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__alu_iss_unit__DOT__slots_valid_dealloc_1 
        = ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__alu_iss_unit__DOT___slots_1_io_will_be_valid)) 
           & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__alu_iss_unit__DOT__slots_1__DOT__slot_valid));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__alu_iss_unit__DOT__slots_valid_alloc_1 
        = ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__alu_iss_unit__DOT__slots_1__DOT__slot_valid)) 
           & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__alu_iss_unit__DOT___slots_1_io_will_be_valid));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__slots_valid_alloc_0 
        = ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__slots_0__DOT__slot_valid)) 
           & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT___slots_0_io_will_be_valid));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__slots_valid_dealloc_0 
        = ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT___slots_0_io_will_be_valid)) 
           & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__slots_0__DOT__slot_valid));
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__2391(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__2391\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__slots_empty_0 
        = (1U & ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT___slots_0_io_will_be_valid)) 
                 & (~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__slots_0__DOT__slot_valid))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unq_iss_unit__DOT__slots_valid_alloc_0 
        = ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unq_iss_unit__DOT__slots_0__DOT__slot_valid)) 
           & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unq_iss_unit__DOT___slots_0_io_will_be_valid));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unq_iss_unit__DOT__slots_valid_dealloc_0 
        = ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unq_iss_unit__DOT___slots_0_io_will_be_valid)) 
           & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unq_iss_unit__DOT__slots_0__DOT__slot_valid));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unq_iss_unit__DOT__slots_empty_0 
        = (1U & ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unq_iss_unit__DOT___slots_0_io_will_be_valid)) 
                 & (~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unq_iss_unit__DOT__slots_0__DOT__slot_valid))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__alu_iss_unit__DOT__slots_valid_alloc_0 
        = ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__alu_iss_unit__DOT__slots_0__DOT__slot_valid)) 
           & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__alu_iss_unit__DOT___slots_0_io_will_be_valid));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__alu_iss_unit__DOT__slots_valid_dealloc_0 
        = ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__alu_iss_unit__DOT___slots_0_io_will_be_valid)) 
           & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__alu_iss_unit__DOT__slots_0__DOT__slot_valid));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__alu_iss_unit__DOT__slots_empty_0 
        = (1U & ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__alu_iss_unit__DOT___slots_0_io_will_be_valid)) 
                 & (~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__alu_iss_unit__DOT__slots_0__DOT__slot_valid))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__alu_exe_unit_0__DOT__alu__DOT__alu__DOT___rotout_l_T_28 
        = ((0xff00ff00ff00ffULL & (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__alu_exe_unit_0__DOT__alu__DOT__alu__DOT___rotout_l_T_18 
                                   >> 8U)) | (0xff00ff00ff00ff00ULL 
                                              & (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__alu_exe_unit_0__DOT__alu__DOT__alu__DOT___rotout_l_T_18 
                                                 << 8U)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__alu_exe_unit_0__DOT__alu__DOT__alu__DOT___shout_l_T_18 
        = ((0xffff0000ffffULL & (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__alu_exe_unit_0__DOT__alu__DOT__alu__DOT___shout_l_T_8 
                                 >> 0x10U)) | (0xffff0000ffff0000ULL 
                                               & (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__alu_exe_unit_0__DOT__alu__DOT__alu__DOT___shout_l_T_8 
                                                  << 0x10U)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___bpd_decoder_1_io_out_sfb_offset_bits 
        = ((0x20U & (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3__DOT__ram[0xdU] 
                     >> 0x18U)) | (0x1eU & (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3__DOT__ram[0xdU] 
                                            >> 0xbU)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___bpd_decoder_2_io_out_sfb_offset_bits 
        = ((0x20U & (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3__DOT__ram[0xeU] 
                     >> 0x18U)) | (0x1eU & (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3__DOT__ram[0xeU] 
                                            >> 0xbU)));
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__2392(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__2392\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___bpd_decoder_3_io_out_sfb_offset_bits 
        = ((0x20U & (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3__DOT__ram[0xfU] 
                     >> 0x18U)) | (0x1eU & (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3__DOT__ram[0xfU] 
                                            >> 0xbU)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___offset_from_aligned_pc_T_4 
        = (0x7fU & (((0x20U & (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3__DOT__ram[0xcU] 
                               >> 0x18U)) | (0x1eU 
                                             & (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3__DOT__ram[0xcU] 
                                                >> 0xbU))) 
                    - (2U & (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3__DOT__ram[0x14U] 
                             >> 3U))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd_decoder_3__DOT____VdfgRegularize_h05eccaf4_0_30 
        = (IData)((0x6f0U == (0x7f0U & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3__DOT__ram[0xfU])));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd_decoder_3__DOT____VdfgRegularize_h05eccaf4_0_31 
        = (1U & (IData)(((0x630U == (0x7f0U & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3__DOT__ram[0xfU])) 
                         & (0x20000U != (0x60000U & 
                                         vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3__DOT__ram[0xfU])))));
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__2393(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__2393\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd_decoder__DOT____VdfgRegularize_h05eccaf4_0_37 
        = (1U & (IData)((((0U == (0xc0000000U & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3__DOT__ram[0xcU])) 
                          & (0U == (0xaU & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3__DOT__ram[0xdU]))) 
                         & (~ vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3__DOT__ram[0xdU]))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd_decoder_1__DOT____VdfgRegularize_h05eccaf4_0_37 
        = (1U & (IData)((((0U == (0xc0000000U & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3__DOT__ram[0xdU])) 
                          & (0U == (0xaU & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3__DOT__ram[0xeU]))) 
                         & (~ vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3__DOT__ram[0xeU]))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd_decoder_2__DOT____VdfgRegularize_h05eccaf4_0_37 
        = (1U & (IData)((((0U == (0xc0000000U & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3__DOT__ram[0xeU])) 
                          & (0U == (0xaU & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3__DOT__ram[0xfU]))) 
                         & (~ vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3__DOT__ram[0xfU]))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd_decoder_3__DOT____VdfgRegularize_h05eccaf4_0_37 
        = (1U & (IData)((((0U == (0xc0000000U & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3__DOT__ram[0xfU])) 
                          & (0U == (0xaU & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3__DOT__ram[0x10U]))) 
                         & (~ vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3__DOT__ram[0x10U]))));
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__2394(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__2394\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.__VdfgRegularize_h787163e4_0_3 = (IData)(
                                                       (0U 
                                                        == 
                                                        (0x70000U 
                                                         & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3__DOT__ram[0xfU])));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd_decoder_2__DOT____VdfgRegularize_h05eccaf4_0_30 
        = (IData)((0x6f0U == (0x7f0U & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3__DOT__ram[0xeU])));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd_decoder_2__DOT____VdfgRegularize_h05eccaf4_0_31 
        = (1U & (IData)(((0x630U == (0x7f0U & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3__DOT__ram[0xeU])) 
                         & (0x20000U != (0x60000U & 
                                         vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3__DOT__ram[0xeU])))));
    vlSelfRef.__VdfgRegularize_h787163e4_0_6 = (1U 
                                                & (IData)(
                                                          (((0U 
                                                             == 
                                                             (0xe0000000U 
                                                              & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3__DOT__ram[0xcU])) 
                                                            & (0U 
                                                               == 
                                                               (0xaU 
                                                                & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3__DOT__ram[0xdU]))) 
                                                           & (~ 
                                                              vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3__DOT__ram[0xdU]))));
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__2395(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__2395\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.__VdfgRegularize_h787163e4_0_7 = (1U 
                                                & (IData)(
                                                          (((0U 
                                                             == 
                                                             (0xe0000000U 
                                                              & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3__DOT__ram[0xdU])) 
                                                            & (0U 
                                                               == 
                                                               (0xaU 
                                                                & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3__DOT__ram[0xeU]))) 
                                                           & (~ 
                                                              vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3__DOT__ram[0xeU]))));
    vlSelfRef.__VdfgRegularize_h787163e4_0_8 = (1U 
                                                & (IData)(
                                                          (((0U 
                                                             == 
                                                             (0xe0000000U 
                                                              & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3__DOT__ram[0xeU])) 
                                                            & (0U 
                                                               == 
                                                               (0xaU 
                                                                & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3__DOT__ram[0xfU]))) 
                                                           & (~ 
                                                              vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3__DOT__ram[0xfU]))));
    vlSelfRef.__VdfgRegularize_h787163e4_0_9 = (1U 
                                                & (IData)(
                                                          (((0U 
                                                             == 
                                                             (0xe0000000U 
                                                              & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3__DOT__ram[0xfU])) 
                                                            & (0U 
                                                               == 
                                                               (0xaU 
                                                                & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3__DOT__ram[0x10U]))) 
                                                           & (~ 
                                                              vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3__DOT__ram[0x10U]))));
    vlSelfRef.__VdfgRegularize_h787163e4_0_2 = (IData)(
                                                       (0U 
                                                        == 
                                                        (0x70000U 
                                                         & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3__DOT__ram[0xeU])));
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__2396(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__2396\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd_decoder__DOT____VdfgRegularize_h05eccaf4_0_35 
        = (1U & (IData)((((0U == (0xc0000000U & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3__DOT__ram[0xcU])) 
                          & (0U == (0xeU & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3__DOT__ram[0xdU]))) 
                         & (~ vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3__DOT__ram[0xdU]))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd_decoder_1__DOT____VdfgRegularize_h05eccaf4_0_35 
        = (1U & (IData)((((0U == (0xc0000000U & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3__DOT__ram[0xdU])) 
                          & (0U == (0xeU & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3__DOT__ram[0xeU]))) 
                         & (~ vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3__DOT__ram[0xeU]))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd_decoder_2__DOT____VdfgRegularize_h05eccaf4_0_35 
        = (1U & (IData)((((0U == (0xc0000000U & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3__DOT__ram[0xeU])) 
                          & (0U == (0xeU & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3__DOT__ram[0xfU]))) 
                         & (~ vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3__DOT__ram[0xfU]))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd_decoder_3__DOT____VdfgRegularize_h05eccaf4_0_35 
        = (1U & (IData)((((0U == (0xc0000000U & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3__DOT__ram[0xfU])) 
                          & (0U == (0xeU & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3__DOT__ram[0x10U]))) 
                         & (~ vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3__DOT__ram[0x10U]))));
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__2397(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__2397\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd_decoder_1__DOT____VdfgRegularize_h05eccaf4_0_30 
        = (IData)((0x6f0U == (0x7f0U & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3__DOT__ram[0xdU])));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd_decoder_1__DOT____VdfgRegularize_h05eccaf4_0_31 
        = (1U & (IData)(((0x630U == (0x7f0U & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3__DOT__ram[0xdU])) 
                         & (0x20000U != (0x60000U & 
                                         vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3__DOT__ram[0xdU])))));
    vlSelfRef.__VdfgRegularize_h787163e4_0_1 = (IData)(
                                                       (0U 
                                                        == 
                                                        (0x70000U 
                                                         & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3__DOT__ram[0xdU])));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT____VdfgRegularize_hce62b063_0_13 
        = (1U & (~ (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3__DOT__ram[1U] 
                    | (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3__DOT__ram[1U] 
                       >> 1U))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd_decoder__DOT____VdfgRegularize_h05eccaf4_0_30 
        = (IData)((0x6f0U == (0x7f0U & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3__DOT__ram[0xcU])));
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__2398(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__2398\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd_decoder__DOT____VdfgRegularize_h05eccaf4_0_31 
        = (1U & (IData)(((0x630U == (0x7f0U & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3__DOT__ram[0xcU])) 
                         & (0x20000U != (0x60000U & 
                                         vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3__DOT__ram[0xcU])))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3_mask_0 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3__DOT__maybe_full) 
           & (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3__DOT__ram[3U] 
              >> 0xfU));
    vlSelfRef.__VdfgRegularize_h787163e4_0_0 = (IData)(
                                                       (0U 
                                                        == 
                                                        (0x70000U 
                                                         & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3__DOT__ram[0xcU])));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__fb__DOT__in_uops_3_taken 
        = (IData)((0x70000000U == (0x70000000U & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f4__DOT__ram[8U])));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__fb__DOT__in_uops_2_taken 
        = (IData)((0x60000000U == (0x70000000U & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f4__DOT__ram[8U])));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__fb__DOT__in_uops_1_taken 
        = (IData)((0x50000000U == (0x70000000U & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f4__DOT__ram[8U])));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__fb__DOT__in_uops_0_debug_pc 
        = (0xffffffffffULL & ((0x8000000U & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f4__DOT__ram[0x17U])
                               ? ((0xfffffffff8ULL 
                                   & (((QData)((IData)(
                                                       vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f4__DOT__ram[0x1bU])) 
                                       << 0x14U) | 
                                      (0xffffffffffff8ULL 
                                       & ((QData)((IData)(
                                                          vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f4__DOT__ram[0x1aU])) 
                                          >> 0xcU)))) 
                                  - 2ULL) : (0xfffffffff8ULL 
                                             & (((QData)((IData)(
                                                                 vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f4__DOT__ram[0x1bU])) 
                                                 << 0x14U) 
                                                | (0xffffffffffff8ULL 
                                                   & ((QData)((IData)(
                                                                      vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f4__DOT__ram[0x1aU])) 
                                                      >> 0xcU))))));
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__2399(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__2399\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__fb__DOT__in_uops_0_taken 
        = (IData)((0x40000000U == (0x70000000U & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f4__DOT__ram[8U])));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__ftq__DOT__new_entry_br_mask 
        = (0xfU & (((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f4__DOT__ram[7U] 
                     << 0x1eU) | (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f4__DOT__ram[7U] 
                                  >> 2U)) & ((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f4__DOT__ram[7U] 
                                              << 0x1aU) 
                                             | (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f4__DOT__ram[7U] 
                                                >> 6U))));
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__ftq__DOT__io_ras_update_REG) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT____Vcellinp__ras__io_write_idx 
            = (0x1fU & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__ftq__DOT__io_ras_update_idx_REG));
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT____Vcellinp__ras__io_write_addr 
            = (0xffffffffffULL & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__ftq__DOT__io_ras_update_pc_REG);
    } else {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT____Vcellinp__ras__io_write_idx 
            = (0x1fU & ((IData)(1U) + ((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f4__DOT__ram[4U] 
                                        << 6U) | (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f4__DOT__ram[4U] 
                                                  >> 0x1aU))));
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT____Vcellinp__ras__io_write_addr 
            = (0xffffffffffULL & ((0xfffffffff8ULL 
                                   & (((QData)((IData)(
                                                       vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f4__DOT__ram[0x1bU])) 
                                       << 0x14U) | 
                                      (0xffffffffffff8ULL 
                                       & ((QData)((IData)(
                                                          vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f4__DOT__ram[0x1aU])) 
                                          >> 0xcU)))) 
                                  + ((QData)((IData)(
                                                     (6U 
                                                      & (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f4__DOT__ram[8U] 
                                                         >> 0x1bU)))) 
                                     + (QData)((IData)(
                                                       ((0x400000U 
                                                         & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f4__DOT__ram[8U])
                                                         ? 4U
                                                         : 2U))))));
    }
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__ftq__DOT___GEN[0U] 
        = ((0xffffff00U & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__ftq__DOT___GEN[0U]) 
           | ((0x80U & (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f4__DOT__ram[5U] 
                        << 6U)) | (((IData)((3U == 
                                             (3U & 
                                              vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f4__DOT__ram[5U]))) 
                                    << 6U) | ((0x20U 
                                               & ((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f4__DOT__ram[4U] 
                                                   >> 0x1aU) 
                                                  & (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f4__DOT__ram[5U] 
                                                     << 4U))) 
                                              | (0x1fU 
                                                 & ((2U 
                                                     & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f4__DOT__ram[5U])
                                                     ? 
                                                    ((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f4__DOT__ram[4U] 
                                                      << 6U) 
                                                     | (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f4__DOT__ram[4U] 
                                                        >> 0x1aU))
                                                     : 
                                                    ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__ftq__DOT___new_ghist_new_history_ras_idx_T)
                                                      ? 
                                                     ((IData)(1U) 
                                                      + (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__ftq__DOT__prev_ghist_ras_idx))
                                                      : 
                                                     ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__ftq__DOT__prev_ghist_ras_idx) 
                                                      - (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__ftq__DOT___new_ghist_new_history_ras_idx_T_4)))))))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__ftq__DOT___GEN[0U] 
        = ((0xffU & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__ftq__DOT___GEN[0U]) 
           | ((IData)(((2U & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f4__DOT__ram[5U])
                        ? (((QData)((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f4__DOT__ram[7U])) 
                            << 0x3eU) | (((QData)((IData)(
                                                          vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f4__DOT__ram[6U])) 
                                          << 0x1eU) 
                                         | ((QData)((IData)(
                                                            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f4__DOT__ram[5U])) 
                                            >> 2U)))
                        : ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__ftq__DOT___new_ghist_new_history_old_history_T_1)
                            ? (1ULL | (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__ftq__DOT__prev_ghist_old_history 
                                       << 1U)) : ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__ftq__DOT__new_ghist_saw_not_taken_branch)
                                                   ? 
                                                  VL_SHIFTL_QQI(64,64,32, vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__ftq__DOT__prev_ghist_old_history, 1U)
                                                   : vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__ftq__DOT__prev_ghist_old_history)))) 
              << 8U));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__ftq__DOT___GEN[1U] 
        = (((IData)(((2U & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f4__DOT__ram[5U])
                      ? (((QData)((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f4__DOT__ram[7U])) 
                          << 0x3eU) | (((QData)((IData)(
                                                        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f4__DOT__ram[6U])) 
                                        << 0x1eU) | 
                                       ((QData)((IData)(
                                                        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f4__DOT__ram[5U])) 
                                        >> 2U))) : 
                     ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__ftq__DOT___new_ghist_new_history_old_history_T_1)
                       ? (1ULL | (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__ftq__DOT__prev_ghist_old_history 
                                  << 1U)) : ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__ftq__DOT__new_ghist_saw_not_taken_branch)
                                              ? VL_SHIFTL_QQI(64,64,32, vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__ftq__DOT__prev_ghist_old_history, 1U)
                                              : vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__ftq__DOT__prev_ghist_old_history)))) 
            >> 0x18U) | ((IData)((((2U & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f4__DOT__ram[5U])
                                    ? (((QData)((IData)(
                                                        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f4__DOT__ram[7U])) 
                                        << 0x3eU) | 
                                       (((QData)((IData)(
                                                         vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f4__DOT__ram[6U])) 
                                         << 0x1eU) 
                                        | ((QData)((IData)(
                                                           vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f4__DOT__ram[5U])) 
                                           >> 2U)))
                                    : ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__ftq__DOT___new_ghist_new_history_old_history_T_1)
                                        ? (1ULL | (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__ftq__DOT__prev_ghist_old_history 
                                                   << 1U))
                                        : ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__ftq__DOT__new_ghist_saw_not_taken_branch)
                                            ? VL_SHIFTL_QQI(64,64,32, vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__ftq__DOT__prev_ghist_old_history, 1U)
                                            : vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__ftq__DOT__prev_ghist_old_history))) 
                                  >> 0x20U)) << 8U));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__ftq__DOT___GEN[2U] 
        = ((IData)((((2U & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f4__DOT__ram[5U])
                      ? (((QData)((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f4__DOT__ram[7U])) 
                          << 0x3eU) | (((QData)((IData)(
                                                        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f4__DOT__ram[6U])) 
                                        << 0x1eU) | 
                                       ((QData)((IData)(
                                                        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f4__DOT__ram[5U])) 
                                        >> 2U))) : 
                     ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__ftq__DOT___new_ghist_new_history_old_history_T_1)
                       ? (1ULL | (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__ftq__DOT__prev_ghist_old_history 
                                  << 1U)) : ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__ftq__DOT__new_ghist_saw_not_taken_branch)
                                              ? VL_SHIFTL_QQI(64,64,32, vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__ftq__DOT__prev_ghist_old_history, 1U)
                                              : vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__ftq__DOT__prev_ghist_old_history))) 
                    >> 0x20U)) >> 0x18U);
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__2400(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__2400\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT____VdfgRegularize_hce62b063_0_31 
        = (IData)((0x41000000U == (0x41000000U & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f4__DOT__ram[8U])));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT____VdfgRegularize_hce62b063_0_37 
        = (1U & (~ (IData)((0U != (0x1800000U & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f4__DOT__ram[4U])))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___f4_decoded_ghist_new_history_old_history_T 
        = (1U & (((0xfU & (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f4__DOT__ram[7U] 
                           >> 2U)) >> (3U & (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f4__DOT__ram[8U] 
                                             >> 0x1cU))) 
                 & (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f4__DOT__ram[8U] 
                    >> 0x1eU)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___f4_decoded_target_T_2 
        = (IData)((0x40800000U == (0x40800000U & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f4__DOT__ram[8U])));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___GEN_32 
        = (7U & (((IData)(1U) << (3U & (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f4__DOT__ram[8U] 
                                        >> 0x1cU))) 
                 | (7U & (((IData)(1U) << (3U & (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f4__DOT__ram[8U] 
                                                 >> 0x1cU))) 
                          >> 1U))));
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3_bpd_queue__DOT__do_enq) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3_bpd_queue__DOT__ram[0U] 
            = (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___bpd_io_resp_f3_meta_0[0U] 
               << 1U);
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3_bpd_queue__DOT__ram[1U] 
            = ((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___bpd_io_resp_f3_meta_0[0U] 
                >> 0x1fU) | (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___bpd_io_resp_f3_meta_0[1U] 
                             << 1U));
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3_bpd_queue__DOT__ram[2U] 
            = ((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___bpd_io_resp_f3_meta_0[1U] 
                >> 0x1fU) | (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___bpd_io_resp_f3_meta_0[2U] 
                             << 1U));
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3_bpd_queue__DOT__ram[3U] 
            = ((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___bpd_io_resp_f3_meta_0[2U] 
                >> 0x1fU) | (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___bpd_io_resp_f3_preds_0_predicted_pc_bits) 
                              << 0x19U) | (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___bpd_io_resp_f3_meta_0[3U] 
                                           << 1U)));
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3_bpd_queue__DOT__ram[4U] 
            = (((1U & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___bpd_io_resp_f3_preds_0_predicted_pc_bits) 
                       >> 7U)) | (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___bpd_io_resp_f3_meta_0[3U] 
                                  >> 0x1fU)) | ((0x1fffffeU 
                                                 & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___bpd_io_resp_f3_preds_0_predicted_pc_bits) 
                                                    >> 7U)) 
                                                | ((IData)(
                                                           (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___bpd_io_resp_f3_preds_0_predicted_pc_bits 
                                                            >> 0x20U)) 
                                                   << 0x19U)));
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3_bpd_queue__DOT__ram[5U] 
            = ((0xfffffff8U & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3_bpd_queue__DOT__ram[5U]) 
               | ((0xfffffffeU & ((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT__REG_3)
                                     ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT__io_resp_f3_0_is_jal_REG)
                                     : (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__io_resp_f3_0_REG_is_jal)) 
                                   << 2U) | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___bpd_io_resp_f3_preds_0_predicted_pc_valid) 
                                             << 1U))) 
                  | (1U & ((IData)((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___bpd_io_resp_f3_preds_0_predicted_pc_bits 
                                    >> 0x20U)) >> 7U))));
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3_bpd_queue__DOT__ram[5U] 
            = ((7U & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3_bpd_queue__DOT__ram[5U]) 
               | ((IData)(((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___bpd_io_resp_f3_preds_1_predicted_pc_bits 
                            << 2U) | (QData)((IData)(
                                                     (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___bpd_io_resp_f3_preds_0_taken) 
                                                       << 1U) 
                                                      | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___bpd_io_resp_f3_preds_0_is_br)))))) 
                  << 3U));
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3_bpd_queue__DOT__ram[6U] 
            = ((0xffffe000U & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3_bpd_queue__DOT__ram[6U]) 
               | (((IData)(((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___bpd_io_resp_f3_preds_1_predicted_pc_bits 
                             << 2U) | (QData)((IData)(
                                                      (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___bpd_io_resp_f3_preds_0_taken) 
                                                        << 1U) 
                                                       | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___bpd_io_resp_f3_preds_0_is_br)))))) 
                   >> 0x1dU) | ((IData)((((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___bpd_io_resp_f3_preds_1_predicted_pc_bits 
                                           << 2U) | (QData)((IData)(
                                                                    (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___bpd_io_resp_f3_preds_0_taken) 
                                                                      << 1U) 
                                                                     | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___bpd_io_resp_f3_preds_0_is_br))))) 
                                         >> 0x20U)) 
                                << 3U)));
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3_bpd_queue__DOT__ram[6U] 
            = ((0xfffe1fffU & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3_bpd_queue__DOT__ram[6U]) 
               | (0xffffe000U & ((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___bpd_io_resp_f3_preds_1_taken) 
                                   << 0x10U) | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___bpd_io_resp_f3_preds_1_is_br) 
                                                << 0xfU)) 
                                 | ((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT__REG_9)
                                       ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT__io_resp_f3_1_is_jal_REG)
                                       : (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__io_resp_f3_1_REG_is_jal)) 
                                     << 0xeU) | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___bpd_io_resp_f3_preds_1_predicted_pc_valid) 
                                                 << 0xdU)))));
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3_bpd_queue__DOT__ram[6U] 
            = ((0x1ffffU & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3_bpd_queue__DOT__ram[6U]) 
               | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___bpd_io_resp_f3_preds_2_predicted_pc_bits) 
                  << 0x11U));
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3_bpd_queue__DOT__ram[7U] 
            = ((0xfe000000U & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3_bpd_queue__DOT__ram[7U]) 
               | (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___bpd_io_resp_f3_preds_2_predicted_pc_bits) 
                   >> 0xfU) | ((IData)((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___bpd_io_resp_f3_preds_2_predicted_pc_bits 
                                        >> 0x20U)) 
                               << 0x11U)));
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3_bpd_queue__DOT__ram[7U] 
            = ((0xe1ffffffU & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3_bpd_queue__DOT__ram[7U]) 
               | (0xfe000000U & ((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___bpd_io_resp_f3_preds_2_taken) 
                                   << 0x1cU) | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___bpd_io_resp_f3_preds_2_is_br) 
                                                << 0x1bU)) 
                                 | ((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT__REG_15)
                                       ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT__io_resp_f3_2_is_jal_REG)
                                       : (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__io_resp_f3_2_REG_is_jal)) 
                                     << 0x1aU) | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___bpd_io_resp_f3_preds_2_predicted_pc_valid) 
                                                  << 0x19U)))));
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3_bpd_queue__DOT__ram[7U] 
            = ((0x1fffffffU & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3_bpd_queue__DOT__ram[7U]) 
               | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___bpd_io_resp_f3_preds_3_predicted_pc_bits) 
                  << 0x1dU));
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3_bpd_queue__DOT__ram[8U] 
            = (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___bpd_io_resp_f3_preds_3_predicted_pc_bits) 
                >> 3U) | ((IData)((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___bpd_io_resp_f3_preds_3_predicted_pc_bits 
                                   >> 0x20U)) << 0x1dU));
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3_bpd_queue__DOT__ram[9U] 
            = ((0xffffffe0U & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3_bpd_queue__DOT__ram[9U]) 
               | ((IData)((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___bpd_io_resp_f3_preds_3_predicted_pc_bits 
                           >> 0x20U)) >> 3U));
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3_bpd_queue__DOT__ram[9U] 
            = ((0xfffffe1fU & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3_bpd_queue__DOT__ram[9U]) 
               | (0xffffffe0U & ((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___bpd_io_resp_f3_preds_3_taken) 
                                   << 8U) | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___bpd_io_resp_f3_preds_3_is_br) 
                                             << 7U)) 
                                 | ((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT__REG_21)
                                       ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT__io_resp_f3_3_is_jal_REG)
                                       : (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__io_resp_f3_3_REG_is_jal)) 
                                     << 6U) | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___bpd_io_resp_f3_preds_3_predicted_pc_valid) 
                                               << 5U)))));
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3_bpd_queue__DOT__ram[9U] 
            = ((0x1ffU & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3_bpd_queue__DOT__ram[9U]) 
               | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__io_resp_f3_pc_REG) 
                  << 9U));
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3_bpd_queue__DOT__ram[0xaU] 
            = (0x1ffffU & (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__io_resp_f3_pc_REG) 
                            >> 0x17U) | ((IData)((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__io_resp_f3_pc_REG 
                                                  >> 0x20U)) 
                                         << 9U)));
    }
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__2401(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__2401\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__alu__DOT__alu__DOT__rotout_r 
        = VL_SHIFTR_QQI(64,64,7, ((1U & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__exe_uop_bits_fcn_op))
                                   ? vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__alu__DOT__alu__DOT__shin_r
                                   : vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__alu__DOT__alu__DOT____VdfgRegularize_h50534096_0_6), 
                        (0x7fU & (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__alu__DOT____Vcellinp__alu__io_dw)
                                    ? 0x40U : 0x20U) 
                                  - (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__alu__DOT__alu__DOT____VdfgRegularize_h50534096_0_19))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__alu__DOT__alu__DOT__shin 
        = (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__alu__DOT__alu__DOT____VdfgRegularize_h50534096_0_5) 
            | ((0x12U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__exe_uop_bits_fcn_op)) 
               | (0x13U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__exe_uop_bits_fcn_op))))
            ? vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__alu__DOT__alu__DOT__shin_r
            : vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__alu__DOT__alu__DOT____VdfgRegularize_h50534096_0_6);
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f4_clear 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___GEN_50) 
           | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT___core_io_ifu_redirect_flush));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___GEN_49 
        = (1U & ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT___core_io_ifu_redirect_flush)) 
                 | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__s_valid_REG)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT____VdfgRegularize_h8fa566d8_0_9 
        = ((0U != (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT___lsu_io_dmem_brupdate_b1_mispredict_mask)) 
           | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__b2_mispredict) 
              | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT___core_io_ifu_redirect_flush)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___GEN_48 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT___core_io_ifu_redirect_flush) 
           | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__s_valid_REG));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fregfile__DOT__rfs_0__DOT__use_port_5 
        = ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fregfile__DOT__rfs_0__DOT___GEN_1)) 
           & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT___fp_exe_unit_0_io_arb_frf_reqs_1_valid));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fregfile__DOT__rfs_0__DOT__use_port_7 
        = ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fregfile__DOT__rfs_0__DOT__use_port_6)) 
           & ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fregfile__DOT__rfs_0__DOT__use_port_4)) 
              & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT___fp_exe_unit_0_io_arb_frf_reqs_2_valid)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_valid_dealloc_7 
        = ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT___slots_7_io_will_be_valid)) 
           & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_7__DOT__slot_valid));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_valid_alloc_7 
        = ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_7__DOT__slot_valid)) 
           & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT___slots_7_io_will_be_valid));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_valid_dealloc_6 
        = ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT___slots_6_io_will_be_valid)) 
           & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_6__DOT__slot_valid));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_valid_alloc_6 
        = ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_6__DOT__slot_valid)) 
           & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT___slots_6_io_will_be_valid));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_valid_dealloc_5 
        = ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT___slots_5_io_will_be_valid)) 
           & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_5__DOT__slot_valid));
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__2402(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__2402\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_valid_alloc_5 
        = ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_5__DOT__slot_valid)) 
           & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT___slots_5_io_will_be_valid));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_valid_dealloc_4 
        = ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT___slots_4_io_will_be_valid)) 
           & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_4__DOT__slot_valid));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_valid_alloc_4 
        = ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_4__DOT__slot_valid)) 
           & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT___slots_4_io_will_be_valid));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_valid_dealloc_3 
        = ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT___slots_3_io_will_be_valid)) 
           & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_3__DOT__slot_valid));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_valid_alloc_3 
        = ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_3__DOT__slot_valid)) 
           & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT___slots_3_io_will_be_valid));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_valid_dealloc_2 
        = ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT___slots_2_io_will_be_valid)) 
           & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_2__DOT__slot_valid));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_valid_alloc_2 
        = ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_2__DOT__slot_valid)) 
           & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT___slots_2_io_will_be_valid));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_valid_dealloc_1 
        = ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT___slots_1_io_will_be_valid)) 
           & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_1__DOT__slot_valid));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_valid_alloc_1 
        = ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_1__DOT__slot_valid)) 
           & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT___slots_1_io_will_be_valid));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_valid_alloc_0 
        = ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_0__DOT__slot_valid)) 
           & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT___slots_0_io_will_be_valid));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_valid_dealloc_0 
        = ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT___slots_0_io_will_be_valid)) 
           & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_0__DOT__slot_valid));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_empty_0 
        = (1U & ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT___slots_0_io_will_be_valid)) 
                 & (~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_0__DOT__slot_valid))));
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__2403(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__2403\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_ftq_idx 
        = (((1U & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__fb__DOT__head))
             ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__fb__DOT__fb_uop_ram_0_ftq_idx)
             : 0U) | (((2U & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__fb__DOT__head))
                        ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__fb__DOT__fb_uop_ram_1_ftq_idx)
                        : 0U) | (((4U & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__fb__DOT__head))
                                   ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__fb__DOT__fb_uop_ram_2_ftq_idx)
                                   : 0U) | (((8U & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__fb__DOT__head))
                                              ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__fb__DOT__fb_uop_ram_3_ftq_idx)
                                              : 0U) 
                                            | (((0x10U 
                                                 & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__fb__DOT__head))
                                                 ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__fb__DOT__fb_uop_ram_4_ftq_idx)
                                                 : 0U) 
                                               | (((0x20U 
                                                    & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__fb__DOT__head))
                                                    ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__fb__DOT__fb_uop_ram_5_ftq_idx)
                                                    : 0U) 
                                                  | (((0x40U 
                                                       & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__fb__DOT__head))
                                                       ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__fb__DOT__fb_uop_ram_6_ftq_idx)
                                                       : 0U) 
                                                     | ((0x80U 
                                                         & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__fb__DOT__head))
                                                         ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__fb__DOT__fb_uop_ram_7_ftq_idx)
                                                         : 0U))))))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__cbus__DOT___GEN_2 
        = (((0xff8000U & (((((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__plusarg_reader__DOT__myplus)) 
                             & (5U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__cbus__DOT__state)))
                             ? 0U : (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__cbus__DOT__state)) 
                           << 0x15U) | (((((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__plusarg_reader__DOT__myplus)) 
                                           & (5U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__cbus__DOT__state)))
                                           ? 0U : (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__cbus__DOT__state)) 
                                         << 0x12U) 
                                        | ((((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__plusarg_reader__DOT__myplus)) 
                                             & (5U 
                                                == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__cbus__DOT__state)))
                                             ? 0U : (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__cbus__DOT__state)) 
                                           << 0xfU)))) 
            | (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__cbus__DOT___in_xbar_auto_anon_in_1_d_valid)
                 ? 5U : (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__cbus__DOT__state)) 
               << 0xcU)) | (((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__cbus__DOT___GEN_0)
                                ? 4U : (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__cbus__DOT__state)) 
                              << 9U) | (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__cbus__DOT___in_xbar_auto_anon_in_1_d_valid)
                                          ? 3U : (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__cbus__DOT__state)) 
                                        << 6U)) | (
                                                   (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__cbus__DOT___GEN_0)
                                                      ? 2U
                                                      : (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__cbus__DOT__state)) 
                                                    << 3U) 
                                                   | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__plusarg_reader__DOT__myplus)
                                                       ? 1U
                                                       : (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__cbus__DOT__state)))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__sbus__DOT__system_bus_xbar__DOT__latch 
        = ((0U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__sbus__DOT__system_bus_xbar__DOT__beatsLeft)) 
           & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT___cbus_auto_bus_xing_in_a_ready));
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__2404(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__2404\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__fbus__DOT__buffer__DOT__nodeOut_a_q__DOT__do_deq 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT___fbus_auto_bus_xing_out_a_valid) 
           & (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__sbus__DOT__system_bus_xbar__DOT__requestAIO_0_0) 
               & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT___cbus_auto_bus_xing_in_a_ready) 
                  & ((0U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__sbus__DOT__system_bus_xbar__DOT__beatsLeft))
                      ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__sbus__DOT__system_bus_xbar__DOT__readys_readys)
                      : (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__sbus__DOT__system_bus_xbar__DOT__state_0)))) 
              | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__sbus__DOT__system_bus_xbar__DOT__requestAIO_0_1) 
                 & ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__InclusiveCache_inner_TLBuffer__DOT__nodeOut_a_q__DOT__maybe_full)) 
                    & ((0U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__sbus__DOT__system_bus_xbar__DOT__beatsLeft_1))
                        ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__sbus__DOT__system_bus_xbar__DOT__readys_readys_1)
                        : (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__sbus__DOT__system_bus_xbar__DOT__state_1_0))))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__buffer__DOT__nodeOut_a_q__DOT__do_deq 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT___tile_prci_domain_auto_tl_master_clock_xing_out_a_valid) 
           & (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__sbus__DOT__system_bus_xbar__DOT__requestAIO_1_0) 
               & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT___cbus_auto_bus_xing_in_a_ready) 
                  & ((0U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__sbus__DOT__system_bus_xbar__DOT__beatsLeft))
                      ? ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__sbus__DOT__system_bus_xbar__DOT__readys_readys) 
                         >> 1U) : (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__sbus__DOT__system_bus_xbar__DOT__state_1)))) 
              | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__sbus__DOT__system_bus_xbar__DOT__requestAIO_1_1) 
                 & ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__InclusiveCache_inner_TLBuffer__DOT__nodeOut_a_q__DOT__maybe_full)) 
                    & ((0U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__sbus__DOT__system_bus_xbar__DOT__beatsLeft_1))
                        ? ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__sbus__DOT__system_bus_xbar__DOT__readys_readys_1) 
                           >> 1U) : (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__sbus__DOT__system_bus_xbar__DOT__state_1_1))))));
    if ((0U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__cbus__DOT__atomics__DOT__beatsLeft))) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__cbus__DOT___atomics_auto_out_a_valid 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__cbus__DOT__atomics__DOT___nodeOut_a_valid_T;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__cbus__DOT__atomics__DOT__muxState_1 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__cbus__DOT__atomics__DOT__winner_1;
    } else {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__cbus__DOT___atomics_auto_out_a_valid 
            = (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__cbus__DOT__atomics__DOT__state_0) 
                & (2U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__cbus__DOT__atomics__DOT__cam_s_0_state))) 
               | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__cbus__DOT__atomics__DOT__state_1) 
                  & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__cbus__DOT__atomics__DOT__source_i_valid)));
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__cbus__DOT__atomics__DOT__muxState_1 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__cbus__DOT__atomics__DOT__state_1;
    }
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__bypass_1 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT___requests_io_push_valid_T) 
           & ((~ ((1U & ((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__requests__DOT__valid 
                          >> 0xeU) | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT___sinkC_io_req_valid)))
                   ? (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__requests__DOT__valid 
                      >> 0xeU) : ((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__requests__DOT__valid 
                                   >> 7U) | vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__requests__DOT__valid))) 
              & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__lowerMatches1)));
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__2405(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__2405\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__bypass_2 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT___requests_io_push_valid_T) 
           & ((~ ((1U & ((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__requests__DOT__valid 
                          >> 0xfU) | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT___sinkC_io_req_valid)))
                   ? (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__requests__DOT__valid 
                      >> 0xfU) : (IData)((0U != (0x102U 
                                                 & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__requests__DOT__valid))))) 
              & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__lowerMatches1) 
                 >> 1U)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__bypass_3 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT___requests_io_push_valid_T) 
           & ((~ ((1U & ((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__requests__DOT__valid 
                          >> 0x10U) | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT___sinkC_io_req_valid)))
                   ? (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__requests__DOT__valid 
                      >> 0x10U) : (IData)((0U != (0x204U 
                                                  & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__requests__DOT__valid))))) 
              & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__lowerMatches1) 
                 >> 2U)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__bypass_4 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT___requests_io_push_valid_T) 
           & ((~ ((1U & ((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__requests__DOT__valid 
                          >> 0x11U) | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT___sinkC_io_req_valid)))
                   ? (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__requests__DOT__valid 
                      >> 0x11U) : (IData)((0U != (0x408U 
                                                  & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__requests__DOT__valid))))) 
              & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__lowerMatches1) 
                 >> 3U)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__bypass_5 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT___requests_io_push_valid_T) 
           & ((~ ((1U & ((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__requests__DOT__valid 
                          >> 0x12U) | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT___sinkC_io_req_valid)))
                   ? (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__requests__DOT__valid 
                      >> 0x12U) : (IData)((0U != (0x810U 
                                                  & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__requests__DOT__valid))))) 
              & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__lowerMatches1) 
                 >> 4U)));
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__2406(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__2406\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__bypass_6 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT___requests_io_push_valid_T) 
           & ((~ ((1U & ((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__requests__DOT__valid 
                          >> 0x13U) | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT___sinkC_io_req_valid)))
                   ? (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__requests__DOT__valid 
                      >> 0x13U) : (IData)((0U != (0x1020U 
                                                  & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__requests__DOT__valid))))) 
              & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__lowerMatches1) 
                 >> 5U)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__bypass_7 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT___requests_io_push_valid_T) 
           & ((~ ((IData)(((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__requests__DOT__valid 
                            >> 0x14U) | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT___sinkC_io_req_valid)))
                   ? (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__requests__DOT__valid 
                      >> 0x14U) : (IData)((0U != (0x2040U 
                                                  & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__requests__DOT__valid))))) 
              & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__lowerMatches1) 
                 >> 6U)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT___requests_io_push_bits_index_T_23 
        = (0x7fU & (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT___requests_io_push_bits_index_T_21) 
                     >> 8U) | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT___requests_io_push_bits_index_T_21)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__bypass 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT___requests_io_push_valid_T) 
           & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__bypassMatches));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__bypassQueue 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__schedule_reload) 
           & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__bypassMatches));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_is_sfence 
        = (0x48073U == ((0x3f8000U & (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst 
                                      >> 0xaU)) | (0x7fffU 
                                                   & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sourceD__DOT__s1_single 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sourceD__DOT__s1_req_prio_0)
            ? ((5U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sourceD__DOT__s1_req_opcode)) 
               | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sourceD__DOT__s1_grant))
            : (6U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sourceD__DOT__s1_req_opcode)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT___sourceC_io_bs_adr_valid 
        = (((0U != (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sourceC__DOT__beat)) 
            | (((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sourceD__DOT__busy)) 
                | (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT___sourceC_io_bs_adr_bits_way) 
                    != (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sourceD__DOT__s1_req_reg_way)) 
                   | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT___sourceC_io_bs_adr_bits_set) 
                      != (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sourceD__DOT__s1_req_reg_set)))) 
               & (((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sourceD__DOT__s2_full)) 
                   | (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT___sourceC_io_bs_adr_bits_way) 
                       != (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sourceD__DOT__s2_req_way)) 
                      | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT___sourceC_io_bs_adr_bits_set) 
                         != (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sourceD__DOT__s2_req_set)))) 
                  & (((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sourceD__DOT__s3_full)) 
                      | (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT___sourceC_io_bs_adr_bits_way) 
                          != (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sourceD__DOT__s3_req_way)) 
                         | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT___sourceC_io_bs_adr_bits_set) 
                            != (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sourceD__DOT__s3_req_set)))) 
                     & ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sourceD__DOT__s4_full)) 
                        | (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT___sourceC_io_bs_adr_bits_way) 
                            != (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sourceD__DOT__s4_req_way)) 
                           | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT___sourceC_io_bs_adr_bits_set) 
                              != (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sourceD__DOT__s4_req_set)))))))) 
           & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sourceC__DOT__want_data));
}
