// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See VTestDriver.h for the primary calling header

#include "VTestDriver__pch.h"
#include "VTestDriver___024root.h"

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__555(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__555\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__queue__DOT__uops_0_br_mask 
        = (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__queue__DOT__do_enq) 
            & (0U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__queue__DOT__enq_ptr_value)))
            ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__queue__DOT___uops_br_mask_T_1)
            : (((- (IData)((1U & (~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__queue__DOT__valids_0))))) 
                | (~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT___lsu_io_dmem_brupdate_b1_resolve_mask))) 
               & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__queue__DOT__uops_0_br_mask)));
    vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__queue__DOT__uops_1_br_mask 
        = (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__queue__DOT__do_enq) 
            & (1U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__queue__DOT__enq_ptr_value)))
            ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__queue__DOT___uops_br_mask_T_1)
            : (((- (IData)((1U & (~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__queue__DOT__valids_1))))) 
                | (~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT___lsu_io_dmem_brupdate_b1_resolve_mask))) 
               & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__queue__DOT__uops_1_br_mask)));
    vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__queue__DOT__uops_2_br_mask 
        = (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__queue__DOT__do_enq) 
            & (2U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__queue__DOT__enq_ptr_value)))
            ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__queue__DOT___uops_br_mask_T_1)
            : (((- (IData)((1U & (~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__queue__DOT__valids_2))))) 
                | (~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT___lsu_io_dmem_brupdate_b1_resolve_mask))) 
               & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__queue__DOT__uops_2_br_mask)));
    vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__queue__DOT__uops_3_br_mask 
        = (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__queue__DOT__do_enq) 
            & (3U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__queue__DOT__enq_ptr_value)))
            ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__queue__DOT___uops_br_mask_T_1)
            : (((- (IData)((1U & (~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__queue__DOT__valids_3))))) 
                | (~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT___lsu_io_dmem_brupdate_b1_resolve_mask))) 
               & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__queue__DOT__uops_3_br_mask)));
    vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__queue__DOT__uops_4_br_mask 
        = (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__queue__DOT__do_enq) 
            & (4U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__queue__DOT__enq_ptr_value)))
            ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__queue__DOT___uops_br_mask_T_1)
            : (((- (IData)((1U & (~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__queue__DOT__valids_4))))) 
                | (~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT___lsu_io_dmem_brupdate_b1_resolve_mask))) 
               & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__queue__DOT__uops_4_br_mask)));
    vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__queue__DOT__uops_5_br_mask 
        = (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__queue__DOT__do_enq) 
            & (5U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__queue__DOT__enq_ptr_value)))
            ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__queue__DOT___uops_br_mask_T_1)
            : (((- (IData)((1U & (~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__queue__DOT__valids_5))))) 
                | (~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT___lsu_io_dmem_brupdate_b1_resolve_mask))) 
               & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__queue__DOT__uops_5_br_mask)));
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__556(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__556\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__queue__DOT__uops_6_br_mask 
        = (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__queue__DOT__do_enq) 
            & (6U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__queue__DOT__enq_ptr_value)))
            ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__queue__DOT___uops_br_mask_T_1)
            : (((- (IData)((1U & (~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__queue__DOT__valids_6))))) 
                | (~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT___lsu_io_dmem_brupdate_b1_resolve_mask))) 
               & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__queue__DOT__uops_6_br_mask)));
    vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__queue__DOT__uops_7_br_mask 
        = (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__queue__DOT__do_enq) 
            & (7U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__queue__DOT__enq_ptr_value)))
            ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__queue__DOT___uops_br_mask_T_1)
            : (((- (IData)((1U & (~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__queue__DOT__valids_7))))) 
                | (~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT___lsu_io_dmem_brupdate_b1_resolve_mask))) 
               & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__queue__DOT__uops_7_br_mask)));
    vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__queue__DOT__uops_8_br_mask 
        = (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__queue__DOT__do_enq) 
            & (8U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__queue__DOT__enq_ptr_value)))
            ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__queue__DOT___uops_br_mask_T_1)
            : (((- (IData)((1U & (~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__queue__DOT__valids_8))))) 
                | (~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT___lsu_io_dmem_brupdate_b1_resolve_mask))) 
               & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__queue__DOT__uops_8_br_mask)));
    vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__queue__DOT__uops_9_br_mask 
        = (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__queue__DOT__do_enq) 
            & (9U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__queue__DOT__enq_ptr_value)))
            ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__queue__DOT___uops_br_mask_T_1)
            : (((- (IData)((1U & (~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__queue__DOT__valids_9))))) 
                | (~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT___lsu_io_dmem_brupdate_b1_resolve_mask))) 
               & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__queue__DOT__uops_9_br_mask)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__alu_iss_unit__DOT__slots_age_matrix_0_0 
        = ((1U & (~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT___system_auto_cbus_fixedClockNode_anon_out_reset))) 
           && ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__alu_iss_unit__DOT__slots_valid_alloc_0)
                ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__alu_iss_unit__DOT__slots_0__DOT__slot_valid)
                : ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__alu_iss_unit__DOT__slots_valid_dealloc_0)) 
                   & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__alu_iss_unit__DOT__slots_age_matrix_0_0))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__alu_iss_unit__DOT__slots_age_matrix_6_0 
        = ((1U & (~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT___system_auto_cbus_fixedClockNode_anon_out_reset))) 
           && ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__alu_iss_unit__DOT__slots_valid_alloc_6)
                ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__alu_iss_unit__DOT__slots_0__DOT__slot_valid)
                : ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__alu_iss_unit__DOT__slots_valid_dealloc_6) 
                   | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__alu_iss_unit__DOT___GEN_59) 
                      & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__alu_iss_unit__DOT__slots_age_matrix_6_0)))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__alu_iss_unit__DOT__slots_age_matrix_5_0 
        = ((1U & (~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT___system_auto_cbus_fixedClockNode_anon_out_reset))) 
           && ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__alu_iss_unit__DOT__slots_valid_alloc_5)
                ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__alu_iss_unit__DOT__slots_0__DOT__slot_valid)
                : ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__alu_iss_unit__DOT__slots_valid_dealloc_5) 
                   | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__alu_iss_unit__DOT___GEN_59) 
                      & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__alu_iss_unit__DOT__slots_age_matrix_5_0)))));
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__557(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__557\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__alu_iss_unit__DOT__slots_age_matrix_4_0 
        = ((1U & (~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT___system_auto_cbus_fixedClockNode_anon_out_reset))) 
           && ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__alu_iss_unit__DOT__slots_valid_alloc_4)
                ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__alu_iss_unit__DOT__slots_0__DOT__slot_valid)
                : ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__alu_iss_unit__DOT__slots_valid_dealloc_4) 
                   | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__alu_iss_unit__DOT___GEN_59) 
                      & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__alu_iss_unit__DOT__slots_age_matrix_4_0)))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__alu_iss_unit__DOT__slots_age_matrix_1_0 
        = ((1U & (~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT___system_auto_cbus_fixedClockNode_anon_out_reset))) 
           && ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__alu_iss_unit__DOT__slots_valid_alloc_1)
                ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__alu_iss_unit__DOT__slots_0__DOT__slot_valid)
                : ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__alu_iss_unit__DOT__slots_valid_dealloc_1) 
                   | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__alu_iss_unit__DOT___GEN_59) 
                      & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__alu_iss_unit__DOT__slots_age_matrix_1_0)))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__alu_iss_unit__DOT__slots_age_matrix_2_0 
        = ((1U & (~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT___system_auto_cbus_fixedClockNode_anon_out_reset))) 
           && ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__alu_iss_unit__DOT__slots_valid_alloc_2)
                ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__alu_iss_unit__DOT__slots_0__DOT__slot_valid)
                : ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__alu_iss_unit__DOT__slots_valid_dealloc_2) 
                   | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__alu_iss_unit__DOT___GEN_59) 
                      & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__alu_iss_unit__DOT__slots_age_matrix_2_0)))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__alu_iss_unit__DOT__slots_age_matrix_3_0 
        = ((1U & (~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT___system_auto_cbus_fixedClockNode_anon_out_reset))) 
           && ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__alu_iss_unit__DOT__slots_valid_alloc_3)
                ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__alu_iss_unit__DOT__slots_0__DOT__slot_valid)
                : ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__alu_iss_unit__DOT__slots_valid_dealloc_3) 
                   | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__alu_iss_unit__DOT___GEN_59) 
                      & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__alu_iss_unit__DOT__slots_age_matrix_3_0)))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__alu_iss_unit__DOT__slots_age_matrix_7_0 
        = ((1U & (~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT___system_auto_cbus_fixedClockNode_anon_out_reset))) 
           && ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__alu_iss_unit__DOT__slots_valid_alloc_7)
                ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__alu_iss_unit__DOT__slots_0__DOT__slot_valid)
                : ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__alu_iss_unit__DOT__slots_valid_dealloc_7) 
                   | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__alu_iss_unit__DOT___GEN_59) 
                      & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__alu_iss_unit__DOT__slots_age_matrix_7_0)))));
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sinkC__DOT__c_q__DOT__do_enq) {
        vlSelfRef.__VdlyVal__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sinkC__DOT__c_q__DOT__ram_ext__DOT__Memory__v0[0U] 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__buffer__DOT__nodeOut_c_q__DOT__ram_ext__DOT__Memory
            [vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__buffer__DOT__nodeOut_c_q__DOT__deq_ptr_value][0U];
        vlSelfRef.__VdlyVal__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sinkC__DOT__c_q__DOT__ram_ext__DOT__Memory__v0[1U] 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__buffer__DOT__nodeOut_c_q__DOT__ram_ext__DOT__Memory
            [vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__buffer__DOT__nodeOut_c_q__DOT__deq_ptr_value][1U];
        vlSelfRef.__VdlyVal__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sinkC__DOT__c_q__DOT__ram_ext__DOT__Memory__v0[2U] 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__buffer__DOT__nodeOut_c_q__DOT__ram_ext__DOT__Memory
            [vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__buffer__DOT__nodeOut_c_q__DOT__deq_ptr_value][2U];
        vlSelfRef.__VdlyVal__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sinkC__DOT__c_q__DOT__ram_ext__DOT__Memory__v0[3U] 
            = ((0xfff0U & vlSelfRef.__VdlyVal__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sinkC__DOT__c_q__DOT__ram_ext__DOT__Memory__v0[3U]) 
               | (0xfU & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__buffer__DOT__nodeOut_c_q__DOT__ram_ext__DOT__Memory
                  [vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__buffer__DOT__nodeOut_c_q__DOT__deq_ptr_value][3U]));
        vlSelfRef.__VdlyVal__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sinkC__DOT__c_q__DOT__ram_ext__DOT__Memory__v0[3U] 
            = ((0xfU & vlSelfRef.__VdlyVal__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sinkC__DOT__c_q__DOT__ram_ext__DOT__Memory__v0[3U]) 
               | (0xfff0U & (0x40U | ((0xfc00U & (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__buffer__DOT__nodeOut_c_q__DOT__ram_ext__DOT__Memory
                                                  [vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__buffer__DOT__nodeOut_c_q__DOT__deq_ptr_value][3U] 
                                                  << 2U)) 
                                      | (0x380U & (
                                                   vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__buffer__DOT__nodeOut_c_q__DOT__ram_ext__DOT__Memory
                                                   [vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__buffer__DOT__nodeOut_c_q__DOT__deq_ptr_value][3U] 
                                                   << 3U))))));
        vlSelfRef.__VdlyDim0__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sinkC__DOT__c_q__DOT__ram_ext__DOT__Memory__v0 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sinkC__DOT__c_q__DOT__enq_ptr_value;
        vlSelfRef.__VdlySet__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sinkC__DOT__c_q__DOT__ram_ext__DOT__Memory__v0 = 1U;
    }
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__558(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__558\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Init
    CData/*31:0*/ __Vtemp_1;
    // Body
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT___system_auto_cbus_fixedClockNode_anon_out_reset) {
        vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sinkC__DOT__c_q__DOT__deq_ptr_value = 0U;
    } else if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sinkC__DOT__c_q__DOT__do_deq) {
        vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sinkC__DOT__c_q__DOT__deq_ptr_value 
            = (1U & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sinkC__DOT__c_q__DOT__deq_ptr_value) 
                     - (IData)(1U)));
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT____Vcellinp__slots_0__io_in_uop_valid) {
        vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__slots_0__DOT__slot_uop_fu_code_1 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rename_stage__DOT__r_uop_fu_code_1;
        vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__slots_0__DOT__slot_uop_fu_code_2 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rename_stage__DOT__r_uop_fu_code_2;
    } else if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__slots_0__DOT___GEN_4) {
        if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__slots_0__DOT__slot_uop_iw_issued_partial_agen) {
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__slots_0__DOT__slot_uop_fu_code_1 
                = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__slots_0__DOT__rebusied_prs1) 
                   & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__slots_0__DOT__slot_uop_fu_code_1));
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__slots_0__DOT__slot_uop_fu_code_2 
                = (1U & ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__slots_0__DOT__rebusied_prs1)) 
                         | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__slots_0__DOT__slot_uop_fu_code_2)));
        } else {
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__slots_0__DOT__slot_uop_fu_code_1 
                = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__slots_0__DOT___GEN_5) 
                   | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__slots_0__DOT__slot_uop_fu_code_1));
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__slots_0__DOT__slot_uop_fu_code_2 
                = (1U & ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__slots_0__DOT___GEN_5)) 
                         & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__slots_0__DOT__slot_uop_fu_code_2)));
        }
    }
    __Vtemp_1 = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT___system_auto_cbus_fixedClockNode_anon_out_reset) 
                 || (1U & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_5__DOT___GEN_96)
                            ? ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_5__DOT__new_request_prio_2)
                                ? ((~ ((((((1U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_5__DOT__new_request_param)) 
                                           | (2U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_5__DOT__new_request_param))) 
                                          | (5U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_5__DOT__new_request_param))) 
                                         & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_5__DOT__new_meta_clients)) 
                                        & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_5__DOT__new_clientBit)) 
                                       | (((0U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_5__DOT__new_request_param)) 
                                           | (4U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_5__DOT__new_request_param))) 
                                          & (2U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_5__DOT__new_meta_state))))) 
                                   & (~ ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_5__DOT__new_request_opcode) 
                                         & (~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_5__DOT__new_meta_dirty)))))
                                : ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_5__DOT__new_request_control) 
                                   | ((~ (((((~ ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_5__DOT__new_request_opcode) 
                                                 >> 2U)) 
                                             & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_5__DOT__new_meta_hit)) 
                                            & (~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_5__DOT__new_meta_dirty))) 
                                           | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_5__DOT___GEN_105)) 
                                          | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_5__DOT___GEN_112))) 
                                      & (~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_5__DOT___GEN_102)))))
                            : ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_5__DOT___GEN_98) 
                               | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_5__DOT__s_writeback)))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_5__DOT__s_writeback 
        = __Vtemp_1;
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__559(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__559\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_5__DOT__w_pprobeacklast 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT___system_auto_cbus_fixedClockNode_anon_out_reset) 
           || ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_5__DOT___GEN_96)
                ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_5__DOT___GEN_113)
                : ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_5__DOT___GEN_110) 
                   | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_5__DOT__w_pprobeacklast))));
    vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_5__DOT__w_rprobeacklast 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT___system_auto_cbus_fixedClockNode_anon_out_reset) 
           || ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_5__DOT___GEN_96)
                ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_5__DOT___GEN_111)
                : ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_5__DOT___GEN_110) 
                   | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_5__DOT__w_rprobeacklast))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_5__DOT__w_grantack 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT___system_auto_cbus_fixedClockNode_anon_out_reset) 
           || (1U & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_5__DOT___GEN_96)
                      ? ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_5__DOT___GEN_103) 
                         | (~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_5__DOT___GEN_105)))
                      : (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT___InclusiveCache_inner_TLBuffer_auto_out_e_valid) 
                          & (5U == vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__buffer__DOT__nodeOut_e_q__DOT__ram_ext__DOT__Memory
                             [vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__buffer__DOT__nodeOut_e_q__DOT__deq_ptr_value])) 
                         | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_5__DOT__w_grantack)))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_5__DOT__s_rprobe 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT___system_auto_cbus_fixedClockNode_anon_out_reset) 
           || (1U & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_5__DOT___GEN_96)
                      ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_5__DOT___GEN_111)
                      : (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshr_selectOH) 
                          >> 5U) | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_5__DOT__s_rprobe)))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__slots_age_matrix_0_0 
        = ((1U & (~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT___system_auto_cbus_fixedClockNode_anon_out_reset))) 
           && ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__slots_valid_alloc_0)
                ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__slots_0__DOT__slot_valid)
                : ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__slots_valid_dealloc_0)) 
                   & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__slots_age_matrix_0_0))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__slots_age_matrix_6_0 
        = ((1U & (~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT___system_auto_cbus_fixedClockNode_anon_out_reset))) 
           && ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__slots_valid_alloc_6)
                ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__slots_0__DOT__slot_valid)
                : ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__slots_valid_dealloc_6) 
                   | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT___GEN_61) 
                      & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__slots_age_matrix_6_0)))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__slots_age_matrix_5_0 
        = ((1U & (~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT___system_auto_cbus_fixedClockNode_anon_out_reset))) 
           && ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__slots_valid_alloc_5)
                ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__slots_0__DOT__slot_valid)
                : ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__slots_valid_dealloc_5) 
                   | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT___GEN_61) 
                      & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__slots_age_matrix_5_0)))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__slots_age_matrix_4_0 
        = ((1U & (~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT___system_auto_cbus_fixedClockNode_anon_out_reset))) 
           && ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__slots_valid_alloc_4)
                ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__slots_0__DOT__slot_valid)
                : ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__slots_valid_dealloc_4) 
                   | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT___GEN_61) 
                      & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__slots_age_matrix_4_0)))));
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__560(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__560\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Init
    CData/*31:0*/ __Vtemp_5;
    // Body
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__slots_age_matrix_1_0 
        = ((1U & (~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT___system_auto_cbus_fixedClockNode_anon_out_reset))) 
           && ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__slots_valid_alloc_1)
                ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__slots_0__DOT__slot_valid)
                : ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__slots_valid_dealloc_1) 
                   | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT___GEN_61) 
                      & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__slots_age_matrix_1_0)))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__slots_age_matrix_2_0 
        = ((1U & (~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT___system_auto_cbus_fixedClockNode_anon_out_reset))) 
           && ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__slots_valid_alloc_2)
                ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__slots_0__DOT__slot_valid)
                : ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__slots_valid_dealloc_2) 
                   | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT___GEN_61) 
                      & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__slots_age_matrix_2_0)))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__slots_age_matrix_3_0 
        = ((1U & (~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT___system_auto_cbus_fixedClockNode_anon_out_reset))) 
           && ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__slots_valid_alloc_3)
                ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__slots_0__DOT__slot_valid)
                : ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__slots_valid_dealloc_3) 
                   | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT___GEN_61) 
                      & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__slots_age_matrix_3_0)))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__slots_age_matrix_7_0 
        = ((1U & (~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT___system_auto_cbus_fixedClockNode_anon_out_reset))) 
           && ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__slots_valid_alloc_7)
                ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__slots_0__DOT__slot_valid)
                : ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__slots_valid_dealloc_7) 
                   | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT___GEN_61) 
                      & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__slots_age_matrix_7_0)))));
    __Vtemp_5 = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT___system_auto_cbus_fixedClockNode_anon_out_reset) 
                 || (1U & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_0__DOT___GEN_96)
                            ? ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_0__DOT__new_request_prio_2)
                                ? ((~ ((((((1U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_0__DOT__new_request_param)) 
                                           | (2U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_0__DOT__new_request_param))) 
                                          | (5U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_0__DOT__new_request_param))) 
                                         & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_0__DOT__new_meta_clients)) 
                                        & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_0__DOT__new_clientBit)) 
                                       | (((0U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_0__DOT__new_request_param)) 
                                           | (4U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_0__DOT__new_request_param))) 
                                          & (2U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_0__DOT__new_meta_state))))) 
                                   & (~ ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_0__DOT__new_request_opcode) 
                                         & (~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_0__DOT__new_meta_dirty)))))
                                : ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_0__DOT__new_request_control) 
                                   | ((~ (((((~ ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_0__DOT__new_request_opcode) 
                                                 >> 2U)) 
                                             & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_0__DOT__new_meta_hit)) 
                                            & (~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_0__DOT__new_meta_dirty))) 
                                           | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_0__DOT___GEN_105)) 
                                          | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_0__DOT___GEN_112))) 
                                      & (~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_0__DOT___GEN_102)))))
                            : ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_0__DOT___GEN_98) 
                               | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_0__DOT__s_writeback)))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_0__DOT__s_writeback 
        = __Vtemp_5;
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__561(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__561\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Init
    CData/*31:0*/ __Vtemp_1;
    CData/*31:0*/ __Vtemp_2;
    // Body
    __Vtemp_1 = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT___system_auto_cbus_fixedClockNode_anon_out_reset) 
                 || (1U & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_1__DOT___GEN_96)
                            ? ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_1__DOT__new_request_prio_2)
                                ? ((~ ((((((1U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_1__DOT__new_request_param)) 
                                           | (2U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_1__DOT__new_request_param))) 
                                          | (5U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_1__DOT__new_request_param))) 
                                         & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_1__DOT__new_meta_clients)) 
                                        & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_1__DOT__new_clientBit)) 
                                       | (((0U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_1__DOT__new_request_param)) 
                                           | (4U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_1__DOT__new_request_param))) 
                                          & (2U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_1__DOT__new_meta_state))))) 
                                   & (~ ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_1__DOT__new_request_opcode) 
                                         & (~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_1__DOT__new_meta_dirty)))))
                                : ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_1__DOT__new_request_control) 
                                   | ((~ (((((~ ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_1__DOT__new_request_opcode) 
                                                 >> 2U)) 
                                             & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_1__DOT__new_meta_hit)) 
                                            & (~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_1__DOT__new_meta_dirty))) 
                                           | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_1__DOT___GEN_105)) 
                                          | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_1__DOT___GEN_112))) 
                                      & (~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_1__DOT___GEN_102)))))
                            : ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_1__DOT___GEN_98) 
                               | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_1__DOT__s_writeback)))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_1__DOT__s_writeback 
        = __Vtemp_1;
    __Vtemp_2 = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT___system_auto_cbus_fixedClockNode_anon_out_reset) 
                 || (1U & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_2__DOT___GEN_96)
                            ? ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_2__DOT__new_request_prio_2)
                                ? ((~ ((((((1U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_2__DOT__new_request_param)) 
                                           | (2U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_2__DOT__new_request_param))) 
                                          | (5U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_2__DOT__new_request_param))) 
                                         & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_2__DOT__new_meta_clients)) 
                                        & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_2__DOT__new_clientBit)) 
                                       | (((0U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_2__DOT__new_request_param)) 
                                           | (4U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_2__DOT__new_request_param))) 
                                          & (2U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_2__DOT__new_meta_state))))) 
                                   & (~ ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_2__DOT__new_request_opcode) 
                                         & (~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_2__DOT__new_meta_dirty)))))
                                : ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_2__DOT__new_request_control) 
                                   | ((~ (((((~ ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_2__DOT__new_request_opcode) 
                                                 >> 2U)) 
                                             & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_2__DOT__new_meta_hit)) 
                                            & (~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_2__DOT__new_meta_dirty))) 
                                           | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_2__DOT___GEN_105)) 
                                          | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_2__DOT___GEN_112))) 
                                      & (~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_2__DOT___GEN_102)))))
                            : ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_2__DOT___GEN_98) 
                               | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_2__DOT__s_writeback)))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_2__DOT__s_writeback 
        = __Vtemp_2;
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__562(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__562\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Init
    CData/*31:0*/ __Vtemp_1;
    CData/*31:0*/ __Vtemp_2;
    // Body
    __Vtemp_1 = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT___system_auto_cbus_fixedClockNode_anon_out_reset) 
                 || (1U & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_3__DOT___GEN_96)
                            ? ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_3__DOT__new_request_prio_2)
                                ? ((~ ((((((1U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_3__DOT__new_request_param)) 
                                           | (2U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_3__DOT__new_request_param))) 
                                          | (5U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_3__DOT__new_request_param))) 
                                         & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_3__DOT__new_meta_clients)) 
                                        & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_3__DOT__new_clientBit)) 
                                       | (((0U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_3__DOT__new_request_param)) 
                                           | (4U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_3__DOT__new_request_param))) 
                                          & (2U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_3__DOT__new_meta_state))))) 
                                   & (~ ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_3__DOT__new_request_opcode) 
                                         & (~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_3__DOT__new_meta_dirty)))))
                                : ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_3__DOT__new_request_control) 
                                   | ((~ (((((~ ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_3__DOT__new_request_opcode) 
                                                 >> 2U)) 
                                             & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_3__DOT__new_meta_hit)) 
                                            & (~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_3__DOT__new_meta_dirty))) 
                                           | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_3__DOT___GEN_105)) 
                                          | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_3__DOT___GEN_112))) 
                                      & (~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_3__DOT___GEN_102)))))
                            : ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_3__DOT___GEN_98) 
                               | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_3__DOT__s_writeback)))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_3__DOT__s_writeback 
        = __Vtemp_1;
    __Vtemp_2 = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT___system_auto_cbus_fixedClockNode_anon_out_reset) 
                 || (1U & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_4__DOT___GEN_96)
                            ? ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_4__DOT__new_request_prio_2)
                                ? ((~ ((((((1U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_4__DOT__new_request_param)) 
                                           | (2U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_4__DOT__new_request_param))) 
                                          | (5U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_4__DOT__new_request_param))) 
                                         & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_4__DOT__new_meta_clients)) 
                                        & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_4__DOT__new_clientBit)) 
                                       | (((0U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_4__DOT__new_request_param)) 
                                           | (4U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_4__DOT__new_request_param))) 
                                          & (2U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_4__DOT__new_meta_state))))) 
                                   & (~ ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_4__DOT__new_request_opcode) 
                                         & (~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_4__DOT__new_meta_dirty)))))
                                : ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_4__DOT__new_request_control) 
                                   | ((~ (((((~ ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_4__DOT__new_request_opcode) 
                                                 >> 2U)) 
                                             & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_4__DOT__new_meta_hit)) 
                                            & (~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_4__DOT__new_meta_dirty))) 
                                           | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_4__DOT___GEN_105)) 
                                          | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_4__DOT___GEN_112))) 
                                      & (~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_4__DOT___GEN_102)))))
                            : ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_4__DOT___GEN_98) 
                               | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_4__DOT__s_writeback)))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_4__DOT__s_writeback 
        = __Vtemp_2;
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__563(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__563\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_0__DOT__w_pprobeacklast 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT___system_auto_cbus_fixedClockNode_anon_out_reset) 
           || ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_0__DOT___GEN_96)
                ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_0__DOT___GEN_113)
                : ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_0__DOT___GEN_110) 
                   | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_0__DOT__w_pprobeacklast))));
    vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_1__DOT__w_pprobeacklast 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT___system_auto_cbus_fixedClockNode_anon_out_reset) 
           || ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_1__DOT___GEN_96)
                ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_1__DOT___GEN_113)
                : ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_1__DOT___GEN_110) 
                   | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_1__DOT__w_pprobeacklast))));
    vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_2__DOT__w_pprobeacklast 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT___system_auto_cbus_fixedClockNode_anon_out_reset) 
           || ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_2__DOT___GEN_96)
                ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_2__DOT___GEN_113)
                : ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_2__DOT___GEN_110) 
                   | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_2__DOT__w_pprobeacklast))));
    vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_3__DOT__w_pprobeacklast 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT___system_auto_cbus_fixedClockNode_anon_out_reset) 
           || ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_3__DOT___GEN_96)
                ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_3__DOT___GEN_113)
                : ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_3__DOT___GEN_110) 
                   | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_3__DOT__w_pprobeacklast))));
    vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_4__DOT__w_pprobeacklast 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT___system_auto_cbus_fixedClockNode_anon_out_reset) 
           || ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_4__DOT___GEN_96)
                ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_4__DOT___GEN_113)
                : ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_4__DOT___GEN_110) 
                   | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_4__DOT__w_pprobeacklast))));
    vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_0__DOT__w_rprobeacklast 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT___system_auto_cbus_fixedClockNode_anon_out_reset) 
           || ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_0__DOT___GEN_96)
                ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_0__DOT___GEN_111)
                : ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_0__DOT___GEN_110) 
                   | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_0__DOT__w_rprobeacklast))));
    vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_1__DOT__w_rprobeacklast 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT___system_auto_cbus_fixedClockNode_anon_out_reset) 
           || ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_1__DOT___GEN_96)
                ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_1__DOT___GEN_111)
                : ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_1__DOT___GEN_110) 
                   | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_1__DOT__w_rprobeacklast))));
    vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_2__DOT__w_rprobeacklast 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT___system_auto_cbus_fixedClockNode_anon_out_reset) 
           || ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_2__DOT___GEN_96)
                ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_2__DOT___GEN_111)
                : ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_2__DOT___GEN_110) 
                   | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_2__DOT__w_rprobeacklast))));
    vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_3__DOT__w_rprobeacklast 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT___system_auto_cbus_fixedClockNode_anon_out_reset) 
           || ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_3__DOT___GEN_96)
                ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_3__DOT___GEN_111)
                : ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_3__DOT___GEN_110) 
                   | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_3__DOT__w_rprobeacklast))));
    vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_4__DOT__w_rprobeacklast 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT___system_auto_cbus_fixedClockNode_anon_out_reset) 
           || ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_4__DOT___GEN_96)
                ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_4__DOT___GEN_111)
                : ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_4__DOT___GEN_110) 
                   | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_4__DOT__w_rprobeacklast))));
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__564(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__564\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_0__DOT__w_grantack 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT___system_auto_cbus_fixedClockNode_anon_out_reset) 
           || (1U & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_0__DOT___GEN_96)
                      ? ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_0__DOT___GEN_103) 
                         | (~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_0__DOT___GEN_105)))
                      : (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT___InclusiveCache_inner_TLBuffer_auto_out_e_valid) 
                          & (0U == vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__buffer__DOT__nodeOut_e_q__DOT__ram_ext__DOT__Memory
                             [vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__buffer__DOT__nodeOut_e_q__DOT__deq_ptr_value])) 
                         | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_0__DOT__w_grantack)))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_1__DOT__w_grantack 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT___system_auto_cbus_fixedClockNode_anon_out_reset) 
           || (1U & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_1__DOT___GEN_96)
                      ? ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_1__DOT___GEN_103) 
                         | (~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_1__DOT___GEN_105)))
                      : (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT___InclusiveCache_inner_TLBuffer_auto_out_e_valid) 
                          & (1U == vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__buffer__DOT__nodeOut_e_q__DOT__ram_ext__DOT__Memory
                             [vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__buffer__DOT__nodeOut_e_q__DOT__deq_ptr_value])) 
                         | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_1__DOT__w_grantack)))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_2__DOT__w_grantack 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT___system_auto_cbus_fixedClockNode_anon_out_reset) 
           || (1U & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_2__DOT___GEN_96)
                      ? ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_2__DOT___GEN_103) 
                         | (~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_2__DOT___GEN_105)))
                      : (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT___InclusiveCache_inner_TLBuffer_auto_out_e_valid) 
                          & (2U == vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__buffer__DOT__nodeOut_e_q__DOT__ram_ext__DOT__Memory
                             [vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__buffer__DOT__nodeOut_e_q__DOT__deq_ptr_value])) 
                         | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_2__DOT__w_grantack)))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_3__DOT__w_grantack 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT___system_auto_cbus_fixedClockNode_anon_out_reset) 
           || (1U & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_3__DOT___GEN_96)
                      ? ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_3__DOT___GEN_103) 
                         | (~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_3__DOT___GEN_105)))
                      : (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT___InclusiveCache_inner_TLBuffer_auto_out_e_valid) 
                          & (3U == vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__buffer__DOT__nodeOut_e_q__DOT__ram_ext__DOT__Memory
                             [vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__buffer__DOT__nodeOut_e_q__DOT__deq_ptr_value])) 
                         | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_3__DOT__w_grantack)))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_4__DOT__w_grantack 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT___system_auto_cbus_fixedClockNode_anon_out_reset) 
           || (1U & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_4__DOT___GEN_96)
                      ? ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_4__DOT___GEN_103) 
                         | (~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_4__DOT___GEN_105)))
                      : (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT___InclusiveCache_inner_TLBuffer_auto_out_e_valid) 
                          & (4U == vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__buffer__DOT__nodeOut_e_q__DOT__ram_ext__DOT__Memory
                             [vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__buffer__DOT__nodeOut_e_q__DOT__deq_ptr_value])) 
                         | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_4__DOT__w_grantack)))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_0__DOT__s_rprobe 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT___system_auto_cbus_fixedClockNode_anon_out_reset) 
           || (1U & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_0__DOT___GEN_96)
                      ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_0__DOT___GEN_111)
                      : ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshr_selectOH) 
                         | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_0__DOT__s_rprobe)))));
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__565(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__565\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_1__DOT__s_rprobe 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT___system_auto_cbus_fixedClockNode_anon_out_reset) 
           || (1U & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_1__DOT___GEN_96)
                      ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_1__DOT___GEN_111)
                      : (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshr_selectOH) 
                          >> 1U) | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_1__DOT__s_rprobe)))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_2__DOT__s_rprobe 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT___system_auto_cbus_fixedClockNode_anon_out_reset) 
           || (1U & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_2__DOT___GEN_96)
                      ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_2__DOT___GEN_111)
                      : (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshr_selectOH) 
                          >> 2U) | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_2__DOT__s_rprobe)))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_3__DOT__s_rprobe 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT___system_auto_cbus_fixedClockNode_anon_out_reset) 
           || (1U & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_3__DOT___GEN_96)
                      ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_3__DOT___GEN_111)
                      : (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshr_selectOH) 
                          >> 3U) | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_3__DOT__s_rprobe)))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_4__DOT__s_rprobe 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT___system_auto_cbus_fixedClockNode_anon_out_reset) 
           || (1U & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_4__DOT___GEN_96)
                      ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_4__DOT___GEN_111)
                      : (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshr_selectOH) 
                          >> 4U) | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_4__DOT__s_rprobe)))));
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__io_div_resp_div__DOT__div__DOT___GEN_5) {
        vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__io_div_resp_div__DOT__div__DOT__divisor[0U] 
            = (IData)((((QData)((IData)(((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__exe_uop_bits_fcn_dw)
                                          ? (IData)(
                                                    (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__exe_rs2_data 
                                                     >> 0x20U))
                                          : (- (IData)((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__io_div_resp_div__DOT__div__DOT__rhs_sign)))))) 
                        << 0x20U) | (QData)((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__exe_rs2_data))));
        vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__io_div_resp_div__DOT__div__DOT__divisor[1U] 
            = (IData)(((((QData)((IData)(((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__exe_uop_bits_fcn_dw)
                                           ? (IData)(
                                                     (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__exe_rs2_data 
                                                      >> 0x20U))
                                           : (- (IData)((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__io_div_resp_div__DOT__div__DOT__rhs_sign)))))) 
                         << 0x20U) | (QData)((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__exe_rs2_data))) 
                       >> 0x20U));
        vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__io_div_resp_div__DOT__div__DOT__divisor[2U] 
            = (1U & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__io_div_resp_div__DOT__div__DOT__rhs_sign));
    } else if (((1U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__io_div_resp_div__DOT__div__DOT__state)) 
                & (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__io_div_resp_div__DOT__div__DOT__divisor[1U] 
                   >> 0x1fU))) {
        vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__io_div_resp_div__DOT__div__DOT__divisor[0U] 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__io_div_resp_div__DOT__div__DOT___subtractor_T_1[0U];
        vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__io_div_resp_div__DOT__div__DOT__divisor[1U] 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__io_div_resp_div__DOT__div__DOT___subtractor_T_1[1U];
        vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__io_div_resp_div__DOT__div__DOT__divisor[2U] 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__io_div_resp_div__DOT__div__DOT___subtractor_T_1[2U];
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__buffer__DOT__nodeIn_b_q__DOT__do_enq) {
        vlSelfRef.__VdlyVal__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__buffer__DOT__nodeIn_b_q__DOT__ram_ext__DOT__Memory__v0[0U] = 0U;
        vlSelfRef.__VdlyVal__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__buffer__DOT__nodeIn_b_q__DOT__ram_ext__DOT__Memory__v0[1U] = 0U;
        vlSelfRef.__VdlyVal__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__buffer__DOT__nodeIn_b_q__DOT__ram_ext__DOT__Memory__v0[2U] 
            = (0x1feU | (0xfffffe00U & vlSelfRef.__VdlyVal__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__buffer__DOT__nodeIn_b_q__DOT__ram_ext__DOT__Memory__v0[2U]));
        vlSelfRef.__VdlyVal__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__buffer__DOT__nodeIn_b_q__DOT__ram_ext__DOT__Memory__v0[2U] 
            = ((0x1ffU & vlSelfRef.__VdlyVal__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__buffer__DOT__nodeIn_b_q__DOT__ram_ext__DOT__Memory__v0[2U]) 
               | (0xfffffe00U & (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sourceB__DOT__tag) 
                                  << 0x19U) | (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sourceB__DOT__remain)
                                                 ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sourceB__DOT__set_r)
                                                 : (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT____Vcellinp__directory__io_write_bits_set)) 
                                               << 0xfU))));
        vlSelfRef.__VdlyVal__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__buffer__DOT__nodeIn_b_q__DOT__ram_ext__DOT__Memory__v0[3U] 
            = ((0x1fff00U & vlSelfRef.__VdlyVal__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__buffer__DOT__nodeIn_b_q__DOT__ram_ext__DOT__Memory__v0[3U]) 
               | (0x1ffU & ((0x1fU & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sourceB__DOT__tag) 
                                      >> 7U)) | (0x1ffU 
                                                 & (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sourceB__DOT__remain)
                                                      ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sourceB__DOT__set_r)
                                                      : (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT____Vcellinp__directory__io_write_bits_set)) 
                                                    >> 0x11U)))));
        vlSelfRef.__VdlyVal__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__buffer__DOT__nodeIn_b_q__DOT__ram_ext__DOT__Memory__v0[3U] 
            = ((0xffU & vlSelfRef.__VdlyVal__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__buffer__DOT__nodeIn_b_q__DOT__ram_ext__DOT__Memory__v0[3U]) 
               | (0x1fff00U & (0x186000U | ((0x30000U 
                                             & (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sourceB__DOT__remain)
                                                  ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sourceB__DOT__param_r)
                                                  : (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT____Vcellinp__sourceB__io_req_bits_param)) 
                                                << 0x10U)) 
                                            | (0x100U 
                                               & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sourceB__DOT__tag) 
                                                  >> 4U))))));
        vlSelfRef.__VdlyDim0__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__buffer__DOT__nodeIn_b_q__DOT__ram_ext__DOT__Memory__v0 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__buffer__DOT__nodeIn_b_q__DOT__enq_ptr_value;
        vlSelfRef.__VdlySet__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__buffer__DOT__nodeIn_b_q__DOT__ram_ext__DOT__Memory__v0 = 1U;
    }
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__568(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__568\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__cork__DOT__q_1__DOT__do_enq) {
        vlSelfRef.__VdlyVal__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__cork__DOT__q_1__DOT__ram_ext__DOT__Memory__v0[0U] = 0U;
        vlSelfRef.__VdlyVal__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__cork__DOT__q_1__DOT__ram_ext__DOT__Memory__v0[1U] = 0U;
        vlSelfRef.__VdlyVal__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__cork__DOT__q_1__DOT__ram_ext__DOT__Memory__v0[2U] 
            = ((0xf800U & vlSelfRef.__VdlyVal__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__cork__DOT__q_1__DOT__ram_ext__DOT__Memory__v0[2U]) 
               | (0x7e0U & (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sourceA__DOT__io_a_q__DOT__ram_ext__DOT__Memory
                            [vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sourceA__DOT__io_a_q__DOT__deq_ptr_value][3U] 
                            >> 4U)));
        vlSelfRef.__VdlyVal__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__cork__DOT__q_1__DOT__ram_ext__DOT__Memory__v0[2U] 
            = (0x8000U | (0x7ffU & vlSelfRef.__VdlyVal__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__cork__DOT__q_1__DOT__ram_ext__DOT__Memory__v0[2U]));
        vlSelfRef.__VdlyDim0__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__cork__DOT__q_1__DOT__ram_ext__DOT__Memory__v0 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__cork__DOT__q_1__DOT__enq_ptr_value;
        vlSelfRef.__VdlySet__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__cork__DOT__q_1__DOT__ram_ext__DOT__Memory__v0 = 1U;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__mbus__DOT__buffer_1__DOT__nodeOut_a_q__DOT__do_enq) {
        vlSelfRef.__VdlyVal__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__mbus__DOT__buffer_1__DOT__nodeOut_a_q__DOT__ram_ext__DOT__Memory__v0[0U] 
            = ((0xfffffffeU & vlSelfRef.__VdlyVal__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__mbus__DOT__buffer_1__DOT__nodeOut_a_q__DOT__ram_ext__DOT__Memory__v0[0U]) 
               | (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__cork__DOT__muxState_0) 
                   & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sourceC__DOT__queue__DOT___ram_ext_R0_data[0U]) 
                  | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__cork__DOT__muxState_1) 
                     & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sourceA__DOT__io_a_q__DOT__ram_ext__DOT__Memory
                     [vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sourceA__DOT__io_a_q__DOT__deq_ptr_value][0U])));
        vlSelfRef.__VdlyVal__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__mbus__DOT__buffer_1__DOT__nodeOut_a_q__DOT__ram_ext__DOT__Memory__v0[0U] 
            = ((1U & vlSelfRef.__VdlyVal__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__mbus__DOT__buffer_1__DOT__nodeOut_a_q__DOT__ram_ext__DOT__Memory__v0[0U]) 
               | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT___cork_auto_out_a_bits_data) 
                  << 1U));
        vlSelfRef.__VdlyVal__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__mbus__DOT__buffer_1__DOT__nodeOut_a_q__DOT__ram_ext__DOT__Memory__v0[1U] 
            = (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT___cork_auto_out_a_bits_data) 
                >> 0x1fU) | ((IData)((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT___cork_auto_out_a_bits_data 
                                      >> 0x20U)) << 1U));
        vlSelfRef.__VdlyVal__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__mbus__DOT__buffer_1__DOT__nodeOut_a_q__DOT__ram_ext__DOT__Memory__v0[2U] 
            = (((IData)((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT___cork_auto_out_a_bits_data 
                         >> 0x20U)) >> 0x1fU) | ((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT___cork_auto_out_a_bits_address 
                                                  << 9U) 
                                                 | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT___cork_auto_out_a_bits_mask) 
                                                    << 1U)));
        vlSelfRef.__VdlyVal__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__mbus__DOT__buffer_1__DOT__nodeOut_a_q__DOT__ram_ext__DOT__Memory__v0[3U] 
            = ((0x3ffe0U & vlSelfRef.__VdlyVal__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__mbus__DOT__buffer_1__DOT__nodeOut_a_q__DOT__ram_ext__DOT__Memory__v0[3U]) 
               | (0x3ffffU & (((1U & (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT___cork_auto_out_a_bits_address 
                                      >> 0x17U)) | 
                               ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT___cork_auto_out_a_bits_mask) 
                                >> 0x1fU)) | (0x1eU 
                                              & (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT___cork_auto_out_a_bits_address 
                                                 >> 0x17U)))));
        vlSelfRef.__VdlyVal__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__mbus__DOT__buffer_1__DOT__nodeOut_a_q__DOT__ram_ext__DOT__Memory__v0[3U] 
            = ((0x1fU & vlSelfRef.__VdlyVal__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__mbus__DOT__buffer_1__DOT__nodeOut_a_q__DOT__ram_ext__DOT__Memory__v0[3U]) 
               | (0x3ffe0U & ((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT___cork_auto_out_a_bits_opcode) 
                                << 0xfU) | (((1U & 
                                              ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__cork__DOT__muxState_1)) 
                                               | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__cork__DOT___GEN)))
                                              ? 0U : (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT___l2_auto_out_a_bits_param)) 
                                            << 0xcU)) 
                              | (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT___cork_auto_out_a_bits_size) 
                                  << 9U) | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT___cork_auto_out_a_bits_source) 
                                            << 5U)))));
        vlSelfRef.__VdlyDim0__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__mbus__DOT__buffer_1__DOT__nodeOut_a_q__DOT__ram_ext__DOT__Memory__v0 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__mbus__DOT__buffer_1__DOT__nodeOut_a_q__DOT__enq_ptr_value;
        vlSelfRef.__VdlySet__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__mbus__DOT__buffer_1__DOT__nodeOut_a_q__DOT__ram_ext__DOT__Memory__v0 = 1U;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sourceA__DOT__io_a_q__DOT__do_enq) {
        vlSelfRef.__VdlyVal__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sourceA__DOT__io_a_q__DOT__ram_ext__DOT__Memory__v0[0U] 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sourceA__DOT__io_a_q__DOT____Vcellinp__ram_ext__W0_data[0U];
        vlSelfRef.__VdlyVal__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sourceA__DOT__io_a_q__DOT__ram_ext__DOT__Memory__v0[1U] 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sourceA__DOT__io_a_q__DOT____Vcellinp__ram_ext__W0_data[1U];
        vlSelfRef.__VdlyVal__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sourceA__DOT__io_a_q__DOT__ram_ext__DOT__Memory__v0[2U] 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sourceA__DOT__io_a_q__DOT____Vcellinp__ram_ext__W0_data[2U];
        vlSelfRef.__VdlyVal__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sourceA__DOT__io_a_q__DOT__ram_ext__DOT__Memory__v0[3U] 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sourceA__DOT__io_a_q__DOT____Vcellinp__ram_ext__W0_data[3U];
        vlSelfRef.__VdlyDim0__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sourceA__DOT__io_a_q__DOT__ram_ext__DOT__Memory__v0 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sourceA__DOT__io_a_q__DOT__enq_ptr_value;
        vlSelfRef.__VdlySet__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sourceA__DOT__io_a_q__DOT__ram_ext__DOT__Memory__v0 = 1U;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sourceE__DOT__io_e_q__DOT__do_enq) {
        vlSelfRef.__VdlyVal__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sourceE__DOT__io_e_q__DOT__ram_ext__DOT__Memory__v0 
            = (((1U & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshr_selectOH))
                 ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_0__DOT__sink)
                 : 0U) | (((2U & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshr_selectOH))
                            ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_1__DOT__sink)
                            : 0U) | (((4U & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshr_selectOH))
                                       ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_2__DOT__sink)
                                       : 0U) | (((8U 
                                                  & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshr_selectOH))
                                                  ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_3__DOT__sink)
                                                  : 0U) 
                                                | (((0x10U 
                                                     & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshr_selectOH))
                                                     ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_4__DOT__sink)
                                                     : 0U) 
                                                   | (((0x20U 
                                                        & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshr_selectOH))
                                                        ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_5__DOT__sink)
                                                        : 0U) 
                                                      | ((0x40U 
                                                          & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshr_selectOH))
                                                          ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_6__DOT__sink)
                                                          : 0U)))))));
        vlSelfRef.__VdlyDim0__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sourceE__DOT__io_e_q__DOT__ram_ext__DOT__Memory__v0 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sourceE__DOT__io_e_q__DOT__enq_ptr_value;
        vlSelfRef.__VdlySet__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sourceE__DOT__io_e_q__DOT__ram_ext__DOT__Memory__v0 = 1U;
    }
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__569(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__569\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT___system_auto_cbus_fixedClockNode_anon_out_reset) {
        vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_6__DOT__w_grantfirst = 1U;
        vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_6__DOT__s_grantack = 1U;
        vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_5__DOT__w_grantfirst = 1U;
        vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_5__DOT__s_grantack = 1U;
    } else {
        if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_6__DOT___GEN_96) {
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_6__DOT__w_grantfirst 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_6__DOT___GEN_104;
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_6__DOT__s_grantack 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_6__DOT___GEN_104;
        } else {
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_6__DOT__w_grantfirst 
                = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_6__DOT___GEN_108) 
                   | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_6__DOT__w_grantfirst));
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_6__DOT__s_grantack 
                = ((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshr_selectOH) 
                     >> 6U) & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_6__DOT__w_grantfirst)) 
                   | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_6__DOT__s_grantack));
        }
        if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_5__DOT___GEN_96) {
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_5__DOT__w_grantfirst 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_5__DOT___GEN_104;
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_5__DOT__s_grantack 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_5__DOT___GEN_104;
        } else {
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_5__DOT__w_grantfirst 
                = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_5__DOT___GEN_108) 
                   | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_5__DOT__w_grantfirst));
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_5__DOT__s_grantack 
                = ((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshr_selectOH) 
                     >> 5U) & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_5__DOT__w_grantfirst)) 
                   | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_5__DOT__s_grantack));
        }
    }
    vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__io_div_resp_div__DOT__req_valid 
        = (1U & ((~ (((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__ll_arb__DOT___grant_T)) 
                      & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___unique_exe_unit_0_io_div_resp_valid)) 
                     | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT___system_auto_cbus_fixedClockNode_anon_out_reset))) 
                 & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__io_div_resp_div__DOT___GEN)
                     ? (~ ((0U != ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT___lsu_io_dmem_brupdate_b1_mispredict_mask) 
                                   & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__exe_uop_bits_br_mask))) 
                           | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0_io_kill_REG)))
                     : ((~ ((0U != ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT___lsu_io_dmem_brupdate_b1_mispredict_mask) 
                                    & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__io_div_resp_div__DOT__req_bits_br_mask))) 
                            | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0_io_kill_REG))) 
                        & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__io_div_resp_div__DOT__req_valid)))));
    vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__io_div_resp_div__DOT__req_bits_br_mask 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__io_div_resp_div__DOT___GEN)
            ? ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__exe_uop_bits_br_mask) 
               & (~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT___lsu_io_dmem_brupdate_b1_resolve_mask)))
            : ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__io_div_resp_div__DOT__req_bits_br_mask) 
               & (~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT___lsu_io_dmem_brupdate_b1_resolve_mask))));
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__570(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__570\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__io_fdiv_resp_fdivsqrt__DOT__r_req_bits_uop_br_mask 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__io_fdiv_resp_fdivsqrt__DOT___GEN)
            ? ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__exe_uop_bits_br_mask) 
               & (~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT___lsu_io_dmem_brupdate_b1_resolve_mask)))
            : ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__io_fdiv_resp_fdivsqrt__DOT__r_req_bits_uop_br_mask) 
               & (~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT___lsu_io_dmem_brupdate_b1_resolve_mask))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__ldq_executed_7 
        = ((((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT___dcache_io_lsu_nack_0_valid)) 
             | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__s2_req_0_is_hella)) 
            | (~ ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__s2_req_0_uop_uses_ldq) 
                  & (7U == (7U & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__s2_req_0_uop_ldq_idx)))))) 
           & (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_433)
                ? ((~ ((7U == (7U & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__lcam_ldq_idx_0))) 
                       | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_643))) 
                   & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_626))
                : ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_643)) 
                   & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_626))) 
              | ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_20)) 
                 & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__ldq_executed_7))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__ldq_executed_0 
        = ((((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT___dcache_io_lsu_nack_0_valid)) 
             | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__s2_req_0_is_hella)) 
            | (~ ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__s2_req_0_uop_uses_ldq) 
                  & (0U == (7U & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__s2_req_0_uop_ldq_idx)))))) 
           & (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_433)
                ? ((~ ((~ (0U != (7U & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__lcam_ldq_idx_0)))) 
                       | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_636))) 
                   & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_628))
                : ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_636)) 
                   & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_628))) 
              | ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_13)) 
                 & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__ldq_executed_0))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__ldq_executed_6 
        = ((((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT___dcache_io_lsu_nack_0_valid)) 
             | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__s2_req_0_is_hella)) 
            | (~ ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__s2_req_0_uop_uses_ldq) 
                  & (6U == (7U & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__s2_req_0_uop_ldq_idx)))))) 
           & (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_433)
                ? ((~ ((6U == (7U & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__lcam_ldq_idx_0))) 
                       | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_642))) 
                   & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_634))
                : ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_642)) 
                   & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_634))) 
              | ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_19)) 
                 & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__ldq_executed_6))));
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__571(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__571\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__ldq_executed_5 
        = ((((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT___dcache_io_lsu_nack_0_valid)) 
             | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__s2_req_0_is_hella)) 
            | (~ ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__s2_req_0_uop_uses_ldq) 
                  & (5U == (7U & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__s2_req_0_uop_ldq_idx)))))) 
           & (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_433)
                ? ((~ ((5U == (7U & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__lcam_ldq_idx_0))) 
                       | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_641))) 
                   & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_633))
                : ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_641)) 
                   & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_633))) 
              | ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_18)) 
                 & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__ldq_executed_5))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__ldq_executed_4 
        = ((((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT___dcache_io_lsu_nack_0_valid)) 
             | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__s2_req_0_is_hella)) 
            | (~ ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__s2_req_0_uop_uses_ldq) 
                  & (4U == (7U & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__s2_req_0_uop_ldq_idx)))))) 
           & (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_433)
                ? ((~ ((4U == (7U & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__lcam_ldq_idx_0))) 
                       | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_640))) 
                   & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_632))
                : ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_640)) 
                   & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_632))) 
              | ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_17)) 
                 & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__ldq_executed_4))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__ldq_executed_2 
        = ((((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT___dcache_io_lsu_nack_0_valid)) 
             | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__s2_req_0_is_hella)) 
            | (~ ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__s2_req_0_uop_uses_ldq) 
                  & (2U == (7U & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__s2_req_0_uop_ldq_idx)))))) 
           & (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_433)
                ? ((~ ((2U == (7U & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__lcam_ldq_idx_0))) 
                       | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_638))) 
                   & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_630))
                : ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_638)) 
                   & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_630))) 
              | ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_15)) 
                 & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__ldq_executed_2))));
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__572(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__572\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__ldq_executed_3 
        = ((((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT___dcache_io_lsu_nack_0_valid)) 
             | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__s2_req_0_is_hella)) 
            | (~ ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__s2_req_0_uop_uses_ldq) 
                  & (3U == (7U & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__s2_req_0_uop_ldq_idx)))))) 
           & (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_433)
                ? ((~ ((3U == (7U & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__lcam_ldq_idx_0))) 
                       | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_639))) 
                   & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_631))
                : ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_639)) 
                   & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_631))) 
              | ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_16)) 
                 & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__ldq_executed_3))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__ldq_executed_1 
        = ((((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT___dcache_io_lsu_nack_0_valid)) 
             | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__s2_req_0_is_hella)) 
            | (~ ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__s2_req_0_uop_uses_ldq) 
                  & (1U == (7U & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__s2_req_0_uop_ldq_idx)))))) 
           & (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_433)
                ? ((~ ((1U == (7U & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__lcam_ldq_idx_0))) 
                       | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_637))) 
                   & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_629))
                : ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_637)) 
                   & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_629))) 
              | ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_14)) 
                 & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__ldq_executed_1))));
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT___system_auto_cbus_fixedClockNode_anon_out_reset) {
        vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_6__DOT__w_grant = 1U;
        vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_6__DOT__w_pprobeack = 1U;
        vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_6__DOT__s_execute = 1U;
    } else if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_6__DOT___GEN_96) {
        vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_6__DOT__w_pprobeack 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_6__DOT___GEN_113;
        vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_6__DOT__s_execute 
            = ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_6__DOT__new_request_prio_2)) 
               & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_6__DOT__new_request_control));
        vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_6__DOT__w_grant 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_6__DOT___GEN_104;
    } else {
        vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_6__DOT__w_pprobeack 
            = ((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT____Vcellinp__mshrs_6__io_sinkc_valid) 
                 & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_6__DOT__last_probe)) 
                & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT___sinkC_io_resp_bits_last) 
                   | (~ (0U != (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_6__DOT__request_offset))))) 
               | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_6__DOT__w_pprobeack));
        vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_6__DOT__s_execute 
            = (((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshr_selectOH) 
                  >> 6U) & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_6__DOT__w_pprobeack)) 
                & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_6__DOT__w_grant)) 
               | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_6__DOT__s_execute));
        if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_6__DOT___GEN_108) {
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_6__DOT__w_grant 
                = (1U & ((~ (0U != (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_6__DOT__request_offset))) 
                         | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT___sinkD_io_resp_bits_last)));
        }
    }
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__573(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__573\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT___system_auto_cbus_fixedClockNode_anon_out_reset) {
        vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__retry_queue__DOT__valids_0 = 0U;
        vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__retry_queue__DOT__valids_1 = 0U;
        vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__retry_queue__DOT__valids_2 = 0U;
        vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__retry_queue__DOT__valids_3 = 0U;
        vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__retry_queue__DOT__valids_4 = 0U;
        vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__retry_queue__DOT__valids_5 = 0U;
        vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__retry_queue__DOT__valids_6 = 0U;
        vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__retry_queue__DOT__valids_7 = 0U;
        vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__retry_queue__DOT__enq_ptr_value = 0U;
        vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__retry_queue__DOT__deq_ptr_value = 0U;
    } else {
        vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__retry_queue__DOT__valids_0 
            = ((~ ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__retry_queue__DOT__do_deq) 
                   & (0U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__retry_queue__DOT__deq_ptr_value)))) 
               & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__retry_queue__DOT___GEN_112) 
                  | (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__retry_queue__DOT__valids_0) 
                      & (0U == ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT___lsu_io_dmem_brupdate_b1_mispredict_mask) 
                                & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__retry_queue__DOT__uops_0_br_mask)))) 
                     & (~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__io_lsu_exception_REG)))));
        if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__retry_queue__DOT__do_enq) {
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__retry_queue__DOT__enq_ptr_value 
                = (7U & ((IData)(1U) + (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__retry_queue__DOT__enq_ptr_value)));
        }
        vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__retry_queue__DOT__valids_1 
            = ((~ ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__retry_queue__DOT__do_deq) 
                   & (1U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__retry_queue__DOT__deq_ptr_value)))) 
               & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__retry_queue__DOT___GEN_114) 
                  | (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__retry_queue__DOT__valids_1) 
                      & (0U == ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT___lsu_io_dmem_brupdate_b1_mispredict_mask) 
                                & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__retry_queue__DOT__uops_1_br_mask)))) 
                     & (~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__io_lsu_exception_REG)))));
        vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__retry_queue__DOT__valids_2 
            = ((~ ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__retry_queue__DOT__do_deq) 
                   & (2U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__retry_queue__DOT__deq_ptr_value)))) 
               & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__retry_queue__DOT___GEN_116) 
                  | (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__retry_queue__DOT__valids_2) 
                      & (0U == ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT___lsu_io_dmem_brupdate_b1_mispredict_mask) 
                                & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__retry_queue__DOT__uops_2_br_mask)))) 
                     & (~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__io_lsu_exception_REG)))));
        vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__retry_queue__DOT__valids_3 
            = ((~ ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__retry_queue__DOT__do_deq) 
                   & (3U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__retry_queue__DOT__deq_ptr_value)))) 
               & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__retry_queue__DOT___GEN_118) 
                  | (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__retry_queue__DOT__valids_3) 
                      & (0U == ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT___lsu_io_dmem_brupdate_b1_mispredict_mask) 
                                & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__retry_queue__DOT__uops_3_br_mask)))) 
                     & (~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__io_lsu_exception_REG)))));
        vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__retry_queue__DOT__valids_4 
            = ((~ ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__retry_queue__DOT__do_deq) 
                   & (4U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__retry_queue__DOT__deq_ptr_value)))) 
               & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__retry_queue__DOT___GEN_120) 
                  | (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__retry_queue__DOT__valids_4) 
                      & (0U == ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT___lsu_io_dmem_brupdate_b1_mispredict_mask) 
                                & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__retry_queue__DOT__uops_4_br_mask)))) 
                     & (~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__io_lsu_exception_REG)))));
        vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__retry_queue__DOT__valids_5 
            = ((~ ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__retry_queue__DOT__do_deq) 
                   & (5U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__retry_queue__DOT__deq_ptr_value)))) 
               & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__retry_queue__DOT___GEN_122) 
                  | (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__retry_queue__DOT__valids_5) 
                      & (0U == ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT___lsu_io_dmem_brupdate_b1_mispredict_mask) 
                                & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__retry_queue__DOT__uops_5_br_mask)))) 
                     & (~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__io_lsu_exception_REG)))));
        vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__retry_queue__DOT__valids_6 
            = ((~ ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__retry_queue__DOT__do_deq) 
                   & (6U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__retry_queue__DOT__deq_ptr_value)))) 
               & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__retry_queue__DOT___GEN_124) 
                  | (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__retry_queue__DOT__valids_6) 
                      & (0U == ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT___lsu_io_dmem_brupdate_b1_mispredict_mask) 
                                & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__retry_queue__DOT__uops_6_br_mask)))) 
                     & (~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__io_lsu_exception_REG)))));
        vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__retry_queue__DOT__valids_7 
            = ((~ ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__retry_queue__DOT__do_deq) 
                   & (7U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__retry_queue__DOT__deq_ptr_value)))) 
               & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__retry_queue__DOT___GEN_125) 
                  | (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__retry_queue__DOT__valids_7) 
                      & (0U == ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT___lsu_io_dmem_brupdate_b1_mispredict_mask) 
                                & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__retry_queue__DOT__uops_7_br_mask)))) 
                     & (~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__io_lsu_exception_REG)))));
        if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__retry_queue__DOT__do_deq) {
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__retry_queue__DOT__deq_ptr_value 
                = (7U & ((IData)(1U) + (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__retry_queue__DOT__deq_ptr_value)));
        }
    }
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__574(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__574\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__retry_queue__DOT__uops_0_br_mask 
        = (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__retry_queue__DOT__do_enq) 
            & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__retry_queue__DOT___GEN_111))
            ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__retry_queue__DOT___uops_br_mask_T_1)
            : (((- (IData)((1U & (~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__retry_queue__DOT__valids_0))))) 
                | (~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT___lsu_io_dmem_brupdate_b1_resolve_mask))) 
               & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__retry_queue__DOT__uops_0_br_mask)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__retry_queue__DOT__uops_1_br_mask 
        = (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__retry_queue__DOT__do_enq) 
            & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__retry_queue__DOT___GEN_113))
            ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__retry_queue__DOT___uops_br_mask_T_1)
            : (((- (IData)((1U & (~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__retry_queue__DOT__valids_1))))) 
                | (~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT___lsu_io_dmem_brupdate_b1_resolve_mask))) 
               & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__retry_queue__DOT__uops_1_br_mask)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__retry_queue__DOT__uops_2_br_mask 
        = (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__retry_queue__DOT__do_enq) 
            & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__retry_queue__DOT___GEN_115))
            ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__retry_queue__DOT___uops_br_mask_T_1)
            : (((- (IData)((1U & (~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__retry_queue__DOT__valids_2))))) 
                | (~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT___lsu_io_dmem_brupdate_b1_resolve_mask))) 
               & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__retry_queue__DOT__uops_2_br_mask)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__retry_queue__DOT__uops_3_br_mask 
        = (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__retry_queue__DOT__do_enq) 
            & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__retry_queue__DOT___GEN_117))
            ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__retry_queue__DOT___uops_br_mask_T_1)
            : (((- (IData)((1U & (~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__retry_queue__DOT__valids_3))))) 
                | (~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT___lsu_io_dmem_brupdate_b1_resolve_mask))) 
               & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__retry_queue__DOT__uops_3_br_mask)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__retry_queue__DOT__uops_4_br_mask 
        = (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__retry_queue__DOT__do_enq) 
            & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__retry_queue__DOT___GEN_119))
            ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__retry_queue__DOT___uops_br_mask_T_1)
            : (((- (IData)((1U & (~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__retry_queue__DOT__valids_4))))) 
                | (~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT___lsu_io_dmem_brupdate_b1_resolve_mask))) 
               & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__retry_queue__DOT__uops_4_br_mask)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__retry_queue__DOT__uops_5_br_mask 
        = (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__retry_queue__DOT__do_enq) 
            & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__retry_queue__DOT___GEN_121))
            ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__retry_queue__DOT___uops_br_mask_T_1)
            : (((- (IData)((1U & (~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__retry_queue__DOT__valids_5))))) 
                | (~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT___lsu_io_dmem_brupdate_b1_resolve_mask))) 
               & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__retry_queue__DOT__uops_5_br_mask)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__retry_queue__DOT__uops_6_br_mask 
        = (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__retry_queue__DOT__do_enq) 
            & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__retry_queue__DOT___GEN_123))
            ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__retry_queue__DOT___uops_br_mask_T_1)
            : (((- (IData)((1U & (~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__retry_queue__DOT__valids_6))))) 
                | (~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT___lsu_io_dmem_brupdate_b1_resolve_mask))) 
               & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__retry_queue__DOT__uops_6_br_mask)));
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__575(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__575\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__retry_queue__DOT__uops_7_br_mask 
        = (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__retry_queue__DOT__do_enq) 
            & (7U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__retry_queue__DOT__enq_ptr_value)))
            ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__retry_queue__DOT___uops_br_mask_T_1)
            : (((- (IData)((1U & (~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__retry_queue__DOT__valids_7))))) 
                | (~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT___lsu_io_dmem_brupdate_b1_resolve_mask))) 
               & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__retry_queue__DOT__uops_7_br_mask)));
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT___system_auto_cbus_fixedClockNode_anon_out_reset) {
        vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_0__DOT__w_grantfirst = 1U;
        vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_0__DOT__s_grantack = 1U;
        vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_1__DOT__w_grantfirst = 1U;
        vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_1__DOT__s_grantack = 1U;
        vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_2__DOT__w_grantfirst = 1U;
        vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_2__DOT__s_grantack = 1U;
    } else {
        if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_0__DOT___GEN_96) {
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_0__DOT__w_grantfirst 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_0__DOT___GEN_104;
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_0__DOT__s_grantack 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_0__DOT___GEN_104;
        } else {
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_0__DOT__w_grantfirst 
                = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_0__DOT___GEN_108) 
                   | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_0__DOT__w_grantfirst));
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_0__DOT__s_grantack 
                = (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshr_selectOH) 
                    & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_0__DOT__w_grantfirst)) 
                   | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_0__DOT__s_grantack));
        }
        if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_1__DOT___GEN_96) {
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_1__DOT__w_grantfirst 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_1__DOT___GEN_104;
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_1__DOT__s_grantack 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_1__DOT___GEN_104;
        } else {
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_1__DOT__w_grantfirst 
                = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_1__DOT___GEN_108) 
                   | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_1__DOT__w_grantfirst));
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_1__DOT__s_grantack 
                = ((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshr_selectOH) 
                     >> 1U) & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_1__DOT__w_grantfirst)) 
                   | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_1__DOT__s_grantack));
        }
        if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_2__DOT___GEN_96) {
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_2__DOT__w_grantfirst 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_2__DOT___GEN_104;
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_2__DOT__s_grantack 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_2__DOT___GEN_104;
        } else {
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_2__DOT__w_grantfirst 
                = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_2__DOT___GEN_108) 
                   | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_2__DOT__w_grantfirst));
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_2__DOT__s_grantack 
                = ((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshr_selectOH) 
                     >> 2U) & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_2__DOT__w_grantfirst)) 
                   | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_2__DOT__s_grantack));
        }
    }
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__576(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__576\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT___system_auto_cbus_fixedClockNode_anon_out_reset) {
        vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_3__DOT__w_grantfirst = 1U;
        vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_3__DOT__s_grantack = 1U;
        vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_4__DOT__w_grantfirst = 1U;
        vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_4__DOT__s_grantack = 1U;
        vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__fbus__DOT__buffer__DOT__nodeOut_a_q__DOT__deq_ptr_value = 0U;
        vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_6__DOT__w_releaseack = 1U;
        vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_6__DOT__s_flush = 1U;
    } else {
        if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_3__DOT___GEN_96) {
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_3__DOT__w_grantfirst 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_3__DOT___GEN_104;
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_3__DOT__s_grantack 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_3__DOT___GEN_104;
        } else {
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_3__DOT__w_grantfirst 
                = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_3__DOT___GEN_108) 
                   | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_3__DOT__w_grantfirst));
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_3__DOT__s_grantack 
                = ((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshr_selectOH) 
                     >> 3U) & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_3__DOT__w_grantfirst)) 
                   | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_3__DOT__s_grantack));
        }
        if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_4__DOT___GEN_96) {
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_4__DOT__w_grantfirst 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_4__DOT___GEN_104;
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_4__DOT__s_grantack 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_4__DOT___GEN_104;
        } else {
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_4__DOT__w_grantfirst 
                = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_4__DOT___GEN_108) 
                   | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_4__DOT__w_grantfirst));
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_4__DOT__s_grantack 
                = ((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshr_selectOH) 
                     >> 4U) & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_4__DOT__w_grantfirst)) 
                   | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_4__DOT__s_grantack));
        }
        if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__fbus__DOT__buffer__DOT__nodeOut_a_q__DOT__do_deq) {
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__fbus__DOT__buffer__DOT__nodeOut_a_q__DOT__deq_ptr_value 
                = (1U & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__fbus__DOT__buffer__DOT__nodeOut_a_q__DOT__deq_ptr_value) 
                         - (IData)(1U)));
        }
        if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_6__DOT___GEN_96) {
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_6__DOT__w_releaseack 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_6__DOT___GEN_101;
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_6__DOT__s_flush 
                = (1U & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_6__DOT__new_request_prio_2) 
                         | (~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_6__DOT__new_request_control))));
        } else {
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_6__DOT__w_releaseack 
                = ((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT____Vcellinp__mshrs_6__io_sinkd_valid) 
                     & (~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_0__DOT___GEN_107))) 
                    & (6U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT___sinkD_io_resp_bits_opcode))) 
                   | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_6__DOT__w_releaseack));
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_6__DOT__s_flush 
                = (1U & ((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshr_selectOH) 
                           >> 6U) & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_6__DOT__w_releaseack)) 
                         | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_6__DOT__s_flush)));
        }
    }
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__577(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__577\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__fbus__DOT__buffer__DOT__nodeOut_a_q__DOT__do_enq) {
        vlSelfRef.__VdlyVal__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__fbus__DOT__buffer__DOT__nodeOut_a_q__DOT__ram_ext__DOT__Memory__v0[0U] 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__fbus__DOT__buffer__DOT__nodeOut_a_q__DOT____Vcellinp__ram_ext__W0_data[0U];
        vlSelfRef.__VdlyVal__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__fbus__DOT__buffer__DOT__nodeOut_a_q__DOT__ram_ext__DOT__Memory__v0[1U] 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__fbus__DOT__buffer__DOT__nodeOut_a_q__DOT____Vcellinp__ram_ext__W0_data[1U];
        vlSelfRef.__VdlyVal__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__fbus__DOT__buffer__DOT__nodeOut_a_q__DOT__ram_ext__DOT__Memory__v0[2U] 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__fbus__DOT__buffer__DOT__nodeOut_a_q__DOT____Vcellinp__ram_ext__W0_data[2U];
        vlSelfRef.__VdlyVal__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__fbus__DOT__buffer__DOT__nodeOut_a_q__DOT__ram_ext__DOT__Memory__v0[3U] 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__fbus__DOT__buffer__DOT__nodeOut_a_q__DOT____Vcellinp__ram_ext__W0_data[3U];
        vlSelfRef.__VdlyDim0__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__fbus__DOT__buffer__DOT__nodeOut_a_q__DOT__ram_ext__DOT__Memory__v0 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__fbus__DOT__buffer__DOT__nodeOut_a_q__DOT__enq_ptr_value;
        vlSelfRef.__VdlySet__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__fbus__DOT__buffer__DOT__nodeOut_a_q__DOT__ram_ext__DOT__Memory__v0 = 1U;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT___system_auto_cbus_fixedClockNode_anon_out_reset) {
        vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_5__DOT__w_grant = 1U;
        vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_5__DOT__w_pprobeack = 1U;
        vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_5__DOT__s_execute = 1U;
    } else if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_5__DOT___GEN_96) {
        vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_5__DOT__w_pprobeack 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_5__DOT___GEN_113;
        vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_5__DOT__s_execute 
            = ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_5__DOT__new_request_prio_2)) 
               & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_5__DOT__new_request_control));
        vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_5__DOT__w_grant 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_5__DOT___GEN_104;
    } else {
        vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_5__DOT__w_pprobeack 
            = ((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT____Vcellinp__mshrs_5__io_sinkc_valid) 
                 & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_5__DOT__last_probe)) 
                & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT___sinkC_io_resp_bits_last) 
                   | (~ (0U != (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_5__DOT__request_offset))))) 
               | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_5__DOT__w_pprobeack));
        vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_5__DOT__s_execute 
            = (((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshr_selectOH) 
                  >> 5U) & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_5__DOT__w_pprobeack)) 
                & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_5__DOT__w_grant)) 
               | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_5__DOT__s_execute));
        if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_5__DOT___GEN_108) {
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_5__DOT__w_grant 
                = (1U & ((~ (0U != (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_5__DOT__request_offset))) 
                         | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT___sinkD_io_resp_bits_last)));
        }
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sinkA__DOT__putbuffer_io_pop_valid) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sinkA__DOT__putbuffer__DOT__head_ext__DOT____Vlvbound_h77a2baa6__0 
            = (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sinkA__DOT__putbuffer__DOT____Vcellinp__next_ext__W0_en) 
                & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sinkA__DOT__putbuffer__DOT___head_ext_R0_data) 
                   == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sinkA__DOT__putbuffer__DOT___tail_ext_R0_data)))
                ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sinkA__DOT__putbuffer__DOT__freeIdx)
                : ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sinkA__DOT__putbuffer_io_pop_valid)
                    ? ((0x27U >= (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sinkA__DOT__putbuffer__DOT___head_ext_R0_data))
                        ? vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sinkA__DOT__putbuffer__DOT__next_ext__DOT__Memory
                       [vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sinkA__DOT__putbuffer__DOT___head_ext_R0_data]
                        : 0U) : 0U));
        if ((0x27U >= (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sourceD__DOT__s2_req_put))) {
            vlSelfRef.__VdlyVal__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sinkA__DOT__putbuffer__DOT__head_ext__DOT__Memory__v0 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sinkA__DOT__putbuffer__DOT__head_ext__DOT____Vlvbound_h77a2baa6__0;
            vlSelfRef.__VdlyDim0__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sinkA__DOT__putbuffer__DOT__head_ext__DOT__Memory__v0 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sourceD__DOT__s2_req_put;
            vlSelfRef.__VdlySet__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sinkA__DOT__putbuffer__DOT__head_ext__DOT__Memory__v0 = 1U;
        }
    }
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__578(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__578\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if (((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sinkA__DOT__putbuffer__DOT____VdfgRegularize_h7d1162c1_0_0)) 
         & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sinkA__DOT__putbuffer__DOT__data_MPORT_en))) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sinkA__DOT__putbuffer__DOT__head_ext__DOT____Vlvbound_h947c273e__0 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sinkA__DOT__putbuffer__DOT__freeIdx;
        if ((0x27U >= (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT___sinkA_io_req_bits_put))) {
            vlSelfRef.__VdlyVal__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sinkA__DOT__putbuffer__DOT__head_ext__DOT__Memory__v1 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sinkA__DOT__putbuffer__DOT__head_ext__DOT____Vlvbound_h947c273e__0;
            vlSelfRef.__VdlyDim0__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sinkA__DOT__putbuffer__DOT__head_ext__DOT__Memory__v1 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT___sinkA_io_req_bits_put;
            vlSelfRef.__VdlySet__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sinkA__DOT__putbuffer__DOT__head_ext__DOT__Memory__v1 = 1U;
        }
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sinkC__DOT__putbuffer_io_pop_valid) {
        vlSelfRef.__VdlyVal__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sinkC__DOT__putbuffer__DOT__head_ext__DOT__Memory__v0 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sinkC__DOT__putbuffer__DOT____Vcellinp__head_ext__W0_data;
        vlSelfRef.__VdlyDim0__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sinkC__DOT__putbuffer__DOT__head_ext__DOT__Memory__v0 
            = (1U & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sourceD__DOT__s2_req_put));
        vlSelfRef.__VdlySet__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sinkC__DOT__putbuffer__DOT__head_ext__DOT__Memory__v0 = 1U;
    }
    if (((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sinkC__DOT__putbuffer__DOT____VdfgRegularize_h8b8db233_0_0)) 
         & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sinkC__DOT__putbuffer__DOT__data_MPORT_en))) {
        vlSelfRef.__VdlyVal__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sinkC__DOT__putbuffer__DOT__head_ext__DOT__Memory__v1 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sinkC__DOT__putbuffer__DOT__data_MPORT_addr;
        vlSelfRef.__VdlyDim0__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sinkC__DOT__putbuffer__DOT__head_ext__DOT__Memory__v1 
            = (1U & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sinkC__DOT__put));
        vlSelfRef.__VdlySet__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sinkC__DOT__putbuffer__DOT__head_ext__DOT__Memory__v1 = 1U;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT___system_auto_cbus_fixedClockNode_anon_out_reset) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sinkA__DOT__putbuffer__DOT__valid = 0ULL;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sinkC__DOT__putbuffer__DOT__valid = 0U;
    } else {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sinkA__DOT__putbuffer__DOT__valid 
            = (0xffffffffffULL & ((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sinkA__DOT__putbuffer__DOT__valid 
                                   & (~ (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sinkA__DOT__putbuffer_io_pop_valid) 
                                          & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sinkA__DOT__putbuffer__DOT___head_ext_R0_data) 
                                             == ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sinkA__DOT__putbuffer_io_pop_valid)
                                                  ? 
                                                 ((0x27U 
                                                   >= (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sourceD__DOT__s2_req_put))
                                                   ? 
                                                  vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sinkA__DOT__putbuffer__DOT__tail_ext__DOT__Memory
                                                  [vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sourceD__DOT__s2_req_put]
                                                   : 0U)
                                                  : 0U)))
                                          ? (1ULL << (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sourceD__DOT__s2_req_put))
                                          : 0ULL))) 
                                  | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sinkA__DOT__putbuffer__DOT__data_MPORT_en)
                                      ? (1ULL << (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT___sinkA_io_req_bits_put))
                                      : 0ULL)));
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sinkC__DOT__putbuffer__DOT__valid 
            = (3U & (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sinkC__DOT__putbuffer__DOT__valid) 
                      & (~ (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sinkC__DOT__putbuffer_io_pop_valid) 
                             & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sinkC__DOT__putbuffer__DOT___head_ext_R0_data) 
                                == ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sinkC__DOT__putbuffer_io_pop_valid)
                                     ? vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sinkC__DOT__putbuffer__DOT__tail_ext__DOT__Memory
                                    [(1U & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sourceD__DOT__s2_req_put))]
                                     : 0U))) ? ((IData)(1U) 
                                                << 
                                                (1U 
                                                 & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sourceD__DOT__s2_req_put)))
                             : 0U))) | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sinkC__DOT__putbuffer__DOT__data_MPORT_en)
                                         ? ((IData)(1U) 
                                            << (1U 
                                                & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sinkC__DOT__put)))
                                         : 0U)));
    }
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__579(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__579\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__io_fdiv_resp_fdivsqrt__DOT__r_req_valid 
        = (1U & ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__io_fdiv_resp_fdivsqrt__DOT___GEN_2)) 
                 & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__io_fdiv_resp_fdivsqrt__DOT___GEN)
                     ? (~ ((0U != ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT___lsu_io_dmem_brupdate_b1_mispredict_mask) 
                                   & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__exe_uop_bits_br_mask))) 
                           | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline_io_flush_pipeline_REG)))
                     : ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__io_fdiv_resp_fdivsqrt__DOT__r_req_valid) 
                        & (~ ((0U != (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__io_fdiv_resp_fdivsqrt__DOT___r_req_out_valid_T)) 
                              | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline_io_flush_pipeline_REG)))))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__io_fdiv_resp_fdivsqrt__DOT__r_out_valid 
        = ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__io_fdiv_resp_fdivsqrt__DOT___GEN_2)) 
           & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__io_fdiv_resp_fdivsqrt__DOT___GEN_1)
               ? ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__io_fdiv_resp_fdivsqrt__DOT__r_req_valid) 
                  & (~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__io_fdiv_resp_fdivsqrt__DOT__kill)))
               : ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__io_fdiv_resp_fdivsqrt__DOT___GEN_0)
                   ? ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__io_fdiv_resp_fdivsqrt__DOT__r_req_valid) 
                      & (~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__io_fdiv_resp_fdivsqrt__DOT__kill)))
                   : ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__io_fdiv_resp_fdivsqrt__DOT__r_out_valid) 
                      & (~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__io_fdiv_resp_fdivsqrt__DOT__kill))))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sinkA__DOT__lists 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT___system_auto_cbus_fixedClockNode_anon_out_reset)
            ? 0ULL : ((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sinkA__DOT__lists 
                       | (((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sinkA__DOT___io_req_valid_T) 
                             & (~ ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT___InclusiveCache_inner_TLBuffer_auto_out_a_bits_opcode) 
                                   >> 2U))) & (~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sinkA__DOT__req_block))) 
                           & (~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sinkA__DOT__buf_block)))
                           ? vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sinkA__DOT___GEN
                           : 0ULL)) & (~ (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sinkA__DOT__putbuffer_io_pop_valid) 
                                           & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sourceD__DOT__s2_last))
                                           ? (1ULL 
                                              << (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sourceD__DOT__s2_req_put))
                                           : 0ULL))));
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__sdq_enq) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__sdq_ext__DOT____Vlvbound_ha3843065__0 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__s2_req_0_data;
        if ((0x10U >= (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__sdq_alloc_id))) {
            vlSelfRef.__VdlyVal__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__sdq_ext__DOT__Memory__v0 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__sdq_ext__DOT____Vlvbound_ha3843065__0;
            vlSelfRef.__VdlyDim0__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__sdq_ext__DOT__Memory__v0 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__sdq_alloc_id;
            vlSelfRef.__VdlySet__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__sdq_ext__DOT__Memory__v0 = 1U;
        }
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_execute_queue__DOT__do_enq) {
        vlSelfRef.__VdlyVal__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_execute_queue__DOT__ram_ext__DOT__Memory__v0[0U] 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_execute_queue__DOT____Vcellinp__ram_ext__W0_data[0U];
        vlSelfRef.__VdlyVal__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_execute_queue__DOT__ram_ext__DOT__Memory__v0[1U] 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_execute_queue__DOT____Vcellinp__ram_ext__W0_data[1U];
        vlSelfRef.__VdlyVal__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_execute_queue__DOT__ram_ext__DOT__Memory__v0[2U] 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_execute_queue__DOT____Vcellinp__ram_ext__W0_data[2U];
        vlSelfRef.__VdlyVal__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_execute_queue__DOT__ram_ext__DOT__Memory__v0[3U] 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_execute_queue__DOT____Vcellinp__ram_ext__W0_data[3U];
        vlSelfRef.__VdlyVal__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_execute_queue__DOT__ram_ext__DOT__Memory__v0[4U] 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_execute_queue__DOT____Vcellinp__ram_ext__W0_data[4U];
        vlSelfRef.__VdlyVal__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_execute_queue__DOT__ram_ext__DOT__Memory__v0[5U] 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_execute_queue__DOT____Vcellinp__ram_ext__W0_data[5U];
        vlSelfRef.__VdlyVal__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_execute_queue__DOT__ram_ext__DOT__Memory__v0[6U] 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_execute_queue__DOT____Vcellinp__ram_ext__W0_data[6U];
        vlSelfRef.__VdlyVal__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_execute_queue__DOT__ram_ext__DOT__Memory__v0[7U] 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_execute_queue__DOT____Vcellinp__ram_ext__W0_data[7U];
        vlSelfRef.__VdlyVal__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_execute_queue__DOT__ram_ext__DOT__Memory__v0[8U] 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_execute_queue__DOT____Vcellinp__ram_ext__W0_data[8U];
        vlSelfRef.__VdlyVal__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_execute_queue__DOT__ram_ext__DOT__Memory__v0[9U] 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_execute_queue__DOT____Vcellinp__ram_ext__W0_data[9U];
        vlSelfRef.__VdlyVal__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_execute_queue__DOT__ram_ext__DOT__Memory__v0[0xaU] 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_execute_queue__DOT____Vcellinp__ram_ext__W0_data[0xaU];
        vlSelfRef.__VdlyVal__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_execute_queue__DOT__ram_ext__DOT__Memory__v0[0xbU] 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_execute_queue__DOT____Vcellinp__ram_ext__W0_data[0xbU];
        vlSelfRef.__VdlyVal__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_execute_queue__DOT__ram_ext__DOT__Memory__v0[0xcU] 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_execute_queue__DOT____Vcellinp__ram_ext__W0_data[0xcU];
        vlSelfRef.__VdlyVal__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_execute_queue__DOT__ram_ext__DOT__Memory__v0[0xdU] 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_execute_queue__DOT____Vcellinp__ram_ext__W0_data[0xdU];
        vlSelfRef.__VdlyVal__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_execute_queue__DOT__ram_ext__DOT__Memory__v0[0xeU] 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_execute_queue__DOT____Vcellinp__ram_ext__W0_data[0xeU];
        vlSelfRef.__VdlyVal__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_execute_queue__DOT__ram_ext__DOT__Memory__v0[0xfU] 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_execute_queue__DOT____Vcellinp__ram_ext__W0_data[0xfU];
        vlSelfRef.__VdlyDim0__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_execute_queue__DOT__ram_ext__DOT__Memory__v0 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_execute_queue__DOT__enq_ptr_value;
        vlSelfRef.__VdlySet__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_execute_queue__DOT__ram_ext__DOT__Memory__v0 = 1U;
    }
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__580(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__580\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if ((1U & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_execute_queue_io_deq_ready) 
               | (~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__can_fire_store_commit_slow_0))))) {
        vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__store_blocked_counter = 0U;
    } else if (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__can_fire_store_commit_slow_0) 
                & (~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_execute_queue_io_deq_ready)))) {
        vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__store_blocked_counter 
            = ((0xfU == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__store_blocked_counter))
                ? 0xfU : (0xfU & ((IData)(1U) + (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__store_blocked_counter))));
    }
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_addr_0_valid 
        = ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_480)) 
           & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_578)
               ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___stq_addr_valid_T_3)
               : ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_567)
                   ? ((~ ((0U == (7U & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_enq_retry_idx))) 
                          | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_542))) 
                      & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_addr_0_valid))
                   : ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_542)) 
                      & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_addr_0_valid)))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_addr_1_valid 
        = ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_482)) 
           & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_579)
               ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___stq_addr_valid_T_3)
               : ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_567)
                   ? ((~ ((1U == (7U & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_enq_retry_idx))) 
                          | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_544))) 
                      & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_addr_1_valid))
                   : ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_544)) 
                      & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_addr_1_valid)))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_addr_2_valid 
        = ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_484)) 
           & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_580)
               ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___stq_addr_valid_T_3)
               : ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_567)
                   ? ((~ ((2U == (7U & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_enq_retry_idx))) 
                          | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_546))) 
                      & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_addr_2_valid))
                   : ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_546)) 
                      & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_addr_2_valid)))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_addr_3_valid 
        = ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_486)) 
           & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_581)
               ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___stq_addr_valid_T_3)
               : ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_567)
                   ? ((~ ((3U == (7U & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_enq_retry_idx))) 
                          | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_548))) 
                      & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_addr_3_valid))
                   : ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_548)) 
                      & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_addr_3_valid)))));
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__581(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__581\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_addr_4_valid 
        = ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_488)) 
           & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_582)
               ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___stq_addr_valid_T_3)
               : ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_567)
                   ? ((~ ((4U == (7U & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_enq_retry_idx))) 
                          | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_550))) 
                      & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_addr_4_valid))
                   : ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_550)) 
                      & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_addr_4_valid)))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_addr_5_valid 
        = ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_490)) 
           & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_583)
               ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___stq_addr_valid_T_3)
               : ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_567)
                   ? ((~ ((5U == (7U & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_enq_retry_idx))) 
                          | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_552))) 
                      & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_addr_5_valid))
                   : ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_552)) 
                      & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_addr_5_valid)))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_addr_6_valid 
        = ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_492)) 
           & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_584)
               ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___stq_addr_valid_T_3)
               : ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_567)
                   ? ((~ ((6U == (7U & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_enq_retry_idx))) 
                          | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_554))) 
                      & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_addr_6_valid))
                   : ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_554)) 
                      & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_addr_6_valid)))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_addr_7_valid 
        = ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_494)) 
           & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_585)
               ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___stq_addr_valid_T_3)
               : ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_567)
                   ? ((~ ((7U == (7U & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_enq_retry_idx))) 
                          | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_556))) 
                      & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_addr_7_valid))
                   : ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_556)) 
                      & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_addr_7_valid)))));
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_valid_7) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_7_br_mask 
            = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_7_br_mask) 
               & (~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT___lsu_io_dmem_brupdate_b1_resolve_mask)));
    } else if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_556) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_7_br_mask 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__ldq_uop_out_br_mask;
    }
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__582(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__582\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_valid_6) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_6_br_mask 
            = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_6_br_mask) 
               & (~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT___lsu_io_dmem_brupdate_b1_resolve_mask)));
    } else if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_554) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_6_br_mask 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__ldq_uop_out_br_mask;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_valid_2) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_2_br_mask 
            = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_2_br_mask) 
               & (~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT___lsu_io_dmem_brupdate_b1_resolve_mask)));
    } else if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_546) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_2_br_mask 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__ldq_uop_out_br_mask;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_valid_5) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_5_br_mask 
            = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_5_br_mask) 
               & (~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT___lsu_io_dmem_brupdate_b1_resolve_mask)));
    } else if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_552) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_5_br_mask 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__ldq_uop_out_br_mask;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_valid_4) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_4_br_mask 
            = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_4_br_mask) 
               & (~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT___lsu_io_dmem_brupdate_b1_resolve_mask)));
    } else if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_550) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_4_br_mask 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__ldq_uop_out_br_mask;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_valid_1) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_1_br_mask 
            = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_1_br_mask) 
               & (~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT___lsu_io_dmem_brupdate_b1_resolve_mask)));
    } else if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_544) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_1_br_mask 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__ldq_uop_out_br_mask;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_valid_3) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_3_br_mask 
            = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_3_br_mask) 
               & (~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT___lsu_io_dmem_brupdate_b1_resolve_mask)));
    } else if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_548) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_3_br_mask 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__ldq_uop_out_br_mask;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT___system_auto_cbus_fixedClockNode_anon_out_reset) {
        vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_5__DOT__w_releaseack = 1U;
        vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_5__DOT__s_flush = 1U;
    } else if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_5__DOT___GEN_96) {
        vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_5__DOT__w_releaseack 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_5__DOT___GEN_101;
        vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_5__DOT__s_flush 
            = (1U & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_5__DOT__new_request_prio_2) 
                     | (~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_5__DOT__new_request_control))));
    } else {
        vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_5__DOT__w_releaseack 
            = ((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT____Vcellinp__mshrs_5__io_sinkd_valid) 
                 & (~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_0__DOT___GEN_107))) 
                & (6U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT___sinkD_io_resp_bits_opcode))) 
               | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_5__DOT__w_releaseack));
        vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_5__DOT__s_flush 
            = (1U & ((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshr_selectOH) 
                       >> 5U) & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_5__DOT__w_releaseack)) 
                     | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_5__DOT__s_flush)));
    }
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__583(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__583\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__s1_req_0_uop_ldq_idx 
        = (0xfU & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT___s1_valid_T_8)
                    ? ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_303)
                        ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__exe_tlb_uop_0_ldq_idx)
                        : ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_execute_queue_io_deq_ready)
                            ? ((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_execute_queue__DOT__ram_ext__DOT__Memory
                                [vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_execute_queue__DOT__deq_ptr_value][8U] 
                                << 5U) | (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_execute_queue__DOT__ram_ext__DOT__Memory
                                          [vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_execute_queue__DOT__deq_ptr_value][8U] 
                                          >> 0x1bU))
                            : ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__will_fire_load_wakeup_0)
                                ? (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_89 
                                   >> (0x1fU & VL_SHIFTL_III(5,5,32, 
                                                             (7U 
                                                              & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__ldq_wakeup_idx)), 2U)))
                                : 0U))) : ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT___GEN_10)
                                            ? 0U : 
                                           ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT___mshrs_0_io_replay_valid)
                                             ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_0__DOT__rpq__DOT__out_uop_ldq_idx)
                                             : (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_1__DOT__rpq__DOT__out_uop_ldq_idx)))));
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__retry_queue__DOT__do_enq) {
        vlSelfRef.__VdlyVal__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__retry_queue__DOT__ram_ext__DOT__Memory__v0 
            = (0xffffffffffULL & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__can_enq_store_retry)
                                   ? ((0x13fU >= (0x1ffU 
                                                  & ((IData)(0x28U) 
                                                     * 
                                                     (7U 
                                                      & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_enq_retry_idx)))))
                                       ? (((QData)((IData)(
                                                           vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_269[
                                                           (((IData)(0x27U) 
                                                             + 
                                                             (0x1ffU 
                                                              & ((IData)(0x28U) 
                                                                 * 
                                                                 (7U 
                                                                  & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_enq_retry_idx))))) 
                                                            >> 5U)])) 
                                           << ((0U 
                                                == 
                                                (0x1fU 
                                                 & ((IData)(0x28U) 
                                                    * 
                                                    (7U 
                                                     & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_enq_retry_idx)))))
                                                ? 0x20U
                                                : ((IData)(0x40U) 
                                                   - 
                                                   (0x1fU 
                                                    & ((IData)(0x28U) 
                                                       * 
                                                       (7U 
                                                        & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_enq_retry_idx))))))) 
                                          | (((0U == 
                                               (0x1fU 
                                                & ((IData)(0x28U) 
                                                   * 
                                                   (7U 
                                                    & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_enq_retry_idx)))))
                                               ? 0ULL
                                               : ((QData)((IData)(
                                                                  vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_269[
                                                                  (((IData)(0x1fU) 
                                                                    + 
                                                                    (0x1ffU 
                                                                     & ((IData)(0x28U) 
                                                                        * 
                                                                        (7U 
                                                                         & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_enq_retry_idx))))) 
                                                                   >> 5U)])) 
                                                  << 
                                                  ((IData)(0x20U) 
                                                   - 
                                                   (0x1fU 
                                                    & ((IData)(0x28U) 
                                                       * 
                                                       (7U 
                                                        & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_enq_retry_idx))))))) 
                                             | ((QData)((IData)(
                                                                vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_269[
                                                                (0xfU 
                                                                 & (((IData)(0x28U) 
                                                                     * 
                                                                     (7U 
                                                                      & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_enq_retry_idx))) 
                                                                    >> 5U))])) 
                                                >> 
                                                (0x1fU 
                                                 & ((IData)(0x28U) 
                                                    * 
                                                    (7U 
                                                     & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_enq_retry_idx)))))))
                                       : 0ULL) : ((0x13fU 
                                                   >= 
                                                   (0x1ffU 
                                                    & ((IData)(0x28U) 
                                                       * 
                                                       (7U 
                                                        & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__ldq_enq_retry_idx)))))
                                                   ? 
                                                  (((QData)((IData)(
                                                                    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_259[
                                                                    (((IData)(0x27U) 
                                                                      + 
                                                                      (0x1ffU 
                                                                       & ((IData)(0x28U) 
                                                                          * 
                                                                          (7U 
                                                                           & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__ldq_enq_retry_idx))))) 
                                                                     >> 5U)])) 
                                                    << 
                                                    ((0U 
                                                      == 
                                                      (0x1fU 
                                                       & ((IData)(0x28U) 
                                                          * 
                                                          (7U 
                                                           & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__ldq_enq_retry_idx)))))
                                                      ? 0x20U
                                                      : 
                                                     ((IData)(0x40U) 
                                                      - 
                                                      (0x1fU 
                                                       & ((IData)(0x28U) 
                                                          * 
                                                          (7U 
                                                           & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__ldq_enq_retry_idx))))))) 
                                                   | (((0U 
                                                        == 
                                                        (0x1fU 
                                                         & ((IData)(0x28U) 
                                                            * 
                                                            (7U 
                                                             & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__ldq_enq_retry_idx)))))
                                                        ? 0ULL
                                                        : 
                                                       ((QData)((IData)(
                                                                        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_259[
                                                                        (((IData)(0x1fU) 
                                                                          + 
                                                                          (0x1ffU 
                                                                           & ((IData)(0x28U) 
                                                                              * 
                                                                              (7U 
                                                                               & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__ldq_enq_retry_idx))))) 
                                                                         >> 5U)])) 
                                                        << 
                                                        ((IData)(0x20U) 
                                                         - 
                                                         (0x1fU 
                                                          & ((IData)(0x28U) 
                                                             * 
                                                             (7U 
                                                              & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__ldq_enq_retry_idx))))))) 
                                                      | ((QData)((IData)(
                                                                         vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_259[
                                                                         (0xfU 
                                                                          & (((IData)(0x28U) 
                                                                              * 
                                                                              (7U 
                                                                               & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__ldq_enq_retry_idx))) 
                                                                             >> 5U))])) 
                                                         >> 
                                                         (0x1fU 
                                                          & ((IData)(0x28U) 
                                                             * 
                                                             (7U 
                                                              & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__ldq_enq_retry_idx)))))))
                                                   : 0ULL)));
        vlSelfRef.__VdlyDim0__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__retry_queue__DOT__ram_ext__DOT__Memory__v0 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__retry_queue__DOT__enq_ptr_value;
        vlSelfRef.__VdlySet__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__retry_queue__DOT__ram_ext__DOT__Memory__v0 = 1U;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT___system_auto_cbus_fixedClockNode_anon_out_reset) {
        vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_0__DOT__w_grant = 1U;
        vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_0__DOT__w_pprobeack = 1U;
        vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_0__DOT__s_execute = 1U;
    } else if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_0__DOT___GEN_96) {
        vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_0__DOT__w_pprobeack 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_0__DOT___GEN_113;
        vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_0__DOT__s_execute 
            = ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_0__DOT__new_request_prio_2)) 
               & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_0__DOT__new_request_control));
        vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_0__DOT__w_grant 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_0__DOT___GEN_104;
    } else {
        vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_0__DOT__w_pprobeack 
            = ((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT____Vcellinp__mshrs_0__io_sinkc_valid) 
                 & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_0__DOT__last_probe)) 
                & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT___sinkC_io_resp_bits_last) 
                   | (~ (0U != (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_0__DOT__request_offset))))) 
               | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_0__DOT__w_pprobeack));
        vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_0__DOT__s_execute 
            = ((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshr_selectOH) 
                 & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_0__DOT__w_pprobeack)) 
                & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_0__DOT__w_grant)) 
               | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_0__DOT__s_execute));
        if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_0__DOT___GEN_108) {
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_0__DOT__w_grant 
                = (1U & ((~ (0U != (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_0__DOT__request_offset))) 
                         | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT___sinkD_io_resp_bits_last)));
        }
    }
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__584(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__584\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT___system_auto_cbus_fixedClockNode_anon_out_reset) {
        vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_1__DOT__w_grant = 1U;
        vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_1__DOT__w_pprobeack = 1U;
        vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_1__DOT__s_execute = 1U;
        vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_2__DOT__w_grant = 1U;
        vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_2__DOT__w_pprobeack = 1U;
        vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_2__DOT__s_execute = 1U;
    } else {
        if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_1__DOT___GEN_96) {
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_1__DOT__w_pprobeack 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_1__DOT___GEN_113;
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_1__DOT__s_execute 
                = ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_1__DOT__new_request_prio_2)) 
                   & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_1__DOT__new_request_control));
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_1__DOT__w_grant 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_1__DOT___GEN_104;
        } else {
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_1__DOT__w_pprobeack 
                = ((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT____Vcellinp__mshrs_1__io_sinkc_valid) 
                     & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_1__DOT__last_probe)) 
                    & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT___sinkC_io_resp_bits_last) 
                       | (~ (0U != (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_1__DOT__request_offset))))) 
                   | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_1__DOT__w_pprobeack));
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_1__DOT__s_execute 
                = (((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshr_selectOH) 
                      >> 1U) & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_1__DOT__w_pprobeack)) 
                    & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_1__DOT__w_grant)) 
                   | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_1__DOT__s_execute));
            if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_1__DOT___GEN_108) {
                vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_1__DOT__w_grant 
                    = (1U & ((~ (0U != (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_1__DOT__request_offset))) 
                             | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT___sinkD_io_resp_bits_last)));
            }
        }
        if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_2__DOT___GEN_96) {
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_2__DOT__w_pprobeack 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_2__DOT___GEN_113;
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_2__DOT__s_execute 
                = ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_2__DOT__new_request_prio_2)) 
                   & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_2__DOT__new_request_control));
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_2__DOT__w_grant 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_2__DOT___GEN_104;
        } else {
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_2__DOT__w_pprobeack 
                = ((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT____Vcellinp__mshrs_2__io_sinkc_valid) 
                     & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_2__DOT__last_probe)) 
                    & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT___sinkC_io_resp_bits_last) 
                       | (~ (0U != (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_2__DOT__request_offset))))) 
                   | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_2__DOT__w_pprobeack));
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_2__DOT__s_execute 
                = (((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshr_selectOH) 
                      >> 2U) & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_2__DOT__w_pprobeack)) 
                    & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_2__DOT__w_grant)) 
                   | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_2__DOT__s_execute));
            if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_2__DOT___GEN_108) {
                vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_2__DOT__w_grant 
                    = (1U & ((~ (0U != (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_2__DOT__request_offset))) 
                             | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT___sinkD_io_resp_bits_last)));
            }
        }
    }
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__585(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__585\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT___system_auto_cbus_fixedClockNode_anon_out_reset) {
        vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_3__DOT__w_grant = 1U;
        vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_3__DOT__w_pprobeack = 1U;
        vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_3__DOT__s_execute = 1U;
        vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_4__DOT__w_grant = 1U;
        vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_4__DOT__w_pprobeack = 1U;
        vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_4__DOT__s_execute = 1U;
    } else {
        if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_3__DOT___GEN_96) {
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_3__DOT__w_pprobeack 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_3__DOT___GEN_113;
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_3__DOT__s_execute 
                = ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_3__DOT__new_request_prio_2)) 
                   & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_3__DOT__new_request_control));
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_3__DOT__w_grant 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_3__DOT___GEN_104;
        } else {
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_3__DOT__w_pprobeack 
                = ((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT____Vcellinp__mshrs_3__io_sinkc_valid) 
                     & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_3__DOT__last_probe)) 
                    & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT___sinkC_io_resp_bits_last) 
                       | (~ (0U != (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_3__DOT__request_offset))))) 
                   | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_3__DOT__w_pprobeack));
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_3__DOT__s_execute 
                = (((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshr_selectOH) 
                      >> 3U) & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_3__DOT__w_pprobeack)) 
                    & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_3__DOT__w_grant)) 
                   | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_3__DOT__s_execute));
            if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_3__DOT___GEN_108) {
                vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_3__DOT__w_grant 
                    = (1U & ((~ (0U != (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_3__DOT__request_offset))) 
                             | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT___sinkD_io_resp_bits_last)));
            }
        }
        if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_4__DOT___GEN_96) {
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_4__DOT__w_pprobeack 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_4__DOT___GEN_113;
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_4__DOT__s_execute 
                = ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_4__DOT__new_request_prio_2)) 
                   & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_4__DOT__new_request_control));
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_4__DOT__w_grant 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_4__DOT___GEN_104;
        } else {
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_4__DOT__w_pprobeack 
                = ((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT____Vcellinp__mshrs_4__io_sinkc_valid) 
                     & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_4__DOT__last_probe)) 
                    & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT___sinkC_io_resp_bits_last) 
                       | (~ (0U != (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_4__DOT__request_offset))))) 
                   | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_4__DOT__w_pprobeack));
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_4__DOT__s_execute 
                = (((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshr_selectOH) 
                      >> 4U) & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_4__DOT__w_pprobeack)) 
                    & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_4__DOT__w_grant)) 
                   | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_4__DOT__s_execute));
            if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_4__DOT___GEN_108) {
                vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_4__DOT__w_grant 
                    = (1U & ((~ (0U != (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_4__DOT__request_offset))) 
                             | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT___sinkD_io_resp_bits_last)));
            }
        }
    }
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__586(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__586\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_5__DOT__request_valid 
        = ((1U & (~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT___system_auto_cbus_fixedClockNode_anon_out_reset))) 
           && ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT____Vcellinp__mshrs_5__io_allocate_valid) 
               | ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_5__DOT___GEN_98)) 
                  & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_5__DOT__request_valid))));
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT___s1_valid_T_8) {
        if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_303) {
            if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___ldq_idx_T) {
                vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__s1_req_0_uop_is_amo 
                    = (1U & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_55) 
                             >> (7U & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_exe_unit_1__DOT__exe_uop_bits_ldq_idx))));
                vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__s1_req_0_uop_mem_signed 
                    = (1U & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_109) 
                             >> (7U & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_exe_unit_1__DOT__exe_uop_bits_ldq_idx))));
            } else if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__will_fire_store_agen_0) {
                vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__s1_req_0_uop_is_amo 
                    = (1U & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_173) 
                             >> (7U & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_exe_unit_1__DOT__exe_uop_bits_stq_idx))));
                vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__s1_req_0_uop_mem_signed 
                    = (1U & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_227) 
                             >> (7U & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_exe_unit_1__DOT__exe_uop_bits_stq_idx))));
            } else {
                vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__s1_req_0_uop_is_amo 
                    = (1U & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__retry_queue_io_deq_ready) 
                             & ((((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__retry_queue__DOT__uops_7_is_amo) 
                                    << 7U) | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__retry_queue__DOT__uops_6_is_amo) 
                                              << 6U)) 
                                  | (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__retry_queue__DOT__uops_5_is_amo) 
                                      << 5U) | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__retry_queue__DOT__uops_4_is_amo) 
                                                << 4U))) 
                                 | ((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__retry_queue__DOT__uops_3_is_amo) 
                                      << 3U) | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__retry_queue__DOT__uops_2_is_amo) 
                                                << 2U)) 
                                    | (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__retry_queue__DOT__uops_1_is_amo) 
                                        << 1U) | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__retry_queue__DOT__uops_0_is_amo)))) 
                                >> (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__retry_queue__DOT__deq_ptr_value))));
                vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__s1_req_0_uop_mem_signed 
                    = (1U & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__retry_queue_io_deq_ready) 
                             & ((((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__retry_queue__DOT__uops_7_mem_signed) 
                                    << 7U) | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__retry_queue__DOT__uops_6_mem_signed) 
                                              << 6U)) 
                                  | (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__retry_queue__DOT__uops_5_mem_signed) 
                                      << 5U) | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__retry_queue__DOT__uops_4_mem_signed) 
                                                << 4U))) 
                                 | ((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__retry_queue__DOT__uops_3_mem_signed) 
                                      << 3U) | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__retry_queue__DOT__uops_2_mem_signed) 
                                                << 2U)) 
                                    | (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__retry_queue__DOT__uops_1_mem_signed) 
                                        << 1U) | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__retry_queue__DOT__uops_0_mem_signed)))) 
                                >> (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__retry_queue__DOT__deq_ptr_value))));
            }
        } else if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_execute_queue_io_deq_ready) {
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__s1_req_0_uop_is_amo 
                = (1U & (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_execute_queue__DOT__ram_ext__DOT__Memory
                         [vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_execute_queue__DOT__deq_ptr_value][0xbU] 
                         >> 9U));
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__s1_req_0_uop_mem_signed 
                = (1U & (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_execute_queue__DOT__ram_ext__DOT__Memory
                         [vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_execute_queue__DOT__deq_ptr_value][5U] 
                         >> 6U));
        } else {
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__s1_req_0_uop_is_amo 
                = (1U & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__will_fire_load_wakeup_0) 
                         & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_55) 
                            >> (7U & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__ldq_wakeup_idx)))));
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__s1_req_0_uop_mem_signed 
                = (1U & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__will_fire_load_wakeup_0) 
                         & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_109) 
                            >> (7U & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__ldq_wakeup_idx)))));
        }
    } else {
        vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__s1_req_0_uop_is_amo 
            = (1U & ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT___GEN_10)) 
                     & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT___mshrs_0_io_replay_valid)
                         ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_0__DOT__rpq__DOT__out_uop_is_amo)
                         : (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_1__DOT__rpq__DOT__out_uop_is_amo))));
        vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__s1_req_0_uop_mem_signed 
            = (1U & ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT___GEN_10)) 
                     & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT___mshrs_0_io_replay_valid)
                         ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_0__DOT__rpq__DOT__out_uop_mem_signed)
                         : (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_1__DOT__rpq__DOT__out_uop_mem_signed))));
    }
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__587(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__587\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT___system_auto_cbus_fixedClockNode_anon_out_reset) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__dec_brmask_logic__DOT__branch_mask = 0U;
        vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_0__DOT__w_releaseack = 1U;
        vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_0__DOT__s_flush = 1U;
    } else {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__dec_brmask_logic__DOT__branch_mask 
            = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__dec_brmask_logic_io_flush_pipeline_REG)
                ? 0U : (((((- (IData)(((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT___core_io_ifu_fetchpacket_ready) 
                                       & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT____VdfgRegularize_h8fa566d8_0_6)))) 
                           & ((1U & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__dec_brmask_logic__DOT__branch_mask))
                               ? ((2U & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__dec_brmask_logic__DOT__branch_mask))
                                   ? ((4U & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__dec_brmask_logic__DOT__branch_mask))
                                       ? ((8U & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__dec_brmask_logic__DOT__branch_mask))
                                           ? ((0x10U 
                                               & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__dec_brmask_logic__DOT__branch_mask))
                                               ? ((0x20U 
                                                   & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__dec_brmask_logic__DOT__branch_mask))
                                                   ? 
                                                  ((0x40U 
                                                    & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__dec_brmask_logic__DOT__branch_mask))
                                                    ? 
                                                   (0x80U 
                                                    & ((~ 
                                                        ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__dec_brmask_logic__DOT__branch_mask) 
                                                         >> 7U)) 
                                                       << 7U))
                                                    : 0x40U)
                                                   : 0x20U)
                                               : 0x10U)
                                           : 8U) : 4U)
                                   : 2U) : 1U)) | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__dec_brmask_logic__DOT__branch_mask)) 
                         & (~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT___lsu_io_dmem_brupdate_b1_resolve_mask))) 
                        & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__b2_mispredict)
                            ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__b2_uop_br_mask)
                            : 0xffU)));
        if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_0__DOT___GEN_96) {
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_0__DOT__w_releaseack 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_0__DOT___GEN_101;
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_0__DOT__s_flush 
                = (1U & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_0__DOT__new_request_prio_2) 
                         | (~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_0__DOT__new_request_control))));
        } else {
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_0__DOT__w_releaseack 
                = ((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT____Vcellinp__mshrs_0__io_sinkd_valid) 
                     & (~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_0__DOT___GEN_107))) 
                    & (6U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT___sinkD_io_resp_bits_opcode))) 
                   | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_0__DOT__w_releaseack));
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_0__DOT__s_flush 
                = (1U & (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshr_selectOH) 
                          & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_0__DOT__w_releaseack)) 
                         | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_0__DOT__s_flush)));
        }
    }
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__588(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__588\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT___system_auto_cbus_fixedClockNode_anon_out_reset) {
        vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_1__DOT__w_releaseack = 1U;
        vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_1__DOT__s_flush = 1U;
        vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_2__DOT__w_releaseack = 1U;
        vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_2__DOT__s_flush = 1U;
        vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_3__DOT__w_releaseack = 1U;
        vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_3__DOT__s_flush = 1U;
    } else {
        if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_1__DOT___GEN_96) {
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_1__DOT__w_releaseack 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_1__DOT___GEN_101;
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_1__DOT__s_flush 
                = (1U & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_1__DOT__new_request_prio_2) 
                         | (~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_1__DOT__new_request_control))));
        } else {
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_1__DOT__w_releaseack 
                = ((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT____Vcellinp__mshrs_1__io_sinkd_valid) 
                     & (~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_0__DOT___GEN_107))) 
                    & (6U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT___sinkD_io_resp_bits_opcode))) 
                   | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_1__DOT__w_releaseack));
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_1__DOT__s_flush 
                = (1U & ((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshr_selectOH) 
                           >> 1U) & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_1__DOT__w_releaseack)) 
                         | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_1__DOT__s_flush)));
        }
        if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_2__DOT___GEN_96) {
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_2__DOT__w_releaseack 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_2__DOT___GEN_101;
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_2__DOT__s_flush 
                = (1U & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_2__DOT__new_request_prio_2) 
                         | (~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_2__DOT__new_request_control))));
        } else {
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_2__DOT__w_releaseack 
                = ((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT____Vcellinp__mshrs_2__io_sinkd_valid) 
                     & (~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_0__DOT___GEN_107))) 
                    & (6U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT___sinkD_io_resp_bits_opcode))) 
                   | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_2__DOT__w_releaseack));
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_2__DOT__s_flush 
                = (1U & ((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshr_selectOH) 
                           >> 2U) & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_2__DOT__w_releaseack)) 
                         | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_2__DOT__s_flush)));
        }
        if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_3__DOT___GEN_96) {
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_3__DOT__w_releaseack 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_3__DOT___GEN_101;
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_3__DOT__s_flush 
                = (1U & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_3__DOT__new_request_prio_2) 
                         | (~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_3__DOT__new_request_control))));
        } else {
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_3__DOT__w_releaseack 
                = ((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT____Vcellinp__mshrs_3__io_sinkd_valid) 
                     & (~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_0__DOT___GEN_107))) 
                    & (6U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT___sinkD_io_resp_bits_opcode))) 
                   | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_3__DOT__w_releaseack));
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_3__DOT__s_flush 
                = (1U & ((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshr_selectOH) 
                           >> 3U) & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_3__DOT__w_releaseack)) 
                         | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_3__DOT__s_flush)));
        }
    }
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__589(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__589\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT___system_auto_cbus_fixedClockNode_anon_out_reset) {
        vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_4__DOT__w_releaseack = 1U;
        vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_4__DOT__s_flush = 1U;
        vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__buffer__DOT__nodeOut_a_q__DOT__deq_ptr_value = 0U;
    } else {
        if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_4__DOT___GEN_96) {
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_4__DOT__w_releaseack 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_4__DOT___GEN_101;
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_4__DOT__s_flush 
                = (1U & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_4__DOT__new_request_prio_2) 
                         | (~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_4__DOT__new_request_control))));
        } else {
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_4__DOT__w_releaseack 
                = ((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT____Vcellinp__mshrs_4__io_sinkd_valid) 
                     & (~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_0__DOT___GEN_107))) 
                    & (6U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT___sinkD_io_resp_bits_opcode))) 
                   | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_4__DOT__w_releaseack));
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_4__DOT__s_flush 
                = (1U & ((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshr_selectOH) 
                           >> 4U) & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_4__DOT__w_releaseack)) 
                         | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_4__DOT__s_flush)));
        }
        if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__buffer__DOT__nodeOut_a_q__DOT__do_deq) {
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__buffer__DOT__nodeOut_a_q__DOT__deq_ptr_value 
                = (1U & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__buffer__DOT__nodeOut_a_q__DOT__deq_ptr_value) 
                         - (IData)(1U)));
        }
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__io_ifpu_resp_queue__DOT__do_enq) {
        vlSelfRef.__VdlyVal__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__io_ifpu_resp_queue__DOT__ram_ext__DOT__Memory__v0[0U] 
            = ((0xffffff80U & vlSelfRef.__VdlyVal__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__io_ifpu_resp_queue__DOT__ram_ext__DOT__Memory__v0[0U]) 
               | (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__io_ifpu_resp_ifpu__DOT__pipe__DOT__uops_1_valid) 
                   << 5U) | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__io_ifpu_resp_ifpu__DOT__ifpu__DOT__io_out_pipe_b_exc)));
        vlSelfRef.__VdlyVal__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__io_ifpu_resp_queue__DOT__ram_ext__DOT__Memory__v0[0U] 
            = ((0x7fU & vlSelfRef.__VdlyVal__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__io_ifpu_resp_queue__DOT__ram_ext__DOT__Memory__v0[0U]) 
               | (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__io_ifpu_resp_ifpu__DOT__out_double_pipe_pipe_b)
                    ? vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__io_ifpu_resp_ifpu__DOT__ifpu__DOT__io_out_pipe_b_data[0U]
                    : ((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__io_ifpu_resp_ifpu__DOT__ifpu__DOT__io_out_pipe_b_data[1U] 
                        << 0x1fU) | (0x7fffffffU & 
                                     vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__io_ifpu_resp_ifpu__DOT__ifpu__DOT__io_out_pipe_b_data[0U]))) 
                  << 7U));
        vlSelfRef.__VdlyVal__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__io_ifpu_resp_queue__DOT__ram_ext__DOT__Memory__v0[1U] 
            = ((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__io_ifpu_resp_ifpu__DOT__out_double_pipe_pipe_b)
                  ? vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__io_ifpu_resp_ifpu__DOT__ifpu__DOT__io_out_pipe_b_data[0U]
                  : ((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__io_ifpu_resp_ifpu__DOT__ifpu__DOT__io_out_pipe_b_data[1U] 
                      << 0x1fU) | (0x7fffffffU & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__io_ifpu_resp_ifpu__DOT__ifpu__DOT__io_out_pipe_b_data[0U]))) 
                >> 0x19U) | (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__io_ifpu_resp_ifpu__DOT__out_double_pipe_pipe_b)
                               ? vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__io_ifpu_resp_ifpu__DOT__ifpu__DOT__io_out_pipe_b_data[1U]
                               : (IData)((0x1ffe00000ULL 
                                          | (QData)((IData)(
                                                            (0xfffffU 
                                                             | (0x100000U 
                                                                & (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__io_ifpu_resp_ifpu__DOT__ifpu__DOT__io_out_pipe_b_data[0U] 
                                                                   >> 0xbU)))))))) 
                             << 7U));
        vlSelfRef.__VdlyVal__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__io_ifpu_resp_queue__DOT__ram_ext__DOT__Memory__v0[2U] 
            = (0xffU & ((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__io_ifpu_resp_ifpu__DOT__out_double_pipe_pipe_b)
                           ? vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__io_ifpu_resp_ifpu__DOT__ifpu__DOT__io_out_pipe_b_data[1U]
                           : (IData)((0x1ffe00000ULL 
                                      | (QData)((IData)(
                                                        (0xfffffU 
                                                         | (0x100000U 
                                                            & (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__io_ifpu_resp_ifpu__DOT__ifpu__DOT__io_out_pipe_b_data[0U] 
                                                               >> 0xbU)))))))) 
                         >> 0x19U) | (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__io_ifpu_resp_ifpu__DOT__out_double_pipe_pipe_b)
                                        ? vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__io_ifpu_resp_ifpu__DOT__ifpu__DOT__io_out_pipe_b_data[2U]
                                        : (IData)((
                                                   (0x1ffe00000ULL 
                                                    | (QData)((IData)(
                                                                      (0xfffffU 
                                                                       | (0x100000U 
                                                                          & (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__io_ifpu_resp_ifpu__DOT__ifpu__DOT__io_out_pipe_b_data[0U] 
                                                                             >> 0xbU)))))) 
                                                   >> 0x20U))) 
                                      << 7U)));
        vlSelfRef.__VdlyDim0__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__io_ifpu_resp_queue__DOT__ram_ext__DOT__Memory__v0 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__io_ifpu_resp_queue__DOT__enq_ptr_value;
        vlSelfRef.__VdlySet__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__io_ifpu_resp_queue__DOT__ram_ext__DOT__Memory__v0 = 1U;
    }
    vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_6__DOT__request_valid 
        = ((1U & (~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT___system_auto_cbus_fixedClockNode_anon_out_reset))) 
           && ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT____Vcellinp__mshrs_6__io_allocate_valid) 
               | ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_6__DOT___GEN_98)) 
                  & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_6__DOT__request_valid))));
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__buffer__DOT__nodeOut_a_q__DOT__do_enq) {
        vlSelfRef.__VdlyVal__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__buffer__DOT__nodeOut_a_q__DOT__ram_ext__DOT__Memory__v0[0U] 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__buffer__DOT__nodeOut_a_q__DOT__ram_ext__DOT__Memory
            [vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__buffer__DOT__nodeOut_a_q__DOT__deq_ptr_value][0U];
        vlSelfRef.__VdlyVal__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__buffer__DOT__nodeOut_a_q__DOT__ram_ext__DOT__Memory__v0[1U] 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__buffer__DOT__nodeOut_a_q__DOT__ram_ext__DOT__Memory
            [vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__buffer__DOT__nodeOut_a_q__DOT__deq_ptr_value][1U];
        vlSelfRef.__VdlyVal__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__buffer__DOT__nodeOut_a_q__DOT__ram_ext__DOT__Memory__v0[2U] 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__buffer__DOT__nodeOut_a_q__DOT__ram_ext__DOT__Memory
            [vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__buffer__DOT__nodeOut_a_q__DOT__deq_ptr_value][2U];
        vlSelfRef.__VdlyVal__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__buffer__DOT__nodeOut_a_q__DOT__ram_ext__DOT__Memory__v0[3U] 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__buffer__DOT__nodeOut_a_q__DOT__ram_ext__DOT__Memory
            [vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__buffer__DOT__nodeOut_a_q__DOT__deq_ptr_value][3U];
        vlSelfRef.__VdlyDim0__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__buffer__DOT__nodeOut_a_q__DOT__ram_ext__DOT__Memory__v0 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__buffer__DOT__nodeOut_a_q__DOT__enq_ptr_value;
        vlSelfRef.__VdlySet__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__buffer__DOT__nodeOut_a_q__DOT__ram_ext__DOT__Memory__v0 = 1U;
    }
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__627(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__627\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT___system_auto_cbus_fixedClockNode_anon_out_reset) {
        vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_6__DOT__w_rprobeackfirst = 1U;
        vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_6__DOT__s_release = 1U;
        vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_6__DOT__s_pprobe = 1U;
        vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_6__DOT__s_acquire = 1U;
        vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_5__DOT__w_rprobeackfirst = 1U;
        vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_5__DOT__s_release = 1U;
        vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_5__DOT__s_pprobe = 1U;
        vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_5__DOT__s_acquire = 1U;
    } else {
        if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_6__DOT___GEN_96) {
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_6__DOT__w_rprobeackfirst 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_6__DOT___GEN_111;
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_6__DOT__s_release 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_6__DOT___GEN_101;
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_6__DOT__s_pprobe 
                = (1U & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_6__DOT___GEN_113));
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_6__DOT__s_acquire 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_6__DOT___GEN_104;
        } else {
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_6__DOT__w_rprobeackfirst 
                = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_6__DOT___GEN_109) 
                   | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_6__DOT__w_rprobeackfirst));
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_6__DOT__s_release 
                = ((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshr_selectOH) 
                     >> 6U) & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_6__DOT__w_rprobeackfirst)) 
                   | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_6__DOT__s_release));
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_6__DOT__s_pprobe 
                = (1U & (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshr_selectOH) 
                          >> 6U) | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_6__DOT__s_pprobe)));
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_6__DOT__s_acquire 
                = (((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshr_selectOH) 
                      >> 6U) & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_6__DOT__s_release)) 
                    & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_6__DOT__s_pprobe)) 
                   | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_6__DOT__s_acquire));
        }
        if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_5__DOT___GEN_96) {
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_5__DOT__w_rprobeackfirst 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_5__DOT___GEN_111;
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_5__DOT__s_release 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_5__DOT___GEN_101;
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_5__DOT__s_pprobe 
                = (1U & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_5__DOT___GEN_113));
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_5__DOT__s_acquire 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_5__DOT___GEN_104;
        } else {
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_5__DOT__w_rprobeackfirst 
                = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_5__DOT___GEN_109) 
                   | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_5__DOT__w_rprobeackfirst));
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_5__DOT__s_release 
                = ((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshr_selectOH) 
                     >> 5U) & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_5__DOT__w_rprobeackfirst)) 
                   | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_5__DOT__s_release));
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_5__DOT__s_pprobe 
                = (1U & (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshr_selectOH) 
                          >> 5U) | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_5__DOT__s_pprobe)));
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_5__DOT__s_acquire 
                = (((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshr_selectOH) 
                      >> 5U) & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_5__DOT__s_release)) 
                    & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_5__DOT__s_pprobe)) 
                   | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_5__DOT__s_acquire));
        }
    }
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__628(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__628\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT___system_auto_cbus_fixedClockNode_anon_out_reset) {
        vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_0__DOT__w_rprobeackfirst = 1U;
        vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_0__DOT__s_release = 1U;
        vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_0__DOT__s_pprobe = 1U;
        vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_0__DOT__s_acquire = 1U;
        vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_1__DOT__w_rprobeackfirst = 1U;
        vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_1__DOT__s_release = 1U;
        vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_1__DOT__s_pprobe = 1U;
        vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_1__DOT__s_acquire = 1U;
    } else {
        if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_0__DOT___GEN_96) {
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_0__DOT__w_rprobeackfirst 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_0__DOT___GEN_111;
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_0__DOT__s_release 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_0__DOT___GEN_101;
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_0__DOT__s_pprobe 
                = (1U & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_0__DOT___GEN_113));
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_0__DOT__s_acquire 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_0__DOT___GEN_104;
        } else {
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_0__DOT__w_rprobeackfirst 
                = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_0__DOT___GEN_109) 
                   | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_0__DOT__w_rprobeackfirst));
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_0__DOT__s_release 
                = (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshr_selectOH) 
                    & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_0__DOT__w_rprobeackfirst)) 
                   | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_0__DOT__s_release));
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_0__DOT__s_pprobe 
                = (1U & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshr_selectOH) 
                         | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_0__DOT__s_pprobe)));
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_0__DOT__s_acquire 
                = ((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshr_selectOH) 
                     & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_0__DOT__s_release)) 
                    & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_0__DOT__s_pprobe)) 
                   | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_0__DOT__s_acquire));
        }
        if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_1__DOT___GEN_96) {
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_1__DOT__w_rprobeackfirst 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_1__DOT___GEN_111;
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_1__DOT__s_release 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_1__DOT___GEN_101;
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_1__DOT__s_pprobe 
                = (1U & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_1__DOT___GEN_113));
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_1__DOT__s_acquire 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_1__DOT___GEN_104;
        } else {
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_1__DOT__w_rprobeackfirst 
                = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_1__DOT___GEN_109) 
                   | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_1__DOT__w_rprobeackfirst));
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_1__DOT__s_release 
                = ((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshr_selectOH) 
                     >> 1U) & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_1__DOT__w_rprobeackfirst)) 
                   | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_1__DOT__s_release));
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_1__DOT__s_pprobe 
                = (1U & (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshr_selectOH) 
                          >> 1U) | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_1__DOT__s_pprobe)));
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_1__DOT__s_acquire 
                = (((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshr_selectOH) 
                      >> 1U) & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_1__DOT__s_release)) 
                    & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_1__DOT__s_pprobe)) 
                   | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_1__DOT__s_acquire));
        }
    }
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__629(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__629\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT___system_auto_cbus_fixedClockNode_anon_out_reset) {
        vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_2__DOT__w_rprobeackfirst = 1U;
        vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_2__DOT__s_release = 1U;
        vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_2__DOT__s_pprobe = 1U;
        vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_2__DOT__s_acquire = 1U;
        vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_3__DOT__w_rprobeackfirst = 1U;
        vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_3__DOT__s_release = 1U;
        vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_3__DOT__s_pprobe = 1U;
        vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_3__DOT__s_acquire = 1U;
    } else {
        if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_2__DOT___GEN_96) {
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_2__DOT__w_rprobeackfirst 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_2__DOT___GEN_111;
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_2__DOT__s_release 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_2__DOT___GEN_101;
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_2__DOT__s_pprobe 
                = (1U & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_2__DOT___GEN_113));
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_2__DOT__s_acquire 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_2__DOT___GEN_104;
        } else {
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_2__DOT__w_rprobeackfirst 
                = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_2__DOT___GEN_109) 
                   | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_2__DOT__w_rprobeackfirst));
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_2__DOT__s_release 
                = ((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshr_selectOH) 
                     >> 2U) & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_2__DOT__w_rprobeackfirst)) 
                   | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_2__DOT__s_release));
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_2__DOT__s_pprobe 
                = (1U & (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshr_selectOH) 
                          >> 2U) | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_2__DOT__s_pprobe)));
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_2__DOT__s_acquire 
                = (((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshr_selectOH) 
                      >> 2U) & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_2__DOT__s_release)) 
                    & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_2__DOT__s_pprobe)) 
                   | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_2__DOT__s_acquire));
        }
        if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_3__DOT___GEN_96) {
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_3__DOT__w_rprobeackfirst 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_3__DOT___GEN_111;
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_3__DOT__s_release 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_3__DOT___GEN_101;
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_3__DOT__s_pprobe 
                = (1U & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_3__DOT___GEN_113));
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_3__DOT__s_acquire 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_3__DOT___GEN_104;
        } else {
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_3__DOT__w_rprobeackfirst 
                = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_3__DOT___GEN_109) 
                   | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_3__DOT__w_rprobeackfirst));
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_3__DOT__s_release 
                = ((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshr_selectOH) 
                     >> 3U) & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_3__DOT__w_rprobeackfirst)) 
                   | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_3__DOT__s_release));
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_3__DOT__s_pprobe 
                = (1U & (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshr_selectOH) 
                          >> 3U) | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_3__DOT__s_pprobe)));
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_3__DOT__s_acquire 
                = (((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshr_selectOH) 
                      >> 3U) & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_3__DOT__s_release)) 
                    & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_3__DOT__s_pprobe)) 
                   | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_3__DOT__s_acquire));
        }
    }
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__630(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__630\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT___system_auto_cbus_fixedClockNode_anon_out_reset) {
        vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_4__DOT__w_rprobeackfirst = 1U;
        vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_4__DOT__s_release = 1U;
        vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_4__DOT__s_pprobe = 1U;
        vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_4__DOT__s_acquire = 1U;
        vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sinkC__DOT__io_bs_adr_q__DOT__maybe_full = 0U;
    } else {
        if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_4__DOT___GEN_96) {
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_4__DOT__w_rprobeackfirst 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_4__DOT___GEN_111;
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_4__DOT__s_release 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_4__DOT___GEN_101;
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_4__DOT__s_pprobe 
                = (1U & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_4__DOT___GEN_113));
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_4__DOT__s_acquire 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_4__DOT___GEN_104;
        } else {
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_4__DOT__w_rprobeackfirst 
                = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_4__DOT___GEN_109) 
                   | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_4__DOT__w_rprobeackfirst));
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_4__DOT__s_release 
                = ((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshr_selectOH) 
                     >> 4U) & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_4__DOT__w_rprobeackfirst)) 
                   | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_4__DOT__s_release));
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_4__DOT__s_pprobe 
                = (1U & (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshr_selectOH) 
                          >> 4U) | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_4__DOT__s_pprobe)));
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_4__DOT__s_acquire 
                = (((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshr_selectOH) 
                      >> 4U) & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_4__DOT__s_release)) 
                    & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_4__DOT__s_pprobe)) 
                   | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_4__DOT__s_acquire));
        }
        if (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sinkC__DOT__io_bs_adr_q__DOT__do_enq) 
             != (0xfU & ((0xfU >> (3U & (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sinkC__DOT__io_bs_adr_q__DOT__ram 
                                         >> 1U))) & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sinkC__DOT__io_bs_adr_q__DOT__maybe_full))))) {
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sinkC__DOT__io_bs_adr_q__DOT__maybe_full 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sinkC__DOT__io_bs_adr_q__DOT__do_enq;
        }
    }
    if (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__directory__DOT__cc_dir__DOT__cc_dir_ext__DOT__mem_0_0__DOT__ram_RW_0_w_en) 
         & ((~ ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__directory__DOT__wipeCount) 
                >> 0xaU)) | ((IData)(1U) << (7U & (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__directory__DOT__write_q__DOT__ram 
                                                   >> 0x11U)))))) {
        vlSelfRef.__VdlyVal__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__directory__DOT__cc_dir__DOT__cc_dir_ext__DOT__mem_0_0__DOT__ram__v0 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__directory__DOT__cc_dir__DOT__cc_dir_ext__DOT__mem_0_0_RW0_wdata;
        vlSelfRef.__VdlyDim0__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__directory__DOT__cc_dir__DOT__cc_dir_ext__DOT__mem_0_0__DOT__ram__v0 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__directory__DOT____Vcellinp__cc_dir__RW0_addr;
        vlSelfRef.__VdlySet__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__directory__DOT__cc_dir__DOT__cc_dir_ext__DOT__mem_0_0__DOT__ram__v0 = 1U;
    }
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__631(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__631\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__directory__DOT__cc_dir__DOT__cc_dir_ext__DOT__mem_0_0__DOT__ram_RW_0_w_en) 
         & ((~ ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__directory__DOT__wipeCount) 
                >> 0xaU)) | (1U & (((IData)(1U) << 
                                    (7U & (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__directory__DOT__write_q__DOT__ram 
                                           >> 0x11U))) 
                                   >> 4U))))) {
        vlSelfRef.__VdlyVal__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__directory__DOT__cc_dir__DOT__cc_dir_ext__DOT__mem_0_4__DOT__ram__v0 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__directory__DOT__cc_dir__DOT__cc_dir_ext__DOT__mem_0_0_RW0_wdata;
        vlSelfRef.__VdlyDim0__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__directory__DOT__cc_dir__DOT__cc_dir_ext__DOT__mem_0_4__DOT__ram__v0 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__directory__DOT____Vcellinp__cc_dir__RW0_addr;
        vlSelfRef.__VdlySet__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__directory__DOT__cc_dir__DOT__cc_dir_ext__DOT__mem_0_4__DOT__ram__v0 = 1U;
    }
    if (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__directory__DOT__cc_dir__DOT__cc_dir_ext__DOT__mem_0_0__DOT__ram_RW_0_w_en) 
         & ((~ ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__directory__DOT__wipeCount) 
                >> 0xaU)) | (1U & (((IData)(1U) << 
                                    (7U & (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__directory__DOT__write_q__DOT__ram 
                                           >> 0x11U))) 
                                   >> 1U))))) {
        vlSelfRef.__VdlyVal__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__directory__DOT__cc_dir__DOT__cc_dir_ext__DOT__mem_0_1__DOT__ram__v0 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__directory__DOT__cc_dir__DOT__cc_dir_ext__DOT__mem_0_0_RW0_wdata;
        vlSelfRef.__VdlyDim0__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__directory__DOT__cc_dir__DOT__cc_dir_ext__DOT__mem_0_1__DOT__ram__v0 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__directory__DOT____Vcellinp__cc_dir__RW0_addr;
        vlSelfRef.__VdlySet__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__directory__DOT__cc_dir__DOT__cc_dir_ext__DOT__mem_0_1__DOT__ram__v0 = 1U;
    }
    if (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__directory__DOT__cc_dir__DOT__cc_dir_ext__DOT__mem_0_0__DOT__ram_RW_0_w_en) 
         & ((~ ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__directory__DOT__wipeCount) 
                >> 0xaU)) | (1U & (((IData)(1U) << 
                                    (7U & (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__directory__DOT__write_q__DOT__ram 
                                           >> 0x11U))) 
                                   >> 2U))))) {
        vlSelfRef.__VdlyVal__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__directory__DOT__cc_dir__DOT__cc_dir_ext__DOT__mem_0_2__DOT__ram__v0 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__directory__DOT__cc_dir__DOT__cc_dir_ext__DOT__mem_0_0_RW0_wdata;
        vlSelfRef.__VdlyDim0__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__directory__DOT__cc_dir__DOT__cc_dir_ext__DOT__mem_0_2__DOT__ram__v0 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__directory__DOT____Vcellinp__cc_dir__RW0_addr;
        vlSelfRef.__VdlySet__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__directory__DOT__cc_dir__DOT__cc_dir_ext__DOT__mem_0_2__DOT__ram__v0 = 1U;
    }
    if (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__directory__DOT__cc_dir__DOT__cc_dir_ext__DOT__mem_0_0__DOT__ram_RW_0_w_en) 
         & ((~ ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__directory__DOT__wipeCount) 
                >> 0xaU)) | (1U & (((IData)(1U) << 
                                    (7U & (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__directory__DOT__write_q__DOT__ram 
                                           >> 0x11U))) 
                                   >> 3U))))) {
        vlSelfRef.__VdlyVal__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__directory__DOT__cc_dir__DOT__cc_dir_ext__DOT__mem_0_3__DOT__ram__v0 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__directory__DOT__cc_dir__DOT__cc_dir_ext__DOT__mem_0_0_RW0_wdata;
        vlSelfRef.__VdlyDim0__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__directory__DOT__cc_dir__DOT__cc_dir_ext__DOT__mem_0_3__DOT__ram__v0 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__directory__DOT____Vcellinp__cc_dir__RW0_addr;
        vlSelfRef.__VdlySet__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__directory__DOT__cc_dir__DOT__cc_dir_ext__DOT__mem_0_3__DOT__ram__v0 = 1U;
    }
    if (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__directory__DOT__cc_dir__DOT__cc_dir_ext__DOT__mem_0_0__DOT__ram_RW_0_w_en) 
         & ((~ ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__directory__DOT__wipeCount) 
                >> 0xaU)) | (1U & (((IData)(1U) << 
                                    (7U & (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__directory__DOT__write_q__DOT__ram 
                                           >> 0x11U))) 
                                   >> 5U))))) {
        vlSelfRef.__VdlyVal__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__directory__DOT__cc_dir__DOT__cc_dir_ext__DOT__mem_0_5__DOT__ram__v0 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__directory__DOT__cc_dir__DOT__cc_dir_ext__DOT__mem_0_0_RW0_wdata;
        vlSelfRef.__VdlyDim0__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__directory__DOT__cc_dir__DOT__cc_dir_ext__DOT__mem_0_5__DOT__ram__v0 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__directory__DOT____Vcellinp__cc_dir__RW0_addr;
        vlSelfRef.__VdlySet__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__directory__DOT__cc_dir__DOT__cc_dir_ext__DOT__mem_0_5__DOT__ram__v0 = 1U;
    }
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__632(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__632\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__directory__DOT__cc_dir__DOT__cc_dir_ext__DOT__mem_0_0__DOT__ram_RW_0_w_en) 
         & ((~ ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__directory__DOT__wipeCount) 
                >> 0xaU)) | (1U & (((IData)(1U) << 
                                    (7U & (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__directory__DOT__write_q__DOT__ram 
                                           >> 0x11U))) 
                                   >> 6U))))) {
        vlSelfRef.__VdlyVal__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__directory__DOT__cc_dir__DOT__cc_dir_ext__DOT__mem_0_6__DOT__ram__v0 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__directory__DOT__cc_dir__DOT__cc_dir_ext__DOT__mem_0_0_RW0_wdata;
        vlSelfRef.__VdlyDim0__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__directory__DOT__cc_dir__DOT__cc_dir_ext__DOT__mem_0_6__DOT__ram__v0 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__directory__DOT____Vcellinp__cc_dir__RW0_addr;
        vlSelfRef.__VdlySet__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__directory__DOT__cc_dir__DOT__cc_dir_ext__DOT__mem_0_6__DOT__ram__v0 = 1U;
    }
    if (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__directory__DOT__cc_dir__DOT__cc_dir_ext__DOT__mem_0_0__DOT__ram_RW_0_w_en) 
         & ((~ ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__directory__DOT__wipeCount) 
                >> 0xaU)) | (1U & (((IData)(1U) << 
                                    (7U & (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__directory__DOT__write_q__DOT__ram 
                                           >> 0x11U))) 
                                   >> 7U))))) {
        vlSelfRef.__VdlyVal__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__directory__DOT__cc_dir__DOT__cc_dir_ext__DOT__mem_0_7__DOT__ram__v0 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__directory__DOT__cc_dir__DOT__cc_dir_ext__DOT__mem_0_0_RW0_wdata;
        vlSelfRef.__VdlyDim0__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__directory__DOT__cc_dir__DOT__cc_dir_ext__DOT__mem_0_7__DOT__ram__v0 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__directory__DOT____Vcellinp__cc_dir__RW0_addr;
        vlSelfRef.__VdlySet__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__directory__DOT__cc_dir__DOT__cc_dir_ext__DOT__mem_0_7__DOT__ram__v0 = 1U;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT____Vcellinp__stq_execute_queue__reset) {
        vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_execute_queue__DOT__enq_ptr_value = 0U;
        vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_execute_queue__DOT__deq_ptr_value = 0U;
    } else {
        if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_execute_queue__DOT__do_enq) {
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_execute_queue__DOT__enq_ptr_value 
                = (3U & ((IData)(1U) + (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_execute_queue__DOT__enq_ptr_value)));
        }
        if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_execute_queue__DOT__do_deq) {
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_execute_queue__DOT__deq_ptr_value 
                = (3U & ((IData)(1U) + (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_execute_queue__DOT__deq_ptr_value)));
        }
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT____Vcellinp__iregfile__io_write_ports_2_valid) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__iregfile__DOT__rfs_0__DOT__rf__DOT__regfile_ext__DOT____Vlvbound_h8d5828e3__0 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___alu_exe_unit_0_io_alu_resp_bits_data;
        if ((0x33U >= (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__alu_exe_unit_0__DOT__exe_uop_bits_pdst))) {
            vlSelfRef.__VdlyVal__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__iregfile__DOT__rfs_0__DOT__rf__DOT__regfile_ext__DOT__Memory__v0 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__iregfile__DOT__rfs_0__DOT__rf__DOT__regfile_ext__DOT____Vlvbound_h8d5828e3__0;
            vlSelfRef.__VdlyDim0__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__iregfile__DOT__rfs_0__DOT__rf__DOT__regfile_ext__DOT__Memory__v0 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__alu_exe_unit_0__DOT__exe_uop_bits_pdst;
            vlSelfRef.__VdlySet__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__iregfile__DOT__rfs_0__DOT__rf__DOT__regfile_ext__DOT__Memory__v0 = 1U;
        }
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT____Vcellinp__iregfile__io_write_ports_1_valid) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__iregfile__DOT__rfs_0__DOT__rf__DOT__regfile_ext__DOT____Vlvbound_h6e7fbbcb__0 
            = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__io_mul_resp_imul__DOT__pipe__DOT__uops_2_valid)
                ? vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__io_mul_resp_imul__DOT__imul__DOT__io_resp_bits_data_pipe_pipe_b
                : ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___fp_pipeline_io_to_int_valid)
                    ? (((QData)((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__queue__DOT___ram_ext_R0_data[2U])) 
                        << 0x39U) | (((QData)((IData)(
                                                      vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__queue__DOT___ram_ext_R0_data[1U])) 
                                      << 0x19U) | ((QData)((IData)(
                                                                   vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__queue__DOT___ram_ext_R0_data[0U])) 
                                                   >> 7U)))
                    : ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___unique_exe_unit_0_io_div_resp_valid)
                        ? (((QData)((IData)(((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__io_div_resp_div__DOT__div__DOT__req_dw)
                                              ? (IData)(
                                                        (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__io_div_resp_div__DOT__div__DOT__result 
                                                         >> 0x20U))
                                              : (- (IData)(
                                                           (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__io_div_resp_div__DOT__div__DOT__loOut 
                                                            >> 0x1fU)))))) 
                            << 0x20U) | (QData)((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__io_div_resp_div__DOT__div__DOT__loOut)))
                        : vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___csr_io_rw_rdata)));
        if ((0x33U >= (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___ll_arb_io_out_bits_uop_pdst))) {
            vlSelfRef.__VdlyVal__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__iregfile__DOT__rfs_0__DOT__rf__DOT__regfile_ext__DOT__Memory__v1 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__iregfile__DOT__rfs_0__DOT__rf__DOT__regfile_ext__DOT____Vlvbound_h6e7fbbcb__0;
            vlSelfRef.__VdlyDim0__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__iregfile__DOT__rfs_0__DOT__rf__DOT__regfile_ext__DOT__Memory__v1 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___ll_arb_io_out_bits_uop_pdst;
            vlSelfRef.__VdlySet__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__iregfile__DOT__rfs_0__DOT__rf__DOT__regfile_ext__DOT__Memory__v1 = 1U;
        }
    }
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__633(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__633\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__iregfile_io_write_ports_0_valid_REG) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__iregfile__DOT__rfs_0__DOT__rf__DOT__regfile_ext__DOT____Vlvbound_h7e9de3e5__0 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__iregfile_io_write_ports_0_bits_data_REG;
        if ((0x33U >= (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__iregfile_io_write_ports_0_bits_addr_REG))) {
            vlSelfRef.__VdlyVal__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__iregfile__DOT__rfs_0__DOT__rf__DOT__regfile_ext__DOT__Memory__v2 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__iregfile__DOT__rfs_0__DOT__rf__DOT__regfile_ext__DOT____Vlvbound_h7e9de3e5__0;
            vlSelfRef.__VdlyDim0__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__iregfile__DOT__rfs_0__DOT__rf__DOT__regfile_ext__DOT__Memory__v2 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__iregfile_io_write_ports_0_bits_addr_REG;
            vlSelfRef.__VdlySet__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__iregfile__DOT__rfs_0__DOT__rf__DOT__regfile_ext__DOT__Memory__v2 = 1U;
        }
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT___system_auto_cbus_fixedClockNode_anon_out_reset) {
        vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__tlb__DOT__state = 0U;
        vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dtlb__DOT__state = 0U;
    } else {
        if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__resp_valid_1) {
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__tlb__DOT__state = 0U;
        } else if (((2U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__tlb__DOT__state)) 
                    & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__tlb_io_sfence_REG_valid))) {
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__tlb__DOT__state = 3U;
        } else if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___tlb_io_ptw_req_valid) {
            if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT___ptw_io_requestor_1_req_ready) {
                vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__tlb__DOT__state 
                    = (2U | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__tlb_io_sfence_REG_valid));
            } else if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__tlb_io_sfence_REG_valid) {
                vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__tlb__DOT__state = 0U;
            } else if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__tlb__DOT___GEN_114) {
                vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__tlb__DOT__state = 1U;
            }
        } else if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__tlb__DOT___GEN_114) {
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__tlb__DOT__state = 1U;
        }
        if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__resp_valid_0) {
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dtlb__DOT__state = 0U;
        } else if (((2U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dtlb__DOT__state)) 
                    & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__s_valid_REG))) {
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dtlb__DOT__state = 3U;
        } else if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT___lsu_io_ptw_req_valid) {
            if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT____Vcellinp__dtlb__io_kill) {
                vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dtlb__DOT__state = 0U;
            } else if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT___ptw_io_requestor_0_req_ready) {
                vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dtlb__DOT__state 
                    = (2U | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__s_valid_REG));
            } else if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__s_valid_REG) {
                vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dtlb__DOT__state = 0U;
            } else if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dtlb__DOT___GEN_49) {
                vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dtlb__DOT__state = 1U;
            }
        } else if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dtlb__DOT___GEN_49) {
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dtlb__DOT__state = 1U;
        }
    }
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__634(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__634\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Init
    CData/*31:0*/ __Vtemp_1;
    // Body
    __Vtemp_1 = ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dtlb__DOT___GEN_65)) 
                 & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__s_valid_REG)
                     ? ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__s_bits_rs1_REG)
                         ? ((~ ((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dtlb__DOT__special_entry_valid_0) 
                                  & ((0x1ffU & (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dtlb__DOT__special_entry_tag 
                                                >> 0x12U)) 
                                     == (0x1ffU & (IData)(
                                                          (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__exe_tlb_vaddr_0 
                                                           >> 0x1eU))))) 
                                 & ((0U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dtlb__DOT__special_entry_level)) 
                                    | ((0x1ffU & (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dtlb__DOT__special_entry_tag 
                                                  >> 9U)) 
                                       == (0x1ffU & (IData)(
                                                            (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__exe_tlb_vaddr_0 
                                                             >> 0x15U)))))) 
                                & ((~ ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dtlb__DOT__special_entry_level) 
                                       >> 1U)) | ((0x1ffU 
                                                   & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dtlb__DOT__special_entry_tag) 
                                                  == 
                                                  (0x1ffU 
                                                   & (IData)(
                                                             (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__exe_tlb_vaddr_0 
                                                              >> 0xcU))))))) 
                            & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dtlb__DOT___GEN_23))
                         : (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__s_bits_rs2_REG) 
                             & (IData)((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dtlb__DOT__special_entry_data_0 
                                        >> 0xcU))) 
                            & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dtlb__DOT___GEN_23)))
                     : (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dtlb__DOT___GEN_23)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dtlb__DOT__special_entry_valid_0 
        = __Vtemp_1;
    if (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT____Vcellinp__l2_tlb_ram__RW0_en) 
         & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__l2_refill))) {
        vlSelfRef.__VdlyVal__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__l2_tlb_ram__DOT__l2_tlb_ram_ext__DOT__mem_0_0__DOT__ram__v0 
            = (((QData)((IData)(((0x40000U & ((((((
                                                   ((VL_REDXOR_32(
                                                                  (0x7fffe00U 
                                                                   & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__r_req_addr)) 
                                                     ^ 
                                                     VL_REDXOR_32(
                                                                  (0xfffffULL 
                                                                   & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__r_pte_ppn))) 
                                                    ^ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__r_pte_d)) 
                                                   ^ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__r_pte_a)) 
                                                  ^ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__r_pte_u)) 
                                                 ^ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__r_pte_x)) 
                                                ^ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__r_pte_r)) 
                                               ^ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__r_pte_w)) 
                                              << 0x12U)) 
                                 | (0x3ffffU & (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__r_req_addr 
                                                >> 9U))))) 
                << 0x1aU) | (QData)((IData)(((0x3ffffc0U 
                                              & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__r_pte_ppn) 
                                                 << 6U)) 
                                             | ((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__r_pte_d) 
                                                  << 5U) 
                                                 | (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__r_pte_a) 
                                                     << 4U) 
                                                    | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__r_pte_u) 
                                                       << 3U))) 
                                                | (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__r_pte_x) 
                                                    << 2U) 
                                                   | (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__r_pte_w) 
                                                       << 1U) 
                                                      | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__r_pte_r))))))));
        vlSelfRef.__VdlyDim0__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__l2_tlb_ram__DOT__l2_tlb_ram_ext__DOT__mem_0_0__DOT__ram__v0 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT____Vcellinp__l2_tlb_ram__RW0_addr;
        vlSelfRef.__VdlySet__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__l2_tlb_ram__DOT__l2_tlb_ram_ext__DOT__mem_0_0__DOT__ram__v0 = 1U;
    }
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__635(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__635\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Init
    VlWide<16>/*511:0*/ __Vtemp_7;
    // Body
    vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__s1_mshr_meta_read_way_en 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT___mshrs_0_io_meta_read_valid)
            ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_0__DOT__req_way_en)
            : (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_1__DOT__req_way_en));
    vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__s1_replay_way_en 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT___mshrs_0_io_replay_valid)
            ? ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_0__DOT___GEN_23)
                ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_0__DOT__rpq__DOT__out_reg_way_en)
                : (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_0__DOT__req_way_en))
            : ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_1__DOT___GEN_23)
                ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_1__DOT__rpq__DOT__out_reg_way_en)
                : (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_1__DOT__req_way_en)));
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__wb__DOT___GEN_7) {
        vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__wb__DOT__req_idx 
            = (0x3fU & ((7U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__prober__DOT__state))
                         ? (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__prober__DOT__req_address 
                            >> 6U) : ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT___mshrs_0_io_wb_req_valid)
                                       ? (IData)((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_0__DOT__req_addr 
                                                  >> 6U))
                                       : (IData)((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_1__DOT__req_addr 
                                                  >> 6U)))));
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT___io_lsu_perf_release_T) {
        vlSelfRef.__VdlyVal__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__buffer_1__DOT__nodeOut_c_q__DOT__ram_ext__DOT__Memory__v0[0U] 
            = (0xfffffffeU & vlSelfRef.__VdlyVal__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__buffer_1__DOT__nodeOut_c_q__DOT__ram_ext__DOT__Memory__v0[0U]);
        __Vtemp_7[0U] = (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__wb__DOT__wb_buffer_0);
        __Vtemp_7[1U] = (IData)((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__wb__DOT__wb_buffer_0 
                                 >> 0x20U));
        __Vtemp_7[2U] = (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__wb__DOT__wb_buffer_1);
        __Vtemp_7[3U] = (IData)((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__wb__DOT__wb_buffer_1 
                                 >> 0x20U));
        __Vtemp_7[4U] = (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__wb__DOT__wb_buffer_2);
        __Vtemp_7[5U] = (IData)((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__wb__DOT__wb_buffer_2 
                                 >> 0x20U));
        __Vtemp_7[6U] = (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__wb__DOT__wb_buffer_3);
        __Vtemp_7[7U] = (IData)((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__wb__DOT__wb_buffer_3 
                                 >> 0x20U));
        __Vtemp_7[8U] = (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__wb__DOT__wb_buffer_4);
        __Vtemp_7[9U] = (IData)((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__wb__DOT__wb_buffer_4 
                                 >> 0x20U));
        __Vtemp_7[0xaU] = (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__wb__DOT__wb_buffer_5);
        __Vtemp_7[0xbU] = (IData)((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__wb__DOT__wb_buffer_5 
                                   >> 0x20U));
        __Vtemp_7[0xcU] = (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__wb__DOT__wb_buffer_6);
        __Vtemp_7[0xdU] = (IData)((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__wb__DOT__wb_buffer_6 
                                   >> 0x20U));
        __Vtemp_7[0xeU] = (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__wb__DOT__wb_buffer_7);
        __Vtemp_7[0xfU] = (IData)((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__wb__DOT__wb_buffer_7 
                                   >> 0x20U));
        vlSelfRef.__VdlyVal__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__buffer_1__DOT__nodeOut_c_q__DOT__ram_ext__DOT__Memory__v0[0U] 
            = ((1U & vlSelfRef.__VdlyVal__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__buffer_1__DOT__nodeOut_c_q__DOT__ram_ext__DOT__Memory__v0[0U]) 
               | ((IData)(((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__muxState_0)
                            ? (((QData)((IData)(__Vtemp_7[
                                                (((IData)(0x3fU) 
                                                  + 
                                                  (0x1ffU 
                                                   & VL_SHIFTL_III(9,9,32, 
                                                                   (7U 
                                                                    & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__wb__DOT__data_req_cnt)), 6U))) 
                                                 >> 5U)])) 
                                << ((0U == (0x1fU & 
                                            VL_SHIFTL_III(9,9,32, 
                                                          (7U 
                                                           & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__wb__DOT__data_req_cnt)), 6U)))
                                     ? 0x20U : ((IData)(0x40U) 
                                                - (0x1fU 
                                                   & VL_SHIFTL_III(9,9,32, 
                                                                   (7U 
                                                                    & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__wb__DOT__data_req_cnt)), 6U))))) 
                               | (((0U == (0x1fU & 
                                           VL_SHIFTL_III(9,9,32, 
                                                         (7U 
                                                          & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__wb__DOT__data_req_cnt)), 6U)))
                                    ? 0ULL : ((QData)((IData)(
                                                              __Vtemp_7[
                                                              (((IData)(0x1fU) 
                                                                + 
                                                                (0x1ffU 
                                                                 & VL_SHIFTL_III(9,9,32, 
                                                                                (7U 
                                                                                & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__wb__DOT__data_req_cnt)), 6U))) 
                                                               >> 5U)])) 
                                              << ((IData)(0x20U) 
                                                  - 
                                                  (0x1fU 
                                                   & VL_SHIFTL_III(9,9,32, 
                                                                   (7U 
                                                                    & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__wb__DOT__data_req_cnt)), 6U))))) 
                                  | ((QData)((IData)(
                                                     __Vtemp_7[
                                                     (0xfU 
                                                      & (VL_SHIFTL_III(9,9,32, 
                                                                       (7U 
                                                                        & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__wb__DOT__data_req_cnt)), 6U) 
                                                         >> 5U))])) 
                                     >> (0x1fU & VL_SHIFTL_III(9,9,32, 
                                                               (7U 
                                                                & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__wb__DOT__data_req_cnt)), 6U)))))
                            : 0ULL)) << 1U));
        vlSelfRef.__VdlyVal__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__buffer_1__DOT__nodeOut_c_q__DOT__ram_ext__DOT__Memory__v0[1U] 
            = (((IData)(((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__muxState_0)
                          ? (((QData)((IData)(__Vtemp_7[
                                              (((IData)(0x3fU) 
                                                + (0x1ffU 
                                                   & VL_SHIFTL_III(9,9,32, 
                                                                   (7U 
                                                                    & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__wb__DOT__data_req_cnt)), 6U))) 
                                               >> 5U)])) 
                              << ((0U == (0x1fU & VL_SHIFTL_III(9,9,32, 
                                                                (7U 
                                                                 & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__wb__DOT__data_req_cnt)), 6U)))
                                   ? 0x20U : ((IData)(0x40U) 
                                              - (0x1fU 
                                                 & VL_SHIFTL_III(9,9,32, 
                                                                 (7U 
                                                                  & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__wb__DOT__data_req_cnt)), 6U))))) 
                             | (((0U == (0x1fU & VL_SHIFTL_III(9,9,32, 
                                                               (7U 
                                                                & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__wb__DOT__data_req_cnt)), 6U)))
                                  ? 0ULL : ((QData)((IData)(
                                                            __Vtemp_7[
                                                            (((IData)(0x1fU) 
                                                              + 
                                                              (0x1ffU 
                                                               & VL_SHIFTL_III(9,9,32, 
                                                                               (7U 
                                                                                & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__wb__DOT__data_req_cnt)), 6U))) 
                                                             >> 5U)])) 
                                            << ((IData)(0x20U) 
                                                - (0x1fU 
                                                   & VL_SHIFTL_III(9,9,32, 
                                                                   (7U 
                                                                    & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__wb__DOT__data_req_cnt)), 6U))))) 
                                | ((QData)((IData)(
                                                   __Vtemp_7[
                                                   (0xfU 
                                                    & (VL_SHIFTL_III(9,9,32, 
                                                                     (7U 
                                                                      & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__wb__DOT__data_req_cnt)), 6U) 
                                                       >> 5U))])) 
                                   >> (0x1fU & VL_SHIFTL_III(9,9,32, 
                                                             (7U 
                                                              & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__wb__DOT__data_req_cnt)), 6U)))))
                          : 0ULL)) >> 0x1fU) | ((IData)(
                                                        (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__muxState_0)
                                                           ? 
                                                          (((QData)((IData)(
                                                                            __Vtemp_7[
                                                                            (((IData)(0x3fU) 
                                                                              + 
                                                                              (0x1ffU 
                                                                               & VL_SHIFTL_III(9,9,32, 
                                                                                (7U 
                                                                                & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__wb__DOT__data_req_cnt)), 6U))) 
                                                                             >> 5U)])) 
                                                            << 
                                                            ((0U 
                                                              == 
                                                              (0x1fU 
                                                               & VL_SHIFTL_III(9,9,32, 
                                                                               (7U 
                                                                                & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__wb__DOT__data_req_cnt)), 6U)))
                                                              ? 0x20U
                                                              : 
                                                             ((IData)(0x40U) 
                                                              - 
                                                              (0x1fU 
                                                               & VL_SHIFTL_III(9,9,32, 
                                                                               (7U 
                                                                                & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__wb__DOT__data_req_cnt)), 6U))))) 
                                                           | (((0U 
                                                                == 
                                                                (0x1fU 
                                                                 & VL_SHIFTL_III(9,9,32, 
                                                                                (7U 
                                                                                & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__wb__DOT__data_req_cnt)), 6U)))
                                                                ? 0ULL
                                                                : 
                                                               ((QData)((IData)(
                                                                                __Vtemp_7[
                                                                                (((IData)(0x1fU) 
                                                                                + 
                                                                                (0x1ffU 
                                                                                & VL_SHIFTL_III(9,9,32, 
                                                                                (7U 
                                                                                & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__wb__DOT__data_req_cnt)), 6U))) 
                                                                                >> 5U)])) 
                                                                << 
                                                                ((IData)(0x20U) 
                                                                 - 
                                                                 (0x1fU 
                                                                  & VL_SHIFTL_III(9,9,32, 
                                                                                (7U 
                                                                                & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__wb__DOT__data_req_cnt)), 6U))))) 
                                                              | ((QData)((IData)(
                                                                                __Vtemp_7[
                                                                                (0xfU 
                                                                                & (VL_SHIFTL_III(9,9,32, 
                                                                                (7U 
                                                                                & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__wb__DOT__data_req_cnt)), 6U) 
                                                                                >> 5U))])) 
                                                                 >> 
                                                                 (0x1fU 
                                                                  & VL_SHIFTL_III(9,9,32, 
                                                                                (7U 
                                                                                & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__wb__DOT__data_req_cnt)), 6U)))))
                                                           : 0ULL) 
                                                         >> 0x20U)) 
                                                << 1U));
        vlSelfRef.__VdlyVal__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__buffer_1__DOT__nodeOut_c_q__DOT__ram_ext__DOT__Memory__v0[2U] 
            = ((0xfffffffeU & vlSelfRef.__VdlyVal__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__buffer_1__DOT__nodeOut_c_q__DOT__ram_ext__DOT__Memory__v0[2U]) 
               | ((IData)((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__muxState_0)
                             ? (((QData)((IData)(__Vtemp_7[
                                                 (((IData)(0x3fU) 
                                                   + 
                                                   (0x1ffU 
                                                    & VL_SHIFTL_III(9,9,32, 
                                                                    (7U 
                                                                     & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__wb__DOT__data_req_cnt)), 6U))) 
                                                  >> 5U)])) 
                                 << ((0U == (0x1fU 
                                             & VL_SHIFTL_III(9,9,32, 
                                                             (7U 
                                                              & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__wb__DOT__data_req_cnt)), 6U)))
                                      ? 0x20U : ((IData)(0x40U) 
                                                 - 
                                                 (0x1fU 
                                                  & VL_SHIFTL_III(9,9,32, 
                                                                  (7U 
                                                                   & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__wb__DOT__data_req_cnt)), 6U))))) 
                                | (((0U == (0x1fU & 
                                            VL_SHIFTL_III(9,9,32, 
                                                          (7U 
                                                           & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__wb__DOT__data_req_cnt)), 6U)))
                                     ? 0ULL : ((QData)((IData)(
                                                               __Vtemp_7[
                                                               (((IData)(0x1fU) 
                                                                 + 
                                                                 (0x1ffU 
                                                                  & VL_SHIFTL_III(9,9,32, 
                                                                                (7U 
                                                                                & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__wb__DOT__data_req_cnt)), 6U))) 
                                                                >> 5U)])) 
                                               << ((IData)(0x20U) 
                                                   - 
                                                   (0x1fU 
                                                    & VL_SHIFTL_III(9,9,32, 
                                                                    (7U 
                                                                     & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__wb__DOT__data_req_cnt)), 6U))))) 
                                   | ((QData)((IData)(
                                                      __Vtemp_7[
                                                      (0xfU 
                                                       & (VL_SHIFTL_III(9,9,32, 
                                                                        (7U 
                                                                         & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__wb__DOT__data_req_cnt)), 6U) 
                                                          >> 5U))])) 
                                      >> (0x1fU & VL_SHIFTL_III(9,9,32, 
                                                                (7U 
                                                                 & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__wb__DOT__data_req_cnt)), 6U)))))
                             : 0ULL) >> 0x20U)) >> 0x1fU));
        vlSelfRef.__VdlyVal__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__buffer_1__DOT__nodeOut_c_q__DOT__ram_ext__DOT__Memory__v0[2U] 
            = ((1U & vlSelfRef.__VdlyVal__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__buffer_1__DOT__nodeOut_c_q__DOT__ram_ext__DOT__Memory__v0[2U]) 
               | ((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__muxState_0)
                     ? vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT___wb_io_release_bits_address
                     : 0U) | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__muxState_1)
                               ? vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__prober__DOT__req_address
                               : 0U)) << 1U));
        vlSelfRef.__VdlyVal__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__buffer_1__DOT__nodeOut_c_q__DOT__ram_ext__DOT__Memory__v0[3U] 
            = ((0x1ffeU & vlSelfRef.__VdlyVal__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__buffer_1__DOT__nodeOut_c_q__DOT__ram_ext__DOT__Memory__v0[3U]) 
               | (0x1fffU & ((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__muxState_0)
                                ? vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT___wb_io_release_bits_address
                                : 0U) | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__muxState_1)
                                          ? vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__prober__DOT__req_address
                                          : 0U)) >> 0x1fU)));
        vlSelfRef.__VdlyVal__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__buffer_1__DOT__nodeOut_c_q__DOT__ram_ext__DOT__Memory__v0[3U] 
            = ((1U & vlSelfRef.__VdlyVal__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__buffer_1__DOT__nodeOut_c_q__DOT__ram_ext__DOT__Memory__v0[3U]) 
               | (0x1ffeU & ((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT___dcache_auto_out_c_bits_opcode) 
                               << 0xaU) | ((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__muxState_0)
                                              ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__wb__DOT__req_param)
                                              : 0U) 
                                            | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__muxState_1)
                                                ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT___prober_io_rep_bits_param)
                                                : 0U)) 
                                           << 7U)) 
                             | (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT___dcache_auto_out_c_bits_size) 
                                 << 3U) | ((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__muxState_0)
                                              ? ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__wb__DOT__req_voluntary)
                                                  ? 2U
                                                  : (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__wb__DOT__req_source))
                                              : 0U) 
                                            | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__muxState_1)
                                                ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__prober__DOT__req_source)
                                                : 0U)) 
                                           << 1U)))));
        vlSelfRef.__VdlyDim0__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__buffer_1__DOT__nodeOut_c_q__DOT__ram_ext__DOT__Memory__v0 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__buffer_1__DOT__nodeOut_c_q__DOT__enq_ptr_value;
        vlSelfRef.__VdlySet__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__buffer_1__DOT__nodeOut_c_q__DOT__ram_ext__DOT__Memory__v0 = 1U;
    }
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__636(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__636\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__wb__DOT___GEN_7) {
        vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__wb__DOT__req_way_en 
            = ((7U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__prober__DOT__state))
                ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__prober__DOT__way_en)
                : ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT___mshrs_0_io_wb_req_valid)
                    ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_0__DOT__req_way_en)
                    : (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_1__DOT__req_way_en)));
    }
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_predicated_2 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_603)
            ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___fp_pipeline_io_wb_1_bits_predicated)
            : ((~ ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___fp_pipeline_io_wb_0_valid) 
                   & (2U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__fpu__DOT__pipe__DOT__uops_3_bits_uop_rob_idx)))) 
               & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_441)
                   ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob_io_wb_resps_2_bits_REG_predicated)
                   : (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob_io_wb_resps_1_valid_REG_1) 
                       & (2U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob_io_wb_resps_1_bits_REG_uop_rob_idx)))
                       ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob_io_wb_resps_1_bits_REG_predicated)
                       : ((~ ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_250) 
                              | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_122))) 
                          & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_predicated_2))))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_predicated_1 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_601)
            ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___fp_pipeline_io_wb_1_bits_predicated)
            : ((~ ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___fp_pipeline_io_wb_0_valid) 
                   & (1U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__fpu__DOT__pipe__DOT__uops_3_bits_uop_rob_idx)))) 
               & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_440)
                   ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob_io_wb_resps_2_bits_REG_predicated)
                   : (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob_io_wb_resps_1_valid_REG_1) 
                       & (1U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob_io_wb_resps_1_bits_REG_uop_rob_idx)))
                       ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob_io_wb_resps_1_bits_REG_predicated)
                       : ((~ ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_249) 
                              | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_121))) 
                          & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_predicated_1))))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_predicated_0 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_599)
            ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___fp_pipeline_io_wb_1_bits_predicated)
            : ((~ ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___fp_pipeline_io_wb_0_valid) 
                   & (0U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__fpu__DOT__pipe__DOT__uops_3_bits_uop_rob_idx)))) 
               & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_439)
                   ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob_io_wb_resps_2_bits_REG_predicated)
                   : (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob_io_wb_resps_1_valid_REG_1) 
                       & (0U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob_io_wb_resps_1_bits_REG_uop_rob_idx)))
                       ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob_io_wb_resps_1_bits_REG_predicated)
                       : ((~ ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_248) 
                              | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_120))) 
                          & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_predicated_0))))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_predicated_26 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_651)
            ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___fp_pipeline_io_wb_1_bits_predicated)
            : ((~ ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___fp_pipeline_io_wb_0_valid) 
                   & (0x1aU == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__fpu__DOT__pipe__DOT__uops_3_bits_uop_rob_idx)))) 
               & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_465)
                   ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob_io_wb_resps_2_bits_REG_predicated)
                   : (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob_io_wb_resps_1_valid_REG_1) 
                       & (0x1aU == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob_io_wb_resps_1_bits_REG_uop_rob_idx)))
                       ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob_io_wb_resps_1_bits_REG_predicated)
                       : ((~ ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_274) 
                              | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_146))) 
                          & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_predicated_26))))));
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__637(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__637\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_predicated_21 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_641)
            ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___fp_pipeline_io_wb_1_bits_predicated)
            : ((~ ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___fp_pipeline_io_wb_0_valid) 
                   & (0x15U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__fpu__DOT__pipe__DOT__uops_3_bits_uop_rob_idx)))) 
               & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_460)
                   ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob_io_wb_resps_2_bits_REG_predicated)
                   : (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob_io_wb_resps_1_valid_REG_1) 
                       & (0x15U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob_io_wb_resps_1_bits_REG_uop_rob_idx)))
                       ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob_io_wb_resps_1_bits_REG_predicated)
                       : ((~ ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_269) 
                              | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_141))) 
                          & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_predicated_21))))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_predicated_16 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_631)
            ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___fp_pipeline_io_wb_1_bits_predicated)
            : ((~ ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___fp_pipeline_io_wb_0_valid) 
                   & (0x10U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__fpu__DOT__pipe__DOT__uops_3_bits_uop_rob_idx)))) 
               & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_455)
                   ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob_io_wb_resps_2_bits_REG_predicated)
                   : (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob_io_wb_resps_1_valid_REG_1) 
                       & (0x10U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob_io_wb_resps_1_bits_REG_uop_rob_idx)))
                       ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob_io_wb_resps_1_bits_REG_predicated)
                       : ((~ ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_264) 
                              | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_136))) 
                          & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_predicated_16))))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_predicated_29 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_657)
            ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___fp_pipeline_io_wb_1_bits_predicated)
            : ((~ ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___fp_pipeline_io_wb_0_valid) 
                   & (0x1dU == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__fpu__DOT__pipe__DOT__uops_3_bits_uop_rob_idx)))) 
               & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_468)
                   ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob_io_wb_resps_2_bits_REG_predicated)
                   : (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob_io_wb_resps_1_valid_REG_1) 
                       & (0x1dU == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob_io_wb_resps_1_bits_REG_uop_rob_idx)))
                       ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob_io_wb_resps_1_bits_REG_predicated)
                       : ((~ ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_277) 
                              | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_149))) 
                          & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_predicated_29))))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_predicated_31 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_660)
            ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___fp_pipeline_io_wb_1_bits_predicated)
            : ((~ ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___fp_pipeline_io_wb_0_valid) 
                   & (0x1fU == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__fpu__DOT__pipe__DOT__uops_3_bits_uop_rob_idx)))) 
               & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_470)
                   ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob_io_wb_resps_2_bits_REG_predicated)
                   : (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob_io_wb_resps_1_valid_REG_1) 
                       & (0x1fU == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob_io_wb_resps_1_bits_REG_uop_rob_idx)))
                       ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob_io_wb_resps_1_bits_REG_predicated)
                       : ((~ ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_279) 
                              | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_151))) 
                          & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_predicated_31))))));
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__638(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__638\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_predicated_5 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_609)
            ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___fp_pipeline_io_wb_1_bits_predicated)
            : ((~ ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___fp_pipeline_io_wb_0_valid) 
                   & (5U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__fpu__DOT__pipe__DOT__uops_3_bits_uop_rob_idx)))) 
               & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_444)
                   ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob_io_wb_resps_2_bits_REG_predicated)
                   : (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob_io_wb_resps_1_valid_REG_1) 
                       & (5U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob_io_wb_resps_1_bits_REG_uop_rob_idx)))
                       ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob_io_wb_resps_1_bits_REG_predicated)
                       : ((~ ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_253) 
                              | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_125))) 
                          & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_predicated_5))))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_predicated_6 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_611)
            ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___fp_pipeline_io_wb_1_bits_predicated)
            : ((~ ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___fp_pipeline_io_wb_0_valid) 
                   & (6U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__fpu__DOT__pipe__DOT__uops_3_bits_uop_rob_idx)))) 
               & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_445)
                   ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob_io_wb_resps_2_bits_REG_predicated)
                   : (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob_io_wb_resps_1_valid_REG_1) 
                       & (6U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob_io_wb_resps_1_bits_REG_uop_rob_idx)))
                       ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob_io_wb_resps_1_bits_REG_predicated)
                       : ((~ ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_254) 
                              | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_126))) 
                          & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_predicated_6))))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_predicated_3 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_605)
            ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___fp_pipeline_io_wb_1_bits_predicated)
            : ((~ ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___fp_pipeline_io_wb_0_valid) 
                   & (3U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__fpu__DOT__pipe__DOT__uops_3_bits_uop_rob_idx)))) 
               & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_442)
                   ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob_io_wb_resps_2_bits_REG_predicated)
                   : (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob_io_wb_resps_1_valid_REG_1) 
                       & (3U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob_io_wb_resps_1_bits_REG_uop_rob_idx)))
                       ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob_io_wb_resps_1_bits_REG_predicated)
                       : ((~ ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_251) 
                              | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_123))) 
                          & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_predicated_3))))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_predicated_4 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_607)
            ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___fp_pipeline_io_wb_1_bits_predicated)
            : ((~ ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___fp_pipeline_io_wb_0_valid) 
                   & (4U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__fpu__DOT__pipe__DOT__uops_3_bits_uop_rob_idx)))) 
               & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_443)
                   ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob_io_wb_resps_2_bits_REG_predicated)
                   : (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob_io_wb_resps_1_valid_REG_1) 
                       & (4U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob_io_wb_resps_1_bits_REG_uop_rob_idx)))
                       ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob_io_wb_resps_1_bits_REG_predicated)
                       : ((~ ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_252) 
                              | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_124))) 
                          & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_predicated_4))))));
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__639(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__639\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_predicated_11 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_621)
            ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___fp_pipeline_io_wb_1_bits_predicated)
            : ((~ ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___fp_pipeline_io_wb_0_valid) 
                   & (0xbU == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__fpu__DOT__pipe__DOT__uops_3_bits_uop_rob_idx)))) 
               & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_450)
                   ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob_io_wb_resps_2_bits_REG_predicated)
                   : (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob_io_wb_resps_1_valid_REG_1) 
                       & (0xbU == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob_io_wb_resps_1_bits_REG_uop_rob_idx)))
                       ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob_io_wb_resps_1_bits_REG_predicated)
                       : ((~ ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_259) 
                              | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_131))) 
                          & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_predicated_11))))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_predicated_19 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_637)
            ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___fp_pipeline_io_wb_1_bits_predicated)
            : ((~ ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___fp_pipeline_io_wb_0_valid) 
                   & (0x13U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__fpu__DOT__pipe__DOT__uops_3_bits_uop_rob_idx)))) 
               & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_458)
                   ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob_io_wb_resps_2_bits_REG_predicated)
                   : (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob_io_wb_resps_1_valid_REG_1) 
                       & (0x13U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob_io_wb_resps_1_bits_REG_uop_rob_idx)))
                       ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob_io_wb_resps_1_bits_REG_predicated)
                       : ((~ ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_267) 
                              | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_139))) 
                          & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_predicated_19))))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_predicated_7 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_613)
            ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___fp_pipeline_io_wb_1_bits_predicated)
            : ((~ ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___fp_pipeline_io_wb_0_valid) 
                   & (7U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__fpu__DOT__pipe__DOT__uops_3_bits_uop_rob_idx)))) 
               & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_446)
                   ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob_io_wb_resps_2_bits_REG_predicated)
                   : (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob_io_wb_resps_1_valid_REG_1) 
                       & (7U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob_io_wb_resps_1_bits_REG_uop_rob_idx)))
                       ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob_io_wb_resps_1_bits_REG_predicated)
                       : ((~ ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_255) 
                              | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_127))) 
                          & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_predicated_7))))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_predicated_8 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_615)
            ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___fp_pipeline_io_wb_1_bits_predicated)
            : ((~ ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___fp_pipeline_io_wb_0_valid) 
                   & (8U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__fpu__DOT__pipe__DOT__uops_3_bits_uop_rob_idx)))) 
               & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_447)
                   ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob_io_wb_resps_2_bits_REG_predicated)
                   : (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob_io_wb_resps_1_valid_REG_1) 
                       & (8U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob_io_wb_resps_1_bits_REG_uop_rob_idx)))
                       ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob_io_wb_resps_1_bits_REG_predicated)
                       : ((~ ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_256) 
                              | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_128))) 
                          & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_predicated_8))))));
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__640(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__640\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_predicated_9 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_617)
            ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___fp_pipeline_io_wb_1_bits_predicated)
            : ((~ ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___fp_pipeline_io_wb_0_valid) 
                   & (9U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__fpu__DOT__pipe__DOT__uops_3_bits_uop_rob_idx)))) 
               & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_448)
                   ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob_io_wb_resps_2_bits_REG_predicated)
                   : (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob_io_wb_resps_1_valid_REG_1) 
                       & (9U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob_io_wb_resps_1_bits_REG_uop_rob_idx)))
                       ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob_io_wb_resps_1_bits_REG_predicated)
                       : ((~ ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_257) 
                              | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_129))) 
                          & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_predicated_9))))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_predicated_10 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_619)
            ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___fp_pipeline_io_wb_1_bits_predicated)
            : ((~ ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___fp_pipeline_io_wb_0_valid) 
                   & (0xaU == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__fpu__DOT__pipe__DOT__uops_3_bits_uop_rob_idx)))) 
               & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_449)
                   ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob_io_wb_resps_2_bits_REG_predicated)
                   : (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob_io_wb_resps_1_valid_REG_1) 
                       & (0xaU == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob_io_wb_resps_1_bits_REG_uop_rob_idx)))
                       ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob_io_wb_resps_1_bits_REG_predicated)
                       : ((~ ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_258) 
                              | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_130))) 
                          & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_predicated_10))))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_predicated_12 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_623)
            ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___fp_pipeline_io_wb_1_bits_predicated)
            : ((~ ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___fp_pipeline_io_wb_0_valid) 
                   & (0xcU == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__fpu__DOT__pipe__DOT__uops_3_bits_uop_rob_idx)))) 
               & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_451)
                   ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob_io_wb_resps_2_bits_REG_predicated)
                   : (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob_io_wb_resps_1_valid_REG_1) 
                       & (0xcU == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob_io_wb_resps_1_bits_REG_uop_rob_idx)))
                       ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob_io_wb_resps_1_bits_REG_predicated)
                       : ((~ ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_260) 
                              | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_132))) 
                          & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_predicated_12))))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_predicated_13 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_625)
            ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___fp_pipeline_io_wb_1_bits_predicated)
            : ((~ ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___fp_pipeline_io_wb_0_valid) 
                   & (0xdU == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__fpu__DOT__pipe__DOT__uops_3_bits_uop_rob_idx)))) 
               & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_452)
                   ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob_io_wb_resps_2_bits_REG_predicated)
                   : (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob_io_wb_resps_1_valid_REG_1) 
                       & (0xdU == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob_io_wb_resps_1_bits_REG_uop_rob_idx)))
                       ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob_io_wb_resps_1_bits_REG_predicated)
                       : ((~ ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_261) 
                              | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_133))) 
                          & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_predicated_13))))));
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__641(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__641\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_predicated_14 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_627)
            ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___fp_pipeline_io_wb_1_bits_predicated)
            : ((~ ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___fp_pipeline_io_wb_0_valid) 
                   & (0xeU == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__fpu__DOT__pipe__DOT__uops_3_bits_uop_rob_idx)))) 
               & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_453)
                   ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob_io_wb_resps_2_bits_REG_predicated)
                   : (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob_io_wb_resps_1_valid_REG_1) 
                       & (0xeU == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob_io_wb_resps_1_bits_REG_uop_rob_idx)))
                       ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob_io_wb_resps_1_bits_REG_predicated)
                       : ((~ ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_262) 
                              | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_134))) 
                          & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_predicated_14))))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_predicated_15 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_629)
            ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___fp_pipeline_io_wb_1_bits_predicated)
            : ((~ ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___fp_pipeline_io_wb_0_valid) 
                   & (0xfU == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__fpu__DOT__pipe__DOT__uops_3_bits_uop_rob_idx)))) 
               & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_454)
                   ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob_io_wb_resps_2_bits_REG_predicated)
                   : (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob_io_wb_resps_1_valid_REG_1) 
                       & (0xfU == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob_io_wb_resps_1_bits_REG_uop_rob_idx)))
                       ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob_io_wb_resps_1_bits_REG_predicated)
                       : ((~ ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_263) 
                              | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_135))) 
                          & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_predicated_15))))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_predicated_17 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_633)
            ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___fp_pipeline_io_wb_1_bits_predicated)
            : ((~ ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___fp_pipeline_io_wb_0_valid) 
                   & (0x11U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__fpu__DOT__pipe__DOT__uops_3_bits_uop_rob_idx)))) 
               & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_456)
                   ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob_io_wb_resps_2_bits_REG_predicated)
                   : (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob_io_wb_resps_1_valid_REG_1) 
                       & (0x11U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob_io_wb_resps_1_bits_REG_uop_rob_idx)))
                       ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob_io_wb_resps_1_bits_REG_predicated)
                       : ((~ ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_265) 
                              | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_137))) 
                          & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_predicated_17))))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_predicated_18 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_635)
            ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___fp_pipeline_io_wb_1_bits_predicated)
            : ((~ ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___fp_pipeline_io_wb_0_valid) 
                   & (0x12U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__fpu__DOT__pipe__DOT__uops_3_bits_uop_rob_idx)))) 
               & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_457)
                   ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob_io_wb_resps_2_bits_REG_predicated)
                   : (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob_io_wb_resps_1_valid_REG_1) 
                       & (0x12U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob_io_wb_resps_1_bits_REG_uop_rob_idx)))
                       ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob_io_wb_resps_1_bits_REG_predicated)
                       : ((~ ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_266) 
                              | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_138))) 
                          & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_predicated_18))))));
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__642(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__642\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_predicated_20 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_639)
            ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___fp_pipeline_io_wb_1_bits_predicated)
            : ((~ ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___fp_pipeline_io_wb_0_valid) 
                   & (0x14U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__fpu__DOT__pipe__DOT__uops_3_bits_uop_rob_idx)))) 
               & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_459)
                   ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob_io_wb_resps_2_bits_REG_predicated)
                   : (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob_io_wb_resps_1_valid_REG_1) 
                       & (0x14U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob_io_wb_resps_1_bits_REG_uop_rob_idx)))
                       ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob_io_wb_resps_1_bits_REG_predicated)
                       : ((~ ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_268) 
                              | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_140))) 
                          & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_predicated_20))))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_predicated_22 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_643)
            ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___fp_pipeline_io_wb_1_bits_predicated)
            : ((~ ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___fp_pipeline_io_wb_0_valid) 
                   & (0x16U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__fpu__DOT__pipe__DOT__uops_3_bits_uop_rob_idx)))) 
               & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_461)
                   ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob_io_wb_resps_2_bits_REG_predicated)
                   : (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob_io_wb_resps_1_valid_REG_1) 
                       & (0x16U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob_io_wb_resps_1_bits_REG_uop_rob_idx)))
                       ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob_io_wb_resps_1_bits_REG_predicated)
                       : ((~ ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_270) 
                              | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_142))) 
                          & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_predicated_22))))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_predicated_23 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_645)
            ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___fp_pipeline_io_wb_1_bits_predicated)
            : ((~ ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___fp_pipeline_io_wb_0_valid) 
                   & (0x17U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__fpu__DOT__pipe__DOT__uops_3_bits_uop_rob_idx)))) 
               & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_462)
                   ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob_io_wb_resps_2_bits_REG_predicated)
                   : (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob_io_wb_resps_1_valid_REG_1) 
                       & (0x17U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob_io_wb_resps_1_bits_REG_uop_rob_idx)))
                       ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob_io_wb_resps_1_bits_REG_predicated)
                       : ((~ ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_271) 
                              | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_143))) 
                          & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_predicated_23))))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_predicated_24 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_647)
            ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___fp_pipeline_io_wb_1_bits_predicated)
            : ((~ ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___fp_pipeline_io_wb_0_valid) 
                   & (0x18U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__fpu__DOT__pipe__DOT__uops_3_bits_uop_rob_idx)))) 
               & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_463)
                   ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob_io_wb_resps_2_bits_REG_predicated)
                   : (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob_io_wb_resps_1_valid_REG_1) 
                       & (0x18U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob_io_wb_resps_1_bits_REG_uop_rob_idx)))
                       ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob_io_wb_resps_1_bits_REG_predicated)
                       : ((~ ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_272) 
                              | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_144))) 
                          & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_predicated_24))))));
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__643(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__643\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_predicated_25 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_649)
            ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___fp_pipeline_io_wb_1_bits_predicated)
            : ((~ ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___fp_pipeline_io_wb_0_valid) 
                   & (0x19U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__fpu__DOT__pipe__DOT__uops_3_bits_uop_rob_idx)))) 
               & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_464)
                   ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob_io_wb_resps_2_bits_REG_predicated)
                   : (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob_io_wb_resps_1_valid_REG_1) 
                       & (0x19U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob_io_wb_resps_1_bits_REG_uop_rob_idx)))
                       ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob_io_wb_resps_1_bits_REG_predicated)
                       : ((~ ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_273) 
                              | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_145))) 
                          & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_predicated_25))))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_predicated_27 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_653)
            ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___fp_pipeline_io_wb_1_bits_predicated)
            : ((~ ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___fp_pipeline_io_wb_0_valid) 
                   & (0x1bU == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__fpu__DOT__pipe__DOT__uops_3_bits_uop_rob_idx)))) 
               & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_466)
                   ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob_io_wb_resps_2_bits_REG_predicated)
                   : (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob_io_wb_resps_1_valid_REG_1) 
                       & (0x1bU == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob_io_wb_resps_1_bits_REG_uop_rob_idx)))
                       ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob_io_wb_resps_1_bits_REG_predicated)
                       : ((~ ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_275) 
                              | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_147))) 
                          & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_predicated_27))))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_predicated_28 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_655)
            ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___fp_pipeline_io_wb_1_bits_predicated)
            : ((~ ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___fp_pipeline_io_wb_0_valid) 
                   & (0x1cU == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__fpu__DOT__pipe__DOT__uops_3_bits_uop_rob_idx)))) 
               & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_467)
                   ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob_io_wb_resps_2_bits_REG_predicated)
                   : (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob_io_wb_resps_1_valid_REG_1) 
                       & (0x1cU == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob_io_wb_resps_1_bits_REG_uop_rob_idx)))
                       ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob_io_wb_resps_1_bits_REG_predicated)
                       : ((~ ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_276) 
                              | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_148))) 
                          & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_predicated_28))))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_predicated_30 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_659)
            ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___fp_pipeline_io_wb_1_bits_predicated)
            : ((~ ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___fp_pipeline_io_wb_0_valid) 
                   & (0x1eU == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__fpu__DOT__pipe__DOT__uops_3_bits_uop_rob_idx)))) 
               & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_469)
                   ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob_io_wb_resps_2_bits_REG_predicated)
                   : (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob_io_wb_resps_1_valid_REG_1) 
                       & (0x1eU == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob_io_wb_resps_1_bits_REG_uop_rob_idx)))
                       ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob_io_wb_resps_1_bits_REG_predicated)
                       : ((~ ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_278) 
                              | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_150))) 
                          & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_predicated_30))))));
}

extern const VlWide<16>/*511:0*/ VTestDriver__ConstPool__CONST_h1c449781_0;
extern const VlWide<16>/*511:0*/ VTestDriver__ConstPool__CONST_h93e1b771_0;

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__644(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__644\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Init
    VlWide<16>/*511:0*/ __Vtemp_1;
    VlWide<16>/*511:0*/ __Vtemp_8;
    VlWide<16>/*511:0*/ __Vtemp_14;
    VlWide<16>/*511:0*/ __Vtemp_16;
    // Body
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__queue__DOT__do_enq) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__queue__DOT__ram_ext__DOT____Vlvbound_h669ad2d3__0[0U] 
            = ((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT___fpu_io_resp_bits_data[0U] 
                << 7U) | (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__fpu__DOT__pipe__DOT__uops_3_valid) 
                           << 5U) | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___fp_pipeline_io_wb_0_bits_fflags_bits)));
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__queue__DOT__ram_ext__DOT____Vlvbound_h669ad2d3__0[1U] 
            = ((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT___fpu_io_resp_bits_data[0U] 
                >> 0x19U) | (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT___fpu_io_resp_bits_data[1U] 
                             << 7U));
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__queue__DOT__ram_ext__DOT____Vlvbound_h669ad2d3__0[2U] 
            = ((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT___fpu_io_resp_bits_data[1U] 
                >> 0x19U) | (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT___fpu_io_resp_bits_data[2U] 
                             << 7U));
        if ((9U >= (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__queue__DOT__enq_ptr_value))) {
            vlSelfRef.__VdlyVal__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__queue__DOT__ram_ext__DOT__Memory__v0[0U] 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__queue__DOT__ram_ext__DOT____Vlvbound_h669ad2d3__0[0U];
            vlSelfRef.__VdlyVal__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__queue__DOT__ram_ext__DOT__Memory__v0[1U] 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__queue__DOT__ram_ext__DOT____Vlvbound_h669ad2d3__0[1U];
            vlSelfRef.__VdlyVal__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__queue__DOT__ram_ext__DOT__Memory__v0[2U] 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__queue__DOT__ram_ext__DOT____Vlvbound_h669ad2d3__0[2U];
            vlSelfRef.__VdlyDim0__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__queue__DOT__ram_ext__DOT__Memory__v0 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__queue__DOT__enq_ptr_value;
            vlSelfRef.__VdlySet__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__queue__DOT__ram_ext__DOT__Memory__v0 = 1U;
        }
    }
    VL_SHIFTL_WWI(512,512,9, __Vtemp_1, VTestDriver__ConstPool__CONST_h1c449781_0, 
                  (0x1ffU & (IData)((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__s_bits_addr_REG 
                                     >> 0xcU))));
    VL_SHIFTL_WWI(512,512,9, __Vtemp_8, VTestDriver__ConstPool__CONST_h1c449781_0, 
                  (0x1ffU & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__r_req_addr));
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT___system_auto_cbus_fixedClockNode_anon_out_reset) {
        vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__valid_0[0U] 
            = VTestDriver__ConstPool__CONST_h93e1b771_0[0U];
        vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__valid_0[1U] 
            = VTestDriver__ConstPool__CONST_h93e1b771_0[1U];
        vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__valid_0[2U] 
            = VTestDriver__ConstPool__CONST_h93e1b771_0[2U];
        vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__valid_0[3U] 
            = VTestDriver__ConstPool__CONST_h93e1b771_0[3U];
        vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__valid_0[4U] 
            = VTestDriver__ConstPool__CONST_h93e1b771_0[4U];
        vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__valid_0[5U] 
            = VTestDriver__ConstPool__CONST_h93e1b771_0[5U];
        vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__valid_0[6U] 
            = VTestDriver__ConstPool__CONST_h93e1b771_0[6U];
        vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__valid_0[7U] 
            = VTestDriver__ConstPool__CONST_h93e1b771_0[7U];
        vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__valid_0[8U] 
            = VTestDriver__ConstPool__CONST_h93e1b771_0[8U];
        vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__valid_0[9U] 
            = VTestDriver__ConstPool__CONST_h93e1b771_0[9U];
        vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__valid_0[0xaU] 
            = VTestDriver__ConstPool__CONST_h93e1b771_0[0xaU];
        vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__valid_0[0xbU] 
            = VTestDriver__ConstPool__CONST_h93e1b771_0[0xbU];
        vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__valid_0[0xcU] 
            = VTestDriver__ConstPool__CONST_h93e1b771_0[0xcU];
        vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__valid_0[0xdU] 
            = VTestDriver__ConstPool__CONST_h93e1b771_0[0xdU];
        vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__valid_0[0xeU] 
            = VTestDriver__ConstPool__CONST_h93e1b771_0[0xeU];
        vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__valid_0[0xfU] 
            = VTestDriver__ConstPool__CONST_h93e1b771_0[0xfU];
    } else if (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__s2_valid) 
                & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__l2_error))) {
        vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__valid_0[0U] 
            = VTestDriver__ConstPool__CONST_h93e1b771_0[0U];
        vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__valid_0[1U] 
            = VTestDriver__ConstPool__CONST_h93e1b771_0[1U];
        vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__valid_0[2U] 
            = VTestDriver__ConstPool__CONST_h93e1b771_0[2U];
        vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__valid_0[3U] 
            = VTestDriver__ConstPool__CONST_h93e1b771_0[3U];
        vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__valid_0[4U] 
            = VTestDriver__ConstPool__CONST_h93e1b771_0[4U];
        vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__valid_0[5U] 
            = VTestDriver__ConstPool__CONST_h93e1b771_0[5U];
        vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__valid_0[6U] 
            = VTestDriver__ConstPool__CONST_h93e1b771_0[6U];
        vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__valid_0[7U] 
            = VTestDriver__ConstPool__CONST_h93e1b771_0[7U];
        vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__valid_0[8U] 
            = VTestDriver__ConstPool__CONST_h93e1b771_0[8U];
        vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__valid_0[9U] 
            = VTestDriver__ConstPool__CONST_h93e1b771_0[9U];
        vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__valid_0[0xaU] 
            = VTestDriver__ConstPool__CONST_h93e1b771_0[0xaU];
        vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__valid_0[0xbU] 
            = VTestDriver__ConstPool__CONST_h93e1b771_0[0xbU];
        vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__valid_0[0xcU] 
            = VTestDriver__ConstPool__CONST_h93e1b771_0[0xcU];
        vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__valid_0[0xdU] 
            = VTestDriver__ConstPool__CONST_h93e1b771_0[0xdU];
        vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__valid_0[0xeU] 
            = VTestDriver__ConstPool__CONST_h93e1b771_0[0xeU];
        vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__valid_0[0xfU] 
            = VTestDriver__ConstPool__CONST_h93e1b771_0[0xfU];
    } else if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__s_valid_REG) {
        if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__s_bits_rs1_REG) {
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__valid_0[0U] 
                = (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__valid_0[0U] 
                   & (~ __Vtemp_1[0U]));
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__valid_0[1U] 
                = (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__valid_0[1U] 
                   & (~ __Vtemp_1[1U]));
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__valid_0[2U] 
                = (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__valid_0[2U] 
                   & (~ __Vtemp_1[2U]));
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__valid_0[3U] 
                = (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__valid_0[3U] 
                   & (~ __Vtemp_1[3U]));
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__valid_0[4U] 
                = (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__valid_0[4U] 
                   & (~ __Vtemp_1[4U]));
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__valid_0[5U] 
                = (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__valid_0[5U] 
                   & (~ __Vtemp_1[5U]));
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__valid_0[6U] 
                = (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__valid_0[6U] 
                   & (~ __Vtemp_1[6U]));
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__valid_0[7U] 
                = (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__valid_0[7U] 
                   & (~ __Vtemp_1[7U]));
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__valid_0[8U] 
                = (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__valid_0[8U] 
                   & (~ __Vtemp_1[8U]));
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__valid_0[9U] 
                = (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__valid_0[9U] 
                   & (~ __Vtemp_1[9U]));
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__valid_0[0xaU] 
                = (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__valid_0[0xaU] 
                   & (~ __Vtemp_1[0xaU]));
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__valid_0[0xbU] 
                = (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__valid_0[0xbU] 
                   & (~ __Vtemp_1[0xbU]));
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__valid_0[0xcU] 
                = (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__valid_0[0xcU] 
                   & (~ __Vtemp_1[0xcU]));
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__valid_0[0xdU] 
                = (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__valid_0[0xdU] 
                   & (~ __Vtemp_1[0xdU]));
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__valid_0[0xeU] 
                = (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__valid_0[0xeU] 
                   & (~ __Vtemp_1[0xeU]));
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__valid_0[0xfU] 
                = (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__valid_0[0xfU] 
                   & (~ __Vtemp_1[0xfU]));
        } else if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__s_bits_rs2_REG) {
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__valid_0[0U] 
                = (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__valid_0[0U] 
                   & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__g_0[0U]);
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__valid_0[1U] 
                = (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__valid_0[1U] 
                   & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__g_0[1U]);
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__valid_0[2U] 
                = (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__valid_0[2U] 
                   & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__g_0[2U]);
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__valid_0[3U] 
                = (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__valid_0[3U] 
                   & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__g_0[3U]);
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__valid_0[4U] 
                = (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__valid_0[4U] 
                   & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__g_0[4U]);
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__valid_0[5U] 
                = (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__valid_0[5U] 
                   & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__g_0[5U]);
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__valid_0[6U] 
                = (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__valid_0[6U] 
                   & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__g_0[6U]);
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__valid_0[7U] 
                = (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__valid_0[7U] 
                   & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__g_0[7U]);
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__valid_0[8U] 
                = (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__valid_0[8U] 
                   & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__g_0[8U]);
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__valid_0[9U] 
                = (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__valid_0[9U] 
                   & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__g_0[9U]);
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__valid_0[0xaU] 
                = (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__valid_0[0xaU] 
                   & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__g_0[0xaU]);
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__valid_0[0xbU] 
                = (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__valid_0[0xbU] 
                   & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__g_0[0xbU]);
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__valid_0[0xcU] 
                = (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__valid_0[0xcU] 
                   & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__g_0[0xcU]);
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__valid_0[0xdU] 
                = (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__valid_0[0xdU] 
                   & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__g_0[0xdU]);
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__valid_0[0xeU] 
                = (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__valid_0[0xeU] 
                   & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__g_0[0xeU]);
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__valid_0[0xfU] 
                = (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__valid_0[0xfU] 
                   & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__g_0[0xfU]);
        } else {
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__valid_0[0U] 
                = VTestDriver__ConstPool__CONST_h93e1b771_0[0U];
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__valid_0[1U] 
                = VTestDriver__ConstPool__CONST_h93e1b771_0[1U];
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__valid_0[2U] 
                = VTestDriver__ConstPool__CONST_h93e1b771_0[2U];
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__valid_0[3U] 
                = VTestDriver__ConstPool__CONST_h93e1b771_0[3U];
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__valid_0[4U] 
                = VTestDriver__ConstPool__CONST_h93e1b771_0[4U];
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__valid_0[5U] 
                = VTestDriver__ConstPool__CONST_h93e1b771_0[5U];
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__valid_0[6U] 
                = VTestDriver__ConstPool__CONST_h93e1b771_0[6U];
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__valid_0[7U] 
                = VTestDriver__ConstPool__CONST_h93e1b771_0[7U];
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__valid_0[8U] 
                = VTestDriver__ConstPool__CONST_h93e1b771_0[8U];
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__valid_0[9U] 
                = VTestDriver__ConstPool__CONST_h93e1b771_0[9U];
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__valid_0[0xaU] 
                = VTestDriver__ConstPool__CONST_h93e1b771_0[0xaU];
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__valid_0[0xbU] 
                = VTestDriver__ConstPool__CONST_h93e1b771_0[0xbU];
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__valid_0[0xcU] 
                = VTestDriver__ConstPool__CONST_h93e1b771_0[0xcU];
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__valid_0[0xdU] 
                = VTestDriver__ConstPool__CONST_h93e1b771_0[0xdU];
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__valid_0[0xeU] 
                = VTestDriver__ConstPool__CONST_h93e1b771_0[0xeU];
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__valid_0[0xfU] 
                = VTestDriver__ConstPool__CONST_h93e1b771_0[0xfU];
        }
    } else {
        vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__valid_0[0U] 
            = (((- (IData)((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__l2_tlb_ram_MPORT_en))) 
                & __Vtemp_8[0U]) | vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__valid_0[0U]);
        vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__valid_0[1U] 
            = (((- (IData)((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__l2_tlb_ram_MPORT_en))) 
                & __Vtemp_8[1U]) | vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__valid_0[1U]);
        vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__valid_0[2U] 
            = (((- (IData)((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__l2_tlb_ram_MPORT_en))) 
                & __Vtemp_8[2U]) | vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__valid_0[2U]);
        vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__valid_0[3U] 
            = (((- (IData)((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__l2_tlb_ram_MPORT_en))) 
                & __Vtemp_8[3U]) | vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__valid_0[3U]);
        vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__valid_0[4U] 
            = (((- (IData)((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__l2_tlb_ram_MPORT_en))) 
                & __Vtemp_8[4U]) | vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__valid_0[4U]);
        vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__valid_0[5U] 
            = (((- (IData)((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__l2_tlb_ram_MPORT_en))) 
                & __Vtemp_8[5U]) | vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__valid_0[5U]);
        vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__valid_0[6U] 
            = (((- (IData)((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__l2_tlb_ram_MPORT_en))) 
                & __Vtemp_8[6U]) | vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__valid_0[6U]);
        vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__valid_0[7U] 
            = (((- (IData)((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__l2_tlb_ram_MPORT_en))) 
                & __Vtemp_8[7U]) | vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__valid_0[7U]);
        vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__valid_0[8U] 
            = (((- (IData)((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__l2_tlb_ram_MPORT_en))) 
                & __Vtemp_8[8U]) | vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__valid_0[8U]);
        vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__valid_0[9U] 
            = (((- (IData)((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__l2_tlb_ram_MPORT_en))) 
                & __Vtemp_8[9U]) | vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__valid_0[9U]);
        vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__valid_0[0xaU] 
            = (((- (IData)((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__l2_tlb_ram_MPORT_en))) 
                & __Vtemp_8[0xaU]) | vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__valid_0[0xaU]);
        vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__valid_0[0xbU] 
            = (((- (IData)((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__l2_tlb_ram_MPORT_en))) 
                & __Vtemp_8[0xbU]) | vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__valid_0[0xbU]);
        vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__valid_0[0xcU] 
            = (((- (IData)((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__l2_tlb_ram_MPORT_en))) 
                & __Vtemp_8[0xcU]) | vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__valid_0[0xcU]);
        vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__valid_0[0xdU] 
            = (((- (IData)((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__l2_tlb_ram_MPORT_en))) 
                & __Vtemp_8[0xdU]) | vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__valid_0[0xdU]);
        vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__valid_0[0xeU] 
            = (((- (IData)((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__l2_tlb_ram_MPORT_en))) 
                & __Vtemp_8[0xeU]) | vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__valid_0[0xeU]);
        vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__valid_0[0xfU] 
            = (((- (IData)((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__l2_tlb_ram_MPORT_en))) 
                & __Vtemp_8[0xfU]) | vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__valid_0[0xfU]);
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__l2_tlb_ram_MPORT_en) {
        VL_SHIFTL_WWI(512,512,9, __Vtemp_14, VTestDriver__ConstPool__CONST_h1c449781_0, 
                      (0x1ffU & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__r_req_addr));
        VL_SHIFTL_WWI(512,512,9, __Vtemp_16, VTestDriver__ConstPool__CONST_h1c449781_0, 
                      (0x1ffU & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__r_req_addr));
        if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__r_pte_g) {
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__g_0[0U] 
                = (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__g_0[0U] 
                   | __Vtemp_14[0U]);
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__g_0[1U] 
                = (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__g_0[1U] 
                   | __Vtemp_14[1U]);
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__g_0[2U] 
                = (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__g_0[2U] 
                   | __Vtemp_14[2U]);
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__g_0[3U] 
                = (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__g_0[3U] 
                   | __Vtemp_14[3U]);
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__g_0[4U] 
                = (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__g_0[4U] 
                   | __Vtemp_14[4U]);
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__g_0[5U] 
                = (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__g_0[5U] 
                   | __Vtemp_14[5U]);
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__g_0[6U] 
                = (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__g_0[6U] 
                   | __Vtemp_14[6U]);
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__g_0[7U] 
                = (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__g_0[7U] 
                   | __Vtemp_14[7U]);
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__g_0[8U] 
                = (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__g_0[8U] 
                   | __Vtemp_14[8U]);
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__g_0[9U] 
                = (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__g_0[9U] 
                   | __Vtemp_14[9U]);
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__g_0[0xaU] 
                = (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__g_0[0xaU] 
                   | __Vtemp_14[0xaU]);
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__g_0[0xbU] 
                = (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__g_0[0xbU] 
                   | __Vtemp_14[0xbU]);
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__g_0[0xcU] 
                = (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__g_0[0xcU] 
                   | __Vtemp_14[0xcU]);
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__g_0[0xdU] 
                = (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__g_0[0xdU] 
                   | __Vtemp_14[0xdU]);
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__g_0[0xeU] 
                = (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__g_0[0xeU] 
                   | __Vtemp_14[0xeU]);
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__g_0[0xfU] 
                = (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__g_0[0xfU] 
                   | __Vtemp_14[0xfU]);
        } else {
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__g_0[0U] 
                = (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__g_0[0U] 
                   & (~ __Vtemp_16[0U]));
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__g_0[1U] 
                = (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__g_0[1U] 
                   & (~ __Vtemp_16[1U]));
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__g_0[2U] 
                = (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__g_0[2U] 
                   & (~ __Vtemp_16[2U]));
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__g_0[3U] 
                = (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__g_0[3U] 
                   & (~ __Vtemp_16[3U]));
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__g_0[4U] 
                = (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__g_0[4U] 
                   & (~ __Vtemp_16[4U]));
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__g_0[5U] 
                = (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__g_0[5U] 
                   & (~ __Vtemp_16[5U]));
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__g_0[6U] 
                = (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__g_0[6U] 
                   & (~ __Vtemp_16[6U]));
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__g_0[7U] 
                = (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__g_0[7U] 
                   & (~ __Vtemp_16[7U]));
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__g_0[8U] 
                = (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__g_0[8U] 
                   & (~ __Vtemp_16[8U]));
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__g_0[9U] 
                = (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__g_0[9U] 
                   & (~ __Vtemp_16[9U]));
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__g_0[0xaU] 
                = (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__g_0[0xaU] 
                   & (~ __Vtemp_16[0xaU]));
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__g_0[0xbU] 
                = (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__g_0[0xbU] 
                   & (~ __Vtemp_16[0xbU]));
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__g_0[0xcU] 
                = (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__g_0[0xcU] 
                   & (~ __Vtemp_16[0xcU]));
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__g_0[0xdU] 
                = (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__g_0[0xdU] 
                   & (~ __Vtemp_16[0xdU]));
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__g_0[0xeU] 
                = (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__g_0[0xeU] 
                   & (~ __Vtemp_16[0xeU]));
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__g_0[0xfU] 
                = (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__ptw__DOT__g_0[0xfU] 
                   & (~ __Vtemp_16[0xfU]));
        }
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT___io_lsu_perf_acquire_T) {
        vlSelfRef.__VdlyVal__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__buffer_1__DOT__nodeOut_a_q__DOT__ram_ext__DOT__Memory__v0[0U] 
            = (0xfffffffeU & vlSelfRef.__VdlyVal__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__buffer_1__DOT__nodeOut_a_q__DOT__ram_ext__DOT__Memory__v0[0U]);
        vlSelfRef.__VdlyVal__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__buffer_1__DOT__nodeOut_a_q__DOT__ram_ext__DOT__Memory__v0[0U] 
            = ((1U & vlSelfRef.__VdlyVal__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__buffer_1__DOT__nodeOut_a_q__DOT__ram_ext__DOT__Memory__v0[0U]) 
               | ((IData)(((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__muxState_2)
                            ? ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__mmios_0__DOT___io_mem_access_bits_T_16)
                                ? ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__mmios_0__DOT___GEN_2)
                                    ? vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__mmios_0__DOT__req_data
                                    : 0ULL) : ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__mmios_0__DOT__send_resp)
                                                ? 0ULL
                                                : vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__mmios_0__DOT__req_data))
                            : 0ULL)) << 1U));
        vlSelfRef.__VdlyVal__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__buffer_1__DOT__nodeOut_a_q__DOT__ram_ext__DOT__Memory__v0[1U] 
            = (((IData)(((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__muxState_2)
                          ? ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__mmios_0__DOT___io_mem_access_bits_T_16)
                              ? ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__mmios_0__DOT___GEN_2)
                                  ? vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__mmios_0__DOT__req_data
                                  : 0ULL) : ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__mmios_0__DOT__send_resp)
                                              ? 0ULL
                                              : vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__mmios_0__DOT__req_data))
                          : 0ULL)) >> 0x1fU) | ((IData)(
                                                        (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__muxState_2)
                                                           ? 
                                                          ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__mmios_0__DOT___io_mem_access_bits_T_16)
                                                            ? 
                                                           ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__mmios_0__DOT___GEN_2)
                                                             ? vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__mmios_0__DOT__req_data
                                                             : 0ULL)
                                                            : 
                                                           ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__mmios_0__DOT__send_resp)
                                                             ? 0ULL
                                                             : vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__mmios_0__DOT__req_data))
                                                           : 0ULL) 
                                                         >> 0x20U)) 
                                                << 1U));
        vlSelfRef.__VdlyVal__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__buffer_1__DOT__nodeOut_a_q__DOT__ram_ext__DOT__Memory__v0[2U] 
            = ((0xfffffffeU & vlSelfRef.__VdlyVal__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__buffer_1__DOT__nodeOut_a_q__DOT__ram_ext__DOT__Memory__v0[2U]) 
               | ((IData)((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__muxState_2)
                             ? ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__mmios_0__DOT___io_mem_access_bits_T_16)
                                 ? ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__mmios_0__DOT___GEN_2)
                                     ? vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__mmios_0__DOT__req_data
                                     : 0ULL) : ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__mmios_0__DOT__send_resp)
                                                 ? 0ULL
                                                 : vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__mmios_0__DOT__req_data))
                             : 0ULL) >> 0x20U)) >> 0x1fU));
        vlSelfRef.__VdlyVal__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__buffer_1__DOT__nodeOut_a_q__DOT__ram_ext__DOT__Memory__v0[2U] 
            = ((0xfffffe01U & vlSelfRef.__VdlyVal__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__buffer_1__DOT__nodeOut_a_q__DOT__ram_ext__DOT__Memory__v0[2U]) 
               | (0x1feU & (((- (IData)((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__muxState_0))) 
                             | ((- (IData)((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__muxState_1))) 
                                | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__muxState_2)
                                    ? ((0xfU == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__mmios_0__DOT__req_uop_mem_cmd))
                                        ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__mmios_0__DOT____VdfgRegularize_he7d8c9a6_0_9)
                                        : ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__mmios_0__DOT____VdfgRegularize_he7d8c9a6_0_13)
                                            ? ((0xeU 
                                                == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__mmios_0__DOT__req_uop_mem_cmd))
                                                ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__mmios_0__DOT____VdfgRegularize_he7d8c9a6_0_9)
                                                : (
                                                   (0xdU 
                                                    == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__mmios_0__DOT__req_uop_mem_cmd))
                                                    ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__mmios_0__DOT____VdfgRegularize_he7d8c9a6_0_9)
                                                    : 
                                                   ((0xcU 
                                                     == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__mmios_0__DOT__req_uop_mem_cmd))
                                                     ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__mmios_0__DOT____VdfgRegularize_he7d8c9a6_0_9)
                                                     : 
                                                    ((8U 
                                                      == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__mmios_0__DOT__req_uop_mem_cmd))
                                                      ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__mmios_0__DOT____VdfgRegularize_he7d8c9a6_0_9)
                                                      : 
                                                     ((0xbU 
                                                       == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__mmios_0__DOT__req_uop_mem_cmd))
                                                       ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__mmios_0__DOT____VdfgRegularize_he7d8c9a6_0_9)
                                                       : 
                                                      ((0xaU 
                                                        == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__mmios_0__DOT__req_uop_mem_cmd))
                                                        ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__mmios_0__DOT____VdfgRegularize_he7d8c9a6_0_9)
                                                        : 
                                                       ((9U 
                                                         == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__mmios_0__DOT__req_uop_mem_cmd))
                                                         ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__mmios_0__DOT____VdfgRegularize_he7d8c9a6_0_9)
                                                         : 
                                                        ((4U 
                                                          == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__mmios_0__DOT__req_uop_mem_cmd))
                                                          ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__mmios_0__DOT____VdfgRegularize_he7d8c9a6_0_9)
                                                          : 0U))))))))
                                            : (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__mmios_0__DOT____VdfgRegularize_he7d8c9a6_0_9)))
                                    : 0U))) << 1U)));
        vlSelfRef.__VdlyVal__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__buffer_1__DOT__nodeOut_a_q__DOT__ram_ext__DOT__Memory__v0[2U] 
            = ((0x1ffU & vlSelfRef.__VdlyVal__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__buffer_1__DOT__nodeOut_a_q__DOT__ram_ext__DOT__Memory__v0[2U]) 
               | ((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__muxState_0)
                     ? ((IData)((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_0__DOT__req_addr 
                                 >> 6U)) << 6U) : 0U) 
                   | (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__muxState_1)
                        ? ((IData)((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_1__DOT__req_addr 
                                    >> 6U)) << 6U) : 0U) 
                      | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__muxState_2)
                          ? ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__mmios_0__DOT___GEN_4)
                              ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__mmios_0__DOT__req_addr)
                              : 0U) : 0U))) << 9U));
        vlSelfRef.__VdlyVal__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__buffer_1__DOT__nodeOut_a_q__DOT__ram_ext__DOT__Memory__v0[3U] 
            = ((0x1ffe00U & vlSelfRef.__VdlyVal__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__buffer_1__DOT__nodeOut_a_q__DOT__ram_ext__DOT__Memory__v0[3U]) 
               | (0x1fffffU & ((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__muxState_0)
                                  ? ((IData)((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_0__DOT__req_addr 
                                              >> 6U)) 
                                     << 6U) : 0U) | 
                                (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__muxState_1)
                                   ? ((IData)((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_1__DOT__req_addr 
                                               >> 6U)) 
                                      << 6U) : 0U) 
                                 | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__muxState_2)
                                     ? ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__mmios_0__DOT___GEN_4)
                                         ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__mmios_0__DOT__req_addr)
                                         : 0U) : 0U))) 
                               >> 0x17U)));
        vlSelfRef.__VdlyVal__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__buffer_1__DOT__nodeOut_a_q__DOT__ram_ext__DOT__Memory__v0[3U] 
            = ((0x1ffU & vlSelfRef.__VdlyVal__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__buffer_1__DOT__nodeOut_a_q__DOT__ram_ext__DOT__Memory__v0[3U]) 
               | (0x1ffe00U & ((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT___mshrs_io_mem_acquire_bits_opcode) 
                                 << 0x12U) | ((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__muxState_0)
                                                 ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_0__DOT____VdfgRegularize_h9e012354_0_13)
                                                 : 0U) 
                                               | (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__muxState_1)
                                                    ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_1__DOT____VdfgRegularize_h9e012354_0_13)
                                                    : 0U) 
                                                  | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__muxState_2)
                                                      ? 
                                                     ((0xfU 
                                                       == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__mmios_0__DOT__req_uop_mem_cmd))
                                                       ? 3U
                                                       : 
                                                      ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__mmios_0__DOT____VdfgRegularize_he7d8c9a6_0_13)
                                                        ? 
                                                       ((0xeU 
                                                         == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__mmios_0__DOT__req_uop_mem_cmd))
                                                         ? 2U
                                                         : 
                                                        ((0xdU 
                                                          == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__mmios_0__DOT__req_uop_mem_cmd))
                                                          ? 1U
                                                          : 
                                                         ((0xcU 
                                                           == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__mmios_0__DOT__req_uop_mem_cmd))
                                                           ? 0U
                                                           : 
                                                          ((8U 
                                                            == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__mmios_0__DOT__req_uop_mem_cmd))
                                                            ? 4U
                                                            : 
                                                           ((0xbU 
                                                             == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__mmios_0__DOT__req_uop_mem_cmd))
                                                             ? 2U
                                                             : 
                                                            ((0xaU 
                                                              == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__mmios_0__DOT__req_uop_mem_cmd))
                                                              ? 1U
                                                              : 
                                                             (((4U 
                                                                != (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__mmios_0__DOT__req_uop_mem_cmd)) 
                                                               | (9U 
                                                                  == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__mmios_0__DOT__req_uop_mem_cmd)))
                                                               ? 0U
                                                               : 3U)))))))
                                                        : 0U))
                                                      : 0U))) 
                                              << 0xfU)) 
                               | (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT___mshrs_io_mem_acquire_bits_size) 
                                   << 0xbU) | (0x600U 
                                               & ((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__muxState_1)
                                                     ? 1U
                                                     : 0U) 
                                                   | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__muxState_2)
                                                       ? 
                                                      ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__mmios_0__DOT___io_mem_access_bits_T_16)
                                                        ? 
                                                       (- (IData)((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__mmios_0__DOT___GEN_2)))
                                                        : 3U)
                                                       : 0U)) 
                                                  << 9U))))));
        vlSelfRef.__VdlyDim0__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__buffer_1__DOT__nodeOut_a_q__DOT__ram_ext__DOT__Memory__v0 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__buffer_1__DOT__nodeOut_a_q__DOT__enq_ptr_value;
        vlSelfRef.__VdlySet__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__buffer_1__DOT__nodeOut_a_q__DOT__ram_ext__DOT__Memory__v0 = 1U;
    }
}
