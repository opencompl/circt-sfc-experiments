// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See VTestDriver.h for the primary calling header

#include "VTestDriver__pch.h"
#include "VTestDriver___024root.h"

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__719(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__719\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__pred_rename_stage__DOT__busy_table_14 
        = ((1U & (~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT___system_auto_cbus_fixedClockNode_anon_out_reset))) 
           && (1U & (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__pred_rename_stage__DOT___GEN_22) 
                      & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__pred_rename_stage__DOT___GEN_19)) 
                     >> 0xeU)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__pred_rename_stage__DOT__busy_table_12 
        = ((1U & (~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT___system_auto_cbus_fixedClockNode_anon_out_reset))) 
           && (1U & (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__pred_rename_stage__DOT___GEN_22) 
                      & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__pred_rename_stage__DOT___GEN_19)) 
                     >> 0xcU)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__pred_rename_stage__DOT__busy_table_11 
        = ((1U & (~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT___system_auto_cbus_fixedClockNode_anon_out_reset))) 
           && (1U & (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__pred_rename_stage__DOT___GEN_22) 
                      & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__pred_rename_stage__DOT___GEN_19)) 
                     >> 0xbU)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__pred_rename_stage__DOT__busy_table_8 
        = ((1U & (~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT___system_auto_cbus_fixedClockNode_anon_out_reset))) 
           && (1U & (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__pred_rename_stage__DOT___GEN_22) 
                      & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__pred_rename_stage__DOT___GEN_19)) 
                     >> 8U)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__pred_rename_stage__DOT__busy_table_3 
        = ((1U & (~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT___system_auto_cbus_fixedClockNode_anon_out_reset))) 
           && (1U & (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__pred_rename_stage__DOT___GEN_22) 
                      & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__pred_rename_stage__DOT___GEN_19)) 
                     >> 3U)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__pred_rename_stage__DOT__busy_table_0 
        = ((1U & (~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT___system_auto_cbus_fixedClockNode_anon_out_reset))) 
           && (1U & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__pred_rename_stage__DOT___GEN_22) 
                     & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__pred_rename_stage__DOT___GEN_19))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__pred_rename_stage__DOT__busy_table_1 
        = ((1U & (~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT___system_auto_cbus_fixedClockNode_anon_out_reset))) 
           && (1U & (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__pred_rename_stage__DOT___GEN_22) 
                      & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__pred_rename_stage__DOT___GEN_19)) 
                     >> 1U)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__pred_rename_stage__DOT__busy_table_2 
        = ((1U & (~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT___system_auto_cbus_fixedClockNode_anon_out_reset))) 
           && (1U & (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__pred_rename_stage__DOT___GEN_22) 
                      & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__pred_rename_stage__DOT___GEN_19)) 
                     >> 2U)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__pred_rename_stage__DOT__busy_table_5 
        = ((1U & (~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT___system_auto_cbus_fixedClockNode_anon_out_reset))) 
           && (1U & (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__pred_rename_stage__DOT___GEN_22) 
                      & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__pred_rename_stage__DOT___GEN_19)) 
                     >> 5U)));
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__720(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__720\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__pred_rename_stage__DOT__busy_table_7 
        = ((1U & (~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT___system_auto_cbus_fixedClockNode_anon_out_reset))) 
           && (1U & (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__pred_rename_stage__DOT___GEN_22) 
                      & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__pred_rename_stage__DOT___GEN_19)) 
                     >> 7U)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__pred_rename_stage__DOT__busy_table_9 
        = ((1U & (~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT___system_auto_cbus_fixedClockNode_anon_out_reset))) 
           && (1U & (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__pred_rename_stage__DOT___GEN_22) 
                      & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__pred_rename_stage__DOT___GEN_19)) 
                     >> 9U)));
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT___system_auto_cbus_fixedClockNode_anon_out_reset) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__serial_tl_domain__DOT__phy__DOT__in_phits_io_inner_ser_1_in_q__DOT__maybe_full = 0U;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__serial_tl_domain__DOT__phy__DOT__in_phits_io_inner_ser_2_in_q__DOT__maybe_full = 0U;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__serial_tl_domain__DOT__phy__DOT__in_phits_io_inner_ser_3_in_q__DOT__maybe_full = 0U;
    } else {
        if (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__serial_tl_domain__DOT__phy__DOT__in_phits_io_inner_ser_1_in_q__DOT__do_enq) 
             != (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__serial_tl_domain__DOT__serdesser__DOT__des_1__DOT___GEN))) {
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__serial_tl_domain__DOT__phy__DOT__in_phits_io_inner_ser_1_in_q__DOT__maybe_full 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__serial_tl_domain__DOT__phy__DOT__in_phits_io_inner_ser_1_in_q__DOT__do_enq;
        }
        if (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__serial_tl_domain__DOT__phy__DOT__in_phits_io_inner_ser_2_in_q__DOT__do_enq) 
             != (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__serial_tl_domain__DOT__serdesser__DOT__des_2__DOT___GEN))) {
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__serial_tl_domain__DOT__phy__DOT__in_phits_io_inner_ser_2_in_q__DOT__maybe_full 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__serial_tl_domain__DOT__phy__DOT__in_phits_io_inner_ser_2_in_q__DOT__do_enq;
        }
        if (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__serial_tl_domain__DOT__phy__DOT__in_phits_io_inner_ser_3_in_q__DOT__do_enq) 
             != (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__serial_tl_domain__DOT__serdesser__DOT__des_3__DOT___GEN))) {
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__serial_tl_domain__DOT__phy__DOT__in_phits_io_inner_ser_3_in_q__DOT__maybe_full 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__serial_tl_domain__DOT__phy__DOT__in_phits_io_inner_ser_3_in_q__DOT__do_enq;
        }
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__queue__DOT___GEN_6) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__queue__DOT__uops_0_pdst 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__fpu__DOT__pipe__DOT__uops_3_bits_uop_pdst;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__queue__DOT___GEN_10) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__queue__DOT__uops_2_pdst 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__fpu__DOT__pipe__DOT__uops_3_bits_uop_pdst;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__queue__DOT___GEN_8) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__queue__DOT__uops_1_pdst 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__fpu__DOT__pipe__DOT__uops_3_bits_uop_pdst;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__queue__DOT___GEN_12) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__queue__DOT__uops_3_pdst 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__fpu__DOT__pipe__DOT__uops_3_bits_uop_pdst;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__queue__DOT___GEN_14) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__queue__DOT__uops_4_pdst 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__fpu__DOT__pipe__DOT__uops_3_bits_uop_pdst;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__queue__DOT___GEN_22) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__queue__DOT__uops_8_pdst 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__fpu__DOT__pipe__DOT__uops_3_bits_uop_pdst;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__queue__DOT___GEN_16) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__queue__DOT__uops_5_pdst 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__fpu__DOT__pipe__DOT__uops_3_bits_uop_pdst;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__queue__DOT___GEN_18) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__queue__DOT__uops_6_pdst 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__fpu__DOT__pipe__DOT__uops_3_bits_uop_pdst;
    }
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__721(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__721\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__queue__DOT___GEN_20) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__queue__DOT__uops_7_pdst 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__fpu__DOT__pipe__DOT__uops_3_bits_uop_pdst;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__queue__DOT___GEN_24) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__queue__DOT__uops_9_pdst 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__fpu__DOT__pipe__DOT__uops_3_bits_uop_pdst;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT___system_auto_cbus_fixedClockNode_anon_out_reset) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__buffer_1__DOT__nodeOut_c_q__DOT__maybe_full = 0U;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__bank__DOT__buffer__DOT__nodeOut_a_q__DOT__maybe_full = 0U;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__sbus__DOT__system_bus_xbar__DOT__state_2_0 = 0U;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__sbus__DOT__system_bus_xbar__DOT__state_3_0 = 0U;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__buffer_1__DOT__nodeIn_d_q__DOT__maybe_full = 0U;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__tlMasterXbar__DOT__state_0 = 0U;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__tlMasterXbar__DOT__state_1 = 0U;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__fbus__DOT__buffer__DOT__nodeIn_d_q__DOT__maybe_full = 0U;
    } else {
        if (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT___io_lsu_perf_release_T) 
             != (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__buffer_1__DOT__nodeOut_c_q__DOT__do_deq))) {
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__buffer_1__DOT__nodeOut_c_q__DOT__maybe_full 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT___io_lsu_perf_release_T;
        }
        if (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__bank__DOT__buffer__DOT__nodeOut_a_q__DOT__do_enq) 
             != (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__bank__DOT__buffer__DOT__nodeOut_a_q__DOT__do_deq))) {
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__bank__DOT__buffer__DOT__nodeOut_a_q__DOT__maybe_full 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__bank__DOT__buffer__DOT__nodeOut_a_q__DOT__do_enq;
        }
        if ((0U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__sbus__DOT__system_bus_xbar__DOT__beatsLeft_2))) {
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__sbus__DOT__system_bus_xbar__DOT__state_2_0 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__sbus__DOT__system_bus_xbar__DOT__winner_2_0;
        }
        if ((0U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__sbus__DOT__system_bus_xbar__DOT__beatsLeft_3))) {
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__sbus__DOT__system_bus_xbar__DOT__state_3_0 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__sbus__DOT__system_bus_xbar__DOT__winner_3_0;
        }
        if (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__buffer_1__DOT__nodeIn_d_q__DOT__do_enq) 
             != (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__buffer_1__DOT__nodeIn_d_q__DOT__do_deq))) {
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__buffer_1__DOT__nodeIn_d_q__DOT__maybe_full 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__buffer_1__DOT__nodeIn_d_q__DOT__do_enq;
        }
        if ((0U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__tlMasterXbar__DOT__beatsLeft))) {
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__tlMasterXbar__DOT__state_0 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__tlMasterXbar__DOT__winner_0;
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__tlMasterXbar__DOT__state_1 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__tlMasterXbar__DOT__winner_1;
        }
        if (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__fbus__DOT__buffer__DOT__nodeIn_d_q__DOT__do_enq) 
             != (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__fbus__DOT__buffer__DOT__nodeIn_d_q__DOT__do_deq))) {
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__fbus__DOT__buffer__DOT__nodeIn_d_q__DOT__maybe_full 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__fbus__DOT__buffer__DOT__nodeIn_d_q__DOT__do_enq;
        }
    }
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__rrd_uop_bits_prs1 
        = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__arb_uop_bits_prs1;
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__722(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__722\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT___system_auto_cbus_fixedClockNode_anon_out_reset) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__serial_tl_domain__DOT__phy__DOT__in_phits_io_inner_ser_4_in_q__DOT__maybe_full = 0U;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__uartClockDomainWrapper__DOT__uart_0__DOT__rxq__DOT__maybe_full = 0U;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__uartClockDomainWrapper__DOT__uart_0__DOT__txq__DOT__maybe_full = 0U;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__uartClockDomainWrapper__DOT__uart_0__DOT__rxwm = 0U;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__uartClockDomainWrapper__DOT__uart_0__DOT__txwm = 0U;
    } else {
        if (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__serial_tl_domain__DOT__phy__DOT__in_phits_io_inner_ser_4_in_q__DOT__do_enq) 
             != (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__serial_tl_domain__DOT__serdesser__DOT__des_4__DOT___GEN))) {
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__serial_tl_domain__DOT__phy__DOT__in_phits_io_inner_ser_4_in_q__DOT__maybe_full 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__serial_tl_domain__DOT__phy__DOT__in_phits_io_inner_ser_4_in_q__DOT__do_enq;
        }
        if (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__uartClockDomainWrapper__DOT__uart_0__DOT__rxq__DOT__do_enq) 
             != (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__uartClockDomainWrapper__DOT__uart_0__DOT__rxq__DOT__do_deq))) {
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__uartClockDomainWrapper__DOT__uart_0__DOT__rxq__DOT__maybe_full 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__uartClockDomainWrapper__DOT__uart_0__DOT__rxq__DOT__do_enq;
        }
        if (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__uartClockDomainWrapper__DOT__uart_0__DOT__txq__DOT__do_enq) 
             != (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__uartClockDomainWrapper__DOT__uart_0__DOT__txq__DOT__do_deq))) {
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__uartClockDomainWrapper__DOT__uart_0__DOT__txq__DOT__maybe_full 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__uartClockDomainWrapper__DOT__uart_0__DOT__txq__DOT__do_enq;
        }
        if (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__uartClockDomainWrapper__DOT__uart_0__DOT__out_woready_9) 
             & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT___pbus_auto_coupler_to_device_named_uart_0_control_xing_out_a_bits_mask) 
                >> 6U))) {
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__uartClockDomainWrapper__DOT__uart_0__DOT__rxwm 
                = (0xfU & (IData)((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT___pbus_auto_coupler_to_device_named_uart_0_control_xing_out_a_bits_data 
                                   >> 0x30U)));
        }
        if (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__uartClockDomainWrapper__DOT__uart_0__DOT__out_woready_9) 
             & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT___pbus_auto_coupler_to_device_named_uart_0_control_xing_out_a_bits_mask) 
                >> 2U))) {
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__uartClockDomainWrapper__DOT__uart_0__DOT__txwm 
                = (0xfU & (IData)((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT___pbus_auto_coupler_to_device_named_uart_0_control_xing_out_a_bits_data 
                                   >> 0x10U)));
        }
    }
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__rrd_uop_bits_prs2 
        = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__arb_uop_bits_prs2;
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_542) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_0_prs1 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_prs1;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_544) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_1_prs1 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_prs1;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_546) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_2_prs1 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_prs1;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_548) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_3_prs1 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_prs1;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_550) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_4_prs1 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_prs1;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_552) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_5_prs1 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_prs1;
    }
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__723(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__723\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_554) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_6_prs1 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_prs1;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_6_prs2 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_prs2;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_556) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_7_prs1 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_prs1;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_7_prs2 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_prs2;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_542) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_0_prs2 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_prs2;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_0_imm_rename 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_imm_rename;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_544) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_1_prs2 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_prs2;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_1_imm_rename 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_imm_rename;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_546) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_2_prs2 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_prs2;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_2_imm_rename 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_imm_rename;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_548) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_3_prs2 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_prs2;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_550) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_4_prs2 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_prs2;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_552) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_5_prs2 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_prs2;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT___system_auto_cbus_fixedClockNode_anon_out_reset) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__chipyard_prcictrl_domain__DOT__xbar__DOT__state_0 = 0U;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__chipyard_prcictrl_domain__DOT__xbar__DOT__state_1 = 0U;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__bank__DOT__buffer__DOT__nodeIn_d_q__DOT__maybe_full = 0U;
    } else {
        if ((0U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__chipyard_prcictrl_domain__DOT__xbar__DOT__beatsLeft))) {
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__chipyard_prcictrl_domain__DOT__xbar__DOT__state_0 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__chipyard_prcictrl_domain__DOT__xbar__DOT__winner_0;
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__chipyard_prcictrl_domain__DOT__xbar__DOT__state_1 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__chipyard_prcictrl_domain__DOT__xbar__DOT__winner_1;
        }
        if (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__bank__DOT__buffer__DOT__nodeIn_d_q__DOT__do_enq) 
             != (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__bank__DOT__buffer__DOT__nodeIn_d_q__DOT__do_deq))) {
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__bank__DOT__buffer__DOT__nodeIn_d_q__DOT__maybe_full 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__bank__DOT__buffer__DOT__nodeIn_d_q__DOT__do_enq;
        }
    }
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__724(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__724\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_548) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_3_imm_rename 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_imm_rename;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_3_lrs2 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_lrs2;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_3_fu_code_9 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fu_code_9;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_550) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_4_imm_rename 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_imm_rename;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_4_lrs2 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_lrs2;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_4_fu_code_9 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fu_code_9;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_552) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_5_imm_rename 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_imm_rename;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_5_lrs2 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_lrs2;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_5_fu_code_9 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fu_code_9;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_554) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_6_imm_rename 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_imm_rename;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_6_lrs2 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_lrs2;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_6_fu_code_9 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fu_code_9;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_556) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_7_imm_rename 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_imm_rename;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_7_lrs2 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_lrs2;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_542) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_0_lrs2 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_lrs2;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_0_fu_code_9 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fu_code_9;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_544) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_1_lrs2 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_lrs2;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_1_fu_code_9 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fu_code_9;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_546) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_2_lrs2 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_lrs2;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_2_fu_code_9 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fu_code_9;
    }
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__725(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__725\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_556) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_7_fu_code_9 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fu_code_9;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_7_fp_ctrl_div 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fp_ctrl_div;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_7_fp_ctrl_fastpipe 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fp_ctrl_fastpipe;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_542) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_0_fp_ctrl_div 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fp_ctrl_div;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_0_fp_ctrl_fastpipe 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fp_ctrl_fastpipe;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_0_fp_ctrl_toint 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fp_ctrl_toint;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_544) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_1_fp_ctrl_div 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fp_ctrl_div;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_1_fp_ctrl_fastpipe 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fp_ctrl_fastpipe;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_1_fp_ctrl_toint 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fp_ctrl_toint;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_546) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_2_fp_ctrl_div 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fp_ctrl_div;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_2_fp_ctrl_fastpipe 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fp_ctrl_fastpipe;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_2_fp_ctrl_toint 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fp_ctrl_toint;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_548) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_3_fp_ctrl_div 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fp_ctrl_div;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_3_fp_ctrl_fastpipe 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fp_ctrl_fastpipe;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_550) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_4_fp_ctrl_div 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fp_ctrl_div;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_4_fp_ctrl_fastpipe 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fp_ctrl_fastpipe;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_552) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_5_fp_ctrl_div 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fp_ctrl_div;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_5_fp_ctrl_fastpipe 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fp_ctrl_fastpipe;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_554) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_6_fp_ctrl_div 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fp_ctrl_div;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_6_fp_ctrl_fastpipe 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fp_ctrl_fastpipe;
    }
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__726(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__726\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_548) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_3_fp_ctrl_toint 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fp_ctrl_toint;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_3_fp_ctrl_swap23 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fp_ctrl_swap23;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_3_fp_ctrl_ren1 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fp_ctrl_ren1;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_550) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_4_fp_ctrl_toint 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fp_ctrl_toint;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_4_fp_ctrl_swap23 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fp_ctrl_swap23;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_4_fp_ctrl_ren1 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fp_ctrl_ren1;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_552) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_5_fp_ctrl_toint 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fp_ctrl_toint;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_5_fp_ctrl_swap23 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fp_ctrl_swap23;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_5_fp_ctrl_ren1 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fp_ctrl_ren1;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_554) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_6_fp_ctrl_toint 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fp_ctrl_toint;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_6_fp_ctrl_swap23 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fp_ctrl_swap23;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_6_fp_ctrl_ren1 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fp_ctrl_ren1;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_556) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_7_fp_ctrl_toint 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fp_ctrl_toint;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_7_fp_ctrl_swap23 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fp_ctrl_swap23;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_542) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_0_fp_ctrl_swap23 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fp_ctrl_swap23;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_0_fp_ctrl_ren1 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fp_ctrl_ren1;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_544) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_1_fp_ctrl_swap23 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fp_ctrl_swap23;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_1_fp_ctrl_ren1 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fp_ctrl_ren1;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_546) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_2_fp_ctrl_swap23 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fp_ctrl_swap23;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_2_fp_ctrl_ren1 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fp_ctrl_ren1;
    }
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__727(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__727\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_556) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_7_fp_ctrl_ren1 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fp_ctrl_ren1;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_7_fu_code_2 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fu_code_2;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_7_fu_code_3 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fu_code_3;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_542) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_0_fu_code_2 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fu_code_2;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_0_fu_code_3 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fu_code_3;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_544) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_1_fu_code_2 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fu_code_2;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_1_fu_code_3 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fu_code_3;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_546) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_2_fu_code_2 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fu_code_2;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_2_fu_code_3 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fu_code_3;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_548) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_3_fu_code_2 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fu_code_2;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_3_fu_code_3 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fu_code_3;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_550) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_4_fu_code_2 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fu_code_2;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_4_fu_code_3 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fu_code_3;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_552) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_5_fu_code_2 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fu_code_2;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_5_fu_code_3 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fu_code_3;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_554) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_6_fu_code_2 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fu_code_2;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_6_fu_code_3 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fu_code_3;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__io_fdiv_resp_fdivsqrt__DOT___GEN) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__io_fdiv_resp_fdivsqrt__DOT__r_sigs_div 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__exe_uop_bits_fp_ctrl_div;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT___system_auto_cbus_fixedClockNode_anon_out_reset) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__buffer_2__DOT__nodeIn_d_q__DOT__maybe_full = 0U;
    } else if (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__buffer_2__DOT__nodeIn_d_q__DOT__do_enq) 
                != (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT___buffer_2_auto_in_d_valid))) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__buffer_2__DOT__nodeIn_d_q__DOT__maybe_full 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__buffer_2__DOT__nodeIn_d_q__DOT__do_enq;
    }
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__728(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__728\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_542) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_0_fp_ctrl_typeTagIn 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fp_ctrl_typeTagIn;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_0_imm_packed 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_imm_packed;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_0_fu_code_0 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fu_code_0;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_544) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_1_fp_ctrl_typeTagIn 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fp_ctrl_typeTagIn;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_1_imm_packed 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_imm_packed;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_1_fu_code_0 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fu_code_0;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_546) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_2_fp_ctrl_typeTagIn 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fp_ctrl_typeTagIn;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_2_imm_packed 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_imm_packed;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_2_fu_code_0 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fu_code_0;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_548) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_3_fp_ctrl_typeTagIn 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fp_ctrl_typeTagIn;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_3_imm_packed 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_imm_packed;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_3_fu_code_0 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fu_code_0;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_550) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_4_fp_ctrl_typeTagIn 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fp_ctrl_typeTagIn;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_4_imm_packed 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_imm_packed;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_552) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_5_fp_ctrl_typeTagIn 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fp_ctrl_typeTagIn;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_5_imm_packed 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_imm_packed;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_554) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_6_fp_ctrl_typeTagIn 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fp_ctrl_typeTagIn;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_6_imm_packed 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_imm_packed;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_556) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_7_fp_ctrl_typeTagIn 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fp_ctrl_typeTagIn;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_7_imm_packed 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_imm_packed;
    }
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__729(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__729\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_550) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_4_fu_code_0 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fu_code_0;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_4_fcn_dw 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fcn_dw;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_4_ftq_idx 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_ftq_idx;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_552) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_5_fu_code_0 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fu_code_0;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_5_fcn_dw 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fcn_dw;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_5_ftq_idx 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_ftq_idx;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_554) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_6_fu_code_0 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fu_code_0;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_6_fcn_dw 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fcn_dw;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_6_ftq_idx 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_ftq_idx;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_556) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_7_fu_code_0 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fu_code_0;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_7_fcn_dw 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fcn_dw;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_7_ftq_idx 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_ftq_idx;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_542) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_0_fcn_dw 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fcn_dw;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_0_ftq_idx 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_ftq_idx;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_544) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_1_fcn_dw 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fcn_dw;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_1_ftq_idx 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_ftq_idx;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_546) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_2_fcn_dw 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fcn_dw;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_2_ftq_idx 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_ftq_idx;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_548) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_3_fcn_dw 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fcn_dw;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_3_ftq_idx 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_ftq_idx;
    }
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__730(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__730\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT___system_auto_cbus_fixedClockNode_anon_out_reset) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__fbus__DOT__fbus_xbar__DOT__state_1 = 0U;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__pbus__DOT__buffer_1__DOT__nodeOut_a_q__DOT__maybe_full = 0U;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__state_1 = 0U;
    } else {
        if ((0U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__fbus__DOT__fbus_xbar__DOT__beatsLeft))) {
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__fbus__DOT__fbus_xbar__DOT__state_1 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__fbus__DOT__fbus_xbar__DOT__winner_1;
        }
        if (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__pbus__DOT__buffer_1__DOT__nodeOut_a_q__DOT__do_enq) 
             != (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__pbus__DOT__buffer_1__DOT__nodeOut_a_q__DOT__do_deq))) {
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__pbus__DOT__buffer_1__DOT__nodeOut_a_q__DOT__maybe_full 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__pbus__DOT__buffer_1__DOT__nodeOut_a_q__DOT__do_enq;
        }
        if ((0U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__beatsLeft))) {
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__state_1 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__winner_1;
        }
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_542) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_0_fp_ctrl_fromint 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fp_ctrl_fromint;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_0_fcn_op 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fcn_op;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_544) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_1_fp_ctrl_fromint 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fp_ctrl_fromint;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_1_fcn_op 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fcn_op;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_546) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_2_fp_ctrl_fromint 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fp_ctrl_fromint;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_2_fcn_op 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fcn_op;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_548) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_3_fp_ctrl_fromint 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fp_ctrl_fromint;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_3_fcn_op 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fcn_op;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_550) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_4_fp_ctrl_fromint 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fp_ctrl_fromint;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_4_fcn_op 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fcn_op;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_552) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_5_fp_ctrl_fromint 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fp_ctrl_fromint;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_554) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_6_fp_ctrl_fromint 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fp_ctrl_fromint;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_556) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_7_fp_ctrl_fromint 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fp_ctrl_fromint;
    }
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__731(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__731\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_552) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_5_fcn_op 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fcn_op;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_5_fu_code_8 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fu_code_8;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_554) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_6_fcn_op 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fcn_op;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_6_fu_code_8 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fu_code_8;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_556) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_7_fcn_op 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fcn_op;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_7_fu_code_8 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fu_code_8;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_542) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_0_fu_code_8 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fu_code_8;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_0_bp_debug_if 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_bp_debug_if;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_544) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_1_fu_code_8 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fu_code_8;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_1_bp_debug_if 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_bp_debug_if;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_546) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_2_fu_code_8 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fu_code_8;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_2_bp_debug_if 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_bp_debug_if;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_548) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_3_fu_code_8 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fu_code_8;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_3_bp_debug_if 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_bp_debug_if;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_550) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_4_fu_code_8 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fu_code_8;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT___system_auto_cbus_fixedClockNode_anon_out_reset) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__buffer_1__DOT__nodeOut_a_q__DOT__maybe_full = 0U;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__fbus__DOT__fbus_xbar__DOT__state_0 = 0U;
    } else {
        if (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT___io_lsu_perf_acquire_T) 
             != (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__buffer_1__DOT__nodeOut_a_q__DOT__do_deq))) {
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__buffer_1__DOT__nodeOut_a_q__DOT__maybe_full 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT___io_lsu_perf_acquire_T;
        }
        if ((0U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__fbus__DOT__fbus_xbar__DOT__beatsLeft))) {
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__fbus__DOT__fbus_xbar__DOT__state_0 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__fbus__DOT__fbus_xbar__DOT__winner_0;
        }
    }
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__732(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__732\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_550) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_4_bp_debug_if 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_bp_debug_if;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_4_xcpt_ae_if 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_xcpt_ae_if;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_4_xcpt_pf_if 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_xcpt_pf_if;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_552) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_5_bp_debug_if 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_bp_debug_if;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_5_xcpt_ae_if 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_xcpt_ae_if;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_5_xcpt_pf_if 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_xcpt_pf_if;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_554) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_6_bp_debug_if 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_bp_debug_if;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_6_xcpt_ae_if 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_xcpt_ae_if;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_6_xcpt_pf_if 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_xcpt_pf_if;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_556) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_7_bp_debug_if 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_bp_debug_if;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_7_xcpt_ae_if 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_xcpt_ae_if;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_7_xcpt_pf_if 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_xcpt_pf_if;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_542) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_0_xcpt_ae_if 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_xcpt_ae_if;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_0_xcpt_pf_if 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_xcpt_pf_if;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_544) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_1_xcpt_ae_if 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_xcpt_ae_if;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_1_xcpt_pf_if 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_xcpt_pf_if;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_546) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_2_xcpt_ae_if 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_xcpt_ae_if;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_2_xcpt_pf_if 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_xcpt_pf_if;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_548) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_3_xcpt_ae_if 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_xcpt_ae_if;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_3_xcpt_pf_if 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_xcpt_pf_if;
    }
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__733(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__733\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_542) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_0_bp_xcpt_if 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_bp_xcpt_if;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_0_is_rocc 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_is_rocc;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_0_is_sfence 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_is_sfence;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_544) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_1_bp_xcpt_if 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_bp_xcpt_if;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_1_is_rocc 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_is_rocc;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_1_is_sfence 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_is_sfence;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_546) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_2_bp_xcpt_if 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_bp_xcpt_if;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_2_is_rocc 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_is_rocc;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_548) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_3_bp_xcpt_if 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_bp_xcpt_if;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_3_is_rocc 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_is_rocc;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_550) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_4_bp_xcpt_if 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_bp_xcpt_if;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_4_is_rocc 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_is_rocc;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_552) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_5_bp_xcpt_if 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_bp_xcpt_if;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_5_is_rocc 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_is_rocc;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_554) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_6_bp_xcpt_if 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_bp_xcpt_if;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_6_is_rocc 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_is_rocc;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_556) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_7_bp_xcpt_if 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_bp_xcpt_if;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_7_is_rocc 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_is_rocc;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT___system_auto_cbus_fixedClockNode_anon_out_reset) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__pbus__DOT__buffer__DOT__nodeIn_d_q__DOT__maybe_full = 0U;
    } else if (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__pbus__DOT__buffer__DOT__nodeIn_d_q__DOT__do_enq) 
                != (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__pbus__DOT__buffer__DOT__nodeIn_d_q__DOT__do_deq))) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__pbus__DOT__buffer__DOT__nodeIn_d_q__DOT__maybe_full 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__pbus__DOT__buffer__DOT__nodeIn_d_q__DOT__do_enq;
    }
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__734(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__734\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_546) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_2_is_sfence 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_is_sfence;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_2_iq_type_0 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_iq_type_0;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_2_iq_type_1 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_iq_type_1;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_548) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_3_is_sfence 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_is_sfence;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_3_iq_type_0 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_iq_type_0;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_3_iq_type_1 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_iq_type_1;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_550) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_4_is_sfence 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_is_sfence;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_4_iq_type_0 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_iq_type_0;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_4_iq_type_1 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_iq_type_1;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_552) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_5_is_sfence 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_is_sfence;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_5_iq_type_0 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_iq_type_0;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_5_iq_type_1 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_iq_type_1;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_554) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_6_is_sfence 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_is_sfence;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_6_iq_type_0 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_iq_type_0;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_556) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_7_is_sfence 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_is_sfence;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_7_iq_type_0 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_iq_type_0;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_542) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_0_iq_type_0 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_iq_type_0;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_0_iq_type_1 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_iq_type_1;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_544) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_1_iq_type_0 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_iq_type_0;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_1_iq_type_1 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_iq_type_1;
    }
}

extern const VlUnpacked<CData/*2:0*/, 128> VTestDriver__ConstPool__TABLE_h1127d7aa_0;
extern const VlUnpacked<CData/*1:0*/, 128> VTestDriver__ConstPool__TABLE_h57b64589_0;
extern const VlUnpacked<CData/*1:0*/, 128> VTestDriver__ConstPool__TABLE_h72df3708_0;
extern const VlUnpacked<CData/*0:0*/, 128> VTestDriver__ConstPool__TABLE_hd9cc75c2_0;

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__735(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__735\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Init
    CData/*6:0*/ __Vtableidx1;
    __Vtableidx1 = 0;
    // Body
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_554) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_6_iq_type_1 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_iq_type_1;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_556) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_7_iq_type_1 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_iq_type_1;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT___system_auto_cbus_fixedClockNode_anon_out_reset) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__tlMasterXbar__DOT__readys_mask = 3U;
    } else if (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__tlMasterXbar__DOT__latch) 
                & (0U != (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__tlMasterXbar__DOT__readys_valid)))) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__tlMasterXbar__DOT__readys_mask 
            = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__tlMasterXbar__DOT___readys_mask_T) 
               | (2U & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__tlMasterXbar__DOT___readys_mask_T) 
                        << 1U)));
    }
    __Vtableidx1 = ((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sourceD__DOT__queue__DOT__deq_ptr_value) 
                      << 5U) | (((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sourceD__DOT__queue__DOT__empty)) 
                                 & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sourceD__DOT____Vcellinp__queue__io_deq_ready) 
                                    & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sourceD__DOT___queue_io_deq_valid))) 
                                << 4U)) | (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sourceD__DOT__queue__DOT__enq_ptr_value) 
                                            << 2U) 
                                           | (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sourceD__DOT__queue__DOT__do_enq) 
                                               << 1U) 
                                              | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT___system_auto_cbus_fixedClockNode_anon_out_reset))));
    if ((1U & VTestDriver__ConstPool__TABLE_h1127d7aa_0
         [__Vtableidx1])) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sourceD__DOT__queue__DOT__enq_ptr_value 
            = VTestDriver__ConstPool__TABLE_h57b64589_0
            [__Vtableidx1];
    }
    if ((2U & VTestDriver__ConstPool__TABLE_h1127d7aa_0
         [__Vtableidx1])) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sourceD__DOT__queue__DOT__deq_ptr_value 
            = VTestDriver__ConstPool__TABLE_h72df3708_0
            [__Vtableidx1];
    }
    if ((4U & VTestDriver__ConstPool__TABLE_h1127d7aa_0
         [__Vtableidx1])) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sourceD__DOT__queue__DOT__maybe_full 
            = VTestDriver__ConstPool__TABLE_hd9cc75c2_0
            [__Vtableidx1];
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_542) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_0_iq_type_2 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_iq_type_2;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_544) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_1_iq_type_2 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_iq_type_2;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_546) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_2_iq_type_2 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_iq_type_2;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_548) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_3_iq_type_2 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_iq_type_2;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_550) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_4_iq_type_2 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_iq_type_2;
    }
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__736(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__736\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_552) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_5_iq_type_2 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_iq_type_2;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_5_is_mov 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_is_mov;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_554) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_6_iq_type_2 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_iq_type_2;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_6_is_mov 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_is_mov;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_556) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_7_iq_type_2 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_iq_type_2;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_7_is_mov 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_is_mov;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_542) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_0_is_mov 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_is_mov;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_544) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_1_is_mov 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_is_mov;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_546) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_2_is_mov 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_is_mov;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_548) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_3_is_mov 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_is_mov;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_550) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_4_is_mov 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_is_mov;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT___system_auto_cbus_fixedClockNode_anon_out_reset) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__state_0 = 0U;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__sbus__DOT__system_bus_xbar__DOT__readys_mask_2 = 3U;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__sbus__DOT__system_bus_xbar__DOT__readys_mask_3 = 3U;
    } else {
        if ((0U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__beatsLeft))) {
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__state_0 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT___wb_io_release_valid;
        }
        if (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__sbus__DOT__system_bus_xbar__DOT__latch_2) 
             & (0U != (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__sbus__DOT__system_bus_xbar__DOT__readys_valid_2)))) {
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__sbus__DOT__system_bus_xbar__DOT__readys_mask_2 
                = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__sbus__DOT__system_bus_xbar__DOT___readys_mask_T_10) 
                   | (2U & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__sbus__DOT__system_bus_xbar__DOT___readys_mask_T_10) 
                            << 1U)));
        }
        if (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__sbus__DOT__system_bus_xbar__DOT__latch_3) 
             & (0U != (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__sbus__DOT__system_bus_xbar__DOT__readys_valid_3)))) {
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__sbus__DOT__system_bus_xbar__DOT__readys_mask_3 
                = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__sbus__DOT__system_bus_xbar__DOT___readys_mask_T_15) 
                   | (2U & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__sbus__DOT__system_bus_xbar__DOT___readys_mask_T_15) 
                            << 1U)));
        }
    }
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__737(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__737\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if ((0U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__cork__DOT__d_first_counter))) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__cork__DOT__nodeIn_d_bits_sink_r 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__cork__DOT__pool__DOT__select;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT___system_auto_cbus_fixedClockNode_anon_out_reset) {
        vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_0_1__DOT__wrbypass_enq_idx = 0U;
        vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_1_1__DOT__wrbypass_enq_idx = 0U;
    } else {
        if ((1U & (~ ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_0_1__DOT___GEN_5)) 
                      | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_0_1__DOT__wrbypass_hit))))) {
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_0_1__DOT__wrbypass_enq_idx 
                = (1U & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_0_1__DOT__wrbypass_enq_idx) 
                         - (IData)(1U)));
        }
        if ((1U & (~ ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_1_1__DOT___GEN_5)) 
                      | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_1_1__DOT__wrbypass_hit))))) {
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_1_1__DOT__wrbypass_enq_idx 
                = (1U & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_1_1__DOT__wrbypass_enq_idx) 
                         - (IData)(1U)));
        }
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_0_1__DOT___GEN_5) {
        if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_0_1__DOT__wrbypass_hit) {
            if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_0_1__DOT__wrbypass_hits_0) {
                vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_0_1__DOT__wrbypass_0_0 
                    = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_0_1__DOT__update_wdata_0_ctr;
                vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_0_1__DOT__wrbypass_0_1 
                    = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_0_1__DOT__update_wdata_1_ctr;
                vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_0_1__DOT__wrbypass_0_2 
                    = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_0_1__DOT__update_wdata_2_ctr;
                vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_0_1__DOT__wrbypass_0_3 
                    = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_0_1__DOT__update_wdata_3_ctr;
            } else {
                vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_0_1__DOT__wrbypass_1_0 
                    = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_0_1__DOT__update_wdata_0_ctr;
                vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_0_1__DOT__wrbypass_1_1 
                    = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_0_1__DOT__update_wdata_1_ctr;
                vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_0_1__DOT__wrbypass_1_2 
                    = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_0_1__DOT__update_wdata_2_ctr;
                vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_0_1__DOT__wrbypass_1_3 
                    = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_0_1__DOT__update_wdata_3_ctr;
            }
        } else if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_0_1__DOT__wrbypass_enq_idx) {
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_0_1__DOT__wrbypass_1_0 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_0_1__DOT__update_wdata_0_ctr;
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_0_1__DOT__wrbypass_1_1 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_0_1__DOT__update_wdata_1_ctr;
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_0_1__DOT__wrbypass_1_2 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_0_1__DOT__update_wdata_2_ctr;
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_0_1__DOT__wrbypass_1_3 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_0_1__DOT__update_wdata_3_ctr;
        } else {
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_0_1__DOT__wrbypass_0_0 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_0_1__DOT__update_wdata_0_ctr;
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_0_1__DOT__wrbypass_0_1 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_0_1__DOT__update_wdata_1_ctr;
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_0_1__DOT__wrbypass_0_2 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_0_1__DOT__update_wdata_2_ctr;
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_0_1__DOT__wrbypass_0_3 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_0_1__DOT__update_wdata_3_ctr;
        }
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_1_1__DOT___GEN_5) {
        if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_1_1__DOT__wrbypass_hit) {
            if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_1_1__DOT__wrbypass_hits_0) {
                vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_1_1__DOT__wrbypass_0_0 
                    = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_1_1__DOT__update_wdata_0_ctr;
                vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_1_1__DOT__wrbypass_0_1 
                    = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_1_1__DOT__update_wdata_1_ctr;
                vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_1_1__DOT__wrbypass_0_2 
                    = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_1_1__DOT__update_wdata_2_ctr;
                vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_1_1__DOT__wrbypass_0_3 
                    = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_1_1__DOT__update_wdata_3_ctr;
            } else {
                vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_1_1__DOT__wrbypass_1_0 
                    = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_1_1__DOT__update_wdata_0_ctr;
                vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_1_1__DOT__wrbypass_1_1 
                    = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_1_1__DOT__update_wdata_1_ctr;
                vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_1_1__DOT__wrbypass_1_2 
                    = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_1_1__DOT__update_wdata_2_ctr;
                vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_1_1__DOT__wrbypass_1_3 
                    = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_1_1__DOT__update_wdata_3_ctr;
            }
        } else if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_1_1__DOT__wrbypass_enq_idx) {
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_1_1__DOT__wrbypass_1_0 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_1_1__DOT__update_wdata_0_ctr;
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_1_1__DOT__wrbypass_1_1 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_1_1__DOT__update_wdata_1_ctr;
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_1_1__DOT__wrbypass_1_2 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_1_1__DOT__update_wdata_2_ctr;
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_1_1__DOT__wrbypass_1_3 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_1_1__DOT__update_wdata_3_ctr;
        } else {
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_1_1__DOT__wrbypass_0_0 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_1_1__DOT__update_wdata_0_ctr;
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_1_1__DOT__wrbypass_0_1 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_1_1__DOT__update_wdata_1_ctr;
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_1_1__DOT__wrbypass_0_2 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_1_1__DOT__update_wdata_2_ctr;
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_1_1__DOT__wrbypass_0_3 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_1_1__DOT__update_wdata_3_ctr;
        }
    }
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__738(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__738\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT___system_auto_cbus_fixedClockNode_anon_out_reset) {
        vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_2_1__DOT__wrbypass_enq_idx = 0U;
        vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_3_1__DOT__wrbypass_enq_idx = 0U;
    } else {
        if ((1U & (~ ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_2_1__DOT___GEN_3)) 
                      | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_2_1__DOT__wrbypass_hit))))) {
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_2_1__DOT__wrbypass_enq_idx 
                = (1U & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_2_1__DOT__wrbypass_enq_idx) 
                         - (IData)(1U)));
        }
        if ((1U & (~ ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_3_1__DOT___GEN_3)) 
                      | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_3_1__DOT__wrbypass_hit))))) {
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_3_1__DOT__wrbypass_enq_idx 
                = (1U & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_3_1__DOT__wrbypass_enq_idx) 
                         - (IData)(1U)));
        }
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_2_1__DOT___GEN_3) {
        if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_2_1__DOT__wrbypass_hit) {
            if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_2_1__DOT__wrbypass_hits_0) {
                vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_2_1__DOT__wrbypass_0_0 
                    = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_2_1__DOT__update_wdata_0_ctr;
                vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_2_1__DOT__wrbypass_0_1 
                    = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_2_1__DOT__update_wdata_1_ctr;
                vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_2_1__DOT__wrbypass_0_2 
                    = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_2_1__DOT__update_wdata_2_ctr;
                vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_2_1__DOT__wrbypass_0_3 
                    = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_2_1__DOT__update_wdata_3_ctr;
            } else {
                vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_2_1__DOT__wrbypass_1_0 
                    = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_2_1__DOT__update_wdata_0_ctr;
                vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_2_1__DOT__wrbypass_1_1 
                    = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_2_1__DOT__update_wdata_1_ctr;
                vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_2_1__DOT__wrbypass_1_2 
                    = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_2_1__DOT__update_wdata_2_ctr;
                vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_2_1__DOT__wrbypass_1_3 
                    = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_2_1__DOT__update_wdata_3_ctr;
            }
        } else if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_2_1__DOT__wrbypass_enq_idx) {
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_2_1__DOT__wrbypass_1_0 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_2_1__DOT__update_wdata_0_ctr;
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_2_1__DOT__wrbypass_1_1 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_2_1__DOT__update_wdata_1_ctr;
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_2_1__DOT__wrbypass_1_2 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_2_1__DOT__update_wdata_2_ctr;
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_2_1__DOT__wrbypass_1_3 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_2_1__DOT__update_wdata_3_ctr;
        } else {
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_2_1__DOT__wrbypass_0_0 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_2_1__DOT__update_wdata_0_ctr;
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_2_1__DOT__wrbypass_0_1 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_2_1__DOT__update_wdata_1_ctr;
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_2_1__DOT__wrbypass_0_2 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_2_1__DOT__update_wdata_2_ctr;
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_2_1__DOT__wrbypass_0_3 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_2_1__DOT__update_wdata_3_ctr;
        }
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_3_1__DOT___GEN_3) {
        if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_3_1__DOT__wrbypass_hit) {
            if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_3_1__DOT__wrbypass_hits_0) {
                vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_3_1__DOT__wrbypass_0_0 
                    = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_3_1__DOT__update_wdata_0_ctr;
                vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_3_1__DOT__wrbypass_0_1 
                    = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_3_1__DOT__update_wdata_1_ctr;
                vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_3_1__DOT__wrbypass_0_2 
                    = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_3_1__DOT__update_wdata_2_ctr;
                vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_3_1__DOT__wrbypass_0_3 
                    = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_3_1__DOT__update_wdata_3_ctr;
            } else {
                vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_3_1__DOT__wrbypass_1_0 
                    = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_3_1__DOT__update_wdata_0_ctr;
                vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_3_1__DOT__wrbypass_1_1 
                    = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_3_1__DOT__update_wdata_1_ctr;
                vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_3_1__DOT__wrbypass_1_2 
                    = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_3_1__DOT__update_wdata_2_ctr;
                vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_3_1__DOT__wrbypass_1_3 
                    = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_3_1__DOT__update_wdata_3_ctr;
            }
        } else if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_3_1__DOT__wrbypass_enq_idx) {
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_3_1__DOT__wrbypass_1_0 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_3_1__DOT__update_wdata_0_ctr;
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_3_1__DOT__wrbypass_1_1 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_3_1__DOT__update_wdata_1_ctr;
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_3_1__DOT__wrbypass_1_2 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_3_1__DOT__update_wdata_2_ctr;
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_3_1__DOT__wrbypass_1_3 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_3_1__DOT__update_wdata_3_ctr;
        } else {
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_3_1__DOT__wrbypass_0_0 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_3_1__DOT__update_wdata_0_ctr;
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_3_1__DOT__wrbypass_0_1 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_3_1__DOT__update_wdata_1_ctr;
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_3_1__DOT__wrbypass_0_2 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_3_1__DOT__update_wdata_2_ctr;
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_3_1__DOT__wrbypass_0_3 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_3_1__DOT__update_wdata_3_ctr;
        }
    }
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__739(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__739\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT___system_auto_cbus_fixedClockNode_anon_out_reset) {
        vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_4_1__DOT__wrbypass_enq_idx = 0U;
        vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_5_1__DOT__wrbypass_enq_idx = 0U;
    } else {
        if ((1U & (~ ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_4_1__DOT___GEN_3)) 
                      | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_4_1__DOT__wrbypass_hit))))) {
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_4_1__DOT__wrbypass_enq_idx 
                = (1U & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_4_1__DOT__wrbypass_enq_idx) 
                         - (IData)(1U)));
        }
        if ((1U & (~ ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_5_1__DOT___GEN_3)) 
                      | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_5_1__DOT__wrbypass_hit))))) {
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_5_1__DOT__wrbypass_enq_idx 
                = (1U & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_5_1__DOT__wrbypass_enq_idx) 
                         - (IData)(1U)));
        }
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_4_1__DOT___GEN_3) {
        if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_4_1__DOT__wrbypass_hit) {
            if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_4_1__DOT__wrbypass_hits_0) {
                vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_4_1__DOT__wrbypass_0_0 
                    = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_4_1__DOT__update_wdata_0_ctr;
                vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_4_1__DOT__wrbypass_0_1 
                    = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_4_1__DOT__update_wdata_1_ctr;
                vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_4_1__DOT__wrbypass_0_2 
                    = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_4_1__DOT__update_wdata_2_ctr;
                vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_4_1__DOT__wrbypass_0_3 
                    = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_4_1__DOT__update_wdata_3_ctr;
            } else {
                vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_4_1__DOT__wrbypass_1_0 
                    = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_4_1__DOT__update_wdata_0_ctr;
                vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_4_1__DOT__wrbypass_1_1 
                    = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_4_1__DOT__update_wdata_1_ctr;
                vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_4_1__DOT__wrbypass_1_2 
                    = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_4_1__DOT__update_wdata_2_ctr;
                vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_4_1__DOT__wrbypass_1_3 
                    = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_4_1__DOT__update_wdata_3_ctr;
            }
        } else if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_4_1__DOT__wrbypass_enq_idx) {
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_4_1__DOT__wrbypass_1_0 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_4_1__DOT__update_wdata_0_ctr;
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_4_1__DOT__wrbypass_1_1 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_4_1__DOT__update_wdata_1_ctr;
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_4_1__DOT__wrbypass_1_2 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_4_1__DOT__update_wdata_2_ctr;
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_4_1__DOT__wrbypass_1_3 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_4_1__DOT__update_wdata_3_ctr;
        } else {
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_4_1__DOT__wrbypass_0_0 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_4_1__DOT__update_wdata_0_ctr;
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_4_1__DOT__wrbypass_0_1 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_4_1__DOT__update_wdata_1_ctr;
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_4_1__DOT__wrbypass_0_2 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_4_1__DOT__update_wdata_2_ctr;
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_4_1__DOT__wrbypass_0_3 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_4_1__DOT__update_wdata_3_ctr;
        }
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_5_1__DOT___GEN_3) {
        if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_5_1__DOT__wrbypass_hit) {
            if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_5_1__DOT__wrbypass_hits_0) {
                vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_5_1__DOT__wrbypass_0_0 
                    = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_5_1__DOT__update_wdata_0_ctr;
                vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_5_1__DOT__wrbypass_0_1 
                    = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_5_1__DOT__update_wdata_1_ctr;
                vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_5_1__DOT__wrbypass_0_2 
                    = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_5_1__DOT__update_wdata_2_ctr;
                vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_5_1__DOT__wrbypass_0_3 
                    = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_5_1__DOT__update_wdata_3_ctr;
            } else {
                vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_5_1__DOT__wrbypass_1_0 
                    = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_5_1__DOT__update_wdata_0_ctr;
                vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_5_1__DOT__wrbypass_1_1 
                    = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_5_1__DOT__update_wdata_1_ctr;
                vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_5_1__DOT__wrbypass_1_2 
                    = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_5_1__DOT__update_wdata_2_ctr;
                vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_5_1__DOT__wrbypass_1_3 
                    = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_5_1__DOT__update_wdata_3_ctr;
            }
        } else if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_5_1__DOT__wrbypass_enq_idx) {
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_5_1__DOT__wrbypass_1_0 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_5_1__DOT__update_wdata_0_ctr;
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_5_1__DOT__wrbypass_1_1 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_5_1__DOT__update_wdata_1_ctr;
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_5_1__DOT__wrbypass_1_2 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_5_1__DOT__update_wdata_2_ctr;
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_5_1__DOT__wrbypass_1_3 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_5_1__DOT__update_wdata_3_ctr;
        } else {
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_5_1__DOT__wrbypass_0_0 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_5_1__DOT__update_wdata_0_ctr;
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_5_1__DOT__wrbypass_0_1 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_5_1__DOT__update_wdata_1_ctr;
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_5_1__DOT__wrbypass_0_2 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_5_1__DOT__update_wdata_2_ctr;
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_5_1__DOT__wrbypass_0_3 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_5_1__DOT__update_wdata_3_ctr;
        }
    }
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__740(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__740\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_542) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_0_fp_val 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fp_val;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_0_fp_ctrl_ren3 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fp_ctrl_ren3;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_0_fu_code_4 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fu_code_4;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_544) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_1_fp_val 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fp_val;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_1_fp_ctrl_ren3 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fp_ctrl_ren3;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_1_fu_code_4 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fu_code_4;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_546) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_2_fp_val 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fp_val;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_2_fp_ctrl_ren3 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fp_ctrl_ren3;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_548) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_3_fp_val 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fp_val;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_3_fp_ctrl_ren3 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fp_ctrl_ren3;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_550) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_4_fp_val 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fp_val;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_4_fp_ctrl_ren3 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fp_ctrl_ren3;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_552) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_5_fp_val 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fp_val;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_5_fp_ctrl_ren3 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fp_ctrl_ren3;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_554) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_6_fp_val 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fp_val;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_6_fp_ctrl_ren3 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fp_ctrl_ren3;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_556) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_7_fp_val 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fp_val;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_7_fp_ctrl_ren3 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fp_ctrl_ren3;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT___system_auto_cbus_fixedClockNode_anon_out_reset) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__pbus__DOT__atomics__DOT__state_1 = 0U;
    } else if ((0U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__pbus__DOT__atomics__DOT__beatsLeft))) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__pbus__DOT__atomics__DOT__state_1 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__pbus__DOT__atomics__DOT__winner_1;
    }
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__741(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__741\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_546) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_2_fu_code_4 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fu_code_4;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_2_fp_ctrl_fma 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fp_ctrl_fma;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_548) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_3_fu_code_4 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fu_code_4;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_3_fp_ctrl_fma 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fp_ctrl_fma;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_550) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_4_fu_code_4 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fu_code_4;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_4_fp_ctrl_fma 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fp_ctrl_fma;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_552) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_5_fu_code_4 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fu_code_4;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_5_fp_ctrl_fma 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fp_ctrl_fma;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_554) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_6_fu_code_4 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fu_code_4;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_6_fp_ctrl_fma 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fp_ctrl_fma;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_556) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_7_fu_code_4 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fu_code_4;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_7_fp_ctrl_fma 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fp_ctrl_fma;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_542) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_0_fp_ctrl_fma 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fp_ctrl_fma;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_544) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_1_fp_ctrl_fma 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fp_ctrl_fma;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT___system_auto_cbus_fixedClockNode_anon_out_reset) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__chipyard_prcictrl_domain__DOT__xbar__DOT__readys_mask = 3U;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__buffer_2__DOT__nodeOut_a_q__DOT__maybe_full = 0U;
    } else {
        if (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__chipyard_prcictrl_domain__DOT__xbar__DOT__latch) 
             & (0U != (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__chipyard_prcictrl_domain__DOT__xbar__DOT__readys_valid)))) {
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__chipyard_prcictrl_domain__DOT__xbar__DOT__readys_mask 
                = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__chipyard_prcictrl_domain__DOT__xbar__DOT___readys_mask_T) 
                   | (2U & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__chipyard_prcictrl_domain__DOT__xbar__DOT___readys_mask_T) 
                            << 1U)));
        }
        if (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT___frontend_io_cpu_perf_acquire) 
             != (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__buffer_2__DOT__nodeOut_a_q__DOT__do_deq))) {
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__buffer_2__DOT__nodeOut_a_q__DOT__maybe_full 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT___frontend_io_cpu_perf_acquire;
        }
    }
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__742(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__742\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_542) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_0_fu_code_6 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fu_code_6;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_0_frs3_en 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_frs3_en;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_544) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_1_fu_code_6 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fu_code_6;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_1_frs3_en 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_frs3_en;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_546) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_2_fu_code_6 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fu_code_6;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_2_frs3_en 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_frs3_en;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_548) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_3_fu_code_6 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fu_code_6;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_3_frs3_en 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_frs3_en;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_550) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_4_fu_code_6 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fu_code_6;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_4_frs3_en 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_frs3_en;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_552) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_5_fu_code_6 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fu_code_6;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_5_frs3_en 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_frs3_en;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_554) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_6_fu_code_6 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fu_code_6;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_6_frs3_en 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_frs3_en;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_556) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_7_fu_code_6 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fu_code_6;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT___system_auto_cbus_fixedClockNode_anon_out_reset) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__pbus__DOT__out_xbar__DOT__state_0 = 0U;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__pbus__DOT__out_xbar__DOT__state_1 = 0U;
    } else if ((0U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__pbus__DOT__out_xbar__DOT__beatsLeft))) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__pbus__DOT__out_xbar__DOT__state_0 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__pbus__DOT__out_xbar__DOT__winner_0;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__pbus__DOT__out_xbar__DOT__state_1 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__pbus__DOT__out_xbar__DOT__winner_1;
    }
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__743(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__743\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_556) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_7_frs3_en 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_frs3_en;
    }
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_0_1_io_update_hist_REG 
        = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__s1_update_bits_ghist;
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_1_1_io_update_hist_REG 
        = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__s1_update_bits_ghist;
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_2_1_io_update_hist_REG 
        = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__s1_update_bits_ghist;
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_3_1_io_update_hist_REG 
        = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__s1_update_bits_ghist;
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_4_1_io_update_hist_REG 
        = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__s1_update_bits_ghist;
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_5_1_io_update_hist_REG 
        = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__s1_update_bits_ghist;
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT___system_auto_cbus_fixedClockNode_anon_out_reset) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__cbus__DOT__atomics__DOT__state_1 = 0U;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__fbus__DOT__fbus_xbar__DOT__readys_mask = 3U;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__mbus__DOT__coupler_to_memory_controller_port_named_axi4__DOT__tl2axi4__DOT__doneAW = 0U;
    } else {
        if ((0U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__cbus__DOT__atomics__DOT__beatsLeft))) {
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__cbus__DOT__atomics__DOT__state_1 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__cbus__DOT__atomics__DOT__winner_1;
        }
        if (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__fbus__DOT__fbus_xbar__DOT__latch) 
             & (0U != (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__fbus__DOT__fbus_xbar__DOT__readys_valid)))) {
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__fbus__DOT__fbus_xbar__DOT__readys_mask 
                = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__fbus__DOT__fbus_xbar__DOT___readys_mask_T) 
                   | (2U & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__fbus__DOT__fbus_xbar__DOT___readys_mask_T) 
                            << 1U)));
        }
        if (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__mbus__DOT___coupler_to_memory_controller_port_named_axi4_auto_widget_anon_in_a_ready) 
             & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__mbus__DOT___coupler_to_memory_controller_port_named_axi4_auto_tl_out_a_valid))) {
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__mbus__DOT__coupler_to_memory_controller_port_named_axi4__DOT__tl2axi4__DOT__doneAW 
                = (1U & (~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__mbus__DOT__coupler_to_memory_controller_port_named_axi4__DOT__tl2axi4__DOT__a_last)));
        }
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sourceD__DOT__s4_latch) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sourceD__DOT__s4_pdata_data 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sourceD__DOT__s3_pdata_data;
    }
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__io_core_clr_unsafe_0_valid_REG 
        = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__do_st_search_0;
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_valid 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_ld_val) 
           | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_st_val));
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_542) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_0_ppred 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_ppred;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_544) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_1_ppred 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_ppred;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_546) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_2_ppred 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_ppred;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_548) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_3_ppred 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_ppred;
    }
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__744(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__744\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_550) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_4_ppred 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_ppred;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_4_fp_ctrl_sqrt 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fp_ctrl_sqrt;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_4_fu_code_7 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fu_code_7;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_552) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_5_ppred 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_ppred;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_5_fp_ctrl_sqrt 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fp_ctrl_sqrt;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_5_fu_code_7 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fu_code_7;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_554) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_6_ppred 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_ppred;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_6_fp_ctrl_sqrt 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fp_ctrl_sqrt;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_6_fu_code_7 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fu_code_7;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_556) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_7_ppred 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_ppred;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_7_fp_ctrl_sqrt 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fp_ctrl_sqrt;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_7_fu_code_7 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fu_code_7;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_542) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_0_fp_ctrl_sqrt 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fp_ctrl_sqrt;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_0_fu_code_7 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fu_code_7;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_544) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_1_fp_ctrl_sqrt 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fp_ctrl_sqrt;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_1_fu_code_7 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fu_code_7;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_546) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_2_fp_ctrl_sqrt 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fp_ctrl_sqrt;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_2_fu_code_7 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fu_code_7;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_548) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_3_fp_ctrl_sqrt 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fp_ctrl_sqrt;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_3_fu_code_7 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fu_code_7;
    }
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__745(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__745\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__pbus__DOT__coupler_to_device_named_uart_0__DOT__fragmenter__DOT__repeater__DOT___GEN) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__pbus__DOT__coupler_to_device_named_uart_0__DOT__fragmenter__DOT__repeater__DOT__saved_size 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__pbus__DOT___buffer_auto_out_a_bits_size;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_542) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_0_ldst_is_rs1 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_ldst_is_rs1;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_0_br_tag 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_br_tag;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_0_is_sfb 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_is_sfb;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_544) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_1_ldst_is_rs1 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_ldst_is_rs1;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_1_br_tag 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_br_tag;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_546) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_2_ldst_is_rs1 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_ldst_is_rs1;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_2_br_tag 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_br_tag;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_548) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_3_ldst_is_rs1 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_ldst_is_rs1;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_3_br_tag 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_br_tag;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_550) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_4_ldst_is_rs1 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_ldst_is_rs1;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_4_br_tag 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_br_tag;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_552) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_5_ldst_is_rs1 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_ldst_is_rs1;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_5_br_tag 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_br_tag;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_554) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_6_ldst_is_rs1 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_ldst_is_rs1;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_6_br_tag 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_br_tag;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_556) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_7_ldst_is_rs1 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_ldst_is_rs1;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_7_br_tag 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_br_tag;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT___system_auto_cbus_fixedClockNode_anon_out_reset) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__cork__DOT__q_1__DOT__maybe_full = 0U;
    } else if (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__cork__DOT__q_1__DOT__do_enq) 
                != (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__cork__DOT__q_1__DOT__do_deq))) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__cork__DOT__q_1__DOT__maybe_full 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__cork__DOT__q_1__DOT__do_enq;
    }
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__746(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__746\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_544) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_1_is_sfb 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_is_sfb;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_1_exc_cause 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_exc_cause;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_546) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_2_is_sfb 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_is_sfb;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_2_exc_cause 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_exc_cause;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_548) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_3_is_sfb 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_is_sfb;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_3_exc_cause 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_exc_cause;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_550) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_4_is_sfb 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_is_sfb;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_4_exc_cause 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_exc_cause;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_552) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_5_is_sfb 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_is_sfb;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_5_exc_cause 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_exc_cause;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_554) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_6_is_sfb 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_is_sfb;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_6_exc_cause 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_exc_cause;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_556) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_7_is_sfb 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_is_sfb;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_7_exc_cause 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_exc_cause;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT___system_auto_cbus_fixedClockNode_anon_out_reset) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__fbus__DOT__coupler_from_port_named_serial_tl_0_in__DOT__buffer__DOT__nodeOut_a_q__DOT__maybe_full = 0U;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__ras_read_idx = 0U;
    } else {
        if (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__fbus__DOT__coupler_from_port_named_serial_tl_0_in__DOT__buffer__DOT__nodeOut_a_q__DOT__do_enq) 
             != (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__fbus__DOT__coupler_from_port_named_serial_tl_0_in__DOT__buffer__DOT__nodeOut_a_q__DOT__do_deq))) {
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__fbus__DOT__coupler_from_port_named_serial_tl_0_in__DOT__buffer__DOT__nodeOut_a_q__DOT__maybe_full 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__fbus__DOT__coupler_from_port_named_serial_tl_0_in__DOT__buffer__DOT__nodeOut_a_q__DOT__do_enq;
        }
        if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___f4_btb_corrections_io_enq_valid_T) {
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__ras_read_idx 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f4_io_enq_bits_ghist_ras_idx;
        }
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_542) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_0_exc_cause 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_exc_cause;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__fpu__DOT__fpu__DOT____Vcellinp__dfma__io_in_valid) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__fpu__DOT__fpu__DOT__dfma__DOT__in_fmaCmd 
            = (3U & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__exe_uop_bits_fcn_op));
    }
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__747(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__747\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__fpu__DOT__fpu__DOT____Vcellinp__sfma__io_in_valid) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__fpu__DOT__fpu__DOT__sfma__DOT__in_fmaCmd 
            = (3U & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__exe_uop_bits_fcn_op));
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_542) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_0_lrs1 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_lrs1;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_0_lrs1_rtype 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_lrs1_rtype;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_544) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_1_lrs1 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_lrs1;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_1_lrs1_rtype 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_lrs1_rtype;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_546) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_2_lrs1 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_lrs1;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_2_lrs1_rtype 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_lrs1_rtype;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_548) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_3_lrs1 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_lrs1;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_3_lrs1_rtype 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_lrs1_rtype;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_550) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_4_lrs1 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_lrs1;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_4_lrs1_rtype 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_lrs1_rtype;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_552) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_5_lrs1 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_lrs1;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_5_lrs1_rtype 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_lrs1_rtype;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_554) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_6_lrs1 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_lrs1;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_6_lrs1_rtype 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_lrs1_rtype;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_556) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_7_lrs1 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_lrs1;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_7_lrs1_rtype 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_lrs1_rtype;
    }
    if ((1U & (~ ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_6__DOT___GEN_96)) 
                  | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_6__DOT___new_meta_T))))) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_6__DOT__meta_way 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT___directory_io_result_bits_way;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT___system_auto_cbus_fixedClockNode_anon_out_reset) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__cbus__DOT__coupler_to_prci_ctrl__DOT__buffer__DOT__nodeOut_a_q__DOT__maybe_full = 0U;
    } else if (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__cbus__DOT__coupler_to_prci_ctrl__DOT__buffer__DOT__nodeOut_a_q__DOT__do_enq) 
                != (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__cbus__DOT__coupler_to_prci_ctrl__DOT__buffer__DOT__nodeOut_a_q__DOT__do_deq))) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__cbus__DOT__coupler_to_prci_ctrl__DOT__buffer__DOT__nodeOut_a_q__DOT__maybe_full 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__cbus__DOT__coupler_to_prci_ctrl__DOT__buffer__DOT__nodeOut_a_q__DOT__do_enq;
    }
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__748(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__748\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_542) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_0_fp_ctrl_typeTagOut 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fp_ctrl_typeTagOut;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_0_lrs2_rtype 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_lrs2_rtype;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_544) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_1_fp_ctrl_typeTagOut 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fp_ctrl_typeTagOut;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_1_lrs2_rtype 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_lrs2_rtype;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_546) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_2_fp_ctrl_typeTagOut 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fp_ctrl_typeTagOut;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_2_lrs2_rtype 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_lrs2_rtype;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_548) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_3_fp_ctrl_typeTagOut 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fp_ctrl_typeTagOut;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_3_lrs2_rtype 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_lrs2_rtype;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_550) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_4_fp_ctrl_typeTagOut 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fp_ctrl_typeTagOut;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_552) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_5_fp_ctrl_typeTagOut 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fp_ctrl_typeTagOut;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_554) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_6_fp_ctrl_typeTagOut 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fp_ctrl_typeTagOut;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_556) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_7_fp_ctrl_typeTagOut 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fp_ctrl_typeTagOut;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT___system_auto_cbus_fixedClockNode_anon_out_reset) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__reg_senvcfg_fiom = 0U;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_0__DOT__rpq__DOT__main__DOT__maybe_full = 0U;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_1__DOT__rpq__DOT__main__DOT__maybe_full = 0U;
    } else {
        if (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___csr_wen_T_4) 
             & (0x1ffU == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___decoded_addr_decoded_decoded_andMatrixOutputs_T_7)))) {
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__reg_senvcfg_fiom 
                = (1U & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___wdata_T_2) 
                         & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___wdata_T_6)));
        }
        if (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_0__DOT__rpq__DOT__main__DOT__do_enq) 
             != (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_0__DOT__rpq__DOT__main__DOT__do_deq))) {
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_0__DOT__rpq__DOT__main__DOT__maybe_full 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_0__DOT__rpq__DOT__main__DOT__do_enq;
        }
        if (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_1__DOT__rpq__DOT__main__DOT__do_enq) 
             != (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_1__DOT__rpq__DOT__main__DOT__do_deq))) {
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_1__DOT__rpq__DOT__main__DOT__maybe_full 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_1__DOT__rpq__DOT__main__DOT__do_enq;
        }
    }
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__749(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__749\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_550) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_4_lrs2_rtype 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_lrs2_rtype;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_552) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_5_lrs2_rtype 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_lrs2_rtype;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_554) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_6_lrs2_rtype 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_lrs2_rtype;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_556) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_7_lrs2_rtype 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_lrs2_rtype;
    }
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__p2_block_load_mask_7 
        = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__p1_block_load_mask_7;
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__p2_block_load_mask_6 
        = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__p1_block_load_mask_6;
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__p2_block_load_mask_5 
        = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__p1_block_load_mask_5;
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__p2_block_load_mask_4 
        = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__p1_block_load_mask_4;
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__p2_block_load_mask_3 
        = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__p1_block_load_mask_3;
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__p2_block_load_mask_2 
        = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__p1_block_load_mask_2;
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__p2_block_load_mask_1 
        = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__p1_block_load_mask_1;
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__p2_block_load_mask_0 
        = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__p1_block_load_mask_0;
    if (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___csr_wen_T_4) 
         & (0x7ffU == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___decoded_addr_decoded_decoded_andMatrixOutputs_T_81)))) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__reg_dscratch0 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__wdata;
    }
    if (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___csr_wen_T_4) 
         & (0xfffU == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___decoded_addr_decoded_decoded_andMatrixOutputs_T_55)))) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__reg_mtval 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___GEN_43;
    } else if ((1U & (~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___GEN_40)))) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__reg_mtval 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__tval;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT___system_auto_cbus_fixedClockNode_anon_out_reset) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__reg_menvcfg_fiom = 0U;
    } else if (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___csr_wen_T_4) 
                & (0x1ffU == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___decoded_addr_decoded_decoded_andMatrixOutputs_T_21)))) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__reg_menvcfg_fiom 
            = (1U & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___wdata_T_2) 
                     & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___wdata_T_6)));
    }
    if (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___csr_wen_T_4) 
         & (0xfffU == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___decoded_addr_decoded_decoded_andMatrixOutputs_T_52)))) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__reg_mscratch 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__wdata;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_542) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_0_fp_ctrl_ren2 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fp_ctrl_ren2;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_544) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_1_fp_ctrl_ren2 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fp_ctrl_ren2;
    }
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__750(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__750\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_546) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_2_fp_ctrl_ren2 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fp_ctrl_ren2;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_548) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_3_fp_ctrl_ren2 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fp_ctrl_ren2;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_550) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_4_fp_ctrl_ren2 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fp_ctrl_ren2;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_552) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_5_fp_ctrl_ren2 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fp_ctrl_ren2;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_554) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_6_fp_ctrl_ren2 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fp_ctrl_ren2;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_556) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_7_fp_ctrl_ren2 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fp_ctrl_ren2;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT___system_auto_cbus_fixedClockNode_anon_out_reset) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__pbus__DOT__out_xbar__DOT__readys_mask = 3U;
    } else if (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__pbus__DOT__out_xbar__DOT__latch) 
                & (0U != (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__pbus__DOT__out_xbar__DOT__readys_valid)))) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__pbus__DOT__out_xbar__DOT__readys_mask 
            = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__pbus__DOT__out_xbar__DOT___readys_mask_T) 
               | (2U & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__pbus__DOT__out_xbar__DOT___readys_mask_T) 
                        << 1U)));
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_134) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_uop_14_flush_on_commit 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rename_stage__DOT__r_uop_flush_on_commit;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_124) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_uop_4_flush_on_commit 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rename_stage__DOT__r_uop_flush_on_commit;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_145) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_uop_25_flush_on_commit 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rename_stage__DOT__r_uop_flush_on_commit;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_138) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_uop_18_flush_on_commit 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rename_stage__DOT__r_uop_flush_on_commit;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_123) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_uop_3_flush_on_commit 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rename_stage__DOT__r_uop_flush_on_commit;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_144) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_uop_24_flush_on_commit 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rename_stage__DOT__r_uop_flush_on_commit;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_129) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_uop_9_flush_on_commit 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rename_stage__DOT__r_uop_flush_on_commit;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_122) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_uop_2_flush_on_commit 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rename_stage__DOT__r_uop_flush_on_commit;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_143) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_uop_23_flush_on_commit 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rename_stage__DOT__r_uop_flush_on_commit;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_136) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_uop_16_flush_on_commit 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rename_stage__DOT__r_uop_flush_on_commit;
    }
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__751(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__751\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_128) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_uop_8_flush_on_commit 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rename_stage__DOT__r_uop_flush_on_commit;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_135) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_uop_15_flush_on_commit 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rename_stage__DOT__r_uop_flush_on_commit;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_120) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_uop_0_flush_on_commit 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rename_stage__DOT__r_uop_flush_on_commit;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_127) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_uop_7_flush_on_commit 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rename_stage__DOT__r_uop_flush_on_commit;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_148) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_uop_28_flush_on_commit 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rename_stage__DOT__r_uop_flush_on_commit;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_130) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_uop_10_flush_on_commit 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rename_stage__DOT__r_uop_flush_on_commit;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_141) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_uop_21_flush_on_commit 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rename_stage__DOT__r_uop_flush_on_commit;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_149) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_uop_29_flush_on_commit 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rename_stage__DOT__r_uop_flush_on_commit;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_132) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_uop_12_flush_on_commit 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rename_stage__DOT__r_uop_flush_on_commit;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_146) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_uop_26_flush_on_commit 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rename_stage__DOT__r_uop_flush_on_commit;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_151) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_uop_31_flush_on_commit 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rename_stage__DOT__r_uop_flush_on_commit;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_126) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_uop_6_flush_on_commit 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rename_stage__DOT__r_uop_flush_on_commit;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_147) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_uop_27_flush_on_commit 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rename_stage__DOT__r_uop_flush_on_commit;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_137) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_uop_17_flush_on_commit 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rename_stage__DOT__r_uop_flush_on_commit;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_131) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_uop_11_flush_on_commit 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rename_stage__DOT__r_uop_flush_on_commit;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_121) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_uop_1_flush_on_commit 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rename_stage__DOT__r_uop_flush_on_commit;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_142) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_uop_22_flush_on_commit 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rename_stage__DOT__r_uop_flush_on_commit;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_150) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_uop_30_flush_on_commit 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rename_stage__DOT__r_uop_flush_on_commit;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_139) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_uop_19_flush_on_commit 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rename_stage__DOT__r_uop_flush_on_commit;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_125) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_uop_5_flush_on_commit 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rename_stage__DOT__r_uop_flush_on_commit;
    }
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__752(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__752\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_140) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_uop_20_flush_on_commit 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rename_stage__DOT__r_uop_flush_on_commit;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_133) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_uop_13_flush_on_commit 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rename_stage__DOT__r_uop_flush_on_commit;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__fpu__DOT__fpu__DOT__sfma__DOT__valid) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__fpu__DOT__fpu__DOT__sfma__DOT__fma__DOT__mulAddRecFNToRaw_postMul_io_mulAddResult_pipe_b 
            = (0x1ffffffffffffULL & ((0xffffffffffffULL 
                                      & ((QData)((IData)(
                                                         (((0U 
                                                            != 
                                                            (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__fpu__DOT__fpu__DOT__sfma__DOT__in_in1[0U] 
                                                             >> 0x1dU)) 
                                                           << 0x17U) 
                                                          | (0x7fffffU 
                                                             & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__fpu__DOT__fpu__DOT__sfma__DOT__in_in1[0U])))) 
                                         * (QData)((IData)(
                                                           (((0U 
                                                              != 
                                                              (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__fpu__DOT__fpu__DOT__sfma__DOT__in_in2[0U] 
                                                               >> 0x1dU)) 
                                                             << 0x17U) 
                                                            | (0x7fffffU 
                                                               & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__fpu__DOT__fpu__DOT__sfma__DOT__in_in2[0U])))))) 
                                     + (0xffffffffffffULL 
                                        & (((QData)((IData)(
                                                            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__fpu__DOT__fpu__DOT__sfma__DOT__fma__DOT__mulAddRecFNToRaw_preMul__DOT__mainAlignedSigC[1U])) 
                                            << 0x1dU) 
                                           | ((QData)((IData)(
                                                              vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__fpu__DOT__fpu__DOT__sfma__DOT__fma__DOT__mulAddRecFNToRaw_preMul__DOT__mainAlignedSigC[0U])) 
                                              >> 3U)))));
    }
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT__io_resp_f2_2_is_br_REG 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT__s1_resp_2_valid) 
           & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT___GEN_9));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT__io_resp_f2_1_is_br_REG 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT__s1_resp_1_valid) 
           & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT___GEN_7));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT__io_resp_f2_0_is_br_REG 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT__s1_resp_0_valid) 
           & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT___GEN_5));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT__io_resp_f2_3_is_br_REG 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT__s1_resp_3_valid) 
           & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT___GEN_11));
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT___system_auto_cbus_fixedClockNode_anon_out_reset) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__cbus__DOT__buffer__DOT__nodeIn_d_q__DOT__maybe_full = 0U;
    } else if (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__cbus__DOT__buffer__DOT__nodeIn_d_q__DOT__do_enq) 
                != (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__cbus__DOT__buffer__DOT__nodeIn_d_q__DOT__do_deq))) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__cbus__DOT__buffer__DOT__nodeIn_d_q__DOT__maybe_full 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__cbus__DOT__buffer__DOT__nodeIn_d_q__DOT__do_enq;
    }
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__s3_provider_3 
        = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT___GEN_83;
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__s3_provider_2 
        = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT___GEN_67;
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__s3_provider_1 
        = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT___GEN_51;
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__s3_provider 
        = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT___GEN_34;
    if (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___csr_wen_T_4) 
         & (0x3ffU == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___decoded_addr_decoded_decoded_andMatrixOutputs_T_56)))) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__reg_mip_stip 
            = (1U & (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___new_mip_T_3) 
                      & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___new_mip_T_7)) 
                     >> 4U));
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__reg_mip_seip 
            = (1U & (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___new_mip_T_3) 
                      & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___new_mip_T_7)) 
                     >> 8U));
    }
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__753(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__753\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if ((1U & (~ (((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__bim__DOT___GEN_0)) 
                   | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__bim__DOT__wrbypass_hit)) 
                  | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__bim__DOT__wrbypass_enq_idx))))) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__bim__DOT__wrbypass_idxs_0 
            = (0x7ffU & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__bim__DOT__s1_update_idx));
    }
    if ((1U & (~ (((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__bim__DOT___GEN_0)) 
                   | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__bim__DOT__wrbypass_hit)) 
                  | (~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__bim__DOT__wrbypass_enq_idx)))))) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__bim__DOT__wrbypass_idxs_1 
            = (0x7ffU & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__bim__DOT__s1_update_idx));
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__bim__DOT___GEN_0) {
        if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__bim__DOT__wrbypass_hit) {
            if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__bim__DOT__wrbypass_hits_0) {
                vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__bim__DOT__wrbypass_0_0 
                    = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__bim__DOT__s1_update_wdata_0;
                vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__bim__DOT__wrbypass_0_1 
                    = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__bim__DOT__s1_update_wdata_1;
                vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__bim__DOT__wrbypass_0_2 
                    = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__bim__DOT__s1_update_wdata_2;
                vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__bim__DOT__wrbypass_0_3 
                    = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__bim__DOT__s1_update_wdata_3;
            } else {
                vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__bim__DOT__wrbypass_1_0 
                    = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__bim__DOT__s1_update_wdata_0;
                vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__bim__DOT__wrbypass_1_1 
                    = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__bim__DOT__s1_update_wdata_1;
                vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__bim__DOT__wrbypass_1_2 
                    = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__bim__DOT__s1_update_wdata_2;
                vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__bim__DOT__wrbypass_1_3 
                    = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__bim__DOT__s1_update_wdata_3;
            }
        } else if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__bim__DOT__wrbypass_enq_idx) {
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__bim__DOT__wrbypass_1_0 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__bim__DOT__s1_update_wdata_0;
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__bim__DOT__wrbypass_1_1 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__bim__DOT__s1_update_wdata_1;
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__bim__DOT__wrbypass_1_2 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__bim__DOT__s1_update_wdata_2;
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__bim__DOT__wrbypass_1_3 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__bim__DOT__s1_update_wdata_3;
        } else {
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__bim__DOT__wrbypass_0_0 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__bim__DOT__s1_update_wdata_0;
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__bim__DOT__wrbypass_0_1 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__bim__DOT__s1_update_wdata_1;
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__bim__DOT__wrbypass_0_2 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__bim__DOT__s1_update_wdata_2;
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__bim__DOT__wrbypass_0_3 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__bim__DOT__s1_update_wdata_3;
        }
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT___system_auto_cbus_fixedClockNode_anon_out_reset) {
        vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__bim__DOT__wrbypass_enq_idx = 0U;
    } else if ((1U & (~ ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__bim__DOT___GEN_0)) 
                         | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__bim__DOT__wrbypass_hit))))) {
        vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__bim__DOT__wrbypass_enq_idx 
            = (1U & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__bim__DOT__wrbypass_enq_idx) 
                     - (IData)(1U)));
    }
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__754(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__754\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT____Vcellinp__slots_7__io_in_uop_valid) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__slots_7__DOT__slot_uop_iw_p1_speculative_child 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__issue_slots_7_in_uop_bits_iw_p1_speculative_child;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__slots_7__DOT__slot_uop_iw_p2_speculative_child 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__issue_slots_7_in_uop_bits_iw_p2_speculative_child;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__slots_7__DOT__slot_uop_lrs2_rtype 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__issue_slots_7_in_uop_bits_lrs2_rtype;
    } else {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__slots_7__DOT__slot_uop_iw_p1_speculative_child 
            = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__slots_7__DOT___GEN_1) 
               & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__slots_7__DOT__prs1_wakeups_2));
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__slots_7__DOT__slot_uop_iw_p2_speculative_child 
            = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__slots_7__DOT___GEN_2) 
               & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__slots_7__DOT__prs2_wakeups_2));
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__alu_iss_unit__DOT____Vcellinp__slots_7__io_in_uop_valid) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__alu_iss_unit__DOT__slots_7__DOT__slot_uop_iw_p2_speculative_child 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__issue_slots_7_in_uop_bits_iw_p2_speculative_child;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__alu_iss_unit__DOT__slots_7__DOT__slot_uop_iw_p1_speculative_child 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__issue_slots_7_in_uop_bits_iw_p1_speculative_child;
    } else {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__alu_iss_unit__DOT__slots_7__DOT__slot_uop_iw_p2_speculative_child 
            = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__alu_iss_unit__DOT__slots_7__DOT___GEN_2) 
               & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__alu_iss_unit__DOT__slots_7__DOT__prs2_wakeups_2));
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__alu_iss_unit__DOT__slots_7__DOT__slot_uop_iw_p1_speculative_child 
            = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__alu_iss_unit__DOT__slots_7__DOT___GEN_1) 
               & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__alu_iss_unit__DOT__slots_7__DOT__prs1_wakeups_2));
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unq_iss_unit__DOT____Vcellinp__slots_7__io_in_uop_valid) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unq_iss_unit__DOT__slots_7__DOT__slot_uop_iw_p2_speculative_child 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__issue_slots_7_in_uop_bits_iw_p2_speculative_child;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unq_iss_unit__DOT__slots_7__DOT__slot_uop_iw_p1_speculative_child 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__issue_slots_7_in_uop_bits_iw_p1_speculative_child;
    } else {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unq_iss_unit__DOT__slots_7__DOT__slot_uop_iw_p2_speculative_child 
            = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unq_iss_unit__DOT__slots_7__DOT___GEN_2) 
               & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unq_iss_unit__DOT__slots_7__DOT__prs2_wakeups_2));
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unq_iss_unit__DOT__slots_7__DOT__slot_uop_iw_p1_speculative_child 
            = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unq_iss_unit__DOT__slots_7__DOT___GEN_1) 
               & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unq_iss_unit__DOT__slots_7__DOT__prs1_wakeups_2));
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT___system_auto_cbus_fixedClockNode_anon_out_reset) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__cbus__DOT__out_xbar__DOT__state_7 = 0U;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__cbus__DOT__out_xbar__DOT__state_2 = 0U;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__cbus__DOT__out_xbar__DOT__state_0 = 0U;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__cbus__DOT__out_xbar__DOT__state_1 = 0U;
    } else if ((0U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__cbus__DOT__out_xbar__DOT__beatsLeft))) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__cbus__DOT__out_xbar__DOT__state_7 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__cbus__DOT__out_xbar__DOT__winner_7;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__cbus__DOT__out_xbar__DOT__state_2 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__cbus__DOT__out_xbar__DOT__winner_2;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__cbus__DOT__out_xbar__DOT__state_0 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__cbus__DOT__out_xbar__DOT__winner_0;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__cbus__DOT__out_xbar__DOT__state_1 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__cbus__DOT__out_xbar__DOT__winner_1;
    }
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__755(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__755\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_542) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_0_iq_type_3 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_iq_type_3;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_544) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_1_iq_type_3 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_iq_type_3;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_546) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_2_iq_type_3 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_iq_type_3;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_548) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_3_iq_type_3 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_iq_type_3;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_550) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_4_iq_type_3 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_iq_type_3;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_552) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_5_iq_type_3 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_iq_type_3;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_554) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_6_iq_type_3 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_iq_type_3;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_556) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_7_iq_type_3 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_iq_type_3;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT___system_auto_cbus_fixedClockNode_anon_out_reset) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__cbus__DOT__out_xbar__DOT__state_6 = 0U;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__cork__DOT__state_1_2 = 0U;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__cork__DOT__state_1_1 = 0U;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__cork__DOT__q__DOT__maybe_full = 0U;
    } else {
        if ((0U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__cbus__DOT__out_xbar__DOT__beatsLeft))) {
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__cbus__DOT__out_xbar__DOT__state_6 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__cbus__DOT__out_xbar__DOT__winner_6;
        }
        if ((0U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__cork__DOT__beatsLeft_1))) {
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__cork__DOT__state_1_2 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__cork__DOT__winner_1_2;
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__cork__DOT__state_1_1 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__cork__DOT__winner_1_1;
        }
        if (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__cork__DOT__q__DOT__do_enq) 
             != (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__cork__DOT__q__DOT__do_deq))) {
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__cork__DOT__q__DOT__maybe_full 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__cork__DOT__q__DOT__do_enq;
        }
    }
    if (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___csr_wen_T_4) 
         & (0xfffU == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___decoded_addr_decoded_decoded_andMatrixOutputs_T_80)))) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__reg_dpc 
            = (0xfffffffffeULL & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__wdata);
    } else if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___GEN_37) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__reg_dpc 
            = (0xfffffffffeULL & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT____Vcellinp__csr__io_pc);
    }
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__756(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__756\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sourceD__DOT__s4_latch) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sourceD__DOT__s4_pdata_mask 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sourceD__DOT__s3_pdata_mask;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT___system_auto_cbus_fixedClockNode_anon_out_reset) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__cbus__DOT__out_xbar__DOT__state_4 = 0U;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__pbus__DOT__buffer__DOT__nodeOut_a_q__DOT__maybe_full = 0U;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__cbus__DOT__out_xbar__DOT__state_3 = 0U;
    } else {
        if ((0U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__cbus__DOT__out_xbar__DOT__beatsLeft))) {
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__cbus__DOT__out_xbar__DOT__state_4 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__cbus__DOT__out_xbar__DOT__winner_4;
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__cbus__DOT__out_xbar__DOT__state_3 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__cbus__DOT__out_xbar__DOT__winner_3;
        }
        if (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__pbus__DOT__buffer__DOT__nodeOut_a_q__DOT__do_enq) 
             != (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__pbus__DOT__buffer__DOT__nodeOut_a_q__DOT__do_deq))) {
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__pbus__DOT__buffer__DOT__nodeOut_a_q__DOT__maybe_full 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__pbus__DOT__buffer__DOT__nodeOut_a_q__DOT__do_enq;
        }
    }
    if (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___csr_wen_T_4) 
         & (0xfffU == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___decoded_addr_decoded_decoded_andMatrixOutputs_T_53)))) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__reg_mepc 
            = (0xfffffffffeULL & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__wdata);
    } else if ((1U & (~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___GEN_40)))) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__reg_mepc 
            = (0xfffffffffeULL & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT____Vcellinp__csr__io_pc);
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_542) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_0_fu_code_1 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fu_code_1;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_544) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_1_fu_code_1 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fu_code_1;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_546) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_2_fu_code_1 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fu_code_1;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_548) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_3_fu_code_1 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fu_code_1;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_550) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_4_fu_code_1 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fu_code_1;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_552) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_5_fu_code_1 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fu_code_1;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_554) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_6_fu_code_1 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fu_code_1;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_556) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_7_fu_code_1 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fu_code_1;
    }
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__757(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__757\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT____Vcellinp__slots_7__io_in_uop_valid) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__slots_7__DOT__slot_uop_prs1 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___dispatcher_io_dis_uops_3_0_bits_prs1;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__slots_7__DOT__slot_uop_prs2 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___dispatcher_io_dis_uops_3_0_bits_prs2;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT___system_auto_cbus_fixedClockNode_anon_out_reset) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__cbus__DOT__out_xbar__DOT__state_5 = 0U;
    } else if ((0U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__cbus__DOT__out_xbar__DOT__beatsLeft))) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__cbus__DOT__out_xbar__DOT__state_5 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__cbus__DOT__out_xbar__DOT__winner_5;
    }
    if ((1U & (~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__pred_rename_stage__DOT___GEN_20)))) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_rename_stage__DOT__r_uop_dst_rtype 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_dst_rtype;
    }
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__exe_uop_bits_fp_ctrl_fma 
        = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__rrd_uop_bits_fp_ctrl_fma;
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr_io_counters_1_inc_REG 
        = (((3U == (3U & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__reg_hpmevent_1))) 
            | (2U == (3U & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__reg_hpmevent_1))))
            ? (0U != ((IData)((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__reg_hpmevent_1 
                               >> 8U)) & ((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT___ptw_io_dpath_perf_l2miss) 
                                            << 5U) 
                                           | (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT___lsu_io_core_perf_tlbMiss) 
                                               << 4U) 
                                              | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT___frontend_io_cpu_perf_tlbMiss) 
                                                 << 3U))) 
                                          | (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT___lsu_io_core_perf_release) 
                                              << 2U) 
                                             | (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT___lsu_io_core_perf_acquire) 
                                                 << 1U) 
                                                | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT___frontend_io_cpu_perf_acquire))))))
            : ((1U == (3U & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__reg_hpmevent_1)))
                ? (0U != ((IData)((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__reg_hpmevent_1 
                                   >> 9U)) & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___GEN_10)))
                : ((IData)((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__reg_hpmevent_1 
                            >> 8U)) & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___rob_io_com_xcpt_valid))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr_io_counters_0_inc_REG 
        = (((3U == (3U & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__reg_hpmevent_0))) 
            | (2U == (3U & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__reg_hpmevent_0))))
            ? (0U != ((IData)((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__reg_hpmevent_0 
                               >> 8U)) & ((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT___ptw_io_dpath_perf_l2miss) 
                                            << 5U) 
                                           | (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT___lsu_io_core_perf_tlbMiss) 
                                               << 4U) 
                                              | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT___frontend_io_cpu_perf_tlbMiss) 
                                                 << 3U))) 
                                          | (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT___lsu_io_core_perf_release) 
                                              << 2U) 
                                             | (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT___lsu_io_core_perf_acquire) 
                                                 << 1U) 
                                                | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT___frontend_io_cpu_perf_acquire))))))
            : ((1U == (3U & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__reg_hpmevent_0)))
                ? (0U != ((IData)((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__reg_hpmevent_0 
                                   >> 9U)) & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___GEN_10)))
                : ((IData)((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__reg_hpmevent_0 
                            >> 8U)) & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___rob_io_com_xcpt_valid))));
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__758(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__758\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Init
    VlWide<4>/*127:0*/ __Vtemp_3;
    VlWide<4>/*127:0*/ __Vtemp_4;
    VlWide<4>/*127:0*/ __Vtemp_5;
    VlWide<4>/*127:0*/ __Vtemp_7;
    VlWide<4>/*127:0*/ __Vtemp_11;
    VlWide<4>/*127:0*/ __Vtemp_12;
    // Body
    if ((1U & (~ (IData)(vlSelfRef.__VdfgRegularize_h36cfaf1a_0_23)))) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sinkD__DOT__io_bs_adr_bits_beat_r 
            = (7U & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sinkD__DOT__beat) 
                     + (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT___bankedStore_io_sinkD_adr_ready)));
    }
    if ((1U & (~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT___fp_exe_unit_0_io_squash_iss)))) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__arb_uop_bits_frs3_en 
            = (1U & ((((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_7__DOT__slot_uop_frs3_en) 
                         << 7U) | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_6__DOT__slot_uop_frs3_en) 
                                   << 6U)) | (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_5__DOT__slot_uop_frs3_en) 
                                               << 5U) 
                                              | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_4__DOT__slot_uop_frs3_en) 
                                                 << 4U))) 
                      | ((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_3__DOT__slot_uop_frs3_en) 
                           << 3U) | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_2__DOT__slot_uop_frs3_en) 
                                     << 2U)) | (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_1__DOT__slot_uop_frs3_en) 
                                                 << 1U) 
                                                | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_0__DOT__slot_uop_frs3_en)))) 
                     >> (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__iss_signals_0_bits)));
    }
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__wb_ldst_forward_e_REG_uop_stq_idx 
        = (0xfU & (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_90 
                   >> (0x1fU & VL_SHIFTL_III(5,32,32, 
                                             (7U & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__lcam_ldq_idx_0)), 2U))));
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__fpu__DOT__fpu__DOT__dfma__DOT__valid) {
        __Vtemp_3[0U] = (IData)((((QData)((IData)((0U 
                                                   != 
                                                   (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__fpu__DOT__fpu__DOT__dfma__DOT__in_in1[1U] 
                                                    >> 0x1dU)))) 
                                  << 0x34U) | (0xfffffffffffffULL 
                                               & (((QData)((IData)(
                                                                   vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__fpu__DOT__fpu__DOT__dfma__DOT__in_in1[1U])) 
                                                   << 0x20U) 
                                                  | (QData)((IData)(
                                                                    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__fpu__DOT__fpu__DOT__dfma__DOT__in_in1[0U]))))));
        __Vtemp_3[1U] = (IData)(((((QData)((IData)(
                                                   (0U 
                                                    != 
                                                    (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__fpu__DOT__fpu__DOT__dfma__DOT__in_in1[1U] 
                                                     >> 0x1dU)))) 
                                   << 0x34U) | (0xfffffffffffffULL 
                                                & (((QData)((IData)(
                                                                    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__fpu__DOT__fpu__DOT__dfma__DOT__in_in1[1U])) 
                                                    << 0x20U) 
                                                   | (QData)((IData)(
                                                                     vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__fpu__DOT__fpu__DOT__dfma__DOT__in_in1[0U]))))) 
                                 >> 0x20U));
        __Vtemp_3[2U] = 0U;
        __Vtemp_3[3U] = 0U;
        __Vtemp_4[0U] = (IData)((((QData)((IData)((0U 
                                                   != 
                                                   (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__fpu__DOT__fpu__DOT__dfma__DOT__in_in2[1U] 
                                                    >> 0x1dU)))) 
                                  << 0x34U) | (0xfffffffffffffULL 
                                               & (((QData)((IData)(
                                                                   vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__fpu__DOT__fpu__DOT__dfma__DOT__in_in2[1U])) 
                                                   << 0x20U) 
                                                  | (QData)((IData)(
                                                                    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__fpu__DOT__fpu__DOT__dfma__DOT__in_in2[0U]))))));
        __Vtemp_4[1U] = (IData)(((((QData)((IData)(
                                                   (0U 
                                                    != 
                                                    (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__fpu__DOT__fpu__DOT__dfma__DOT__in_in2[1U] 
                                                     >> 0x1dU)))) 
                                   << 0x34U) | (0xfffffffffffffULL 
                                                & (((QData)((IData)(
                                                                    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__fpu__DOT__fpu__DOT__dfma__DOT__in_in2[1U])) 
                                                    << 0x20U) 
                                                   | (QData)((IData)(
                                                                     vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__fpu__DOT__fpu__DOT__dfma__DOT__in_in2[0U]))))) 
                                 >> 0x20U));
        __Vtemp_4[2U] = 0U;
        __Vtemp_4[3U] = 0U;
        VL_MUL_W(4, __Vtemp_5, __Vtemp_3, __Vtemp_4);
        __Vtemp_7[0U] = __Vtemp_5[0U];
        __Vtemp_7[1U] = __Vtemp_5[1U];
        __Vtemp_7[2U] = __Vtemp_5[2U];
        __Vtemp_7[3U] = (0x3ffU & __Vtemp_5[3U]);
        __Vtemp_11[0U] = ((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__fpu__DOT__fpu__DOT__dfma__DOT__fma__DOT__mulAddRecFNToRaw_preMul__DOT__mainAlignedSigC[1U] 
                           << 0x1dU) | (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__fpu__DOT__fpu__DOT__dfma__DOT__fma__DOT__mulAddRecFNToRaw_preMul__DOT__mainAlignedSigC[0U] 
                                        >> 3U));
        __Vtemp_11[1U] = ((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__fpu__DOT__fpu__DOT__dfma__DOT__fma__DOT__mulAddRecFNToRaw_preMul__DOT__mainAlignedSigC[2U] 
                           << 0x1dU) | (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__fpu__DOT__fpu__DOT__dfma__DOT__fma__DOT__mulAddRecFNToRaw_preMul__DOT__mainAlignedSigC[1U] 
                                        >> 3U));
        __Vtemp_11[2U] = ((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__fpu__DOT__fpu__DOT__dfma__DOT__fma__DOT__mulAddRecFNToRaw_preMul__DOT__mainAlignedSigC[3U] 
                           << 0x1dU) | (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__fpu__DOT__fpu__DOT__dfma__DOT__fma__DOT__mulAddRecFNToRaw_preMul__DOT__mainAlignedSigC[2U] 
                                        >> 3U));
        __Vtemp_11[3U] = (0x3ffU & (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__fpu__DOT__fpu__DOT__dfma__DOT__fma__DOT__mulAddRecFNToRaw_preMul__DOT__mainAlignedSigC[3U] 
                                    >> 3U));
        VL_ADD_W(4, __Vtemp_12, __Vtemp_7, __Vtemp_11);
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__fpu__DOT__fpu__DOT__dfma__DOT__fma__DOT__mulAddRecFNToRaw_postMul_io_mulAddResult_pipe_b[0U] 
            = __Vtemp_12[0U];
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__fpu__DOT__fpu__DOT__dfma__DOT__fma__DOT__mulAddRecFNToRaw_postMul_io_mulAddResult_pipe_b[1U] 
            = __Vtemp_12[1U];
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__fpu__DOT__fpu__DOT__dfma__DOT__fma__DOT__mulAddRecFNToRaw_postMul_io_mulAddResult_pipe_b[2U] 
            = __Vtemp_12[2U];
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__fpu__DOT__fpu__DOT__dfma__DOT__fma__DOT__mulAddRecFNToRaw_postMul_io_mulAddResult_pipe_b[3U] 
            = (0x7ffU & __Vtemp_12[3U]);
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_542) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_0_br_type 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_br_type;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_544) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_1_br_type 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_br_type;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_546) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_2_br_type 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_br_type;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_548) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_3_br_type 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_br_type;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_550) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_4_br_type 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_br_type;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_552) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_5_br_type 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_br_type;
    }
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__759(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__759\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_554) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_6_br_type 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_br_type;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_6_fu_code_5 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fu_code_5;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_556) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_7_br_type 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_br_type;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_7_fu_code_5 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fu_code_5;
    }
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__wb_ldst_forward_e_REG_observed 
        = (1U & ((((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__ldq_observed_7) 
                     << 7U) | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__ldq_observed_6) 
                               << 6U)) | (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__ldq_observed_5) 
                                           << 5U) | 
                                          ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__ldq_observed_4) 
                                           << 4U))) 
                  | ((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__ldq_observed_3) 
                       << 3U) | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__ldq_observed_2) 
                                 << 2U)) | (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__ldq_observed_1) 
                                             << 1U) 
                                            | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__ldq_observed_0)))) 
                 >> (7U & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__lcam_ldq_idx_0))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__alu_exe_unit_0__DOT__exe_uop_bits_is_mov 
        = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__alu_exe_unit_0__DOT__rrd_uop_bits_is_mov;
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT____Vcellinp__slots_7__io_in_uop_valid) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__slots_7__DOT__slot_uop_lrs1_rtype 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rename_stage__DOT__r_uop_lrs1_rtype;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT___system_auto_cbus_fixedClockNode_anon_out_reset) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__cork__DOT__state_1_0 = 0U;
    } else if ((0U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__cork__DOT__beatsLeft_1))) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__cork__DOT__state_1_0 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT___binder_auto_in_d_valid;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_542) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_0_fu_code_5 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fu_code_5;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_0_is_fencei 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_is_fencei;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_544) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_1_fu_code_5 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fu_code_5;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_546) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_2_fu_code_5 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fu_code_5;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_548) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_3_fu_code_5 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fu_code_5;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_550) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_4_fu_code_5 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fu_code_5;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_552) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_5_fu_code_5 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_fu_code_5;
    }
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr_io_cause_REG 
        = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__r_xcpt_uop_exc_cause;
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__760(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__760\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_544) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_1_is_fencei 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_is_fencei;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_546) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_2_is_fencei 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_is_fencei;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_548) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_3_is_fencei 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_is_fencei;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_550) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_4_is_fencei 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_is_fencei;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_552) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_5_is_fencei 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_is_fencei;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_554) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_6_is_fencei 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_is_fencei;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_556) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_7_is_fencei 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_is_fencei;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT___system_auto_cbus_fixedClockNode_anon_out_reset) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__io_ifpu_resp_queue__DOT__maybe_full = 0U;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__reg_mstatus_tw = 0U;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__reg_mstatus_tsr = 0U;
    } else {
        if (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__io_ifpu_resp_queue__DOT__do_enq) 
             != (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__io_ifpu_resp_queue__DOT__do_deq))) {
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__io_ifpu_resp_queue__DOT__maybe_full 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unique_exe_unit_0__DOT__io_ifpu_resp_queue__DOT__do_enq;
        }
        if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___GEN_34) {
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__reg_mstatus_tw 
                = (1U & (IData)((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__wdata 
                                 >> 0x15U)));
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__reg_mstatus_tsr 
                = (1U & (IData)((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__wdata 
                                 >> 0x16U)));
        }
    }
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__wb_ldst_forward_e_REG_next_stq_idx 
        = (0xfU & (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_138 
                   >> (0x1fU & VL_SHIFTL_III(5,32,32, 
                                             (7U & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__lcam_ldq_idx_0)), 2U))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT__io_resp_f2_0_predicted_pc_REG_bits 
        = (0xffffffffffULL & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT__s1_hit_ohs_0_0)
                               ? ((1U & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT___btb_data_way_0_R0_data))
                                   ? vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT___btb_ebtb_R0_data
                                   : (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT__s1_pc 
                                      + (((QData)((IData)(
                                                          (0x7ffffffU 
                                                           & (- (IData)(
                                                                        (1U 
                                                                         & (IData)(
                                                                                (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT___btb_data_way_0_R0_data 
                                                                                >> 0xdU)))))))) 
                                          << 0xdU) 
                                         | (QData)((IData)(
                                                           (0x1fffU 
                                                            & (IData)(
                                                                      (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT___btb_data_way_0_R0_data 
                                                                       >> 1U))))))))
                               : ((1U & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT___btb_data_way_1_R0_data))
                                   ? vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT___btb_ebtb_R0_data
                                   : (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT__s1_pc 
                                      + (((QData)((IData)(
                                                          (0x7ffffffU 
                                                           & (- (IData)(
                                                                        (1U 
                                                                         & (IData)(
                                                                                (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT___btb_data_way_1_R0_data 
                                                                                >> 0xdU)))))))) 
                                          << 0xdU) 
                                         | (QData)((IData)(
                                                           (0x1fffU 
                                                            & (IData)(
                                                                      (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT___btb_data_way_1_R0_data 
                                                                       >> 1U))))))))));
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__761(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__761\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT__io_resp_f2_1_predicted_pc_REG_bits 
        = (0xffffffffffULL & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT__s1_hit_ohs_1_0)
                               ? ((1U & (IData)((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT___btb_data_way_0_R0_data 
                                                 >> 0xeU)))
                                   ? vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT___btb_ebtb_R0_data
                                   : (2ULL + (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT__s1_pc 
                                              + (((QData)((IData)(
                                                                  (0x7ffffffU 
                                                                   & (- (IData)(
                                                                                (1U 
                                                                                & (IData)(
                                                                                (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT___btb_data_way_0_R0_data 
                                                                                >> 0x1bU)))))))) 
                                                  << 0xdU) 
                                                 | (QData)((IData)(
                                                                   (0x1fffU 
                                                                    & (IData)(
                                                                              (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT___btb_data_way_0_R0_data 
                                                                               >> 0xfU)))))))))
                               : ((1U & (IData)((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT___btb_data_way_1_R0_data 
                                                 >> 0xeU)))
                                   ? vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT___btb_ebtb_R0_data
                                   : (2ULL + (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT__s1_pc 
                                              + (((QData)((IData)(
                                                                  (0x7ffffffU 
                                                                   & (- (IData)(
                                                                                (1U 
                                                                                & (IData)(
                                                                                (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT___btb_data_way_1_R0_data 
                                                                                >> 0x1bU)))))))) 
                                                  << 0xdU) 
                                                 | (QData)((IData)(
                                                                   (0x1fffU 
                                                                    & (IData)(
                                                                              (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT___btb_data_way_1_R0_data 
                                                                               >> 0xfU)))))))))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT__io_resp_f2_2_predicted_pc_REG_bits 
        = (0xffffffffffULL & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT__s1_hit_ohs_2_0)
                               ? ((1U & (IData)((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT___btb_data_way_0_R0_data 
                                                 >> 0x1cU)))
                                   ? vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT___btb_ebtb_R0_data
                                   : (4ULL + (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT__s1_pc 
                                              + (((QData)((IData)(
                                                                  (0x7ffffffU 
                                                                   & (- (IData)(
                                                                                (1U 
                                                                                & (IData)(
                                                                                (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT___btb_data_way_0_R0_data 
                                                                                >> 0x29U)))))))) 
                                                  << 0xdU) 
                                                 | (QData)((IData)(
                                                                   (0x1fffU 
                                                                    & (IData)(
                                                                              (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT___btb_data_way_0_R0_data 
                                                                               >> 0x1dU)))))))))
                               : ((1U & (IData)((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT___btb_data_way_1_R0_data 
                                                 >> 0x1cU)))
                                   ? vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT___btb_ebtb_R0_data
                                   : (4ULL + (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT__s1_pc 
                                              + (((QData)((IData)(
                                                                  (0x7ffffffU 
                                                                   & (- (IData)(
                                                                                (1U 
                                                                                & (IData)(
                                                                                (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT___btb_data_way_1_R0_data 
                                                                                >> 0x29U)))))))) 
                                                  << 0xdU) 
                                                 | (QData)((IData)(
                                                                   (0x1fffU 
                                                                    & (IData)(
                                                                              (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT___btb_data_way_1_R0_data 
                                                                               >> 0x1dU)))))))))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT__io_resp_f2_3_predicted_pc_REG_bits 
        = (0xffffffffffULL & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT__s1_hit_ohs_3_0)
                               ? ((1U & (IData)((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT___btb_data_way_0_R0_data 
                                                 >> 0x2aU)))
                                   ? vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT___btb_ebtb_R0_data
                                   : (6ULL + (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT__s1_pc 
                                              + (((QData)((IData)(
                                                                  (0x7ffffffU 
                                                                   & (- (IData)(
                                                                                (1U 
                                                                                & (IData)(
                                                                                (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT___btb_data_way_0_R0_data 
                                                                                >> 0x37U)))))))) 
                                                  << 0xdU) 
                                                 | (QData)((IData)(
                                                                   (0x1fffU 
                                                                    & (IData)(
                                                                              (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT___btb_data_way_0_R0_data 
                                                                               >> 0x2bU)))))))))
                               : ((1U & (IData)((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT___btb_data_way_1_R0_data 
                                                 >> 0x2aU)))
                                   ? vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT___btb_ebtb_R0_data
                                   : (6ULL + (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT__s1_pc 
                                              + (((QData)((IData)(
                                                                  (0x7ffffffU 
                                                                   & (- (IData)(
                                                                                (1U 
                                                                                & (IData)(
                                                                                (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT___btb_data_way_1_R0_data 
                                                                                >> 0x37U)))))))) 
                                                  << 0xdU) 
                                                 | (QData)((IData)(
                                                                   (0x1fffU 
                                                                    & (IData)(
                                                                              (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT___btb_data_way_1_R0_data 
                                                                               >> 0x2bU)))))))))));
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__762(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__762\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT___system_auto_cbus_fixedClockNode_anon_out_reset) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__reg_mstatus_tvm = 0U;
    } else if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___GEN_34) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__reg_mstatus_tvm 
            = (1U & (IData)((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__wdata 
                             >> 0x14U)));
    }
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT__io_resp_f3_2_predicted_pc_REG_bits 
        = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___bpd_io_resp_f2_preds_2_predicted_pc_bits;
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT__io_resp_f3_1_predicted_pc_REG_bits 
        = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___bpd_io_resp_f2_preds_1_predicted_pc_bits;
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT__io_resp_f3_3_predicted_pc_REG_bits 
        = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___bpd_io_resp_f2_preds_3_predicted_pc_bits;
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT__io_resp_f3_0_predicted_pc_REG_bits 
        = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___bpd_io_resp_f2_preds_0_predicted_pc_bits;
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unq_iss_unit__DOT__slots_7__DOT__slot_uop_iw_issued 
        = ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unq_iss_unit__DOT____Vcellinp__slots_7__io_in_uop_valid)) 
           & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unq_iss_unit__DOT__issue_slots_7_grant) 
              & (~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT____Vcellinp__unq_iss_unit__io_squash_grant))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_stq_oh_6 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_st_val) 
           & (6U == (7U & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_tail))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_stq_oh_5 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_st_val) 
           & (5U == (7U & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_tail))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_stq_oh_4 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_st_val) 
           & (4U == (7U & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_tail))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_stq_oh_2 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_st_val) 
           & (2U == (7U & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_tail))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_stq_oh_0 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_st_val) 
           & (0U == (7U & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_tail))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_stq_oh_3 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_st_val) 
           & (3U == (7U & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_tail))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_stq_oh_1 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_st_val) 
           & (1U == (7U & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_tail))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_7__DOT__slot_uop_iw_issued 
        = ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT____Vcellinp__slots_7__io_in_uop_valid)) 
           & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__issue_slots_7_grant) 
              & (~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT___fp_exe_unit_0_io_squash_iss))));
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__763(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__763\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT___core_io_ifu_redirect_val) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__ftq__DOT__do_commit_update_REG = 1U;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__ftq__DOT__io_ras_update_REG = 1U;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__ftq__DOT__io_ras_update_pc_REG 
            = ((0x27fU >= (0x3ffU & ((IData)(0x28U) 
                                     * (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT___core_io_ifu_redirect_ftq_idx))))
                ? (0xffffffffffULL & (((QData)((IData)(
                                                       vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__ftq__DOT___GEN_34[
                                                       (((IData)(0x27U) 
                                                         + 
                                                         (0x3ffU 
                                                          & ((IData)(0x28U) 
                                                             * (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT___core_io_ifu_redirect_ftq_idx)))) 
                                                        >> 5U)])) 
                                       << ((0U == (0x1fU 
                                                   & ((IData)(0x28U) 
                                                      * (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT___core_io_ifu_redirect_ftq_idx))))
                                            ? 0x20U
                                            : ((IData)(0x40U) 
                                               - (0x1fU 
                                                  & ((IData)(0x28U) 
                                                     * (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT___core_io_ifu_redirect_ftq_idx)))))) 
                                      | (((0U == (0x1fU 
                                                  & ((IData)(0x28U) 
                                                     * (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT___core_io_ifu_redirect_ftq_idx))))
                                           ? 0ULL : 
                                          ((QData)((IData)(
                                                           vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__ftq__DOT___GEN_34[
                                                           (((IData)(0x1fU) 
                                                             + 
                                                             (0x3ffU 
                                                              & ((IData)(0x28U) 
                                                                 * (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT___core_io_ifu_redirect_ftq_idx)))) 
                                                            >> 5U)])) 
                                           << ((IData)(0x20U) 
                                               - (0x1fU 
                                                  & ((IData)(0x28U) 
                                                     * (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT___core_io_ifu_redirect_ftq_idx)))))) 
                                         | ((QData)((IData)(
                                                            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__ftq__DOT___GEN_34[
                                                            (0x1fU 
                                                             & (((IData)(0x28U) 
                                                                 * (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT___core_io_ifu_redirect_ftq_idx)) 
                                                                >> 5U))])) 
                                            >> (0x1fU 
                                                & ((IData)(0x28U) 
                                                   * (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT___core_io_ifu_redirect_ftq_idx)))))))
                : 0ULL);
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__ftq__DOT__io_ras_update_idx_REG 
            = ((0x4fU >= (0x7fU & ((IData)(5U) * (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT___core_io_ifu_redirect_ftq_idx))))
                ? (0x1fU & (((0U == (0x1fU & ((IData)(5U) 
                                              * (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT___core_io_ifu_redirect_ftq_idx))))
                              ? 0U : (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__ftq__DOT___GEN_35[
                                      (((IData)(4U) 
                                        + (0x7fU & 
                                           ((IData)(5U) 
                                            * (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT___core_io_ifu_redirect_ftq_idx)))) 
                                       >> 5U)] << ((IData)(0x20U) 
                                                   - 
                                                   (0x1fU 
                                                    & ((IData)(5U) 
                                                       * (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT___core_io_ifu_redirect_ftq_idx)))))) 
                            | (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__ftq__DOT___GEN_35[
                               (3U & (((IData)(5U) 
                                       * (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT___core_io_ifu_redirect_ftq_idx)) 
                                      >> 5U))] >> (0x1fU 
                                                   & ((IData)(5U) 
                                                      * (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT___core_io_ifu_redirect_ftq_idx))))))
                : 0U);
    } else {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__ftq__DOT__do_commit_update_REG = 0U;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__ftq__DOT__io_ras_update_REG = 0U;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__ftq__DOT__io_ras_update_pc_REG = 0ULL;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__ftq__DOT__io_ras_update_idx_REG = 0U;
    }
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__mem_ldq_wakeup_e_bits_uop_mem_size 
        = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_257;
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT___system_auto_cbus_fixedClockNode_anon_out_reset) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__cbus__DOT__in_xbar__DOT__state_1 = 0U;
    } else if ((0U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__cbus__DOT__in_xbar__DOT__beatsLeft))) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__cbus__DOT__in_xbar__DOT__state_1 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__cbus__DOT__in_xbar__DOT__winner_1;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_542) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_0_flush_on_commit 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_flush_on_commit;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_544) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_1_flush_on_commit 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_flush_on_commit;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_546) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_2_flush_on_commit 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_flush_on_commit;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_548) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_3_flush_on_commit 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_flush_on_commit;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_550) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_4_flush_on_commit 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_flush_on_commit;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_552) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_5_flush_on_commit 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_flush_on_commit;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_554) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_6_flush_on_commit 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_flush_on_commit;
    }
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__764(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__764\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_556) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_7_flush_on_commit 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_flush_on_commit;
    }
    if (((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__plic_domain__DOT__plic__DOT___out_wofireMux_T_2) 
           & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__plic_domain__DOT__plic__DOT___out_T_11)) 
          & (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__plic_domain__DOT__plic__DOT__out_back_front_q__DOT__ram[0U] 
             >> 0xdU)) & (((IData)(1U) << (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__plic_domain__DOT__plic__DOT__out_oindex)) 
                          >> 5U))) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__plic_domain__DOT__plic__DOT__enables_1_0 
            = (1U & (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__plic_domain__DOT__plic__DOT__out_back_front_q__DOT__ram[0U] 
                     >> 0x16U));
    }
    if (((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__plic_domain__DOT__plic__DOT___out_wofireMux_T_2) 
           & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__plic_domain__DOT__plic__DOT___out_T_11)) 
          & (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__plic_domain__DOT__plic__DOT__out_back_front_q__DOT__ram[0U] 
             >> 0xdU)) & (((IData)(1U) << (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__plic_domain__DOT__plic__DOT__out_oindex)) 
                          >> 4U))) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__plic_domain__DOT__plic__DOT__enables_0_0 
            = (1U & (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__plic_domain__DOT__plic__DOT__out_back_front_q__DOT__ram[0U] 
                     >> 0x16U));
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_13) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__ldq_uop_0_is_amo 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_is_amo;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_14) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__ldq_uop_1_is_amo 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_is_amo;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_15) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__ldq_uop_2_is_amo 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_is_amo;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_16) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__ldq_uop_3_is_amo 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_is_amo;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_17) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__ldq_uop_4_is_amo 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_is_amo;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_18) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__ldq_uop_5_is_amo 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_is_amo;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_19) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__ldq_uop_6_is_amo 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_is_amo;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_20) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__ldq_uop_7_is_amo 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_is_amo;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_542) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_0_is_amo 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_is_amo;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_544) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_1_is_amo 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_is_amo;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_546) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_2_is_amo 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_is_amo;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_548) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_3_is_amo 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_is_amo;
    }
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__765(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__765\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_550) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_4_is_amo 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_is_amo;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_552) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_5_is_amo 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_is_amo;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_554) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_6_is_amo 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_is_amo;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_556) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_7_is_amo 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_is_amo;
    }
    if ((0U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__chipyard_prcictrl_domain__DOT__fragmenter__DOT__gennum))) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__chipyard_prcictrl_domain__DOT__fragmenter__DOT__aToggle_r 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__chipyard_prcictrl_domain__DOT__fragmenter__DOT__dToggle;
    }
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__loop__DOT__columns_3__DOT__f4_fire 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__loop__DOT__s3_valid) 
           & (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__loop__DOT__s3_mask) 
               >> 3U) & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__loop__DOT__columns_3_io_f3_req_fire_REG) 
                         & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT____Vcellinp__bpd__io_f3_fire))));
    if ((1U & (~ (IData)(vlSelfRef.__VdfgRegularize_h36cfaf1a_0_23)))) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sinkD__DOT__io_source_r 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT___sinkD_io_resp_bits_source;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_576) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__ldq_ld_byte_mask_7 
            = (0xffU & (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_577 
                        >> (0x1fU & VL_SHIFTL_III(5,32,32, (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__exe_tlb_uop_0_mem_size), 3U))));
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_569) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__ldq_ld_byte_mask_0 
            = (0xffU & (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_577 
                        >> (0x1fU & VL_SHIFTL_III(5,32,32, (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__exe_tlb_uop_0_mem_size), 3U))));
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_575) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__ldq_ld_byte_mask_6 
            = (0xffU & (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_577 
                        >> (0x1fU & VL_SHIFTL_III(5,32,32, (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__exe_tlb_uop_0_mem_size), 3U))));
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_574) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__ldq_ld_byte_mask_5 
            = (0xffU & (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_577 
                        >> (0x1fU & VL_SHIFTL_III(5,32,32, (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__exe_tlb_uop_0_mem_size), 3U))));
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_573) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__ldq_ld_byte_mask_4 
            = (0xffU & (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_577 
                        >> (0x1fU & VL_SHIFTL_III(5,32,32, (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__exe_tlb_uop_0_mem_size), 3U))));
    }
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__766(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__766\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT___system_auto_cbus_fixedClockNode_anon_out_reset) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__reg_dcsr_step = 0U;
    } else if (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___csr_wen_T_4) 
                & (0xfffU == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___decoded_addr_decoded_decoded_andMatrixOutputs_T_79)))) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__reg_dcsr_step 
            = (1U & ((IData)((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___wdata_T_2 
                              >> 2U)) & (IData)((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___wdata_T_6 
                                                 >> 2U))));
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_571) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__ldq_ld_byte_mask_2 
            = (0xffU & (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_577 
                        >> (0x1fU & VL_SHIFTL_III(5,32,32, (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__exe_tlb_uop_0_mem_size), 3U))));
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_572) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__ldq_ld_byte_mask_3 
            = (0xffU & (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_577 
                        >> (0x1fU & VL_SHIFTL_III(5,32,32, (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__exe_tlb_uop_0_mem_size), 3U))));
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_570) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__ldq_ld_byte_mask_1 
            = (0xffU & (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_577 
                        >> (0x1fU & VL_SHIFTL_III(5,32,32, (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__exe_tlb_uop_0_mem_size), 3U))));
    }
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_0_1_io_update_old_ctr_0_REG 
        = (7U & (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__s1_update_bits_meta[0U] 
                 >> 0x10U));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_0_1_io_update_old_ctr_1_REG 
        = (7U & (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__s1_update_bits_meta[0U] 
                 >> 0x13U));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_0_1_io_update_old_ctr_2_REG 
        = (7U & (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__s1_update_bits_meta[0U] 
                 >> 0x16U));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_0_1_io_update_old_ctr_3_REG 
        = (7U & (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__s1_update_bits_meta[0U] 
                 >> 0x19U));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_1_1_io_update_old_ctr_0_REG 
        = (7U & (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__s1_update_bits_meta[0U] 
                 >> 0x10U));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_1_1_io_update_old_ctr_1_REG 
        = (7U & (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__s1_update_bits_meta[0U] 
                 >> 0x13U));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_1_1_io_update_old_ctr_2_REG 
        = (7U & (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__s1_update_bits_meta[0U] 
                 >> 0x16U));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_1_1_io_update_old_ctr_3_REG 
        = (7U & (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__s1_update_bits_meta[0U] 
                 >> 0x19U));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_2_1_io_update_old_ctr_0_REG 
        = (7U & (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__s1_update_bits_meta[0U] 
                 >> 0x10U));
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__767(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__767\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_2_1_io_update_old_ctr_1_REG 
        = (7U & (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__s1_update_bits_meta[0U] 
                 >> 0x13U));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_2_1_io_update_old_ctr_2_REG 
        = (7U & (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__s1_update_bits_meta[0U] 
                 >> 0x16U));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_2_1_io_update_old_ctr_3_REG 
        = (7U & (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__s1_update_bits_meta[0U] 
                 >> 0x19U));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_3_1_io_update_old_ctr_0_REG 
        = (7U & (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__s1_update_bits_meta[0U] 
                 >> 0x10U));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_3_1_io_update_old_ctr_1_REG 
        = (7U & (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__s1_update_bits_meta[0U] 
                 >> 0x13U));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_3_1_io_update_old_ctr_2_REG 
        = (7U & (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__s1_update_bits_meta[0U] 
                 >> 0x16U));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_3_1_io_update_old_ctr_3_REG 
        = (7U & (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__s1_update_bits_meta[0U] 
                 >> 0x19U));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_4_1_io_update_old_ctr_0_REG 
        = (7U & (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__s1_update_bits_meta[0U] 
                 >> 0x10U));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_4_1_io_update_old_ctr_1_REG 
        = (7U & (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__s1_update_bits_meta[0U] 
                 >> 0x13U));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_4_1_io_update_old_ctr_2_REG 
        = (7U & (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__s1_update_bits_meta[0U] 
                 >> 0x16U));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_4_1_io_update_old_ctr_3_REG 
        = (7U & (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__s1_update_bits_meta[0U] 
                 >> 0x19U));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_5_1_io_update_old_ctr_0_REG 
        = (7U & (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__s1_update_bits_meta[0U] 
                 >> 0x10U));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_5_1_io_update_old_ctr_1_REG 
        = (7U & (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__s1_update_bits_meta[0U] 
                 >> 0x13U));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_5_1_io_update_old_ctr_2_REG 
        = (7U & (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__s1_update_bits_meta[0U] 
                 >> 0x16U));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_5_1_io_update_old_ctr_3_REG 
        = (7U & (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__s1_update_bits_meta[0U] 
                 >> 0x19U));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_0_1_io_update_alloc_1_REG 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT___GEN_157) 
           & (1U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__s1_update_bits_cfi_idx_bits)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_2_1_io_update_alloc_1_REG 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT___GEN_159) 
           & (1U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__s1_update_bits_cfi_idx_bits)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_0_1_io_update_alloc_2_REG 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT___GEN_157) 
           & (2U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__s1_update_bits_cfi_idx_bits)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_1_1_io_update_alloc_2_REG 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT___GEN_158) 
           & (2U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__s1_update_bits_cfi_idx_bits)));
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__768(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__768\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_4_1_io_update_alloc_1_REG 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT___GEN_161) 
           & (1U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__s1_update_bits_cfi_idx_bits)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_3_1_io_update_alloc_2_REG 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT___GEN_160) 
           & (2U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__s1_update_bits_cfi_idx_bits)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_1_1_io_update_alloc_1_REG 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT___GEN_158) 
           & (1U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__s1_update_bits_cfi_idx_bits)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_4_1_io_update_alloc_2_REG 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT___GEN_161) 
           & (2U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__s1_update_bits_cfi_idx_bits)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_2_1_io_update_alloc_2_REG 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT___GEN_159) 
           & (2U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__s1_update_bits_cfi_idx_bits)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_5_1_io_update_alloc_1_REG 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT___GEN_162) 
           & (1U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__s1_update_bits_cfi_idx_bits)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_5_1_io_update_alloc_2_REG 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT___GEN_162) 
           & (2U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__s1_update_bits_cfi_idx_bits)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_3_1_io_update_alloc_1_REG 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT___GEN_160) 
           & (1U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__s1_update_bits_cfi_idx_bits)));
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT___system_auto_cbus_fixedClockNode_anon_out_reset) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__reg_dcsr_cause = 0U;
    } else if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___GEN_37) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__reg_dcsr_cause 
            = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__reg_singleStepped)
                ? 4U : ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__causeIsDebugInt)
                         ? 3U : ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__causeIsDebugTrigger)
                                  ? 2U : 1U)));
    }
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__reg_singleStepped 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___csr_io_singleStep) 
           & (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr_io_retire_REG) 
               | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__exception)) 
              | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__reg_singleStepped)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_0_1_io_update_alloc_0_REG 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT___GEN_157) 
           & (~ (0U != (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__s1_update_bits_cfi_idx_bits))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_0_1_io_update_alloc_3_REG 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT___GEN_157) 
           & (3U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__s1_update_bits_cfi_idx_bits)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_1_1_io_update_alloc_0_REG 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT___GEN_158) 
           & (~ (0U != (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__s1_update_bits_cfi_idx_bits))));
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__769(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__769\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_1_1_io_update_alloc_3_REG 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT___GEN_158) 
           & (3U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__s1_update_bits_cfi_idx_bits)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_2_1_io_update_alloc_0_REG 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT___GEN_159) 
           & (~ (0U != (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__s1_update_bits_cfi_idx_bits))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_2_1_io_update_alloc_3_REG 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT___GEN_159) 
           & (3U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__s1_update_bits_cfi_idx_bits)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_3_1_io_update_alloc_0_REG 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT___GEN_160) 
           & (~ (0U != (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__s1_update_bits_cfi_idx_bits))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_3_1_io_update_alloc_3_REG 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT___GEN_160) 
           & (3U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__s1_update_bits_cfi_idx_bits)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_4_1_io_update_alloc_0_REG 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT___GEN_161) 
           & (~ (0U != (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__s1_update_bits_cfi_idx_bits))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_4_1_io_update_alloc_3_REG 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT___GEN_161) 
           & (3U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__s1_update_bits_cfi_idx_bits)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_5_1_io_update_alloc_0_REG 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT___GEN_162) 
           & (~ (0U != (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__s1_update_bits_cfi_idx_bits))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__tt_5_1_io_update_alloc_3_REG 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT___GEN_162) 
           & (3U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__s1_update_bits_cfi_idx_bits)));
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT___system_auto_cbus_fixedClockNode_anon_out_reset) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__cbus__DOT__in_xbar__DOT__state_0 = 0U;
    } else if ((0U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__cbus__DOT__in_xbar__DOT__beatsLeft))) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__cbus__DOT__in_xbar__DOT__state_0 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__cbus__DOT__in_xbar__DOT__winner_0;
    }
    if ((0U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__chipyard_prcictrl_domain__DOT__fragmenter_1__DOT__gennum))) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__chipyard_prcictrl_domain__DOT__fragmenter_1__DOT__aToggle_r 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__chipyard_prcictrl_domain__DOT__fragmenter_1__DOT__dToggle;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_125) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_uop_5_dst_rtype 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rename_stage__DOT__r_uop_dst_rtype;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_122) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_uop_2_dst_rtype 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rename_stage__DOT__r_uop_dst_rtype;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_121) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_uop_1_dst_rtype 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rename_stage__DOT__r_uop_dst_rtype;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_134) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_uop_14_dst_rtype 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rename_stage__DOT__r_uop_dst_rtype;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_124) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_uop_4_dst_rtype 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rename_stage__DOT__r_uop_dst_rtype;
    }
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__770(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__770\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_143) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_uop_23_dst_rtype 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rename_stage__DOT__r_uop_dst_rtype;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_150) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_uop_30_dst_rtype 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rename_stage__DOT__r_uop_dst_rtype;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_142) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_uop_22_dst_rtype 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rename_stage__DOT__r_uop_dst_rtype;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_135) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_uop_15_dst_rtype 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rename_stage__DOT__r_uop_dst_rtype;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_149) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_uop_29_dst_rtype 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rename_stage__DOT__r_uop_dst_rtype;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_127) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_uop_7_dst_rtype 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rename_stage__DOT__r_uop_dst_rtype;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_137) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_uop_17_dst_rtype 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rename_stage__DOT__r_uop_dst_rtype;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_120) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_uop_0_dst_rtype 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rename_stage__DOT__r_uop_dst_rtype;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_139) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_uop_19_dst_rtype 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rename_stage__DOT__r_uop_dst_rtype;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_123) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_uop_3_dst_rtype 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rename_stage__DOT__r_uop_dst_rtype;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_144) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_uop_24_dst_rtype 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rename_stage__DOT__r_uop_dst_rtype;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_148) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_uop_28_dst_rtype 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rename_stage__DOT__r_uop_dst_rtype;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_138) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_uop_18_dst_rtype 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rename_stage__DOT__r_uop_dst_rtype;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_151) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_uop_31_dst_rtype 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rename_stage__DOT__r_uop_dst_rtype;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_145) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_uop_25_dst_rtype 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rename_stage__DOT__r_uop_dst_rtype;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_131) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_uop_11_dst_rtype 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rename_stage__DOT__r_uop_dst_rtype;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_136) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_uop_16_dst_rtype 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rename_stage__DOT__r_uop_dst_rtype;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_146) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_uop_26_dst_rtype 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rename_stage__DOT__r_uop_dst_rtype;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_140) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_uop_20_dst_rtype 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rename_stage__DOT__r_uop_dst_rtype;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_126) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_uop_6_dst_rtype 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rename_stage__DOT__r_uop_dst_rtype;
    }
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__771(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__771\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_147) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_uop_27_dst_rtype 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rename_stage__DOT__r_uop_dst_rtype;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_141) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_uop_21_dst_rtype 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rename_stage__DOT__r_uop_dst_rtype;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_128) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_uop_8_dst_rtype 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rename_stage__DOT__r_uop_dst_rtype;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_129) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_uop_9_dst_rtype 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rename_stage__DOT__r_uop_dst_rtype;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_130) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_uop_10_dst_rtype 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rename_stage__DOT__r_uop_dst_rtype;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_132) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_uop_12_dst_rtype 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rename_stage__DOT__r_uop_dst_rtype;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_133) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_uop_13_dst_rtype 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rename_stage__DOT__r_uop_dst_rtype;
    }
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__reg_mstatus_spie 
        = ((1U & (~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT___system_auto_cbus_fixedClockNode_anon_out_reset))) 
           && (1U & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___csr_wen_T_4)
                      ? ((0x3ffU == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___decoded_addr_decoded_decoded_andMatrixOutputs_T_3))
                          ? (IData)((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__wdata 
                                     >> 5U)) : ((0xfffU 
                                                 == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___decoded_addr_decoded_decoded_andMatrixOutputs_T_14))
                                                 ? (IData)(
                                                           (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__wdata 
                                                            >> 5U))
                                                 : (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___GEN_57)))
                      : (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___GEN_57))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__reg_mstatus_spp 
        = ((1U & (~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT___system_auto_cbus_fixedClockNode_anon_out_reset))) 
           && (1U & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___csr_wen_T_4)
                      ? ((0x3ffU == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___decoded_addr_decoded_decoded_andMatrixOutputs_T_3))
                          ? (IData)((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__wdata 
                                     >> 8U)) : ((0xfffU 
                                                 == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___decoded_addr_decoded_decoded_andMatrixOutputs_T_14))
                                                 ? (IData)(
                                                           (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__wdata 
                                                            >> 8U))
                                                 : (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___GEN_58)))
                      : (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___GEN_58))));
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT___system_auto_cbus_fixedClockNode_anon_out_reset) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__reg_mstatus_mxr = 0U;
    } else if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___csr_wen_T_4) {
        if ((0x3ffU == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___decoded_addr_decoded_decoded_andMatrixOutputs_T_3))) {
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__reg_mstatus_mxr 
                = (1U & (IData)((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__wdata 
                                 >> 0x13U)));
        } else if ((0xfffU == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___decoded_addr_decoded_decoded_andMatrixOutputs_T_14))) {
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__reg_mstatus_mxr 
                = (1U & (IData)((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__wdata 
                                 >> 0x13U)));
        }
    }
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__772(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__772\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__reg_mstatus_sie 
        = ((1U & (~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT___system_auto_cbus_fixedClockNode_anon_out_reset))) 
           && (1U & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___csr_wen_T_4)
                      ? ((0x3ffU == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___decoded_addr_decoded_decoded_andMatrixOutputs_T_3))
                          ? (IData)((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__wdata 
                                     >> 1U)) : ((0xfffU 
                                                 == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___decoded_addr_decoded_decoded_andMatrixOutputs_T_14))
                                                 ? (IData)(
                                                           (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__wdata 
                                                            >> 1U))
                                                 : (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___GEN_56)))
                      : (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___GEN_56))));
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT___system_auto_cbus_fixedClockNode_anon_out_reset) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__reg_mtvec = 0U;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__reg_mstatus_sum = 0U;
    } else {
        if (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___csr_wen_T_4) 
             & (0xfffU == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___decoded_addr_decoded_decoded_andMatrixOutputs_T_19)))) {
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__reg_mtvec 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___GEN_42;
        }
        if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___csr_wen_T_4) {
            if ((0x3ffU == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___decoded_addr_decoded_decoded_andMatrixOutputs_T_3))) {
                vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__reg_mstatus_sum 
                    = (1U & (IData)((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__wdata 
                                     >> 0x12U)));
            } else if ((0xfffU == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___decoded_addr_decoded_decoded_andMatrixOutputs_T_14))) {
                vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__reg_mstatus_sum 
                    = (1U & (IData)((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__wdata 
                                     >> 0x12U)));
            }
        }
    }
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__alu_exe_unit_0__DOT__exe_uop_bits_fcn_dw 
        = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__alu_exe_unit_0__DOT__rrd_uop_bits_fcn_dw;
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__alu_exe_unit_0__DOT__exe_pred_data 
        = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__pregfile__DOT__regfile_ext__DOT__Memory
        [vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__pregfile__DOT__io_rrd_read_resps_0_REG];
    if (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__directory__DOT____Vcellinp__cc_dir__RW0_en) 
         & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT____Vcellinp__directory__io_read_valid))) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__directory__DOT__cc_dir__DOT__cc_dir_ext__DOT__mem_0_0__DOT__ram_RW_0_r_addr_pipe_0 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__directory__DOT____Vcellinp__cc_dir__RW0_addr;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__directory__DOT__cc_dir__DOT__cc_dir_ext__DOT__mem_0_4__DOT__ram_RW_0_r_addr_pipe_0 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__directory__DOT____Vcellinp__cc_dir__RW0_addr;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__directory__DOT__cc_dir__DOT__cc_dir_ext__DOT__mem_0_1__DOT__ram_RW_0_r_addr_pipe_0 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__directory__DOT____Vcellinp__cc_dir__RW0_addr;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__directory__DOT__cc_dir__DOT__cc_dir_ext__DOT__mem_0_2__DOT__ram_RW_0_r_addr_pipe_0 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__directory__DOT____Vcellinp__cc_dir__RW0_addr;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__directory__DOT__cc_dir__DOT__cc_dir_ext__DOT__mem_0_3__DOT__ram_RW_0_r_addr_pipe_0 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__directory__DOT____Vcellinp__cc_dir__RW0_addr;
    }
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT__io_resp_f2_3_predicted_pc_REG_valid 
        = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT__s1_resp_3_valid;
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__773(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__773\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__wb_ldst_forward_ld_addr_0 
        = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__lcam_addr_0;
    if (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__directory__DOT____Vcellinp__cc_dir__RW0_en) 
         & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT____Vcellinp__directory__io_read_valid))) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__directory__DOT__cc_dir__DOT__cc_dir_ext__DOT__mem_0_5__DOT__ram_RW_0_r_addr_pipe_0 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__directory__DOT____Vcellinp__cc_dir__RW0_addr;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__directory__DOT__cc_dir__DOT__cc_dir_ext__DOT__mem_0_6__DOT__ram_RW_0_r_addr_pipe_0 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__directory__DOT____Vcellinp__cc_dir__RW0_addr;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__directory__DOT__cc_dir__DOT__cc_dir_ext__DOT__mem_0_7__DOT__ram_RW_0_r_addr_pipe_0 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__directory__DOT____Vcellinp__cc_dir__RW0_addr;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT___system_auto_cbus_fixedClockNode_anon_out_reset) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__reg_dcsr_ebreaku = 0U;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__reg_dcsr_ebreakm = 0U;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__reg_dcsr_ebreaks = 0U;
    } else if (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___csr_wen_T_4) 
                & (0xfffU == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___decoded_addr_decoded_decoded_andMatrixOutputs_T_79)))) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__reg_dcsr_ebreaku 
            = (1U & ((IData)((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___wdata_T_2 
                              >> 0xcU)) & (IData)((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___wdata_T_6 
                                                   >> 0xcU))));
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__reg_dcsr_ebreakm 
            = (1U & ((IData)((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___wdata_T_2 
                              >> 0xfU)) & (IData)((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___wdata_T_6 
                                                   >> 0xfU))));
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__reg_dcsr_ebreaks 
            = (1U & ((IData)((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___wdata_T_2 
                              >> 0xdU)) & (IData)((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___wdata_T_6 
                                                   >> 0xdU))));
    }
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__alu_exe_unit_0__DOT__exe_uop_bits_ldst_is_rs1 
        = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__alu_exe_unit_0__DOT__rrd_uop_bits_ldst_is_rs1;
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__io_fdiv_resp_fdivsqrt__DOT__divSqrt__DOT__divSqrtRecFNToRaw__DOT__divSqrtRawFN__DOT__entering) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__io_fdiv_resp_fdivsqrt__DOT__divSqrt__DOT__divSqrtRecFNToRaw__DOT__divSqrtRawFN__DOT__isInf_Z 
            = (1U & (((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__io_fdiv_resp_fdivsqrt__DOT__r_sigs_sqrt)) 
                      & (~ (0U != (7U & ((IData)(vlSelfRef.__VdfgRegularize_h36cfaf1a_0_99) 
                                         >> 6U))))) 
                     | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__io_fdiv_resp_fdivsqrt__DOT__divSqrt__DOT__divSqrtRecFNToRaw__DOT____Vcellinp__divSqrtRawFN__io_a_isInf)));
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__fpu__DOT__fpu__DOT__sfma__DOT__valid) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__fpu__DOT__fpu__DOT__sfma__DOT__fma__DOT__mulAddRecFNToRaw_postMul_io_fromPreMul_pipe_b_isZeroC 
            = (1U & (~ (0U != (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__fpu__DOT__fpu__DOT__sfma__DOT__in_in3[0U] 
                               >> 0x1dU))));
    }
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__774(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__774\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__io_fdiv_resp_fdivsqrt__DOT__divSqrt__DOT__divSqrtRecFNToRaw__DOT__divSqrtRawFN__DOT__entering) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__io_fdiv_resp_fdivsqrt__DOT__divSqrt__DOT__divSqrtRecFNToRaw__DOT__divSqrtRawFN__DOT__isZero_Z 
            = (1U & (((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__io_fdiv_resp_fdivsqrt__DOT__r_sigs_sqrt)) 
                      & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__io_fdiv_resp_fdivsqrt__DOT__divSqrt__DOT__divSqrtRecFNToRaw__DOT____Vcellinp__divSqrtRawFN__io_b_isInf)) 
                     | (~ (0U != (7U & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__io_fdiv_resp_fdivsqrt__DOT__fpiu__DOT__classify_out_expOut) 
                                        >> 6U))))));
        if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__io_fdiv_resp_fdivsqrt__DOT__r_sigs_sqrt) {
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__io_fdiv_resp_fdivsqrt__DOT__divSqrt__DOT__divSqrtRecFNToRaw__DOT__divSqrtRawFN__DOT__isNaN_Z 
                = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__io_fdiv_resp_fdivsqrt__DOT__divSqrt__DOT__divSqrtRecFNToRaw__DOT____Vcellinp__divSqrtRawFN__io_a_isNaN) 
                   | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__io_fdiv_resp_fdivsqrt__DOT__divSqrt__DOT__divSqrtRecFNToRaw__DOT__divSqrtRawFN__DOT__notSigNaNIn_invalidExc_S_sqrt));
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__io_fdiv_resp_fdivsqrt__DOT__divSqrt__DOT__divSqrtRecFNToRaw__DOT__divSqrtRawFN__DOT__majorExc_Z 
                = (1U & (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__io_fdiv_resp_fdivsqrt__DOT__divSqrt__DOT__divSqrtRecFNToRaw__DOT____Vcellinp__divSqrtRawFN__io_a_isNaN) 
                          & (~ (vlSelfRef.__VdfgRegularize_h36cfaf1a_0_171 
                                >> 0x16U))) | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__io_fdiv_resp_fdivsqrt__DOT__divSqrt__DOT__divSqrtRecFNToRaw__DOT__divSqrtRawFN__DOT__notSigNaNIn_invalidExc_S_sqrt)));
        } else {
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__io_fdiv_resp_fdivsqrt__DOT__divSqrt__DOT__divSqrtRecFNToRaw__DOT__divSqrtRawFN__DOT__isNaN_Z 
                = (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__io_fdiv_resp_fdivsqrt__DOT__divSqrt__DOT__divSqrtRecFNToRaw__DOT____Vcellinp__divSqrtRawFN__io_a_isNaN) 
                    | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__io_fdiv_resp_fdivsqrt__DOT__divSqrt__DOT__divSqrtRecFNToRaw__DOT____Vcellinp__divSqrtRawFN__io_b_isNaN)) 
                   | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__io_fdiv_resp_fdivsqrt__DOT__divSqrt__DOT__divSqrtRecFNToRaw__DOT__divSqrtRawFN__DOT__notSigNaNIn_invalidExc_S_div));
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__io_fdiv_resp_fdivsqrt__DOT__divSqrt__DOT__divSqrtRecFNToRaw__DOT__divSqrtRawFN__DOT__majorExc_Z 
                = (1U & (((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__io_fdiv_resp_fdivsqrt__DOT__divSqrt__DOT__divSqrtRecFNToRaw__DOT____Vcellinp__divSqrtRawFN__io_a_isNaN) 
                            & (~ (vlSelfRef.__VdfgRegularize_h36cfaf1a_0_171 
                                  >> 0x16U))) | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__io_fdiv_resp_fdivsqrt__DOT__divSqrt__DOT__divSqrtRecFNToRaw__DOT____Vcellinp__divSqrtRawFN__io_b_isNaN) 
                                                 & (~ 
                                                    (vlSelfRef.__VdfgRegularize_h36cfaf1a_0_172 
                                                     >> 0x16U)))) 
                          | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__io_fdiv_resp_fdivsqrt__DOT__divSqrt__DOT__divSqrtRecFNToRaw__DOT__divSqrtRawFN__DOT__notSigNaNIn_invalidExc_S_div)) 
                         | (((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__io_fdiv_resp_fdivsqrt__DOT__divSqrt__DOT__divSqrtRecFNToRaw__DOT____Vcellinp__divSqrtRawFN__io_a_isNaN)) 
                             & (~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__io_fdiv_resp_fdivsqrt__DOT__divSqrt__DOT__divSqrtRecFNToRaw__DOT____Vcellinp__divSqrtRawFN__io_a_isInf))) 
                            & (~ (0U != (7U & ((IData)(vlSelfRef.__VdfgRegularize_h36cfaf1a_0_99) 
                                               >> 6U)))))));
        }
    }
    if ((1U & (~ ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT___core_io_ifu_redirect_flush) 
                  | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__dis_stalls_0))))) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__imm_rename_stage__DOT__r_uop_br_type 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_br_type;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT____Vcellinp__slots_0__io_in_uop_valid) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__slots_0__DOT__slot_uop_imm_sel 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__imm_rename_stage__DOT__r_uop_imm_sel;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT____Vcellinp__slots_1__io_in_uop_valid) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__slots_1__DOT__slot_uop_imm_sel 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__imm_rename_stage__DOT__r_uop_imm_sel;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT____Vcellinp__slots_2__io_in_uop_valid) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__slots_2__DOT__slot_uop_imm_sel 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__imm_rename_stage__DOT__r_uop_imm_sel;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT____Vcellinp__slots_3__io_in_uop_valid) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__slots_3__DOT__slot_uop_imm_sel 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__imm_rename_stage__DOT__r_uop_imm_sel;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT____Vcellinp__slots_4__io_in_uop_valid) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__slots_4__DOT__slot_uop_imm_sel 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__imm_rename_stage__DOT__r_uop_imm_sel;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT____Vcellinp__slots_5__io_in_uop_valid) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__slots_5__DOT__slot_uop_imm_sel 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__imm_rename_stage__DOT__r_uop_imm_sel;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT____Vcellinp__slots_6__io_in_uop_valid) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__slots_6__DOT__slot_uop_imm_sel 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__imm_rename_stage__DOT__r_uop_imm_sel;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT____Vcellinp__slots_7__io_in_uop_valid) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__slots_7__DOT__slot_uop_imm_sel 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__imm_rename_stage__DOT__r_uop_imm_sel;
    }
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__alu_exe_unit_0__DOT__exe_uop_bits_fcn_op 
        = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__alu_exe_unit_0__DOT__rrd_uop_bits_fcn_op;
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__775(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__775\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if ((1U & (~ ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT___core_io_ifu_redirect_flush) 
                  | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__dis_stalls_0))))) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__imm_rename_stage__DOT__r_uop_is_sfb 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_is_sfb;
    }
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__io_resp_f3_3_REG_predicted_pc_bits 
        = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__io_resp_f2_3_REG_predicted_pc_bits;
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__io_resp_f3_2_REG_predicted_pc_bits 
        = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__io_resp_f2_2_REG_predicted_pc_bits;
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__io_resp_f3_1_REG_predicted_pc_bits 
        = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__io_resp_f2_1_REG_predicted_pc_bits;
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__io_resp_f3_0_REG_predicted_pc_bits 
        = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__io_resp_f2_0_REG_predicted_pc_bits;
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT___system_auto_cbus_fixedClockNode_anon_out_reset) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__reg_pmp_0_cfg_a = 0U;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__reg_pmp_7_cfg_a = 0U;
    } else {
        if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___GEN_46) {
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__reg_pmp_0_cfg_a 
                = (3U & ((IData)((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___wdata_T_2 
                                  >> 3U)) & (IData)(
                                                    (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___wdata_T_6 
                                                     >> 3U))));
        }
        if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___GEN_55) {
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__reg_pmp_7_cfg_a 
                = (3U & ((IData)((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___wdata_T_2 
                                  >> 0x3bU)) & (IData)(
                                                       (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___wdata_T_6 
                                                        >> 0x3bU))));
        }
    }
    if ((0U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__pbus__DOT__coupler_to_bootaddressreg__DOT__fragmenter__DOT__gennum))) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__pbus__DOT__coupler_to_bootaddressreg__DOT__fragmenter__DOT__aToggle_r 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__pbus__DOT__coupler_to_bootaddressreg__DOT__fragmenter__DOT__dToggle;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__fpu__DOT__fpu__DOT__fpiu_io_in_valid) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__fpu__DOT__fpu__DOT__fpiu__DOT__in_typeTagOut 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__exe_uop_bits_fp_ctrl_typeTagOut;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__io_fdiv_resp_fdivsqrt__DOT__divSqrt_1__DOT__divSqrtRecFNToRaw__DOT__divSqrtRawFN__DOT__entering) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__io_fdiv_resp_fdivsqrt__DOT__divSqrt_1__DOT__divSqrtRecFNToRaw__DOT__divSqrtRawFN__DOT__isNaN_Z 
            = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__io_fdiv_resp_fdivsqrt__DOT__r_sigs_sqrt)
                ? ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__io_fdiv_resp_fdivsqrt__DOT__divSqrt_1__DOT__divSqrtRecFNToRaw__DOT____Vcellinp__divSqrtRawFN__io_a_isNaN) 
                   | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__io_fdiv_resp_fdivsqrt__DOT__divSqrt_1__DOT__divSqrtRecFNToRaw__DOT__divSqrtRawFN__DOT__notSigNaNIn_invalidExc_S_sqrt))
                : (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__io_fdiv_resp_fdivsqrt__DOT__divSqrt_1__DOT__divSqrtRecFNToRaw__DOT____Vcellinp__divSqrtRawFN__io_a_isNaN) 
                    | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__io_fdiv_resp_fdivsqrt__DOT__divSqrt_1__DOT__divSqrtRecFNToRaw__DOT____Vcellinp__divSqrtRawFN__io_b_isNaN)) 
                   | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__io_fdiv_resp_fdivsqrt__DOT__divSqrt_1__DOT__divSqrtRecFNToRaw__DOT__divSqrtRawFN__DOT__notSigNaNIn_invalidExc_S_div)));
    }
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__ll_wbarb_io_in_0_bits_REG_uop_pdst 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_462)
            ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT____VdfgRegularize_h94b53d93_0_211)
            : (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__wb_ldst_forward_e_REG_uop_pdst));
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__alu_iss_unit__DOT____Vcellinp__slots_0__io_in_uop_valid) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__alu_iss_unit__DOT__slots_0__DOT__slot_uop_dst_rtype 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rename_stage__DOT__r_uop_dst_rtype;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__alu_iss_unit__DOT____Vcellinp__slots_1__io_in_uop_valid) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__alu_iss_unit__DOT__slots_1__DOT__slot_uop_dst_rtype 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rename_stage__DOT__r_uop_dst_rtype;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__alu_iss_unit__DOT____Vcellinp__slots_2__io_in_uop_valid) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__alu_iss_unit__DOT__slots_2__DOT__slot_uop_dst_rtype 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rename_stage__DOT__r_uop_dst_rtype;
    }
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__776(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__776\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__alu_iss_unit__DOT____Vcellinp__slots_3__io_in_uop_valid) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__alu_iss_unit__DOT__slots_3__DOT__slot_uop_dst_rtype 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rename_stage__DOT__r_uop_dst_rtype;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__alu_iss_unit__DOT____Vcellinp__slots_4__io_in_uop_valid) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__alu_iss_unit__DOT__slots_4__DOT__slot_uop_dst_rtype 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rename_stage__DOT__r_uop_dst_rtype;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__alu_iss_unit__DOT____Vcellinp__slots_5__io_in_uop_valid) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__alu_iss_unit__DOT__slots_5__DOT__slot_uop_dst_rtype 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rename_stage__DOT__r_uop_dst_rtype;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__alu_iss_unit__DOT____Vcellinp__slots_6__io_in_uop_valid) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__alu_iss_unit__DOT__slots_6__DOT__slot_uop_dst_rtype 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rename_stage__DOT__r_uop_dst_rtype;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__alu_iss_unit__DOT__slots_6__DOT__slot_uop_iw_p2_speculative_child 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__issue_slots_7_in_uop_bits_iw_p2_speculative_child;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__alu_iss_unit__DOT__slots_6__DOT__slot_uop_iw_p1_speculative_child 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__issue_slots_7_in_uop_bits_iw_p1_speculative_child;
    } else {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__alu_iss_unit__DOT__slots_6__DOT__slot_uop_iw_p2_speculative_child 
            = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__alu_iss_unit__DOT__slots_6__DOT___GEN_2) 
               & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__alu_iss_unit__DOT__slots_6__DOT__prs2_wakeups_2));
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__alu_iss_unit__DOT__slots_6__DOT__slot_uop_iw_p1_speculative_child 
            = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__alu_iss_unit__DOT__slots_6__DOT___GEN_1) 
               & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__alu_iss_unit__DOT__slots_6__DOT__prs1_wakeups_2));
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__alu_iss_unit__DOT____Vcellinp__slots_7__io_in_uop_valid) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__alu_iss_unit__DOT__slots_7__DOT__slot_uop_dst_rtype 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rename_stage__DOT__r_uop_dst_rtype;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__fpu__DOT__fpu__DOT__dfma__DOT__valid) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__fpu__DOT__fpu__DOT__dfma__DOT__fma__DOT__mulAddRecFNToRaw_postMul_io_fromPreMul_pipe_b_isZeroC 
            = (1U & (~ (0U != (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__fpu__DOT__fpu__DOT__dfma__DOT__in_in3[1U] 
                               >> 0x1dU))));
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT___system_auto_cbus_fixedClockNode_anon_out_reset) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__cork__DOT__state_1 = 0U;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__cbus__DOT__wrapped_error_device__DOT__buffer__DOT__nodeIn_d_q__DOT__maybe_full = 0U;
    } else {
        if ((0U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__cork__DOT__beatsLeft))) {
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__cork__DOT__state_1 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__cork__DOT__winner_1;
        }
        if (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__cbus__DOT__wrapped_error_device__DOT__buffer__DOT__nodeIn_d_q__DOT__do_enq) 
             != (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__cbus__DOT__wrapped_error_device__DOT__buffer__DOT__nodeIn_d_q__DOT__do_deq))) {
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__cbus__DOT__wrapped_error_device__DOT__buffer__DOT__nodeIn_d_q__DOT__maybe_full 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__cbus__DOT__wrapped_error_device__DOT__buffer__DOT__nodeIn_d_q__DOT__do_enq;
        }
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT____Vcellinp__slots_6__io_in_uop_valid) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__slots_6__DOT__slot_uop_iw_p1_speculative_child 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__issue_slots_7_in_uop_bits_iw_p1_speculative_child;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__slots_6__DOT__slot_uop_iw_p2_speculative_child 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__issue_slots_7_in_uop_bits_iw_p2_speculative_child;
    } else {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__slots_6__DOT__slot_uop_iw_p1_speculative_child 
            = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__slots_6__DOT___GEN_1) 
               & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__slots_6__DOT__prs1_wakeups_2));
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__slots_6__DOT__slot_uop_iw_p2_speculative_child 
            = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__slots_6__DOT___GEN_2) 
               & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__slots_6__DOT__prs2_wakeups_2));
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unq_iss_unit__DOT____Vcellinp__slots_6__io_in_uop_valid) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unq_iss_unit__DOT__slots_6__DOT__slot_uop_iw_p2_speculative_child 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__issue_slots_7_in_uop_bits_iw_p2_speculative_child;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unq_iss_unit__DOT__slots_6__DOT__slot_uop_iw_p1_speculative_child 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__issue_slots_7_in_uop_bits_iw_p1_speculative_child;
    } else {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unq_iss_unit__DOT__slots_6__DOT__slot_uop_iw_p2_speculative_child 
            = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unq_iss_unit__DOT__slots_6__DOT___GEN_2) 
               & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unq_iss_unit__DOT__slots_6__DOT__prs2_wakeups_2));
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unq_iss_unit__DOT__slots_6__DOT__slot_uop_iw_p1_speculative_child 
            = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unq_iss_unit__DOT__slots_6__DOT___GEN_1) 
               & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unq_iss_unit__DOT__slots_6__DOT__prs1_wakeups_2));
    }
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__777(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__777\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT____Vcellinp__slots_6__io_in_uop_valid) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__slots_6__DOT__slot_uop_lrs2_rtype 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__issue_slots_7_in_uop_bits_lrs2_rtype;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__slots_6__DOT__slot_uop_prs1 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___dispatcher_io_dis_uops_3_0_bits_prs1;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__slots_6__DOT__slot_uop_prs2 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___dispatcher_io_dis_uops_3_0_bits_prs2;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT___system_auto_cbus_fixedClockNode_anon_out_reset) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sinkD__DOT__d_q__DOT__maybe_full = 0U;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__reg_mcause = 0ULL;
    } else {
        if (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sinkD__DOT__d_q__DOT__do_enq) 
             != (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sinkD__DOT__d_q__DOT__do_deq))) {
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sinkD__DOT__d_q__DOT__maybe_full 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__sinkD__DOT__d_q__DOT__do_enq;
        }
        if (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___csr_wen_T_4) 
             & (0xfffU == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___decoded_addr_decoded_decoded_andMatrixOutputs_T_54)))) {
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__reg_mcause 
                = (0x800000000000000fULL & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__wdata);
        } else if ((1U & (~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___GEN_40)))) {
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__reg_mcause 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__cause;
        }
    }
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__loop__DOT__columns_3__DOT__f4_scnt 
        = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__loop__DOT___columns_3_io_f3_meta_s_cnt;
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_ldq_oh_6 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_ld_val) 
           & (6U == (7U & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__ldq_tail))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_ldq_oh_5 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_ld_val) 
           & (5U == (7U & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__ldq_tail))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_ldq_oh_3 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_ld_val) 
           & (3U == (7U & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__ldq_tail))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_ldq_oh_2 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_ld_val) 
           & (2U == (7U & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__ldq_tail))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_ldq_oh_1 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_ld_val) 
           & (1U == (7U & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__ldq_tail))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_ldq_oh_4 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_ld_val) 
           & (4U == (7U & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__ldq_tail))));
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__778(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__778\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_ldq_oh_0 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_ld_val) 
           & (0U == (7U & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__ldq_tail))));
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT___system_auto_cbus_fixedClockNode_anon_out_reset) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__cork__DOT__state_0 = 0U;
        vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__mshr_head = 0U;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__small_1 = 0U;
    } else {
        if ((0U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__cork__DOT__beatsLeft))) {
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__cork__DOT__state_0 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__cork__DOT__c_a_valid;
        }
        if (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__pri_rdy) 
             & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__pri_val))) {
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__mshr_head 
                = (1U & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__mshr_head) 
                         - (IData)(1U)));
        }
        if (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___csr_wen_T_4) 
             & (0x7ffU == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___decoded_addr_decoded_decoded_andMatrixOutputs_T_85)))) {
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__small_1 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___GEN_30;
        } else if ((1U & (~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__reg_mcountinhibit)))) {
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__small_1 
                = (0x3fU & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__nextSmall_1));
        }
    }
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT__REG_19 
        = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT__s1_is_jal_3;
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__mshr_alloc_idx_REG 
        = (1U & ((~ ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT___mshrs_0_io_req_pri_rdy) 
                     & (~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__mshr_head)))) 
                 & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT___mshrs_1_io_req_pri_rdy) 
                    | (~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT___mshrs_0_io_req_pri_rdy)))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__bim__DOT__REG_6_3 
        = (3U & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__bim__DOT___bim_col_6_RW0_rdata) 
                 >> 6U));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__bim__DOT__REG_4_3 
        = (3U & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__bim__DOT___bim_col_4_RW0_rdata) 
                 >> 6U));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__bim__DOT__REG_3_3 
        = (3U & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__bim__DOT___bim_col_3_RW0_rdata) 
                 >> 6U));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__bim__DOT__REG_1_3 
        = (3U & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__bim__DOT___bim_col_1_RW0_rdata) 
                 >> 6U));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__bim__DOT__REG_5_3 
        = (3U & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__bim__DOT___bim_col_5_RW0_rdata) 
                 >> 6U));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__bim__DOT__REG_7_3 
        = (3U & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__bim__DOT___bim_col_7_RW0_rdata) 
                 >> 6U));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__bim__DOT__REG_3 
        = (3U & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__bim__DOT___bim_col_0_RW0_rdata) 
                 >> 6U));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__bim__DOT__REG_2_3 
        = (3U & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__bim__DOT___bim_col_2_RW0_rdata) 
                 >> 6U));
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__779(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__779\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__respq__DOT___GEN_9) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__respq__DOT__uops_1_ldq_idx 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT___resp_arb_io_out_bits_uop_ldq_idx;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__respq__DOT___GEN_12) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__respq__DOT__uops_3_ldq_idx 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT___resp_arb_io_out_bits_uop_ldq_idx;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__respq__DOT___GEN_7) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__respq__DOT__uops_0_ldq_idx 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT___resp_arb_io_out_bits_uop_ldq_idx;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__respq__DOT___GEN_11) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__respq__DOT__uops_2_ldq_idx 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT___resp_arb_io_out_bits_uop_ldq_idx;
    }
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__imm_rename_stage__DOT__freelist__DOT__com_deallocs_REG_1_bits 
        = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_exe_unit_0__DOT__rrd_uop_bits_pimm;
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_exe_unit_0__DOT__exe_uop_bits_fu_code_2 
        = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_exe_unit_0__DOT__rrd_uop_bits_fu_code_2;
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_exe_unit_0__DOT__rrd_uop_bits_prs1 
        = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_exe_unit_0__DOT__arb_uop_bits_prs1;
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__fpu__DOT__fpu__DOT__fpmu_io_in_valid) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__fpu__DOT__fpu__DOT__fpmu__DOT__in_pipe_b_ren2 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__exe_uop_bits_fp_ctrl_ren2;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT____Vcellinp__slots_6__io_in_uop_valid) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__slots_6__DOT__slot_uop_lrs1_rtype 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rename_stage__DOT__r_uop_lrs1_rtype;
    }
    if ((0U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__pbus__DOT__coupler_to_device_named_uart_0__DOT__fragmenter__DOT__gennum))) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__pbus__DOT__coupler_to_device_named_uart_0__DOT__fragmenter__DOT__aToggle_r 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__pbus__DOT__coupler_to_device_named_uart_0__DOT__fragmenter__DOT__dToggle;
    }
    if (((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__fb__DOT___GEN_36) 
           | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__fb__DOT___GEN_27)) 
          | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__fb__DOT___GEN_18)) 
         | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__fb__DOT___GEN_9))) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__fb__DOT__fb_uop_ram_5_ftq_idx 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__ftq__DOT__enq_ptr;
    }
    if (((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__fb__DOT___GEN_35) 
           | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__fb__DOT___GEN_26)) 
          | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__fb__DOT___GEN_17)) 
         | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__fb__DOT___GEN_8))) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__fb__DOT__fb_uop_ram_4_ftq_idx 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__ftq__DOT__enq_ptr;
    }
    if (((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__fb__DOT___GEN_33) 
           | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__fb__DOT___GEN_24)) 
          | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__fb__DOT___GEN_15)) 
         | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__fb__DOT___GEN_6))) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__fb__DOT__fb_uop_ram_2_ftq_idx 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__ftq__DOT__enq_ptr;
    }
    if (((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__fb__DOT___GEN_32) 
           | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__fb__DOT___GEN_23)) 
          | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__fb__DOT___GEN_14)) 
         | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__fb__DOT___GEN_5))) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__fb__DOT__fb_uop_ram_1_ftq_idx 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__ftq__DOT__enq_ptr;
    }
    if (((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__fb__DOT___GEN_38) 
           | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__fb__DOT___GEN_29)) 
          | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__fb__DOT___GEN_20)) 
         | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__fb__DOT___GEN_11))) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__fb__DOT__fb_uop_ram_7_ftq_idx 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__ftq__DOT__enq_ptr;
    }
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__780(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__780\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if (((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__fb__DOT___GEN_37) 
           | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__fb__DOT___GEN_28)) 
          | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__fb__DOT___GEN_19)) 
         | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__fb__DOT___GEN_10))) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__fb__DOT__fb_uop_ram_6_ftq_idx 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__ftq__DOT__enq_ptr;
    }
    if (((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__fb__DOT___GEN_34) 
           | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__fb__DOT___GEN_25)) 
          | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__fb__DOT___GEN_16)) 
         | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__fb__DOT___GEN_7))) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__fb__DOT__fb_uop_ram_3_ftq_idx 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__ftq__DOT__enq_ptr;
    }
    if (((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__fb__DOT___GEN_31) 
           | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__fb__DOT___GEN_22)) 
          | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__fb__DOT___GEN_13)) 
         | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__fb__DOT___GEN_4))) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__fb__DOT__fb_uop_ram_0_ftq_idx 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__ftq__DOT__enq_ptr;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT____Vcellinp__mshrs_6__io_allocate_valid) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_6__DOT__request_put 
            = (0x3fU & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT___GEN_18)
                         ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__request_bits_put)
                         : (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__requests__DOT___data_ext_R0_data)));
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT____Vcellinp__mshrs_5__io_allocate_valid) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_5__DOT__request_put 
            = (0x3fU & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT___GEN_15)
                         ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__request_bits_put)
                         : (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__requests__DOT___data_ext_R0_data)));
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT____Vcellinp__mshrs_0__io_allocate_valid) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_0__DOT__request_put 
            = (0x3fU & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT___GEN_5)
                         ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__request_bits_put)
                         : (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__requests__DOT___data_ext_R0_data)));
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT____Vcellinp__mshrs_1__io_allocate_valid) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_1__DOT__request_put 
            = (0x3fU & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT___GEN_7)
                         ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__request_bits_put)
                         : (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__requests__DOT___data_ext_R0_data)));
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT____Vcellinp__mshrs_2__io_allocate_valid) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_2__DOT__request_put 
            = (0x3fU & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT___GEN_9)
                         ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__request_bits_put)
                         : (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__requests__DOT___data_ext_R0_data)));
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT____Vcellinp__mshrs_3__io_allocate_valid) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_3__DOT__request_put 
            = (0x3fU & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT___GEN_11)
                         ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__request_bits_put)
                         : (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__requests__DOT___data_ext_R0_data)));
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT____Vcellinp__mshrs_4__io_allocate_valid) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_4__DOT__request_put 
            = (0x3fU & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT___GEN_13)
                         ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__request_bits_put)
                         : (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__requests__DOT___data_ext_R0_data)));
    }
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__781(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__781\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT____Vcellinp__mshrs_5__io_allocate_valid) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_5__DOT__request_prio_1 
            = (1U & ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT___GEN_15)) 
                     & (IData)((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__requests__DOT___data_ext_R0_data 
                                >> 0x2aU))));
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT____Vcellinp__mshrs_0__io_allocate_valid) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_0__DOT__request_prio_1 
            = (1U & ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT___GEN_5)) 
                     & (IData)((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__requests__DOT___data_ext_R0_data 
                                >> 0x2aU))));
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT____Vcellinp__mshrs_1__io_allocate_valid) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_1__DOT__request_prio_1 
            = (1U & ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT___GEN_7)) 
                     & (IData)((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__requests__DOT___data_ext_R0_data 
                                >> 0x2aU))));
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT____Vcellinp__mshrs_2__io_allocate_valid) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_2__DOT__request_prio_1 
            = (1U & ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT___GEN_9)) 
                     & (IData)((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__requests__DOT___data_ext_R0_data 
                                >> 0x2aU))));
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT____Vcellinp__mshrs_3__io_allocate_valid) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_3__DOT__request_prio_1 
            = (1U & ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT___GEN_11)) 
                     & (IData)((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__requests__DOT___data_ext_R0_data 
                                >> 0x2aU))));
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT____Vcellinp__mshrs_4__io_allocate_valid) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_4__DOT__request_prio_1 
            = (1U & ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT___GEN_13)) 
                     & (IData)((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__requests__DOT___data_ext_R0_data 
                                >> 0x2aU))));
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT___system_auto_cbus_fixedClockNode_anon_out_reset) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__mbus__DOT__mbus_xbar__DOT__state_1 = 0U;
    } else if ((0U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__mbus__DOT__mbus_xbar__DOT__beatsLeft))) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__mbus__DOT__mbus_xbar__DOT__state_1 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__mbus__DOT__mbus_xbar__DOT__winner_1;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__s1_is_replay) {
        vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__s2_tlb_resp_pf_inst 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__s1_tlb_resp_REG_pf_inst;
        vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__s2_tlb_resp_ae_inst 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__s1_tlb_resp_REG_ae_inst;
    } else {
        vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__s2_tlb_resp_pf_inst 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___tlb_io_resp_pf_inst;
        vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__s2_tlb_resp_ae_inst 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___tlb_io_resp_ae_inst;
    }
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__s2_tlb_miss 
        = ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__s1_is_replay)) 
           & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___tlb_io_resp_miss));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__s2_is_replay_REG 
        = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__s1_is_replay;
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__lcam_ldq_idx_reg_1 
        = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___retry_queue_io_deq_bits_uop_ldq_idx;
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT____Vcellinp__mshrs_6__io_allocate_valid) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_6__DOT__request_size 
            = (7U & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT___GEN_18)
                      ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__request_bits_size)
                      : (IData)((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__requests__DOT___data_ext_R0_data 
                                 >> 0x1fU))));
    }
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__782(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__782\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT____Vcellinp__mshrs_5__io_allocate_valid) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_5__DOT__request_size 
            = (7U & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT___GEN_15)
                      ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__request_bits_size)
                      : (IData)((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__requests__DOT___data_ext_R0_data 
                                 >> 0x1fU))));
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT____Vcellinp__mshrs_0__io_allocate_valid) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_0__DOT__request_size 
            = (7U & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT___GEN_5)
                      ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__request_bits_size)
                      : (IData)((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__requests__DOT___data_ext_R0_data 
                                 >> 0x1fU))));
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT____Vcellinp__mshrs_1__io_allocate_valid) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_1__DOT__request_size 
            = (7U & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT___GEN_7)
                      ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__request_bits_size)
                      : (IData)((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__requests__DOT___data_ext_R0_data 
                                 >> 0x1fU))));
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT____Vcellinp__mshrs_2__io_allocate_valid) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_2__DOT__request_size 
            = (7U & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT___GEN_9)
                      ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__request_bits_size)
                      : (IData)((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__requests__DOT___data_ext_R0_data 
                                 >> 0x1fU))));
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT____Vcellinp__mshrs_3__io_allocate_valid) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_3__DOT__request_size 
            = (7U & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT___GEN_11)
                      ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__request_bits_size)
                      : (IData)((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__requests__DOT___data_ext_R0_data 
                                 >> 0x1fU))));
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT____Vcellinp__mshrs_4__io_allocate_valid) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__mshrs_4__DOT__request_size 
            = (7U & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT___GEN_13)
                      ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__request_bits_size)
                      : (IData)((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__coh_wrapper__DOT__l2__DOT__inclusive_cache_bank_sched__DOT__requests__DOT___data_ext_R0_data 
                                 >> 0x1fU))));
    }
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__io_f3_meta_REG_1 
        = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__io_f3_meta_REG;
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT___system_auto_cbus_fixedClockNode_anon_out_reset) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__mbus__DOT__mbus_xbar__DOT__state_0 = 0U;
    } else if ((0U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__mbus__DOT__mbus_xbar__DOT__beatsLeft))) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__mbus__DOT__mbus_xbar__DOT__state_0 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__mbus__DOT__mbus_xbar__DOT__winner_0;
    }
    if ((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT___GEN) 
          & (0U != (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT___GEN_29))) 
         & (0xdU == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__s1_update_write_way)))) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__meta_13_br_mask 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__wmeta_br_mask;
    }
    if ((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT___GEN) 
          & (0U != (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT___GEN_29))) 
         & (0xcU == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__s1_update_write_way)))) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__meta_12_br_mask 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__wmeta_br_mask;
    }
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__783(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__783\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if ((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT___GEN) 
          & (0U != (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT___GEN_29))) 
         & (0xbU == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__s1_update_write_way)))) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__meta_11_br_mask 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__wmeta_br_mask;
    }
    if ((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT___GEN) 
          & (0U != (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT___GEN_29))) 
         & (0xaU == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__s1_update_write_way)))) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__meta_10_br_mask 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__wmeta_br_mask;
    }
    if ((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT___GEN) 
          & (0U != (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT___GEN_29))) 
         & (8U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__s1_update_write_way)))) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__meta_8_br_mask 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__wmeta_br_mask;
    }
    if ((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT___GEN) 
          & (0U != (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT___GEN_29))) 
         & (0U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__s1_update_write_way)))) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__meta_0_br_mask 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__wmeta_br_mask;
    }
    if ((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT___GEN) 
          & (0U != (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT___GEN_29))) 
         & (7U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__s1_update_write_way)))) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__meta_7_br_mask 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__wmeta_br_mask;
    }
    if ((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT___GEN) 
          & (0U != (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT___GEN_29))) 
         & (5U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__s1_update_write_way)))) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__meta_5_br_mask 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__wmeta_br_mask;
    }
    if ((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT___GEN) 
          & (0U != (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT___GEN_29))) 
         & (4U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__s1_update_write_way)))) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__meta_4_br_mask 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__wmeta_br_mask;
    }
    if ((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT___GEN) 
          & (0U != (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT___GEN_29))) 
         & (6U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__s1_update_write_way)))) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__meta_6_br_mask 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__wmeta_br_mask;
    }
    if ((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT___GEN) 
          & (0U != (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT___GEN_29))) 
         & (0x12U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__s1_update_write_way)))) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__meta_18_br_mask 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__wmeta_br_mask;
    }
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__784(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__784\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if ((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT___GEN) 
          & (0U != (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT___GEN_29))) 
         & (9U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__s1_update_write_way)))) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__meta_9_br_mask 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__wmeta_br_mask;
    }
    if ((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT___GEN) 
          & (0U != (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT___GEN_29))) 
         & (2U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__s1_update_write_way)))) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__meta_2_br_mask 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__wmeta_br_mask;
    }
    if ((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT___GEN) 
          & (0U != (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT___GEN_29))) 
         & (1U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__s1_update_write_way)))) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__meta_1_br_mask 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__wmeta_br_mask;
    }
    if ((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT___GEN) 
          & (0U != (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT___GEN_29))) 
         & (3U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__s1_update_write_way)))) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__meta_3_br_mask 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__wmeta_br_mask;
    }
    if ((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT___GEN) 
          & (0U != (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT___GEN_29))) 
         & (0xeU == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__s1_update_write_way)))) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__meta_14_br_mask 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__wmeta_br_mask;
    }
    if ((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT___GEN) 
          & (0U != (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT___GEN_29))) 
         & (0xfU == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__s1_update_write_way)))) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__meta_15_br_mask 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__wmeta_br_mask;
    }
    if ((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT___GEN) 
          & (0U != (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT___GEN_29))) 
         & (0x10U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__s1_update_write_way)))) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__meta_16_br_mask 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__wmeta_br_mask;
    }
    if ((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT___GEN) 
          & (0U != (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT___GEN_29))) 
         & (0x11U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__s1_update_write_way)))) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__meta_17_br_mask 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__wmeta_br_mask;
    }
    if ((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT___GEN) 
          & (0U != (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT___GEN_29))) 
         & (0x13U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__s1_update_write_way)))) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__meta_19_br_mask 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__wmeta_br_mask;
    }
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__785(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__785\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if ((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT___GEN) 
          & (0U != (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT___GEN_29))) 
         & (0x14U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__s1_update_write_way)))) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__meta_20_br_mask 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__wmeta_br_mask;
    }
    if ((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT___GEN) 
          & (0U != (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT___GEN_29))) 
         & (0x15U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__s1_update_write_way)))) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__meta_21_br_mask 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__wmeta_br_mask;
    }
    if ((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT___GEN) 
          & (0U != (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT___GEN_29))) 
         & (0x16U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__s1_update_write_way)))) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__meta_22_br_mask 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__wmeta_br_mask;
    }
    if ((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT___GEN) 
          & (0U != (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT___GEN_29))) 
         & (0x17U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__s1_update_write_way)))) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__meta_23_br_mask 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__wmeta_br_mask;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT___system_auto_cbus_fixedClockNode_anon_out_reset) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__cbus__DOT__in_xbar__DOT__readys_mask = 3U;
    } else if (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__cbus__DOT__in_xbar__DOT__latch) 
                & (0U != (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__cbus__DOT__in_xbar__DOT__readys_valid)))) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__cbus__DOT__in_xbar__DOT__readys_mask 
            = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__cbus__DOT__in_xbar__DOT___readys_mask_T) 
               | (2U & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__cbus__DOT__in_xbar__DOT___readys_mask_T) 
                        << 1U)));
    }
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unq_iss_unit__DOT__slots_6__DOT__slot_uop_iw_issued 
        = ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unq_iss_unit__DOT____Vcellinp__slots_6__io_in_uop_valid)) 
           & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unq_iss_unit__DOT__issue_slots_6_grant) 
              & (~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT____Vcellinp__unq_iss_unit__io_squash_grant))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_6__DOT__slot_uop_iw_issued 
        = ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT____Vcellinp__slots_6__io_in_uop_valid)) 
           & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__issue_slots_6_grant) 
              & (~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT___fp_exe_unit_0_io_squash_iss))));
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_13) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__ldq_uop_0_is_fence 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_is_fence;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_14) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__ldq_uop_1_is_fence 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_is_fence;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_15) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__ldq_uop_2_is_fence 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_is_fence;
    }
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__786(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__786\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_16) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__ldq_uop_3_is_fence 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_is_fence;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_17) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__ldq_uop_4_is_fence 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_is_fence;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_18) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__ldq_uop_5_is_fence 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_is_fence;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_19) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__ldq_uop_6_is_fence 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_is_fence;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_20) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__ldq_uop_7_is_fence 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_is_fence;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_542) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_0_is_fence 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_is_fence;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_544) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_1_is_fence 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_is_fence;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_546) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_2_is_fence 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_is_fence;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_548) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_3_is_fence 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_is_fence;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_550) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_4_is_fence 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_is_fence;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_552) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_5_is_fence 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_is_fence;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_554) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_6_is_fence 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_is_fence;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_556) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_7_is_fence 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_is_fence;
    }
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT__io_resp_f3_2_is_br_REG 
        = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___bpd_io_resp_f2_preds_2_is_br;
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT__io_resp_f3_1_is_br_REG 
        = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___bpd_io_resp_f2_preds_1_is_br;
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT__io_resp_f3_3_is_br_REG 
        = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___bpd_io_resp_f2_preds_3_is_br;
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT__io_resp_f3_0_is_br_REG 
        = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___bpd_io_resp_f2_preds_0_is_br;
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT___system_auto_cbus_fixedClockNode_anon_out_reset) {
        vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__uartClockDomainWrapper__DOT__uart_0__DOT__rxm__DOT__debounce = 0U;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__uartClockDomainWrapper__DOT__uart_0__DOT__rxm__DOT__valid = 0U;
        vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__uartClockDomainWrapper__DOT__uart_0__DOT__rxm__DOT__state = 0U;
    } else {
        if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__uartClockDomainWrapper__DOT__uart_0__DOT__rxen) {
            if ((1U & (~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__uartClockDomainWrapper__DOT__uart_0__DOT__rxm__DOT__state)))) {
                if (vlSelfRef.TestDriver__DOT__testHarness__DOT__uart_sim_0_uartno0__DOT__rxm__DOT__out) {
                    if (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__uart_sim_0_uartno0__DOT__rxm__DOT__out) 
                         & (0U != (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__uartClockDomainWrapper__DOT__uart_0__DOT__rxm__DOT__debounce)))) {
                        vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__uartClockDomainWrapper__DOT__uart_0__DOT__rxm__DOT__debounce 
                            = (3U & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__uartClockDomainWrapper__DOT__uart_0__DOT__rxm__DOT__debounce) 
                                     - (IData)(1U)));
                    }
                } else {
                    vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__uartClockDomainWrapper__DOT__uart_0__DOT__rxm__DOT__debounce 
                        = (3U & ((IData)(1U) + (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__uartClockDomainWrapper__DOT__uart_0__DOT__rxm__DOT__debounce)));
                }
            }
        } else {
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__uartClockDomainWrapper__DOT__uart_0__DOT__rxm__DOT__debounce = 0U;
        }
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__uartClockDomainWrapper__DOT__uart_0__DOT__rxm__DOT__valid 
            = (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__uartClockDomainWrapper__DOT__uart_0__DOT__rxm__DOT__state) 
                & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__uartClockDomainWrapper__DOT__uart_0__DOT__rxm__DOT___GEN_1)) 
               & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__uartClockDomainWrapper__DOT__uart_0__DOT__rxm__DOT__data_last));
        vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__uartClockDomainWrapper__DOT__uart_0__DOT__rxm__DOT__state 
            = (1U & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__uartClockDomainWrapper__DOT__uart_0__DOT__rxm__DOT__state)
                      ? (~ ((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__uartClockDomainWrapper__DOT__uart_0__DOT__rxm__DOT__state) 
                              & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__uartClockDomainWrapper__DOT__uart_0__DOT__rxm__DOT__pulse)) 
                             & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__uartClockDomainWrapper__DOT__uart_0__DOT__rxm__DOT__sample_mid)) 
                            & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__uartClockDomainWrapper__DOT__uart_0__DOT__rxm__DOT__data_last)))
                      : (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__uartClockDomainWrapper__DOT__uart_0__DOT__rxm__DOT___GEN)));
    }
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__787(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__787\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__uartClockDomainWrapper__DOT__uart_0__DOT__rxm__DOT__state) 
         | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__uartClockDomainWrapper__DOT__uart_0__DOT__rxm__DOT___GEN))) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__uartClockDomainWrapper__DOT__uart_0__DOT__rxm__DOT__prescaler 
            = (0x1fffU & (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__uartClockDomainWrapper__DOT__uart_0__DOT__rxm__DOT__restore)
                            ? (0xfffU & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__uartClockDomainWrapper__DOT__uart_0__DOT__div) 
                                         >> 4U)) : (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__uartClockDomainWrapper__DOT__uart_0__DOT__rxm__DOT__prescaler)) 
                          - (1U & (~ ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__uartClockDomainWrapper__DOT__uart_0__DOT__rxm__DOT__restore) 
                                      & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__uartClockDomainWrapper__DOT__uart_0__DOT__rxm__DOT__sample_count) 
                                         < (0xfU & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__uartClockDomainWrapper__DOT__uart_0__DOT__div))))))));
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__uartClockDomainWrapper__DOT__uart_0__DOT__rxm__DOT__state) {
        if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__uartClockDomainWrapper__DOT__uart_0__DOT__rxm__DOT___GEN_0) {
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__uartClockDomainWrapper__DOT__uart_0__DOT__rxm__DOT__data_count 
                = (0xfU & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__uartClockDomainWrapper__DOT__uart_0__DOT__rxm__DOT___countdown_T_1) 
                           >> 4U));
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__uartClockDomainWrapper__DOT__uart_0__DOT__rxm__DOT__sample_count 
                = (0xfU & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__uartClockDomainWrapper__DOT__uart_0__DOT__rxm__DOT___countdown_T_1));
        }
    } else if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__uartClockDomainWrapper__DOT__uart_0__DOT__rxm__DOT___GEN) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__uartClockDomainWrapper__DOT__uart_0__DOT__rxm__DOT__data_count = 9U;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__uartClockDomainWrapper__DOT__uart_0__DOT__rxm__DOT__sample_count = 0xfU;
    }
    if (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__uartClockDomainWrapper__DOT__uart_0__DOT__rxm__DOT__state) 
         & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__uartClockDomainWrapper__DOT__uart_0__DOT__rxm__DOT___GEN_0))) {
        vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__uartClockDomainWrapper__DOT__uart_0__DOT__rxm__DOT__sample 
            = ((6U & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__uartClockDomainWrapper__DOT__uart_0__DOT__rxm__DOT__sample) 
                      << 1U)) | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__uart_sim_0_uartno0__DOT__rxm__DOT__out));
    }
    if ((1U & (~ (((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__uartClockDomainWrapper__DOT__uart_0__DOT__rxm__DOT__state)) 
                   | (~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__uartClockDomainWrapper__DOT__uart_0__DOT__rxm__DOT___GEN_1))) 
                  | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__uartClockDomainWrapper__DOT__uart_0__DOT__rxm__DOT__data_last))))) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__uartClockDomainWrapper__DOT__uart_0__DOT__rxm__DOT__shifter 
            = ((0x80U & ((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__uartClockDomainWrapper__DOT__uart_0__DOT__rxm__DOT__sample) 
                           & (IData)((0U != (6U & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__uartClockDomainWrapper__DOT__uart_0__DOT__rxm__DOT__sample))))) 
                          | (IData)((6U == (6U & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__uartClockDomainWrapper__DOT__uart_0__DOT__rxm__DOT__sample))))) 
                         << 7U)) | (0x7fU & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__uartClockDomainWrapper__DOT__uart_0__DOT__rxm__DOT__shifter) 
                                             >> 1U)));
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_542) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_0_imm_sel 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_imm_sel;
    }
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__788(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__788\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_544) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_1_imm_sel 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_imm_sel;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_1_rob_idx 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_rob_idx;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_546) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_2_imm_sel 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_imm_sel;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_2_rob_idx 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_rob_idx;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_548) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_3_imm_sel 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_imm_sel;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_3_rob_idx 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_rob_idx;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_550) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_4_imm_sel 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_imm_sel;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_4_rob_idx 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_rob_idx;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_552) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_5_imm_sel 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_imm_sel;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_554) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_6_imm_sel 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_imm_sel;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_556) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_7_imm_sel 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_imm_sel;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_13) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__ldq_uop_0_rob_idx 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_rob_idx;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_14) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__ldq_uop_1_rob_idx 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_rob_idx;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_15) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__ldq_uop_2_rob_idx 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_rob_idx;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_16) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__ldq_uop_3_rob_idx 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_rob_idx;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_17) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__ldq_uop_4_rob_idx 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_rob_idx;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_18) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__ldq_uop_5_rob_idx 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_rob_idx;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_19) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__ldq_uop_6_rob_idx 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_rob_idx;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_20) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__ldq_uop_7_rob_idx 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_rob_idx;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_542) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_0_rob_idx 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_rob_idx;
    }
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__789(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__789\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_552) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_5_rob_idx 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_rob_idx;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_554) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_6_rob_idx 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_rob_idx;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_556) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_7_rob_idx 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_rob_idx;
    }
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__loop__DOT__columns_0__DOT__f4_fire 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__loop__DOT__s3_valid) 
           & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__loop__DOT__s3_mask) 
              & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__loop__DOT__columns_0_io_f3_req_fire_REG) 
                 & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT____Vcellinp__bpd__io_f3_fire))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__loop__DOT__columns_1__DOT__f4_fire 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__loop__DOT__s3_valid) 
           & (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__loop__DOT__s3_mask) 
               >> 1U) & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__loop__DOT__columns_1_io_f3_req_fire_REG) 
                         & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT____Vcellinp__bpd__io_f3_fire))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__loop__DOT__columns_2__DOT__f4_fire 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__loop__DOT__s3_valid) 
           & (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__loop__DOT__s3_mask) 
               >> 2U) & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__loop__DOT__columns_2_io_f3_req_fire_REG) 
                         & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT____Vcellinp__bpd__io_f3_fire))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__ldq_order_fail_7 
        = (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_648) 
            & (7U == (7U & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__wb_ldst_forward_ldq_idx_0)))) 
           | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_646)
               ? (((7U == (7U & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__wb_ldst_forward_ldq_idx_0))) 
                   | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_627)) 
                  | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_540))
               : ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_627) 
                  | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_540))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__ldq_order_fail_6 
        = (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_648) 
            & (6U == (7U & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__wb_ldst_forward_ldq_idx_0)))) 
           | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_646)
               ? (((6U == (7U & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__wb_ldst_forward_ldq_idx_0))) 
                   | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_625)) 
                  | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_539))
               : ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_625) 
                  | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_539))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__ldq_order_fail_2 
        = (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_648) 
            & (2U == (7U & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__wb_ldst_forward_ldq_idx_0)))) 
           | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_646)
               ? (((2U == (7U & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__wb_ldst_forward_ldq_idx_0))) 
                   | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_617)) 
                  | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_535))
               : ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_617) 
                  | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_535))));
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__790(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__790\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__ldq_order_fail_4 
        = (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_648) 
            & (4U == (7U & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__wb_ldst_forward_ldq_idx_0)))) 
           | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_646)
               ? (((4U == (7U & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__wb_ldst_forward_ldq_idx_0))) 
                   | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_621)) 
                  | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_537))
               : ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_621) 
                  | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_537))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__ldq_order_fail_5 
        = (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_648) 
            & (5U == (7U & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__wb_ldst_forward_ldq_idx_0)))) 
           | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_646)
               ? (((5U == (7U & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__wb_ldst_forward_ldq_idx_0))) 
                   | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_623)) 
                  | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_538))
               : ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_623) 
                  | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_538))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__ldq_order_fail_3 
        = (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_648) 
            & (3U == (7U & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__wb_ldst_forward_ldq_idx_0)))) 
           | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_646)
               ? (((3U == (7U & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__wb_ldst_forward_ldq_idx_0))) 
                   | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_619)) 
                  | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_536))
               : ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_619) 
                  | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_536))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__ldq_order_fail_1 
        = (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_648) 
            & (1U == (7U & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__wb_ldst_forward_ldq_idx_0)))) 
           | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_646)
               ? (((1U == (7U & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__wb_ldst_forward_ldq_idx_0))) 
                   | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_615)) 
                  | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_534))
               : ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_615) 
                  | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_534))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__ldq_order_fail_0 
        = (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_648) 
            & (0U == (7U & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__wb_ldst_forward_ldq_idx_0)))) 
           | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_646)
               ? (((0U == (7U & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__wb_ldst_forward_ldq_idx_0))) 
                   | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_612)) 
                  | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_533))
               : ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_612) 
                  | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_533))));
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__791(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__791\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__cbus__DOT__coupler_to_plic__DOT__fragmenter__DOT__repeater__DOT___GEN) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__cbus__DOT__coupler_to_plic__DOT__fragmenter__DOT__repeater__DOT__saved_opcode 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT___cbus_auto_coupler_to_bus_named_pbus_bus_xing_out_a_bits_opcode;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__cbus__DOT__coupler_to_plic__DOT__fragmenter__DOT__repeater__DOT__saved_size 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT___cbus_auto_coupler_to_bus_named_pbus_bus_xing_out_a_bits_size;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__cbus__DOT__coupler_to_l2_ctrl__DOT__fragmenter__DOT__repeater__DOT___GEN) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__cbus__DOT__coupler_to_l2_ctrl__DOT__fragmenter__DOT__repeater__DOT__saved_opcode 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT___cbus_auto_coupler_to_bus_named_pbus_bus_xing_out_a_bits_opcode;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__cbus__DOT__coupler_to_l2_ctrl__DOT__fragmenter__DOT__repeater__DOT__saved_size 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT___cbus_auto_coupler_to_bus_named_pbus_bus_xing_out_a_bits_size;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT___system_auto_cbus_fixedClockNode_anon_out_reset) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__sbus__DOT__system_bus_xbar__DOT__readys_mask = 3U;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__mbus__DOT__mbus_xbar__DOT__readys_mask = 3U;
    } else {
        if (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__sbus__DOT__system_bus_xbar__DOT__latch) 
             & (0U != (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__sbus__DOT__system_bus_xbar__DOT__readys_valid)))) {
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__sbus__DOT__system_bus_xbar__DOT__readys_mask 
                = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__sbus__DOT__system_bus_xbar__DOT___readys_mask_T) 
                   | (2U & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__sbus__DOT__system_bus_xbar__DOT___readys_mask_T) 
                            << 1U)));
        }
        if (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__mbus__DOT__mbus_xbar__DOT__latch) 
             & (0U != (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__mbus__DOT__mbus_xbar__DOT__readys_valid)))) {
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__mbus__DOT__mbus_xbar__DOT__readys_mask 
                = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__mbus__DOT__mbus_xbar__DOT___readys_mask_T) 
                   | (2U & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__mbus__DOT__mbus_xbar__DOT___readys_mask_T) 
                            << 1U)));
        }
    }
    if ((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___csr_wen_T_4) 
          & (0xfffU == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___decoded_addr_decoded_decoded_andMatrixOutputs_T_66))) 
         & (~ ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__reg_pmp_7_cfg_l) 
               | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___GEN_54))))) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__reg_pmp_7_addr 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___GEN_47;
    }
    if ((1U & (~ ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT___core_io_ifu_redirect_flush) 
                  | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__dis_stalls_0))))) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__imm_rename_stage__DOT__r_uop_imm_rename 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_imm_rename;
    }
    if ((0U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__cbus__DOT__coupler_to_bootrom__DOT__fragmenter__DOT__gennum))) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__cbus__DOT__coupler_to_bootrom__DOT__fragmenter__DOT__aToggle_r 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__cbus__DOT__coupler_to_bootrom__DOT__fragmenter__DOT__dToggle;
    }
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__REG_1 
        = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___rob_io_flush_valid;
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__mem_stq_incoming_e_0_bits_uop_mem_size 
        = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_226;
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__mem_ldq_incoming_e_0_bits_uop_mem_size 
        = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_108;
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_542) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_0_is_unique 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_is_unique;
    }
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__792(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__792\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_544) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_1_is_unique 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_is_unique;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_546) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_2_is_unique 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_is_unique;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_548) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_3_is_unique 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_is_unique;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_550) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_4_is_unique 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_is_unique;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_552) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_5_is_unique 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_is_unique;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_554) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_6_is_unique 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_is_unique;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_556) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_7_is_unique 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_is_unique;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__retry_queue__DOT___GEN_120) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__retry_queue__DOT__uops_4_mem_size 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT____Vcellinp__retry_queue__io_enq_bits_uop_mem_size;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__retry_queue__DOT___GEN_112) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__retry_queue__DOT__uops_0_mem_size 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT____Vcellinp__retry_queue__io_enq_bits_uop_mem_size;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__retry_queue__DOT___GEN_118) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__retry_queue__DOT__uops_3_mem_size 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT____Vcellinp__retry_queue__io_enq_bits_uop_mem_size;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__retry_queue__DOT___GEN_114) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__retry_queue__DOT__uops_1_mem_size 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT____Vcellinp__retry_queue__io_enq_bits_uop_mem_size;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__retry_queue__DOT___GEN_116) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__retry_queue__DOT__uops_2_mem_size 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT____Vcellinp__retry_queue__io_enq_bits_uop_mem_size;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__retry_queue__DOT___GEN_122) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__retry_queue__DOT__uops_5_mem_size 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT____Vcellinp__retry_queue__io_enq_bits_uop_mem_size;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__retry_queue__DOT___GEN_124) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__retry_queue__DOT__uops_6_mem_size 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT____Vcellinp__retry_queue__io_enq_bits_uop_mem_size;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__retry_queue__DOT___GEN_125) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__retry_queue__DOT__uops_7_mem_size 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT____Vcellinp__retry_queue__io_enq_bits_uop_mem_size;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT___system_auto_cbus_fixedClockNode_anon_out_reset) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__small_0 = 0U;
        vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__large_0 = 0ULL;
    } else if (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___csr_wen_T_4) 
                & (0xfffU == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___decoded_addr_decoded_decoded_andMatrixOutputs_T_86)))) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__small_0 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___GEN_30;
        vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__large_0 
            = ((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___wdata_T_2 
                & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___wdata_T_6) 
               >> 6U);
    } else {
        if ((IData)((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__nextSmall) 
                      >> 6U) & (~ ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__reg_mcountinhibit) 
                                   >> 2U))))) {
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__large_0 
                = (0x3ffffffffffffffULL & (1ULL + vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__large_0));
        }
        if ((1U & (~ ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__reg_mcountinhibit) 
                      >> 2U)))) {
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__small_0 
                = (0x3fU & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__nextSmall));
        }
    }
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__793(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__793\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___csr_wen_T_4) 
         & (0xfffU == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___decoded_addr_decoded_decoded_andMatrixOutputs_T_87)))) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__small_2 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___GEN_30;
        vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__large_2 
            = (0x3ffffffffULL & ((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___wdata_T_2 
                                  & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___wdata_T_6) 
                                 >> 6U));
    } else {
        if ((IData)((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__nextSmall_2) 
                      >> 6U) & (~ ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__reg_mcountinhibit) 
                                   >> 3U))))) {
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__large_2 
                = (0x3ffffffffULL & (1ULL + vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__large_2));
        }
        if ((1U & (~ ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__reg_mcountinhibit) 
                      >> 3U)))) {
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__small_2 
                = (0x3fU & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__nextSmall_2));
        }
    }
    if (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___csr_wen_T_4) 
         & (0xfffU == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___decoded_addr_decoded_decoded_andMatrixOutputs_T_88)))) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__small_3 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___GEN_30;
        vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__large_3 
            = (0x3ffffffffULL & ((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___wdata_T_2 
                                  & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___wdata_T_6) 
                                 >> 6U));
    } else {
        if ((IData)((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__nextSmall_3) 
                      >> 6U) & (~ ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__reg_mcountinhibit) 
                                   >> 4U))))) {
            vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__large_3 
                = (0x3ffffffffULL & (1ULL + vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__large_3));
        }
        if ((1U & (~ ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__reg_mcountinhibit) 
                      >> 4U)))) {
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__small_3 
                = (0x3fU & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__nextSmall_3));
        }
    }
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__mem_stq_retry_e_bits_uop_mem_size 
        = (3U & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_225) 
                 >> (0xfU & VL_SHIFTL_III(4,32,32, 
                                          (7U & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___retry_queue_io_deq_bits_uop_stq_idx)), 1U))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__mem_ldq_retry_e_bits_uop_mem_size 
        = (3U & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_107) 
                 >> (0xfU & VL_SHIFTL_III(4,32,32, 
                                          (7U & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___retry_queue_io_deq_bits_uop_ldq_idx)), 1U))));
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__794(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__794\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__cbus__DOT__coupler_to_bootrom__DOT__fragmenter__DOT__repeater__DOT___GEN) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__cbus__DOT__coupler_to_bootrom__DOT__fragmenter__DOT__repeater__DOT__saved_size 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT___cbus_auto_coupler_to_bus_named_pbus_bus_xing_out_a_bits_size;
    }
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__ll_wbarb_io_in_0_bits_REG_uop_rob_idx 
        = (0x1fU & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_462)
                     ? ((0x27U >= (0x3fU & ((IData)(5U) 
                                            * (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__resp_uop_ldq_idx))))
                         ? (IData)((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_87 
                                    >> (0x3fU & ((IData)(5U) 
                                                 * (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__resp_uop_ldq_idx)))))
                         : 0U) : (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__wb_ldst_forward_e_REG_uop_rob_idx)));
    if ((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT___GEN) 
          & (0U != (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT___GEN_29))) 
         & (0xcU == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__s1_update_write_way)))) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__meta_12_jal_mask 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__wmeta_jal_mask;
    }
    if ((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT___GEN) 
          & (0U != (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT___GEN_29))) 
         & (0xbU == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__s1_update_write_way)))) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__meta_11_jal_mask 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__wmeta_jal_mask;
    }
    if ((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT___GEN) 
          & (0U != (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT___GEN_29))) 
         & (9U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__s1_update_write_way)))) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__meta_9_jal_mask 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__wmeta_jal_mask;
    }
    if ((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT___GEN) 
          & (0U != (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT___GEN_29))) 
         & (8U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__s1_update_write_way)))) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__meta_8_jal_mask 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__wmeta_jal_mask;
    }
    if ((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT___GEN) 
          & (0U != (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT___GEN_29))) 
         & (6U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__s1_update_write_way)))) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__meta_6_jal_mask 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__wmeta_jal_mask;
    }
    if ((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT___GEN) 
          & (0U != (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT___GEN_29))) 
         & (5U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__s1_update_write_way)))) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__meta_5_jal_mask 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__wmeta_jal_mask;
    }
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__795(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__795\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if ((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT___GEN) 
          & (0U != (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT___GEN_29))) 
         & (4U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__s1_update_write_way)))) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__meta_4_jal_mask 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__wmeta_jal_mask;
    }
    if ((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT___GEN) 
          & (0U != (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT___GEN_29))) 
         & (7U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__s1_update_write_way)))) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__meta_7_jal_mask 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__wmeta_jal_mask;
    }
    if ((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT___GEN) 
          & (0U != (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT___GEN_29))) 
         & (0x13U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__s1_update_write_way)))) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__meta_19_jal_mask 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__wmeta_jal_mask;
    }
    if ((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT___GEN) 
          & (0U != (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT___GEN_29))) 
         & (0xaU == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__s1_update_write_way)))) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__meta_10_jal_mask 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__wmeta_jal_mask;
    }
    if ((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT___GEN) 
          & (0U != (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT___GEN_29))) 
         & (1U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__s1_update_write_way)))) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__meta_1_jal_mask 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__wmeta_jal_mask;
    }
    if ((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT___GEN) 
          & (0U != (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT___GEN_29))) 
         & (0xdU == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__s1_update_write_way)))) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__meta_13_jal_mask 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__wmeta_jal_mask;
    }
    if ((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT___GEN) 
          & (0U != (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT___GEN_29))) 
         & (2U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__s1_update_write_way)))) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__meta_2_jal_mask 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__wmeta_jal_mask;
    }
    if ((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT___GEN) 
          & (0U != (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT___GEN_29))) 
         & (0U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__s1_update_write_way)))) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__meta_0_jal_mask 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__wmeta_jal_mask;
    }
    if ((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT___GEN) 
          & (0U != (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT___GEN_29))) 
         & (3U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__s1_update_write_way)))) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__meta_3_jal_mask 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__wmeta_jal_mask;
    }
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__796(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__796\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if ((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT___GEN) 
          & (0U != (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT___GEN_29))) 
         & (0xeU == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__s1_update_write_way)))) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__meta_14_jal_mask 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__wmeta_jal_mask;
    }
    if ((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT___GEN) 
          & (0U != (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT___GEN_29))) 
         & (0xfU == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__s1_update_write_way)))) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__meta_15_jal_mask 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__wmeta_jal_mask;
    }
    if ((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT___GEN) 
          & (0U != (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT___GEN_29))) 
         & (0x10U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__s1_update_write_way)))) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__meta_16_jal_mask 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__wmeta_jal_mask;
    }
    if ((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT___GEN) 
          & (0U != (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT___GEN_29))) 
         & (0x11U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__s1_update_write_way)))) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__meta_17_jal_mask 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__wmeta_jal_mask;
    }
    if ((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT___GEN) 
          & (0U != (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT___GEN_29))) 
         & (0x12U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__s1_update_write_way)))) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__meta_18_jal_mask 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__wmeta_jal_mask;
    }
    if ((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT___GEN) 
          & (0U != (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT___GEN_29))) 
         & (0x14U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__s1_update_write_way)))) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__meta_20_jal_mask 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__wmeta_jal_mask;
    }
    if ((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT___GEN) 
          & (0U != (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT___GEN_29))) 
         & (0x15U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__s1_update_write_way)))) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__meta_21_jal_mask 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__wmeta_jal_mask;
    }
    if ((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT___GEN) 
          & (0U != (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT___GEN_29))) 
         & (0x16U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__s1_update_write_way)))) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__meta_22_jal_mask 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__wmeta_jal_mask;
    }
    if ((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT___GEN) 
          & (0U != (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT___GEN_29))) 
         & (0x17U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__s1_update_write_way)))) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__meta_23_jal_mask 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__wmeta_jal_mask;
    }
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__797(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__797\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT___system_auto_cbus_fixedClockNode_anon_out_reset) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__pbus__DOT__buffer_1__DOT__nodeIn_d_q__DOT__maybe_full = 0U;
    } else if (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__pbus__DOT__buffer_1__DOT__nodeIn_d_q__DOT__do_enq) 
                != (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__pbus__DOT__buffer_1__DOT__nodeIn_d_q__DOT__do_deq))) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__pbus__DOT__buffer_1__DOT__nodeIn_d_q__DOT__maybe_full 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__pbus__DOT__buffer_1__DOT__nodeIn_d_q__DOT__do_enq;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__mmios_0__DOT___GEN_5) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__mmios_0__DOT__req_uop_ldq_idx 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__s2_req_0_uop_ldq_idx;
    }
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__io_resp_f3_0_REG_is_br 
        = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__io_resp_f2_0_REG_is_br;
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__io_resp_f3_2_REG_is_br 
        = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__io_resp_f2_2_REG_is_br;
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__io_resp_f3_3_REG_is_br 
        = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__io_resp_f2_3_REG_is_br;
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__io_resp_f3_1_REG_is_br 
        = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__io_resp_f2_1_REG_is_br;
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_13) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__ldq_uop_0_mem_cmd 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_mem_cmd;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_14) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__ldq_uop_1_mem_cmd 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_mem_cmd;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_15) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__ldq_uop_2_mem_cmd 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_mem_cmd;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_16) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__ldq_uop_3_mem_cmd 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_mem_cmd;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_17) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__ldq_uop_4_mem_cmd 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_mem_cmd;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_18) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__ldq_uop_5_mem_cmd 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_mem_cmd;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_19) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__ldq_uop_6_mem_cmd 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_mem_cmd;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_20) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__ldq_uop_7_mem_cmd 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_mem_cmd;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_542) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_0_mem_cmd 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_mem_cmd;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_544) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_1_mem_cmd 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_mem_cmd;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_546) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_2_mem_cmd 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_mem_cmd;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_548) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_3_mem_cmd 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_mem_cmd;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_550) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_4_mem_cmd 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_mem_cmd;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_552) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_5_mem_cmd 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_mem_cmd;
    }
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__798(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__798\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_554) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_6_mem_cmd 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_mem_cmd;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_556) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_uop_7_mem_cmd 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_uops_0_bits_mem_cmd;
    }
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT___system_auto_cbus_fixedClockNode_anon_out_reset) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__sbus__DOT__system_bus_xbar__DOT__state_1 = 0U;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__sbus__DOT__system_bus_xbar__DOT__state_0 = 0U;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__mbus__DOT__buffer_1__DOT__nodeIn_d_q__DOT__maybe_full = 0U;
    } else {
        if ((0U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__sbus__DOT__system_bus_xbar__DOT__beatsLeft))) {
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__sbus__DOT__system_bus_xbar__DOT__state_1 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__sbus__DOT__system_bus_xbar__DOT__winner_1;
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__sbus__DOT__system_bus_xbar__DOT__state_0 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__sbus__DOT__system_bus_xbar__DOT__winner_0;
        }
        if (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__mbus__DOT__buffer_1__DOT__nodeIn_d_q__DOT__do_enq) 
             != (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__mbus__DOT__buffer_1__DOT__nodeIn_d_q__DOT__do_deq))) {
            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__mbus__DOT__buffer_1__DOT__nodeIn_d_q__DOT__maybe_full 
                = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__mbus__DOT__buffer_1__DOT__nodeIn_d_q__DOT__do_enq;
        }
    }
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__mem_paddr_0 
        = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT___lsu_io_dmem_req_bits_0_bits_addr;
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__lcam_addr_REG 
        = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___dtlb_io_resp_0_paddr;
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__io_fdiv_resp_fdivsqrt__DOT__divSqrt_1__DOT__divSqrtRecFNToRaw__DOT__divSqrtRawFN__DOT__entering) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__io_fdiv_resp_fdivsqrt__DOT__divSqrt_1__DOT__divSqrtRecFNToRaw__DOT__divSqrtRawFN__DOT__isInf_Z 
            = (1U & (((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__io_fdiv_resp_fdivsqrt__DOT__r_sigs_sqrt)) 
                      & (~ (0U != (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__io_fdiv_resp_fdivsqrt__DOT__fpiu__DOT__in_in2[1U] 
                                   >> 0x1dU)))) | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__io_fdiv_resp_fdivsqrt__DOT__divSqrt_1__DOT__divSqrtRecFNToRaw__DOT____Vcellinp__divSqrtRawFN__io_a_isInf)));
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__io_fdiv_resp_fdivsqrt__DOT__divSqrt_1__DOT__divSqrtRecFNToRaw__DOT__divSqrtRawFN__DOT__majorExc_Z 
            = (1U & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__io_fdiv_resp_fdivsqrt__DOT__r_sigs_sqrt)
                      ? (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__io_fdiv_resp_fdivsqrt__DOT__divSqrt_1__DOT__divSqrtRecFNToRaw__DOT____Vcellinp__divSqrtRawFN__io_a_isNaN) 
                          & (~ (IData)((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__io_fdiv_resp_fdivsqrt__DOT__fpiu__DOT__dcmp__DOT___GEN 
                                        >> 0x33U)))) 
                         | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__io_fdiv_resp_fdivsqrt__DOT__divSqrt_1__DOT__divSqrtRecFNToRaw__DOT__divSqrtRawFN__DOT__notSigNaNIn_invalidExc_S_sqrt))
                      : (((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__io_fdiv_resp_fdivsqrt__DOT__divSqrt_1__DOT__divSqrtRecFNToRaw__DOT____Vcellinp__divSqrtRawFN__io_a_isNaN) 
                            & (~ (IData)((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__io_fdiv_resp_fdivsqrt__DOT__fpiu__DOT__dcmp__DOT___GEN 
                                          >> 0x33U)))) 
                           | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__io_fdiv_resp_fdivsqrt__DOT__divSqrt_1__DOT__divSqrtRecFNToRaw__DOT____Vcellinp__divSqrtRawFN__io_b_isNaN) 
                              & (~ (IData)((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__io_fdiv_resp_fdivsqrt__DOT__fpiu__DOT__dcmp__DOT___GEN_0 
                                            >> 0x33U))))) 
                          | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__io_fdiv_resp_fdivsqrt__DOT__divSqrt_1__DOT__divSqrtRecFNToRaw__DOT__divSqrtRawFN__DOT__notSigNaNIn_invalidExc_S_div)) 
                         | (((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__io_fdiv_resp_fdivsqrt__DOT__divSqrt_1__DOT__divSqrtRecFNToRaw__DOT____Vcellinp__divSqrtRawFN__io_a_isNaN)) 
                             & (~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__io_fdiv_resp_fdivsqrt__DOT__divSqrt_1__DOT__divSqrtRecFNToRaw__DOT____Vcellinp__divSqrtRawFN__io_a_isInf))) 
                            & (~ (0U != (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_exe_unit_0__DOT__io_fdiv_resp_fdivsqrt__DOT__fpiu__DOT__in_in2[1U] 
                                         >> 0x1dU)))))));
    }
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT__io_resp_f2_1_predicted_pc_REG_valid 
        = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT__s1_resp_1_valid;
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT__io_resp_f2_0_predicted_pc_REG_valid 
        = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT__s1_resp_0_valid;
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT__io_resp_f2_2_predicted_pc_REG_valid 
        = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT__s1_resp_2_valid;
}
