// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See VTestDriver.h for the primary calling header

#include "VTestDriver__pch.h"
#include "VTestDriver___024root.h"

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__2511(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__2511\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__io_resp_f3_pc_REG 
        = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__io_resp_f2_pc_REG;
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__io_resp_f3_3_REG_is_jal 
        = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__io_resp_f2_3_REG_is_jal;
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__io_resp_f3_2_REG_is_jal 
        = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__io_resp_f2_2_REG_is_jal;
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__io_resp_f3_1_REG_is_jal 
        = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__io_resp_f2_1_REG_is_jal;
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__io_resp_f3_0_REG_is_jal 
        = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__io_resp_f2_0_REG_is_jal;
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT__io_resp_f3_3_is_jal_REG 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT__REG_18)
            ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT__io_resp_f2_3_is_jal_REG)
            : (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__io_resp_f2_3_REG_is_jal));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT__REG_21 
        = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT__REG_20;
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT__io_resp_f3_2_is_jal_REG 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT__REG_12)
            ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT__io_resp_f2_2_is_jal_REG)
            : (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__io_resp_f2_2_REG_is_jal));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT__io_resp_f3_1_is_jal_REG 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT__REG_6)
            ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT__io_resp_f2_1_is_jal_REG)
            : (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__io_resp_f2_1_REG_is_jal));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT__io_resp_f3_0_is_jal_REG 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT__REG)
            ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT__io_resp_f2_0_is_jal_REG)
            : (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__io_resp_f2_0_REG_is_jal));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT__REG_15 
        = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT__REG_14;
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT__REG_9 
        = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT__REG_8;
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT__REG_3 
        = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT__REG_2;
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_is_mov 
        = (IData)(((0x33U == vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT___GEN_2) 
                   & (0U == (0xf8000U & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__pred_rename_stage__DOT___GEN_21 
        = ((0U != (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_br_type)) 
           & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_is_sfb));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT____VdfgRegularize_h8fa566d8_0_6 
        = (((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_is_sfb)) 
            & ((1U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_br_type)) 
               | ((2U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_br_type)) 
                  | ((3U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_br_type)) 
                     | ((4U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_br_type)) 
                        | ((5U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_br_type)) 
                           | (6U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_br_type)))))))) 
           | (8U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_br_type)));
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__2512(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__2512\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT___GEN_3 
        = ((0U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_br_type)) 
           & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_is_sfb));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_192 
        = (IData)(((0U == (0x1c000000U & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst)) 
                   & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_191)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_200 
        = (IData)(((0x8000000U == (0xc000000U & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst)) 
                   & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_194)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_195 
        = (IData)(((0U == (0xc000000U & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst)) 
                   & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_194)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_134 
        = (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst 
           & ((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst 
               >> 1U) & (IData)(vlSelfRef.__VdfgRegularize_h787163e4_0_37)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_120 
        = (IData)(((7U == (7U & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst)) 
                   & (IData)(vlSelfRef.__VdfgRegularize_h787163e4_0_37)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_169 
        = (IData)(((0x53U == (0x107fU & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst)) 
                   & (IData)(vlSelfRef.__VdfgRegularize_h787163e4_0_41)));
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__2513(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__2513\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_170 
        = (IData)(((0x53U == (0x207fU & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst)) 
                   & (IData)(vlSelfRef.__VdfgRegularize_h787163e4_0_41)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_94 
        = (IData)(((0x53U == (0x107fU & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst)) 
                   & (IData)(vlSelfRef.__VdfgRegularize_h787163e4_0_39)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_95 
        = (IData)(((0x53U == (0x207fU & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst)) 
                   & (IData)(vlSelfRef.__VdfgRegularize_h787163e4_0_39)));
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__2514(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__2514\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_51 
        = (IData)(((0x10000053U == (0x1df0707fU & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst)) 
                   & (7U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_264))));
    vlSelfRef.__VdfgRegularize_h787163e4_0_43 = (IData)(
                                                        ((0U 
                                                          == 
                                                          (0x1c000000U 
                                                           & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst)) 
                                                         & (7U 
                                                            == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_264))));
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__2515(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__2515\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_50 
        = (IData)(((0x10000053U == (0x1dc0007fU & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst)) 
                   & (7U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_262))));
    vlSelfRef.__VdfgRegularize_h787163e4_0_42 = (IData)(
                                                        ((0U 
                                                          == 
                                                          (0xc000000U 
                                                           & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst)) 
                                                         & (7U 
                                                            == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_262))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_55 
        = (IData)(((0x13U == (0x77U & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst)) 
                   & (7U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_210))));
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__2516(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__2516\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.__VdfgRegularize_h787163e4_0_22 = (IData)(
                                                        ((0x60U 
                                                          == 
                                                          (0x78U 
                                                           & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst)) 
                                                         & (7U 
                                                            == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_210))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_177 
        = (IData)(((0U == (0x6000U & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst)) 
                   & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_176)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT____VdfgRegularize_h51aa2a42_0_74 
        = ((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst 
            & (IData)(vlSelfRef.__VdfgRegularize_h36cfaf1a_0_123)) 
           | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_190));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_60 
        = ((~ (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst 
               >> 0x1cU)) & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_59));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT____VdfgRegularize_h51aa2a42_0_73 
        = (IData)(((0x10000000U == (0x1c000000U & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst)) 
                   & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_59)));
    vlSelfRef.__VdfgRegularize_h787163e4_0_28 = (IData)(
                                                        ((0x5000U 
                                                          == 
                                                          (0x2007040U 
                                                           & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst)) 
                                                         & (0x1fU 
                                                            == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_246))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_80 
        = (IData)(((0x5013U == (0x707fU & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst)) 
                   & (0x1fU == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_246))));
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__2517(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__2517\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.__VdfgRegularize_h787163e4_0_12 = (IData)(
                                                        ((0x18000000U 
                                                          == 
                                                          (0x1c000000U 
                                                           & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst)) 
                                                         & (7U 
                                                            == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_242))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_243 
        = ((8U & ((~ (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst 
                      >> 0x1cU)) << 3U)) | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_242));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_107 
        = (IData)(((0x1b200070U == (0x1ffffff0U & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst)) 
                   & (7U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_252))));
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__2518(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__2518\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_253 
        = ((8U & ((~ (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst 
                      >> 0x1cU)) << 3U)) | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_252));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_126 
        = (IData)(((3U == (0xfU & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst)) 
                   & (IData)(vlSelfRef.__VdfgRegularize_h787163e4_0_19)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_105 
        = (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst 
           & (IData)(vlSelfRef.__VdfgRegularize_h787163e4_0_19));
    vlSelfRef.__VdfgRegularize_h787163e4_0_33 = ((~ 
                                                  (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst 
                                                   >> 0x1aU)) 
                                                 & (0xfU 
                                                    == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_235)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_79 
        = (IData)(((0x8705013U == (0xff0707fU & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst)) 
                   & (0xfU == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_235))));
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__2519(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__2519\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_237 
        = ((0x20U & ((~ (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst 
                         >> 0x1aU)) << 5U)) | ((0x10U 
                                                & ((~ 
                                                    (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst 
                                                     >> 0x1bU)) 
                                                   << 4U)) 
                                               | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_235)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_158 
        = (IData)(((0x53U == (0xc00007fU & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst)) 
                   & (7U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_213))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_53 
        = (IData)(((0x800202fU == (0x800607fU & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst)) 
                   & (7U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_213))));
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__2520(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__2520\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.__VdfgRegularize_h787163e4_0_38 = ((~ 
                                                  (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst 
                                                   >> 0x1aU)) 
                                                 & (7U 
                                                    == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_213)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_226 
        = ((8U & (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst 
                  >> 0x19U)) | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_213));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_214 
        = ((8U & ((~ (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst 
                      >> 0x1cU)) << 3U)) | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_213));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_compact_uop_wdata_0 
        = (((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rename_stage__DOT__r_uop_is_fencei) 
              << 0x1aU) | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rename_stage__DOT__r_uop_ftq_idx) 
                           << 0x16U)) | (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rename_stage__DOT__r_uop_uses_ldq) 
                                          << 0x15U) 
                                         | (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rename_stage__DOT__r_uop_uses_stq) 
                                             << 0x14U) 
                                            | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rename_stage__DOT__r_uop_dst_rtype) 
                                               << 0x12U)))) 
           | (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rename_stage__DOT__r_uop_ldst) 
               << 0xcU) | (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___dispatcher_io_dis_uops_3_0_bits_pdst) 
                            << 6U) | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___dispatcher_io_dis_uops_3_0_bits_stale_pdst))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_85 
        = (3U & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_84) 
                 | (((IData)(1U) << (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__b2_uop_rob_idx)) 
                    >> 0x1eU)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__issue_slots_6_in_uop_valid 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__shamts_oh_7) 
           & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT___slots_7_io_will_be_valid));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__ae_st_0 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___dtlb_io_resp_0_ae_st) 
           & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__exe_tlb_uop_0_uses_stq));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__ae_ld_0 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___dtlb_io_resp_0_ae_ld) 
           & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__exe_tlb_uop_0_uses_ldq));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___GEN_46 
        = ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__reg_pmp_0_cfg_l)) 
           & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT____VdfgRegularize_h51aa2a42_0_69));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___GEN_48 
        = ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__reg_pmp_1_cfg_l)) 
           & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT____VdfgRegularize_h51aa2a42_0_69));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___GEN_49 
        = ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__reg_pmp_2_cfg_l)) 
           & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT____VdfgRegularize_h51aa2a42_0_69));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___GEN_50 
        = ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__reg_pmp_3_cfg_l)) 
           & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT____VdfgRegularize_h51aa2a42_0_69));
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__2521(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__2521\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___GEN_51 
        = ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__reg_pmp_4_cfg_l)) 
           & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT____VdfgRegularize_h51aa2a42_0_69));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___GEN_52 
        = ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__reg_pmp_5_cfg_l)) 
           & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT____VdfgRegularize_h51aa2a42_0_69));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___GEN_53 
        = ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__reg_pmp_6_cfg_l)) 
           & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT____VdfgRegularize_h51aa2a42_0_69));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT___GEN_55 
        = ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__reg_pmp_7_cfg_l)) 
           & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT____VdfgRegularize_h51aa2a42_0_69));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___bpd_decoder_io_out_shadowable 
        = (((IData)((0x130U == (0x107f0U & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3__DOT__ram[0xcU]))) 
            | ((IData)(((0x130U == (0x770U & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3__DOT__ram[0xcU])) 
                        & (IData)(vlSelfRef.__VdfgRegularize_h787163e4_0_0))) 
               | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd_decoder__DOT____VdfgRegularize_h05eccaf4_0_33) 
                  | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd_decoder__DOT____VdfgRegularize_h05eccaf4_0_34) 
                     | ((IData)((0x370U == (0x7f0U 
                                            & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3__DOT__ram[0xcU]))) 
                        | ((IData)(((0x10130U == (0x307f0U 
                                                  & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3__DOT__ram[0xcU])) 
                                    & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd_decoder__DOT____VdfgRegularize_h05eccaf4_0_35))) 
                           | ((IData)(((0x101b0U == 
                                        (0x305f0U & 
                                         vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3__DOT__ram[0xcU])) 
                                       & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd_decoder__DOT____VdfgRegularize_h05eccaf4_0_36))) 
                              | ((IData)((0x20130U 
                                          == (0x207f0U 
                                              & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3__DOT__ram[0xcU]))) 
                                 | ((IData)(((0x50130U 
                                              == (0x707f0U 
                                                  & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3__DOT__ram[0xcU])) 
                                             & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd_decoder__DOT____VdfgRegularize_h05eccaf4_0_37))) 
                                    | ((IData)(((0x501b0U 
                                                 == 
                                                 (0x200705f0U 
                                                  & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3__DOT__ram[0xcU])) 
                                                & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd_decoder__DOT____VdfgRegularize_h05eccaf4_0_37))) 
                                       | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd_decoder__DOT____VdfgRegularize_h05eccaf4_0_38))))))))))) 
           & ((0U == ((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd_decoder__DOT____VdfgRegularize_h05eccaf4_0_33) 
                        << 3U) | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd_decoder__DOT____VdfgRegularize_h05eccaf4_0_34) 
                                  << 2U)) | (((IData)(
                                                      ((0x330U 
                                                        == 
                                                        (0x60770U 
                                                         & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3__DOT__ram[0xcU])) 
                                                       & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd_decoder__DOT____VdfgRegularize_h05eccaf4_0_36))) 
                                              << 1U) 
                                             | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd_decoder__DOT____VdfgRegularize_h05eccaf4_0_38)))) 
              | (((0x1fU & (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3__DOT__ram[0xcU] 
                            >> 0x13U)) == (0x1fU & 
                                           (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3__DOT__ram[0xcU] 
                                            >> 0xbU))) 
                 | (IData)(((0U == (0xf80000U & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3__DOT__ram[0xcU])) 
                            & (0x33U == ((0x1fc00U 
                                          & ((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3__DOT__ram[0xdU] 
                                              << 0xdU) 
                                             | (0x1c00U 
                                                & (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3__DOT__ram[0xcU] 
                                                   >> 0x13U)))) 
                                         | ((0x380U 
                                             & (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3__DOT__ram[0xcU] 
                                                >> 9U)) 
                                            | (0x7fU 
                                               & (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3__DOT__ram[0xcU] 
                                                  >> 4U))))))))));
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__2522(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__2522\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___bpd_decoder_1_io_out_shadowable 
        = (((IData)((0x130U == (0x107f0U & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3__DOT__ram[0xdU]))) 
            | ((IData)(((0x130U == (0x770U & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3__DOT__ram[0xdU])) 
                        & (IData)(vlSelfRef.__VdfgRegularize_h787163e4_0_1))) 
               | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd_decoder_1__DOT____VdfgRegularize_h05eccaf4_0_33) 
                  | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd_decoder_1__DOT____VdfgRegularize_h05eccaf4_0_34) 
                     | ((IData)((0x370U == (0x7f0U 
                                            & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3__DOT__ram[0xdU]))) 
                        | ((IData)(((0x10130U == (0x307f0U 
                                                  & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3__DOT__ram[0xdU])) 
                                    & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd_decoder_1__DOT____VdfgRegularize_h05eccaf4_0_35))) 
                           | ((IData)(((0x101b0U == 
                                        (0x305f0U & 
                                         vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3__DOT__ram[0xdU])) 
                                       & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd_decoder_1__DOT____VdfgRegularize_h05eccaf4_0_36))) 
                              | ((IData)((0x20130U 
                                          == (0x207f0U 
                                              & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3__DOT__ram[0xdU]))) 
                                 | ((IData)(((0x50130U 
                                              == (0x707f0U 
                                                  & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3__DOT__ram[0xdU])) 
                                             & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd_decoder_1__DOT____VdfgRegularize_h05eccaf4_0_37))) 
                                    | ((IData)(((0x501b0U 
                                                 == 
                                                 (0x200705f0U 
                                                  & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3__DOT__ram[0xdU])) 
                                                & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd_decoder_1__DOT____VdfgRegularize_h05eccaf4_0_37))) 
                                       | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd_decoder_1__DOT____VdfgRegularize_h05eccaf4_0_38))))))))))) 
           & ((0U == ((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd_decoder_1__DOT____VdfgRegularize_h05eccaf4_0_33) 
                        << 3U) | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd_decoder_1__DOT____VdfgRegularize_h05eccaf4_0_34) 
                                  << 2U)) | (((IData)(
                                                      ((0x330U 
                                                        == 
                                                        (0x60770U 
                                                         & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3__DOT__ram[0xdU])) 
                                                       & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd_decoder_1__DOT____VdfgRegularize_h05eccaf4_0_36))) 
                                              << 1U) 
                                             | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd_decoder_1__DOT____VdfgRegularize_h05eccaf4_0_38)))) 
              | (((0x1fU & (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3__DOT__ram[0xdU] 
                            >> 0x13U)) == (0x1fU & 
                                           (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3__DOT__ram[0xdU] 
                                            >> 0xbU))) 
                 | (IData)(((0U == (0xf80000U & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3__DOT__ram[0xdU])) 
                            & (0x33U == ((0x1fc00U 
                                          & ((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3__DOT__ram[0xeU] 
                                              << 0xdU) 
                                             | (0x1c00U 
                                                & (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3__DOT__ram[0xdU] 
                                                   >> 0x13U)))) 
                                         | ((0x380U 
                                             & (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3__DOT__ram[0xdU] 
                                                >> 9U)) 
                                            | (0x7fU 
                                               & (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3__DOT__ram[0xdU] 
                                                  >> 4U))))))))));
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__2523(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__2523\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___bpd_decoder_2_io_out_shadowable 
        = (((IData)((0x130U == (0x107f0U & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3__DOT__ram[0xeU]))) 
            | ((IData)(((0x130U == (0x770U & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3__DOT__ram[0xeU])) 
                        & (IData)(vlSelfRef.__VdfgRegularize_h787163e4_0_2))) 
               | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd_decoder_2__DOT____VdfgRegularize_h05eccaf4_0_33) 
                  | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd_decoder_2__DOT____VdfgRegularize_h05eccaf4_0_34) 
                     | ((IData)((0x370U == (0x7f0U 
                                            & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3__DOT__ram[0xeU]))) 
                        | ((IData)(((0x10130U == (0x307f0U 
                                                  & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3__DOT__ram[0xeU])) 
                                    & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd_decoder_2__DOT____VdfgRegularize_h05eccaf4_0_35))) 
                           | ((IData)(((0x101b0U == 
                                        (0x305f0U & 
                                         vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3__DOT__ram[0xeU])) 
                                       & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd_decoder_2__DOT____VdfgRegularize_h05eccaf4_0_36))) 
                              | ((IData)((0x20130U 
                                          == (0x207f0U 
                                              & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3__DOT__ram[0xeU]))) 
                                 | ((IData)(((0x50130U 
                                              == (0x707f0U 
                                                  & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3__DOT__ram[0xeU])) 
                                             & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd_decoder_2__DOT____VdfgRegularize_h05eccaf4_0_37))) 
                                    | ((IData)(((0x501b0U 
                                                 == 
                                                 (0x200705f0U 
                                                  & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3__DOT__ram[0xeU])) 
                                                & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd_decoder_2__DOT____VdfgRegularize_h05eccaf4_0_37))) 
                                       | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd_decoder_2__DOT____VdfgRegularize_h05eccaf4_0_38))))))))))) 
           & ((0U == ((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd_decoder_2__DOT____VdfgRegularize_h05eccaf4_0_33) 
                        << 3U) | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd_decoder_2__DOT____VdfgRegularize_h05eccaf4_0_34) 
                                  << 2U)) | (((IData)(
                                                      ((0x330U 
                                                        == 
                                                        (0x60770U 
                                                         & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3__DOT__ram[0xeU])) 
                                                       & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd_decoder_2__DOT____VdfgRegularize_h05eccaf4_0_36))) 
                                              << 1U) 
                                             | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd_decoder_2__DOT____VdfgRegularize_h05eccaf4_0_38)))) 
              | (((0x1fU & (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3__DOT__ram[0xeU] 
                            >> 0x13U)) == (0x1fU & 
                                           (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3__DOT__ram[0xeU] 
                                            >> 0xbU))) 
                 | (IData)(((0U == (0xf80000U & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3__DOT__ram[0xeU])) 
                            & (0x33U == ((0x1fc00U 
                                          & ((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3__DOT__ram[0xfU] 
                                              << 0xdU) 
                                             | (0x1c00U 
                                                & (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3__DOT__ram[0xeU] 
                                                   >> 0x13U)))) 
                                         | ((0x380U 
                                             & (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3__DOT__ram[0xeU] 
                                                >> 9U)) 
                                            | (0x7fU 
                                               & (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3__DOT__ram[0xeU] 
                                                  >> 4U))))))))));
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__2524(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__2524\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___bpd_decoder_3_io_out_shadowable 
        = (((IData)((0x130U == (0x107f0U & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3__DOT__ram[0xfU]))) 
            | ((IData)(((0x130U == (0x770U & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3__DOT__ram[0xfU])) 
                        & (IData)(vlSelfRef.__VdfgRegularize_h787163e4_0_3))) 
               | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd_decoder_3__DOT____VdfgRegularize_h05eccaf4_0_33) 
                  | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd_decoder_3__DOT____VdfgRegularize_h05eccaf4_0_34) 
                     | ((IData)((0x370U == (0x7f0U 
                                            & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3__DOT__ram[0xfU]))) 
                        | ((IData)(((0x10130U == (0x307f0U 
                                                  & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3__DOT__ram[0xfU])) 
                                    & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd_decoder_3__DOT____VdfgRegularize_h05eccaf4_0_35))) 
                           | ((IData)(((0x101b0U == 
                                        (0x305f0U & 
                                         vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3__DOT__ram[0xfU])) 
                                       & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd_decoder_3__DOT____VdfgRegularize_h05eccaf4_0_36))) 
                              | ((IData)((0x20130U 
                                          == (0x207f0U 
                                              & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3__DOT__ram[0xfU]))) 
                                 | ((IData)(((0x50130U 
                                              == (0x707f0U 
                                                  & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3__DOT__ram[0xfU])) 
                                             & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd_decoder_3__DOT____VdfgRegularize_h05eccaf4_0_37))) 
                                    | ((IData)(((0x501b0U 
                                                 == 
                                                 (0x200705f0U 
                                                  & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3__DOT__ram[0xfU])) 
                                                & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd_decoder_3__DOT____VdfgRegularize_h05eccaf4_0_37))) 
                                       | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd_decoder_3__DOT____VdfgRegularize_h05eccaf4_0_38))))))))))) 
           & ((0U == ((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd_decoder_3__DOT____VdfgRegularize_h05eccaf4_0_33) 
                        << 3U) | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd_decoder_3__DOT____VdfgRegularize_h05eccaf4_0_34) 
                                  << 2U)) | (((IData)(
                                                      ((0x330U 
                                                        == 
                                                        (0x60770U 
                                                         & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3__DOT__ram[0xfU])) 
                                                       & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd_decoder_3__DOT____VdfgRegularize_h05eccaf4_0_36))) 
                                              << 1U) 
                                             | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd_decoder_3__DOT____VdfgRegularize_h05eccaf4_0_38)))) 
              | (((0x1fU & (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3__DOT__ram[0xfU] 
                            >> 0x13U)) == (0x1fU & 
                                           (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3__DOT__ram[0xfU] 
                                            >> 0xbU))) 
                 | (IData)(((0U == (0xf80000U & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3__DOT__ram[0xfU])) 
                            & (0x33U == ((0x1fc00U 
                                          & ((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3__DOT__ram[0x10U] 
                                              << 0xdU) 
                                             | (0x1c00U 
                                                & (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3__DOT__ram[0xfU] 
                                                   >> 0x13U)))) 
                                         | ((0x380U 
                                             & (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3__DOT__ram[0xfU] 
                                                >> 9U)) 
                                            | (0x7fU 
                                               & (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3__DOT__ram[0xfU] 
                                                  >> 4U))))))))));
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__2525(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__2525\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___f4_correct_f1_ghist_T_5 
        = ((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__s1_ghist_old_history 
            == vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___f4_decoded_ghist_new_history_old_history_T_6) 
           & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT____VdfgRegularize_hce62b063_0_48));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___f4_correct_f2_ghist_T_5 
        = ((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__s2_ghist_old_history 
            == vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___f4_decoded_ghist_new_history_old_history_T_6) 
           & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT____VdfgRegularize_hce62b063_0_47));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___f4_correct_f3_ghist_T_5 
        = (((((QData)((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3__DOT__ram[3U])) 
              << 0x35U) | (((QData)((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3__DOT__ram[2U])) 
                            << 0x15U) | ((QData)((IData)(
                                                         vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3__DOT__ram[1U])) 
                                         >> 0xbU))) 
            == vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___f4_decoded_ghist_new_history_old_history_T_6) 
           & ((~ (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3__DOT__ram[1U] 
                  >> 8U)) & (IData)((0x200U != (0x300U 
                                                & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3__DOT__ram[1U])))));
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__2526(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__2526\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT___GEN_5 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT___GEN_3) 
           & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_is_mov));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_193 
        = ((~ (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst 
               >> 0x19U)) & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_192));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_196 
        = ((~ (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst 
               >> 0x19U)) & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_195));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_175 
        = (IData)(((0x2000053U == (0x3f0607fU & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst)) 
                   & (IData)(vlSelfRef.__VdfgRegularize_h787163e4_0_43)));
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__2527(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__2527\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_100 
        = (IData)(((0x53U == (0x1f0607fU & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst)) 
                   & (IData)(vlSelfRef.__VdfgRegularize_h787163e4_0_43)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_fu_code_8 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_50) 
           | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_51));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_173 
        = (IData)(((0x2000053U == (0x3c0007fU & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst)) 
                   & (IData)(vlSelfRef.__VdfgRegularize_h787163e4_0_42)));
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__2528(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__2528\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_99 
        = (IData)(((0x53U == (0x1c0007fU & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst)) 
                   & (IData)(vlSelfRef.__VdfgRegularize_h787163e4_0_42)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_65 
        = (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst 
           & ((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst 
               >> 1U) & (IData)(vlSelfRef.__VdfgRegularize_h787163e4_0_22)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_112 
        = (IData)(((7U == (7U & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst)) 
                   & (IData)(vlSelfRef.__VdfgRegularize_h787163e4_0_22)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_135 
        = (IData)(((0x8000000U == (0xc000000U & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst)) 
                   & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_60)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_61 
        = (IData)(((0U == (0xc000000U & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst)) 
                   & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_60)));
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__2529(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__2529\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.__VdfgRegularize_h36cfaf1a_0_124 = (IData)(
                                                         ((0U 
                                                           == 
                                                           (0x3800000U 
                                                            & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst)) 
                                                          & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT____VdfgRegularize_h51aa2a42_0_73)));
    vlSelfRef.__VdfgRegularize_h36cfaf1a_0_125 = ((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst 
                                                   >> 0x19U) 
                                                  & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT____VdfgRegularize_h51aa2a42_0_73));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_81 
        = (IData)(((0x1bU == (0x1fU & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst)) 
                   & (IData)(vlSelfRef.__VdfgRegularize_h787163e4_0_28)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_118 
        = (IData)(((0x1bU == (0x3fU & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst)) 
                   & (IData)(vlSelfRef.__VdfgRegularize_h787163e4_0_28)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_172 
        = (IData)(((0x2000053U == (0x3f0007fU & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst)) 
                   & (IData)(vlSelfRef.__VdfgRegularize_h787163e4_0_12)));
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__2530(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__2530\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_fp_ctrl_sqrt 
        = (IData)(((0x53U == (0x1f0007fU & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst)) 
                   & (IData)(vlSelfRef.__VdfgRegularize_h787163e4_0_12)));
    vlSelfRef.__VdfgRegularize_h787163e4_0_45 = ((~ 
                                                  (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst 
                                                   >> 0x1aU)) 
                                                 & (0xfU 
                                                    == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_243)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_244 
        = ((0x20U & ((~ (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst 
                         >> 0x1aU)) << 5U)) | ((0x10U 
                                                & ((~ 
                                                    (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst 
                                                     >> 0x1bU)) 
                                                   << 4U)) 
                                               | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_243)));
    vlSelfRef.__VdfgRegularize_h787163e4_0_29 = (IData)(
                                                        ((0x8000000U 
                                                          == 
                                                          (0xc000000U 
                                                           & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst)) 
                                                         & (0xfU 
                                                            == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_243))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_131 
        = (IData)(((3U == (0xfU & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst)) 
                   & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_107)));
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__2531(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__2531\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_88 
        = (IData)(((0xb805013U == (0xff0707fU & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst)) 
                   & (0xfU == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_253))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_254 
        = ((0x40U & ((~ (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst 
                         >> 0x19U)) << 6U)) | ((0x20U 
                                                & ((~ 
                                                    (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst 
                                                     >> 0x1aU)) 
                                                   << 5U)) 
                                               | ((0x10U 
                                                   & ((~ 
                                                       (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst 
                                                        >> 0x1bU)) 
                                                      << 4U)) 
                                                  | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_253))));
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__2532(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__2532\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_171 
        = (IData)(((0x2000053U == (0x200607fU & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst)) 
                   & (IData)(vlSelfRef.__VdfgRegularize_h787163e4_0_33)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_96 
        = (IData)(((0x53U == (0x607fU & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst)) 
                   & (IData)(vlSelfRef.__VdfgRegularize_h787163e4_0_33)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_159 
        = (IData)(((0x53U == (0x507fU & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst)) 
                   & (0x3fU == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_237))));
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__2533(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__2533\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.__VdfgRegularize_h787163e4_0_26 = ((~ 
                                                  (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst 
                                                   >> 0x19U)) 
                                                 & (0x3fU 
                                                    == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_237)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_is_amo 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_52) 
           | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_53));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_168 
        = (IData)(((0x2000053U == (0x200007fU & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst)) 
                   & (IData)(vlSelfRef.__VdfgRegularize_h787163e4_0_38)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_92 
        = (IData)(((0x53U == (0x7fU & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst)) 
                   & (IData)(vlSelfRef.__VdfgRegularize_h787163e4_0_38)));
    vlSelfRef.__VdfgRegularize_h787163e4_0_11 = ((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst 
                                                  >> 0x1bU) 
                                                 & (0xfU 
                                                    == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_226)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_227 
        = ((0x10U & ((~ (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst 
                         >> 0x1bU)) << 4U)) | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_226));
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__2534(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__2534\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.__VdfgRegularize_h787163e4_0_10 = ((~ 
                                                  (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst 
                                                   >> 0x1aU)) 
                                                 & (0xfU 
                                                    == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_214)));
    vlSelfRef.__VdfgRegularize_h787163e4_0_25 = (IData)(
                                                        ((0x8000000U 
                                                          == 
                                                          (0xc000000U 
                                                           & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst)) 
                                                         & (0xfU 
                                                            == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_214))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_215 
        = ((0x20U & ((~ (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst 
                         >> 0x1aU)) << 5U)) | ((0x10U 
                                                & ((~ 
                                                    (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst 
                                                     >> 0x1bU)) 
                                                   << 4U)) 
                                               | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_214)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT____VdfgRegularize_h9d2b670c_0_13 
        = (~ ((((((0x80000000U & ((IData)(1U) << (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__b2_uop_rob_idx))) 
                  | (0x40000000U & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_56)) 
                 | ((0x20000000U & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_57) 
                    | (0x10000000U & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_58))) 
                | (((0x8000000U & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_59) 
                    | (0x4000000U & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_60)) 
                   | ((0x2000000U & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_61) 
                      | (0x1000000U & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_62)))) 
               | ((((0x800000U & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_63) 
                    | (0x400000U & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_64)) 
                   | ((0x200000U & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_65) 
                      | (0x100000U & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_66))) 
                  | (((0x80000U & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_67) 
                      | (0x40000U & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_68)) 
                     | ((0x20000U & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_69) 
                        | (0x10000U & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_70))))) 
              | (((((0x8000U & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_71)) 
                    | (0x4000U & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_72))) 
                   | ((0x2000U & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_73)) 
                      | (0x1000U & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_74)))) 
                  | (((0x800U & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_75)) 
                      | (0x400U & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_76))) 
                     | ((0x200U & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_77)) 
                        | (0x100U & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_78))))) 
                 | ((((0x80U & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_79)) 
                      | (0x40U & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_80))) 
                     | ((0x20U & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_81)) 
                        | (0x10U & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_82)))) 
                    | (((8U & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_83)) 
                        | (4U & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_84))) 
                       | ((2U & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_85)) 
                          | (1U & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_85) 
                                   | (((IData)(1U) 
                                       << (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__b2_uop_rob_idx)) 
                                      >> 0x1fU)))))))));
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__2535(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__2535\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__issue_slots_7_in_uop_valid) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_7__DOT__slot_uop_rob_idx 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_tail;
    }
    if ((1U & (~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__pred_rename_stage__DOT___GEN_20)))) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rename_stage__DOT__r_uop_br_tag 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___dec_brmask_logic_io_br_tag_0;
    }
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT____VdfgRegularize_h94b53d93_0_308 
        = (1U & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__exe_tlb_miss_0) 
                 | ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___dtlb_io_resp_0_cacheable)) 
                    | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__ma_ld_0) 
                       | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__ae_ld_0) 
                          | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__pf_ld_0))))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f4_io_enq_bits_shadowable_mask_0 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT____VdfgRegularize_hce62b063_0_13) 
           & ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3_mask_0)) 
              | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___bpd_decoder_io_out_shadowable)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___GEN_42 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___GEN_41) 
           & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT____VdfgRegularize_hce62b063_0_36) 
              & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___f4_correct_f1_ghist_T_5)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___GEN_37 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___GEN_36) 
           & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT____VdfgRegularize_hce62b063_0_34) 
              & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___f4_correct_f2_ghist_T_5)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___GEN_44 
        = (((~ ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___f4_correct_f3_ghist_T_5) 
                & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT____VdfgRegularize_hce62b063_0_32))) 
            & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3__DOT__maybe_full)) 
           | (((~ ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___f4_correct_f2_ghist_T_5) 
                   & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT____VdfgRegularize_hce62b063_0_34))) 
               & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___GEN_36)) 
              | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___GEN_41) 
                 & ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__s1_valid)) 
                    | ((~ ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___f4_correct_f1_ghist_T_5) 
                           & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT____VdfgRegularize_hce62b063_0_36))) 
                       & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__s1_valid))))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___GEN_34 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3__DOT__maybe_full) 
           & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT____VdfgRegularize_hce62b063_0_32) 
              & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___f4_correct_f3_ghist_T_5)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__io_resp_f2_pc_REG 
        = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__io_resp_f1_pc_REG;
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT__io_resp_f2_3_is_jal_REG 
        = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT__s1_is_jal_3;
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__io_resp_f2_3_REG_is_jal 
        = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__s1_is_jal_3;
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT__REG_18 
        = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT__s1_hits_3;
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT__REG_20 
        = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT__s1_hits_3;
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___bpd_io_resp_f3_preds_3_predicted_pc_bits 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT__REG_21)
            ? vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT__io_resp_f3_3_predicted_pc_REG_bits
            : vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__io_resp_f3_3_REG_predicted_pc_bits);
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__2536(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__2536\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT__REG_21) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___bpd_io_resp_f3_preds_3_is_br 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT__io_resp_f3_3_is_br_REG;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___bpd_io_resp_f3_preds_3_predicted_pc_valid 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT__io_resp_f3_3_predicted_pc_REG_valid;
    } else {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___bpd_io_resp_f3_preds_3_is_br 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__io_resp_f3_3_REG_is_br;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___bpd_io_resp_f3_preds_3_predicted_pc_valid 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__io_resp_f3_3_REG_predicted_pc_valid;
    }
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT___btb_io_resp_f3_3_taken 
        = (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT__REG_21) 
            & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT__REG_23)) 
           | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__bim__DOT__io_resp_f3_3_taken_REG));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT__io_resp_f2_2_is_jal_REG 
        = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT__s1_is_jal_2;
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__io_resp_f2_2_REG_is_jal 
        = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__s1_is_jal_2;
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT__REG_12 
        = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT__s1_hits_2;
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT__io_resp_f2_1_is_jal_REG 
        = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT__s1_is_jal_1;
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__io_resp_f2_1_REG_is_jal 
        = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__s1_is_jal_1;
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT__REG_6 
        = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT__s1_hits_1;
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT__io_resp_f2_0_is_jal_REG 
        = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT__s1_is_jal_0;
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__io_resp_f2_0_REG_is_jal 
        = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__s1_is_jal_0;
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT__REG 
        = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT__s1_hits_0;
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT__REG_14 
        = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT__s1_hits_2;
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT__REG_15) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___bpd_io_resp_f3_preds_2_predicted_pc_bits 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT__io_resp_f3_2_predicted_pc_REG_bits;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___bpd_io_resp_f3_preds_2_is_br 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT__io_resp_f3_2_is_br_REG;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___bpd_io_resp_f3_preds_2_predicted_pc_valid 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT__io_resp_f3_2_predicted_pc_REG_valid;
    } else {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___bpd_io_resp_f3_preds_2_predicted_pc_bits 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__io_resp_f3_2_REG_predicted_pc_bits;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___bpd_io_resp_f3_preds_2_is_br 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__io_resp_f3_2_REG_is_br;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___bpd_io_resp_f3_preds_2_predicted_pc_valid 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__io_resp_f3_2_REG_predicted_pc_valid;
    }
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT___btb_io_resp_f3_2_taken 
        = (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT__REG_15) 
            & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT__REG_17)) 
           | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__bim__DOT__io_resp_f3_2_taken_REG));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT__REG_8 
        = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT__s1_hits_1;
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT__REG_9) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___bpd_io_resp_f3_preds_1_predicted_pc_bits 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT__io_resp_f3_1_predicted_pc_REG_bits;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___bpd_io_resp_f3_preds_1_is_br 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT__io_resp_f3_1_is_br_REG;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___bpd_io_resp_f3_preds_1_predicted_pc_valid 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT__io_resp_f3_1_predicted_pc_REG_valid;
    } else {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___bpd_io_resp_f3_preds_1_predicted_pc_bits 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__io_resp_f3_1_REG_predicted_pc_bits;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___bpd_io_resp_f3_preds_1_is_br 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__io_resp_f3_1_REG_is_br;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___bpd_io_resp_f3_preds_1_predicted_pc_valid 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__io_resp_f3_1_REG_predicted_pc_valid;
    }
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT___btb_io_resp_f3_1_taken 
        = (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT__REG_11) 
            & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT__REG_9)) 
           | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__bim__DOT__io_resp_f3_1_taken_REG));
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__2537(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__2537\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT__REG_2 
        = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT__s1_hits_0;
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT__REG_3) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___bpd_io_resp_f3_preds_0_predicted_pc_bits 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT__io_resp_f3_0_predicted_pc_REG_bits;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___bpd_io_resp_f3_preds_0_is_br 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT__io_resp_f3_0_is_br_REG;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___bpd_io_resp_f3_preds_0_predicted_pc_valid 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT__io_resp_f3_0_predicted_pc_REG_valid;
    } else {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___bpd_io_resp_f3_preds_0_predicted_pc_bits 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__io_resp_f3_0_REG_predicted_pc_bits;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___bpd_io_resp_f3_preds_0_is_br 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__io_resp_f3_0_REG_is_br;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___bpd_io_resp_f3_preds_0_predicted_pc_valid 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__io_resp_f3_0_REG_predicted_pc_valid;
    }
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT___btb_io_resp_f3_0_taken 
        = (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT__REG_3) 
            & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT__REG_5)) 
           | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__bim__DOT__io_resp_f3_0_taken_REG));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_197 
        = ((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst 
            >> 0xeU) & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_196));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_109 
        = ((IData)(((0x53U == (0x1dc0007fU & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst)) 
                    & (7U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_262)))) 
           | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_100));
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__2538(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__2538\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_184 
        = (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_99) 
            << 2U) | (((IData)(((0x53U == (0xdf0707fU 
                                           & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst)) 
                                & (7U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_264)))) 
                       << 1U) | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_100)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_204 
        = (IData)(((0x2004000U == (0x2004000U & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst)) 
                   & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_135)));
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__2539(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__2539\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_201 
        = ((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst 
            >> 0xeU) & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_61));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_62 
        = ((~ (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst 
               >> 0x19U)) & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_61));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_89 
        = ((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst 
            >> 0x19U) & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_61));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_205 
        = (IData)(((0x5013U == (0x707fU & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst)) 
                   & (IData)(vlSelfRef.__VdfgRegularize_h787163e4_0_45)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_206 
        = (IData)(((0x5033U == (0x200707fU & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst)) 
                   & (IData)(vlSelfRef.__VdfgRegularize_h787163e4_0_45)));
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__2540(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__2540\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_161 
        = (IData)(((0x2000053U == (0x3f0007fU & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst)) 
                   & (0x3fU == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_244))));
    vlSelfRef.__VdfgRegularize_h787163e4_0_34 = ((~ 
                                                  (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst 
                                                   >> 0x19U)) 
                                                 & (0x3fU 
                                                    == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_244)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_83 
        = (IData)(((0x1033U == (0x200307fU & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst)) 
                   & (IData)(vlSelfRef.__VdfgRegularize_h787163e4_0_29)));
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__2541(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__2541\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_82 
        = (IData)(((0x1013U == (0x307fU & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst)) 
                   & (IData)(vlSelfRef.__VdfgRegularize_h787163e4_0_29)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_87 
        = (IData)(((0x1033U == (0x3077U & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst)) 
                   & (0x7fU == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_254))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_255 
        = ((0x100U & ((~ (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst 
                          >> 0x17U)) << 8U)) | ((0x80U 
                                                 & ((~ 
                                                     (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst 
                                                      >> 0x18U)) 
                                                    << 7U)) 
                                                | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_254)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_121 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_94) 
           | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_95) 
              | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_96)));
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__2542(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__2542\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_75 
        = (IData)(((0x2033U == (0x3077U & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst)) 
                   & (IData)(vlSelfRef.__VdfgRegularize_h787163e4_0_26)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_76 
        = (IData)(((0x4033U == (0x5077U & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst)) 
                   & (IData)(vlSelfRef.__VdfgRegularize_h787163e4_0_26)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_fu_code_2 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_133) 
           | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_is_amo));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_fp_ctrl_div 
        = (IData)(((0x53U == (0x400007fU & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst)) 
                   & (IData)(vlSelfRef.__VdfgRegularize_h787163e4_0_11)));
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__2543(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__2543\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_137 
        = (IData)(((0x202fU == (0x607fU & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst)) 
                   & (IData)(vlSelfRef.__VdfgRegularize_h787163e4_0_11)));
    vlSelfRef.__VdfgRegularize_h787163e4_0_17 = (IData)(
                                                        ((0U 
                                                          == 
                                                          (0x1f00000U 
                                                           & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst)) 
                                                         & (0x1fU 
                                                            == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_227))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_230 
        = ((0x20U & ((~ (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst 
                         >> 0x1aU)) << 5U)) | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_227));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_fp_ctrl_swap23 
        = (IData)(((0x53U == (0x7fU & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst)) 
                   & (IData)(vlSelfRef.__VdfgRegularize_h787163e4_0_10)));
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__2544(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__2544\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_63 
        = (IData)(((0x3bU == (0x200707fU & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst)) 
                   & (IData)(vlSelfRef.__VdfgRegularize_h787163e4_0_10)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_181 
        = (IData)(((0x2004033U == (0x200407fU & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst)) 
                   & (IData)(vlSelfRef.__VdfgRegularize_h787163e4_0_10)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_74 
        = (IData)(((0x2004033U == (0x200407fU & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst)) 
                   & (IData)(vlSelfRef.__VdfgRegularize_h787163e4_0_25)));
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__2545(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__2545\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_72 
        = (IData)(((0x101bU == (0x707fU & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst)) 
                   & (IData)(vlSelfRef.__VdfgRegularize_h787163e4_0_25)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_73 
        = (IData)(((0x403bU == (0x3f0707fU & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst)) 
                   & (IData)(vlSelfRef.__VdfgRegularize_h787163e4_0_25)));
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__2546(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__2546\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_179 
        = (IData)(((0x33U == (0x7077U & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst)) 
                   & (0x3fU == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_215))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_178 
        = (IData)(((0x33U == (0x7fU & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst)) 
                   & (0x3fU == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_215))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_fu_code_4 
        = (IData)(((0x2004033U == (0x2004077U & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst)) 
                   & (0x3fU == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_215))));
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__2547(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__2547\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.__VdfgRegularize_h787163e4_0_23 = (IData)(
                                                        ((0x1000U 
                                                          == 
                                                          (0x3040U 
                                                           & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst)) 
                                                         & (0x3fU 
                                                            == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_215))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_219 
        = ((0x40U & ((~ (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst 
                         >> 0x19U)) << 6U)) | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_215));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__brupdate_b2_rob_clr_oh 
        = (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__b2_uop_rob_idx) 
            < (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_head))
            ? (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT____VdfgRegularize_h9d2b670c_0_13 
               & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT____VdfgRegularize_h9d2b670c_0_14)
            : (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT____VdfgRegularize_h9d2b670c_0_13 
               | vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT____VdfgRegularize_h9d2b670c_0_14));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_tail 
        = vlSelfRef.__Vdly__TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_tail;
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___dec_brmask_logic_io_br_tag_0 
        = ((1U & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__dec_brmask_logic__DOT__branch_mask))
            ? ((2U & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__dec_brmask_logic__DOT__branch_mask))
                ? ((4U & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__dec_brmask_logic__DOT__branch_mask))
                    ? ((8U & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__dec_brmask_logic__DOT__branch_mask))
                        ? ((0x10U & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__dec_brmask_logic__DOT__branch_mask))
                            ? ((0x20U & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__dec_brmask_logic__DOT__branch_mask))
                                ? ((0x40U & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__dec_brmask_logic__DOT__branch_mask))
                                    ? (7U & (- (IData)(
                                                       (1U 
                                                        & (~ 
                                                           ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__dec_brmask_logic__DOT__branch_mask) 
                                                            >> 7U))))))
                                    : 6U) : 5U) : 4U)
                        : 3U) : 2U) : 1U) : 0U);
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__s0_kills_0 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__will_fire_load_agen_exec_0)
            ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT____VdfgRegularize_h94b53d93_0_308)
            : ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__will_fire_load_retry_0_will_fire) 
               & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT____VdfgRegularize_h94b53d93_0_308)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___GEN_35 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f4__DOT__maybe_full) 
           & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___GEN_34));
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__2548(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__2548\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___GEN_40 
        = (1U & ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f4__DOT__maybe_full)) 
                 | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___GEN_34)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___GEN_43 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___GEN_34) 
           | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___GEN_37));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__s1_is_jal_3 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__s1_hit) 
           & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__s1_hit_meta_jal_mask) 
              >> 3U));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT__s1_hits_3 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT__s1_hit_ohs_3_0) 
           | ((0x3fffffffU & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT__btb_meta_way_1__DOT__btb_meta_way_1_ext__DOT__mem_0_3__DOT__ram
               [vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT__btb_meta_way_1__DOT__btb_meta_way_1_ext__DOT__mem_0_3__DOT__ram_R_0_addr_pipe_0]) 
              == (0x3fffffffU & (IData)((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT__s1_idx 
                                         >> 7U)))));
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3_bpd_queue__DOT__maybe_full) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___f3_bpd_queue_io_deq_bits_preds_3_predicted_pc_bits 
            = (0xffffffffffULL & (((QData)((IData)(
                                                   vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3_bpd_queue__DOT__ram[9U])) 
                                   << 0x23U) | (((QData)((IData)(
                                                                 vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3_bpd_queue__DOT__ram[8U])) 
                                                 << 3U) 
                                                | ((QData)((IData)(
                                                                   vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3_bpd_queue__DOT__ram[7U])) 
                                                   >> 0x1dU))));
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___f3_bpd_queue_io_deq_bits_preds_3_is_br 
            = (1U & (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3_bpd_queue__DOT__ram[9U] 
                     >> 7U));
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___f3_bpd_queue_io_deq_bits_preds_3_predicted_pc_valid 
            = (1U & (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3_bpd_queue__DOT__ram[9U] 
                     >> 5U));
    } else {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___f3_bpd_queue_io_deq_bits_preds_3_predicted_pc_bits 
            = (0xffffffffffULL & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___bpd_io_resp_f3_preds_3_predicted_pc_bits);
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___f3_bpd_queue_io_deq_bits_preds_3_is_br 
            = (1U & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___bpd_io_resp_f3_preds_3_is_br));
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___f3_bpd_queue_io_deq_bits_preds_3_predicted_pc_valid 
            = (1U & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___bpd_io_resp_f3_preds_3_predicted_pc_valid));
    }
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT___tage_io_resp_f3_3_taken 
        = (1U & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__s3_provided_3)
                  ? (((3U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__prov_3_ctr)) 
                      | (4U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__prov_3_ctr)))
                      ? ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__s3_alt_provided_3)
                          ? ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__alt_3_ctr) 
                             >> 2U) : (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT___btb_io_resp_f3_3_taken))
                      : ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__prov_3_ctr) 
                         >> 2U)) : (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT___btb_io_resp_f3_3_taken)));
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__2549(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__2549\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__s1_is_jal_2 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__s1_hit) 
           & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__s1_hit_meta_jal_mask) 
              >> 2U));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__s1_is_jal_1 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__s1_hit) 
           & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__s1_hit_meta_jal_mask) 
              >> 1U));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__s1_is_jal_0 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__s1_hit) 
           & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__s1_hit_meta_jal_mask));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT__s1_hits_2 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT__s1_hit_ohs_2_0) 
           | ((0x3fffffffU & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT__btb_meta_way_1__DOT__btb_meta_way_1_ext__DOT__mem_0_2__DOT__ram
               [vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT__btb_meta_way_1__DOT__btb_meta_way_1_ext__DOT__mem_0_2__DOT__ram_R_0_addr_pipe_0]) 
              == (0x3fffffffU & (IData)((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT__s1_idx 
                                         >> 7U)))));
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3_bpd_queue__DOT__maybe_full) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___f3_bpd_queue_io_deq_bits_preds_2_predicted_pc_bits 
            = (0xffffffffffULL & (((QData)((IData)(
                                                   vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3_bpd_queue__DOT__ram[7U])) 
                                   << 0x2fU) | (((QData)((IData)(
                                                                 vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3_bpd_queue__DOT__ram[7U])) 
                                                 << 0xfU) 
                                                | ((QData)((IData)(
                                                                   vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3_bpd_queue__DOT__ram[6U])) 
                                                   >> 0x11U))));
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___f3_bpd_queue_io_deq_bits_preds_2_is_br 
            = (1U & (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3_bpd_queue__DOT__ram[7U] 
                     >> 0x1bU));
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___f3_bpd_queue_io_deq_bits_preds_2_predicted_pc_valid 
            = (1U & (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3_bpd_queue__DOT__ram[7U] 
                     >> 0x19U));
    } else {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___f3_bpd_queue_io_deq_bits_preds_2_predicted_pc_bits 
            = (0xffffffffffULL & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___bpd_io_resp_f3_preds_2_predicted_pc_bits);
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___f3_bpd_queue_io_deq_bits_preds_2_is_br 
            = (1U & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___bpd_io_resp_f3_preds_2_is_br));
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___f3_bpd_queue_io_deq_bits_preds_2_predicted_pc_valid 
            = (1U & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___bpd_io_resp_f3_preds_2_predicted_pc_valid));
    }
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT___tage_io_resp_f3_2_taken 
        = (1U & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__s3_provided_2)
                  ? (((3U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__prov_2_ctr)) 
                      | (4U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__prov_2_ctr)))
                      ? ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__s3_alt_provided_2)
                          ? ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__alt_2_ctr) 
                             >> 2U) : (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT___btb_io_resp_f3_2_taken))
                      : ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__prov_2_ctr) 
                         >> 2U)) : (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT___btb_io_resp_f3_2_taken)));
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__2550(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__2550\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT__s1_hits_1 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT__s1_hit_ohs_1_0) 
           | ((0x3fffffffU & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT__btb_meta_way_1__DOT__btb_meta_way_1_ext__DOT__mem_0_1__DOT__ram
               [vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT__btb_meta_way_1__DOT__btb_meta_way_1_ext__DOT__mem_0_1__DOT__ram_R_0_addr_pipe_0]) 
              == (0x3fffffffU & (IData)((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT__s1_idx 
                                         >> 7U)))));
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3_bpd_queue__DOT__maybe_full) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___f3_bpd_queue_io_deq_bits_preds_1_predicted_pc_bits 
            = (0xffffffffffULL & (((QData)((IData)(
                                                   vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3_bpd_queue__DOT__ram[6U])) 
                                   << 0x3bU) | (((QData)((IData)(
                                                                 vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3_bpd_queue__DOT__ram[6U])) 
                                                 << 0x1bU) 
                                                | ((QData)((IData)(
                                                                   vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3_bpd_queue__DOT__ram[5U])) 
                                                   >> 5U))));
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___f3_bpd_queue_io_deq_bits_preds_1_is_br 
            = (1U & (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3_bpd_queue__DOT__ram[6U] 
                     >> 0xfU));
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___f3_bpd_queue_io_deq_bits_preds_1_predicted_pc_valid 
            = (1U & (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3_bpd_queue__DOT__ram[6U] 
                     >> 0xdU));
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___f3_bpd_queue_io_deq_bits_preds_0_predicted_pc_bits 
            = (0xffffffffffULL & (((QData)((IData)(
                                                   vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3_bpd_queue__DOT__ram[5U])) 
                                   << 0x27U) | (((QData)((IData)(
                                                                 vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3_bpd_queue__DOT__ram[4U])) 
                                                 << 7U) 
                                                | ((QData)((IData)(
                                                                   vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3_bpd_queue__DOT__ram[3U])) 
                                                   >> 0x19U))));
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___f3_bpd_queue_io_deq_bits_preds_0_is_br 
            = (1U & (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3_bpd_queue__DOT__ram[5U] 
                     >> 3U));
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___f3_bpd_queue_io_deq_bits_preds_0_predicted_pc_valid 
            = (1U & (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3_bpd_queue__DOT__ram[5U] 
                     >> 1U));
    } else {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___f3_bpd_queue_io_deq_bits_preds_1_predicted_pc_bits 
            = (0xffffffffffULL & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___bpd_io_resp_f3_preds_1_predicted_pc_bits);
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___f3_bpd_queue_io_deq_bits_preds_1_is_br 
            = (1U & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___bpd_io_resp_f3_preds_1_is_br));
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___f3_bpd_queue_io_deq_bits_preds_1_predicted_pc_valid 
            = (1U & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___bpd_io_resp_f3_preds_1_predicted_pc_valid));
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___f3_bpd_queue_io_deq_bits_preds_0_predicted_pc_bits 
            = (0xffffffffffULL & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___bpd_io_resp_f3_preds_0_predicted_pc_bits);
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___f3_bpd_queue_io_deq_bits_preds_0_is_br 
            = (1U & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___bpd_io_resp_f3_preds_0_is_br));
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___f3_bpd_queue_io_deq_bits_preds_0_predicted_pc_valid 
            = (1U & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___bpd_io_resp_f3_preds_0_predicted_pc_valid));
    }
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT___tage_io_resp_f3_1_taken 
        = (1U & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__s3_provided_1)
                  ? (((3U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__prov_1_ctr)) 
                      | (4U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__prov_1_ctr)))
                      ? ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__s3_alt_provided_1)
                          ? ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__alt_1_ctr) 
                             >> 2U) : (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT___btb_io_resp_f3_1_taken))
                      : ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__prov_1_ctr) 
                         >> 2U)) : (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT___btb_io_resp_f3_1_taken)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT__s1_hits_0 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT__s1_hit_ohs_0_0) 
           | ((0x3fffffffU & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT__btb_meta_way_1__DOT__btb_meta_way_1_ext__DOT__mem_0_0__DOT__ram
               [vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT__btb_meta_way_1__DOT__btb_meta_way_1_ext__DOT__mem_0_0__DOT__ram_R_0_addr_pipe_0]) 
              == (0x3fffffffU & (IData)((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT__s1_idx 
                                         >> 7U)))));
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__2551(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__2551\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT___tage_io_resp_f3_0_taken 
        = (1U & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__s3_provided)
                  ? (((3U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__prov_ctr)) 
                      | (4U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__prov_ctr)))
                      ? ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__s3_alt_provided)
                          ? ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__alt_ctr) 
                             >> 2U) : (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT___btb_io_resp_f3_0_taken))
                      : ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__prov_ctr) 
                         >> 2U)) : (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT___btb_io_resp_f3_0_taken)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_198 
        = ((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst 
            >> 0xdU) & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_197));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_fp_ctrl_toint 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_162) 
           | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_163) 
              | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_109)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_fp_ctrl_ren1 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_fp_ctrl_ren3) 
           | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_92) 
              | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_94) 
                 | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_95) 
                    | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_96) 
                       | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_97) 
                          | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_98) 
                             | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_fp_ctrl_sqrt) 
                                | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_109)))))))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_fp_val 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_91) 
           | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_92) 
              | ((IData)(((7U == (0x1fU & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst)) 
                          & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_93))) 
                 | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_94) 
                    | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_95) 
                       | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_96) 
                          | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_97) 
                             | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_98) 
                                | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_fp_ctrl_sqrt) 
                                   | (0U != (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_184)))))))))));
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__2552(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__2552\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_90 
        = ((~ (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst 
               >> 0xeU)) & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_89));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_203 
        = ((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst 
            >> 0xeU) & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_89));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_199 
        = (IData)(((0x33U == (0x7077U & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst)) 
                   & (IData)(vlSelfRef.__VdfgRegularize_h787163e4_0_34)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_160 
        = (IData)(((0x100053U == (0x1f0007fU & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst)) 
                   & (IData)(vlSelfRef.__VdfgRegularize_h787163e4_0_34)));
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__2553(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__2553\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.__VdfgRegularize_h787163e4_0_30 = ((~ 
                                                  (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst 
                                                   >> 0x15U)) 
                                                 & (0x1ffU 
                                                    == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_255)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_257 
        = ((0x200U & ((~ (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst 
                          >> 0x16U)) << 9U)) | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_255));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_182 
        = (IData)(((0x202fU == (0x607fU & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst)) 
                   & (IData)(vlSelfRef.__VdfgRegularize_h787163e4_0_17)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_117 
        = (IData)(((0x2fU == (0x7fU & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst)) 
                   & (IData)(vlSelfRef.__VdfgRegularize_h787163e4_0_17)));
    vlSelfRef.__VdfgRegularize_h787163e4_0_20 = ((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst 
                                                  >> 0x19U) 
                                                 & (0x3fU 
                                                    == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_230)));
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__2554(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__2554\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_106 
        = (IData)(((0x500070U == (0x3fffff0U & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst)) 
                   & (0x3fU == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_230))));
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__2555(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__2555\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_180 
        = (IData)(((0x13U == (0x1fU & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst)) 
                   & (IData)(vlSelfRef.__VdfgRegularize_h787163e4_0_23)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_67 
        = (IData)(((0x13U == (0x3fU & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst)) 
                   & (IData)(vlSelfRef.__VdfgRegularize_h787163e4_0_23)));
    vlSelfRef.__VdfgRegularize_h787163e4_0_24 = (IData)(
                                                        ((0x1000U 
                                                          == 
                                                          (0x3040U 
                                                           & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst)) 
                                                         & (0x7fU 
                                                            == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_219))));
    vlSelfRef.__VdfgRegularize_h787163e4_0_18 = (IData)(
                                                        ((0x70U 
                                                          == 
                                                          (0x1effff0U 
                                                           & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst)) 
                                                         & (0x7fU 
                                                            == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_219))));
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__2556(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__2556\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_86 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__b2_mispredict) 
           & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__brupdate_b2_rob_clr_oh);
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_87 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__b2_mispredict) 
           & (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__brupdate_b2_rob_clr_oh 
              >> 1U));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_88 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__b2_mispredict) 
           & (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__brupdate_b2_rob_clr_oh 
              >> 2U));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_89 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__b2_mispredict) 
           & (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__brupdate_b2_rob_clr_oh 
              >> 3U));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_90 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__b2_mispredict) 
           & (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__brupdate_b2_rob_clr_oh 
              >> 4U));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_91 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__b2_mispredict) 
           & (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__brupdate_b2_rob_clr_oh 
              >> 5U));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_92 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__b2_mispredict) 
           & (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__brupdate_b2_rob_clr_oh 
              >> 6U));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_93 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__b2_mispredict) 
           & (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__brupdate_b2_rob_clr_oh 
              >> 7U));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_94 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__b2_mispredict) 
           & (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__brupdate_b2_rob_clr_oh 
              >> 8U));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_95 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__b2_mispredict) 
           & (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__brupdate_b2_rob_clr_oh 
              >> 9U));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_96 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__b2_mispredict) 
           & (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__brupdate_b2_rob_clr_oh 
              >> 0xaU));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_97 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__b2_mispredict) 
           & (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__brupdate_b2_rob_clr_oh 
              >> 0xbU));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_98 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__b2_mispredict) 
           & (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__brupdate_b2_rob_clr_oh 
              >> 0xcU));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_99 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__b2_mispredict) 
           & (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__brupdate_b2_rob_clr_oh 
              >> 0xdU));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_100 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__b2_mispredict) 
           & (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__brupdate_b2_rob_clr_oh 
              >> 0xeU));
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__2557(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__2557\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_101 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__b2_mispredict) 
           & (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__brupdate_b2_rob_clr_oh 
              >> 0xfU));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_102 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__b2_mispredict) 
           & (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__brupdate_b2_rob_clr_oh 
              >> 0x10U));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_103 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__b2_mispredict) 
           & (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__brupdate_b2_rob_clr_oh 
              >> 0x11U));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_104 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__b2_mispredict) 
           & (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__brupdate_b2_rob_clr_oh 
              >> 0x12U));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_105 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__b2_mispredict) 
           & (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__brupdate_b2_rob_clr_oh 
              >> 0x13U));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_106 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__b2_mispredict) 
           & (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__brupdate_b2_rob_clr_oh 
              >> 0x14U));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_107 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__b2_mispredict) 
           & (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__brupdate_b2_rob_clr_oh 
              >> 0x15U));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_108 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__b2_mispredict) 
           & (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__brupdate_b2_rob_clr_oh 
              >> 0x16U));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_109 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__b2_mispredict) 
           & (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__brupdate_b2_rob_clr_oh 
              >> 0x17U));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_110 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__b2_mispredict) 
           & (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__brupdate_b2_rob_clr_oh 
              >> 0x18U));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_111 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__b2_mispredict) 
           & (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__brupdate_b2_rob_clr_oh 
              >> 0x19U));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_112 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__b2_mispredict) 
           & (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__brupdate_b2_rob_clr_oh 
              >> 0x1aU));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_113 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__b2_mispredict) 
           & (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__brupdate_b2_rob_clr_oh 
              >> 0x1bU));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_114 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__b2_mispredict) 
           & (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__brupdate_b2_rob_clr_oh 
              >> 0x1cU));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_115 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__b2_mispredict) 
           & (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__brupdate_b2_rob_clr_oh 
              >> 0x1dU));
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__2558(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__2558\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_116 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__b2_mispredict) 
           & (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__brupdate_b2_rob_clr_oh 
              >> 0x1eU));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_117 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__b2_mispredict) 
           & (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__brupdate_b2_rob_clr_oh 
              >> 0x1fU));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_0 
        = (1U & (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN 
                 >> (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_tail)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___do_inc_row_T_1 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_pnr) 
           == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_tail));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__full 
        = ((0x1fU & ((IData)(1U) + (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_tail))) 
           == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_head));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___empty_T 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_head) 
           == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_tail));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___s0_executing_loads_T_1 
        = ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__s0_kills_0)) 
           & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dmem_req_fire_0));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f4_io_enq_bits_ghist_ras_idx 
        = (0x1fU & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___GEN_35)
                     ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f4_decoded_ghist_ras_idx)
                     : ((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3__DOT__ram[1U] 
                         << 0x1dU) | (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3__DOT__ram[1U] 
                                      >> 3U))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___GEN_38 
        = (1U & ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___GEN_37)) 
                 | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___GEN_40)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___GEN_54 
        = (1U & ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f4__DOT__maybe_full)) 
                 | ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___GEN_42)) 
                    | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___GEN_43))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___GEN_45 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___GEN_43) 
           | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___GEN_42));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__io_resp_f1_pc_REG 
        = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT____Vcellinp__bpd__io_f0_req_bits_pc;
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___bpd_io_resp_f1_preds_3_taken 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__s1_hit) 
           & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__s1_is_jal_3) 
              | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__s1_hit_meta_ctr)));
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT__REG_18) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___bpd_io_resp_f2_preds_3_predicted_pc_bits 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT__io_resp_f2_3_predicted_pc_REG_bits;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___bpd_io_resp_f2_preds_3_is_br 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT__io_resp_f2_3_is_br_REG;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___bpd_io_resp_f2_preds_3_predicted_pc_valid 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT__io_resp_f2_3_predicted_pc_REG_valid;
    } else {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___bpd_io_resp_f2_preds_3_predicted_pc_bits 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__io_resp_f2_3_REG_predicted_pc_bits;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___bpd_io_resp_f2_preds_3_is_br 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__io_resp_f2_3_REG_is_br;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___bpd_io_resp_f2_preds_3_predicted_pc_valid 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__io_resp_f2_3_REG_predicted_pc_valid;
    }
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___bpd_io_resp_f2_preds_3_taken 
        = (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT__REG_18) 
            & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT__REG_19)) 
           | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT___bim_io_resp_f2_3_taken));
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__2559(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__2559\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT__s1_resp_3_valid 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT____VdfgRegularize_h60a99628_0_5) 
           & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT__s1_hits_3));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3_btb_mispredicts_3 
        = ((2U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___bpd_decoder_3_io_out_cfi_type)) 
           & ((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3__DOT__ram[3U] 
               >> 0x12U) & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___f3_bpd_queue_io_deq_bits_preds_3_predicted_pc_valid) 
                            & (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___f3_bpd_queue_io_deq_bits_preds_3_predicted_pc_bits 
                               != vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___bpd_decoder_3_io_out_target))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___bpd_io_resp_f3_preds_3_taken 
        = ((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__loop__DOT__columns_3__DOT__f3_entry_tag) 
             == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__loop__DOT__columns_3__DOT__f3_tag)) 
            & (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__loop__DOT___columns_3_io_f3_meta_s_cnt) 
                == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__loop__DOT__columns_3__DOT__f3_entry_p_cnt)) 
               & (7U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__loop__DOT__columns_3__DOT__f3_entry_conf)))) 
           ^ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT___tage_io_resp_f3_3_taken));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___bpd_io_resp_f1_preds_2_taken 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__s1_hit) 
           & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__s1_is_jal_2) 
              | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__s1_hit_meta_ctr)));
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT__REG_12) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___bpd_io_resp_f2_preds_2_predicted_pc_bits 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT__io_resp_f2_2_predicted_pc_REG_bits;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___bpd_io_resp_f2_preds_2_is_br 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT__io_resp_f2_2_is_br_REG;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___bpd_io_resp_f2_preds_2_predicted_pc_valid 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT__io_resp_f2_2_predicted_pc_REG_valid;
    } else {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___bpd_io_resp_f2_preds_2_predicted_pc_bits 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__io_resp_f2_2_REG_predicted_pc_bits;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___bpd_io_resp_f2_preds_2_is_br 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__io_resp_f2_2_REG_is_br;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___bpd_io_resp_f2_preds_2_predicted_pc_valid 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__io_resp_f2_2_REG_predicted_pc_valid;
    }
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___bpd_io_resp_f2_preds_2_taken 
        = (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT__REG_12) 
            & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT__REG_13)) 
           | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT___bim_io_resp_f2_2_taken));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___bpd_io_resp_f1_preds_1_taken 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__s1_hit) 
           & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__s1_is_jal_1) 
              | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__s1_hit_meta_ctr)));
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT__REG_6) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___bpd_io_resp_f2_preds_1_predicted_pc_bits 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT__io_resp_f2_1_predicted_pc_REG_bits;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___bpd_io_resp_f2_preds_1_is_br 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT__io_resp_f2_1_is_br_REG;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___bpd_io_resp_f2_preds_1_predicted_pc_valid 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT__io_resp_f2_1_predicted_pc_REG_valid;
    } else {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___bpd_io_resp_f2_preds_1_predicted_pc_bits 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__io_resp_f2_1_REG_predicted_pc_bits;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___bpd_io_resp_f2_preds_1_is_br 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__io_resp_f2_1_REG_is_br;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___bpd_io_resp_f2_preds_1_predicted_pc_valid 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__io_resp_f2_1_REG_predicted_pc_valid;
    }
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___bpd_io_resp_f2_preds_1_taken 
        = (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT__REG_6) 
            & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT__REG_7)) 
           | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT___bim_io_resp_f2_1_taken));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___bpd_io_resp_f1_preds_0_taken 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__s1_hit) 
           & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__s1_is_jal_0) 
              | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__s1_hit_meta_ctr)));
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__2560(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__2560\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT__REG) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___bpd_io_resp_f2_preds_0_predicted_pc_bits 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT__io_resp_f2_0_predicted_pc_REG_bits;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___bpd_io_resp_f2_preds_0_is_br 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT__io_resp_f2_0_is_br_REG;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___bpd_io_resp_f2_preds_0_predicted_pc_valid 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT__io_resp_f2_0_predicted_pc_REG_valid;
    } else {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___bpd_io_resp_f2_preds_0_predicted_pc_bits 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__io_resp_f2_0_REG_predicted_pc_bits;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___bpd_io_resp_f2_preds_0_is_br 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__io_resp_f2_0_REG_is_br;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___bpd_io_resp_f2_preds_0_predicted_pc_valid 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__io_resp_f2_0_REG_predicted_pc_valid;
    }
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___bpd_io_resp_f2_preds_0_taken 
        = (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT__REG) 
            & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT__REG_1)) 
           | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT___bim_io_resp_f2_0_taken));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT__s1_resp_2_valid 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT____VdfgRegularize_h60a99628_0_5) 
           & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT__s1_hits_2));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3_btb_mispredicts_2 
        = ((2U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___bpd_decoder_2_io_out_cfi_type)) 
           & ((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3__DOT__ram[3U] 
               >> 0x11U) & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___f3_bpd_queue_io_deq_bits_preds_2_predicted_pc_valid) 
                            & (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___f3_bpd_queue_io_deq_bits_preds_2_predicted_pc_bits 
                               != vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___bpd_decoder_2_io_out_target))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___bpd_io_resp_f3_preds_2_taken 
        = ((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__loop__DOT__columns_2__DOT__f3_entry_tag) 
             == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__loop__DOT__columns_2__DOT__f3_tag)) 
            & (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__loop__DOT___columns_2_io_f3_meta_s_cnt) 
                == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__loop__DOT__columns_2__DOT__f3_entry_p_cnt)) 
               & (7U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__loop__DOT__columns_2__DOT__f3_entry_conf)))) 
           ^ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT___tage_io_resp_f3_2_taken));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT__s1_resp_1_valid 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT____VdfgRegularize_h60a99628_0_5) 
           & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT__s1_hits_1));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3_btb_mispredicts_1 
        = ((2U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___bpd_decoder_1_io_out_cfi_type)) 
           & ((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3__DOT__ram[3U] 
               >> 0x10U) & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___f3_bpd_queue_io_deq_bits_preds_1_predicted_pc_valid) 
                            & (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___f3_bpd_queue_io_deq_bits_preds_1_predicted_pc_bits 
                               != vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___bpd_decoder_1_io_out_target))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___bpd_io_resp_f3_preds_1_taken 
        = ((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__loop__DOT__columns_1__DOT__f3_entry_tag) 
             == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__loop__DOT__columns_1__DOT__f3_tag)) 
            & (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__loop__DOT___columns_1_io_f3_meta_s_cnt) 
                == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__loop__DOT__columns_1__DOT__f3_entry_p_cnt)) 
               & (7U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__loop__DOT__columns_1__DOT__f3_entry_conf)))) 
           ^ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT___tage_io_resp_f3_1_taken));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT__s1_resp_0_valid 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT____VdfgRegularize_h60a99628_0_5) 
           & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT__s1_hits_0));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3_btb_mispredicts_0 
        = ((2U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___bpd_decoder_io_out_cfi_type)) 
           & ((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3__DOT__ram[3U] 
               >> 0xfU) & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___f3_bpd_queue_io_deq_bits_preds_0_predicted_pc_valid) 
                           & (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___f3_bpd_queue_io_deq_bits_preds_0_predicted_pc_bits 
                              != vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___bpd_decoder_io_out_target))));
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__2561(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__2561\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.__VdfgRegularize_h36cfaf1a_0_195 = (((QData)((IData)(
                                                                   (((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__s3_provided_3) 
                                                                       << 0x17U) 
                                                                      | (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__s3_provider_3) 
                                                                          << 0x14U) 
                                                                         | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__s3_provided_2) 
                                                                            << 0x13U))) 
                                                                     | (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__s3_provider_2) 
                                                                         << 0x10U) 
                                                                        | (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__s3_provided_1) 
                                                                            << 0xfU) 
                                                                           | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__s3_provider_1) 
                                                                              << 0xcU)))) 
                                                                    | ((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__s3_provided) 
                                                                         << 0xbU) 
                                                                        | (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__s3_provider) 
                                                                            << 8U) 
                                                                           | ((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__s3_alt_provided_3) 
                                                                                & ((1U 
                                                                                & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__alt_3_ctr) 
                                                                                >> 2U)) 
                                                                                != (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT___tage_io_resp_f3_3_taken))) 
                                                                               << 7U) 
                                                                              | (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__s3_alt_provided_2) 
                                                                                & ((1U 
                                                                                & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__alt_2_ctr) 
                                                                                >> 2U)) 
                                                                                != (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT___tage_io_resp_f3_2_taken))) 
                                                                                << 6U)))) 
                                                                       | (((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__s3_alt_provided_1) 
                                                                             & ((1U 
                                                                                & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__alt_1_ctr) 
                                                                                >> 2U)) 
                                                                                != (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT___tage_io_resp_f3_1_taken))) 
                                                                            << 5U) 
                                                                           | (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__s3_alt_provided) 
                                                                               & ((1U 
                                                                                & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__alt_ctr) 
                                                                                >> 2U)) 
                                                                                != (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT___tage_io_resp_f3_0_taken))) 
                                                                              << 4U)) 
                                                                          | (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__prov_3_u) 
                                                                              << 2U) 
                                                                             | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__prov_2_u))))))) 
                                                   << 0x20U) 
                                                  | (QData)((IData)(
                                                                    (((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__prov_1_u) 
                                                                        << 0x1eU) 
                                                                       | (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__prov_u) 
                                                                           << 0x1cU) 
                                                                          | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__prov_3_ctr) 
                                                                             << 0x19U))) 
                                                                      | (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__prov_2_ctr) 
                                                                          << 0x16U) 
                                                                         | (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__prov_1_ctr) 
                                                                             << 0x13U) 
                                                                            | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__prov_ctr) 
                                                                               << 0x10U)))) 
                                                                     | (((((0U 
                                                                            != (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT___GEN_25)) 
                                                                           << 0xfU) 
                                                                          | (((1U 
                                                                               & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT___GEN_25) 
                                                                                >> (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__masked_entry_3)))
                                                                               ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__masked_entry_3)
                                                                               : 
                                                                              ((1U 
                                                                                & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT___GEN_25))
                                                                                ? 0U
                                                                                : 
                                                                               ((2U 
                                                                                & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT___GEN_25))
                                                                                 ? 1U
                                                                                 : 
                                                                                ((4U 
                                                                                & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT___GEN_25))
                                                                                 ? 2U
                                                                                 : 
                                                                                ((8U 
                                                                                & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT___GEN_25))
                                                                                 ? 3U
                                                                                 : 
                                                                                ((0x10U 
                                                                                & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT___GEN_25))
                                                                                 ? 4U
                                                                                 : 
                                                                                (5U 
                                                                                | (2U 
                                                                                & ((~ 
                                                                                ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT___GEN_25) 
                                                                                >> 5U)) 
                                                                                << 1U))))))))) 
                                                                             << 0xcU)) 
                                                                         | (((0U 
                                                                              != (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT___GEN_18)) 
                                                                             << 0xbU) 
                                                                            | (((1U 
                                                                                & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT___GEN_18) 
                                                                                >> (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__masked_entry_2)))
                                                                                 ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__masked_entry_2)
                                                                                 : 
                                                                                ((1U 
                                                                                & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT___GEN_18))
                                                                                 ? 0U
                                                                                 : 
                                                                                ((2U 
                                                                                & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT___GEN_18))
                                                                                 ? 1U
                                                                                 : 
                                                                                ((4U 
                                                                                & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT___GEN_18))
                                                                                 ? 2U
                                                                                 : 
                                                                                ((8U 
                                                                                & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT___GEN_18))
                                                                                 ? 3U
                                                                                 : 
                                                                                ((0x10U 
                                                                                & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT___GEN_18))
                                                                                 ? 4U
                                                                                 : 
                                                                                (5U 
                                                                                | (2U 
                                                                                & ((~ 
                                                                                ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT___GEN_18) 
                                                                                >> 5U)) 
                                                                                << 1U))))))))) 
                                                                               << 8U))) 
                                                                        | ((((0U 
                                                                              != (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT___GEN_11)) 
                                                                             << 7U) 
                                                                            | (((1U 
                                                                                & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT___GEN_11) 
                                                                                >> (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__masked_entry_1)))
                                                                                 ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__masked_entry_1)
                                                                                 : 
                                                                                ((1U 
                                                                                & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT___GEN_11))
                                                                                 ? 0U
                                                                                 : 
                                                                                ((2U 
                                                                                & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT___GEN_11))
                                                                                 ? 1U
                                                                                 : 
                                                                                ((4U 
                                                                                & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT___GEN_11))
                                                                                 ? 2U
                                                                                 : 
                                                                                ((8U 
                                                                                & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT___GEN_11))
                                                                                 ? 3U
                                                                                 : 
                                                                                ((0x10U 
                                                                                & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT___GEN_11))
                                                                                 ? 4U
                                                                                 : 
                                                                                (5U 
                                                                                | (2U 
                                                                                & ((~ 
                                                                                ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT___GEN_11) 
                                                                                >> 5U)) 
                                                                                << 1U))))))))) 
                                                                               << 4U)) 
                                                                           | (((0U 
                                                                                != (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT___GEN_4)) 
                                                                               << 3U) 
                                                                              | ((1U 
                                                                                & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT___GEN_4) 
                                                                                >> (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__masked_entry)))
                                                                                 ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT__masked_entry)
                                                                                 : 
                                                                                ((1U 
                                                                                & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT___GEN_4))
                                                                                 ? 0U
                                                                                 : 
                                                                                ((2U 
                                                                                & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT___GEN_4))
                                                                                 ? 1U
                                                                                 : 
                                                                                ((4U 
                                                                                & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT___GEN_4))
                                                                                 ? 2U
                                                                                 : 
                                                                                ((8U 
                                                                                & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT___GEN_4))
                                                                                 ? 3U
                                                                                 : 
                                                                                ((0x10U 
                                                                                & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT___GEN_4))
                                                                                 ? 4U
                                                                                 : 
                                                                                (5U 
                                                                                | (2U 
                                                                                & ((~ 
                                                                                ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__tage__DOT___GEN_4) 
                                                                                >> 5U)) 
                                                                                << 1U))))))))))))))));
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__2562(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__2562\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___bpd_io_resp_f3_preds_0_taken 
        = ((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__loop__DOT__columns_0__DOT__f3_entry_tag) 
             == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__loop__DOT__columns_0__DOT__f3_tag)) 
            & (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__loop__DOT___columns_0_io_f3_meta_s_cnt) 
                == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__loop__DOT__columns_0__DOT__f3_entry_p_cnt)) 
               & (7U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__loop__DOT__columns_0__DOT__f3_entry_conf)))) 
           ^ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT___tage_io_resp_f3_0_taken));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_fu_code_9 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_120) 
           | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_fp_ctrl_toint));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_fu_code_3 
        = (IData)(((3U == (7U & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst)) 
                   & ((IData)(((0x30U == (0x78U & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst)) 
                               & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_90))) 
                      | (IData)(((0x30U == (0x3070U 
                                            & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst)) 
                                 & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_90))))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_fp_ctrl_fastpipe 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_96) 
           | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_159) 
              | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_160) 
                 | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_161))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_fp_ctrl_typeTagIn 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_167) 
           | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_168) 
              | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_169) 
                 | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_170) 
                    | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_171) 
                       | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_160) 
                          | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_172) 
                             | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_173) 
                                | ((IData)(((0x53U 
                                             == (0x1df0707fU 
                                                 & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst)) 
                                            & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_174))) 
                                   | ((IData)(((0x2000053U 
                                                == 
                                                (0xff0707fU 
                                                 & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst)) 
                                               & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_174))) 
                                      | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_175)))))))))));
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__2563(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__2563\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_84 
        = (IData)(((0x13U == (0x7fU & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst)) 
                   & (IData)(vlSelfRef.__VdfgRegularize_h787163e4_0_30)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_128 
        = (IData)(((0x1013U == (0x707fU & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst)) 
                   & (IData)(vlSelfRef.__VdfgRegularize_h787163e4_0_30)));
    vlSelfRef.__VdfgRegularize_h787163e4_0_31 = ((~ 
                                                  (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst 
                                                   >> 0x14U)) 
                                                 & (0x3ffU 
                                                    == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_257)));
    vlSelfRef.__VdfgRegularize_h787163e4_0_32 = ((~ 
                                                  (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst 
                                                   >> 0x15U)) 
                                                 & (0x3ffU 
                                                    == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_257)));
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__2564(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__2564\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_iq_type_0 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_155) 
           | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_111) 
              | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_122) 
                 | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_125) 
                    | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_52) 
                       | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_53) 
                          | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_117) 
                             | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_fu_code_2))))))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_136 
        = (IData)(((0x73U == (0x3ffU & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst)) 
                   & (IData)(vlSelfRef.__VdfgRegularize_h787163e4_0_20)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_183 
        = (IData)(((0x73U == (0x7fffU & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst)) 
                   & (IData)(vlSelfRef.__VdfgRegularize_h787163e4_0_20)));
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__2565(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__2565\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_127 
        = (IData)(((3U == (0xfU & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst)) 
                   & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_106)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_108 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_105) 
           | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_106) 
              | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_107)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_68 
        = (IData)(((0x1bU == (0x1fU & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst)) 
                   & (IData)(vlSelfRef.__VdfgRegularize_h787163e4_0_24)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_113 
        = (IData)(((0x1bU == (0x3fU & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst)) 
                   & (IData)(vlSelfRef.__VdfgRegularize_h787163e4_0_24)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_123 
        = (IData)(((3U == (0xfU & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst)) 
                   & (IData)(vlSelfRef.__VdfgRegularize_h787163e4_0_18)));
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__2566(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__2566\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_102 
        = (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst 
           & (IData)(vlSelfRef.__VdfgRegularize_h787163e4_0_18));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_54 
        = (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_53) 
            ^ (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_head) 
                < (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_tail)) 
               ^ ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_pnr) 
                  >= (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_tail)))) 
           | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___do_inc_row_T_1));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_55 
        = ((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_tail) 
             < (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_head)) 
            ^ ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_53) 
               ^ ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_tail) 
                  >= (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_pnr)))) 
           | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__full));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__finished_committing_row 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___rob_io_commit_valids_0) 
           & ((~ ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__r_partial_row) 
                  & ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__b2_mispredict)) 
                     & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___empty_T)))) 
              & ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_12)) 
                 ^ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___rob_io_commit_valids_0))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___rob_io_empty 
        = ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_12)) 
           & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___empty_T));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___GEN_47 
        = (1U & ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f4__DOT__maybe_full)) 
                 | ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___GEN_44)) 
                    | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___GEN_45))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3_clear 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__jump_to_reset) 
           | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___GEN_48) 
              | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f4__DOT__maybe_full) 
                 & ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___GEN_45)) 
                    & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___GEN_44)))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f1_redirects_3 
        = (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___bpd_io_resp_f1_preds_3_predicted_pc_valid) 
            & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___bpd_io_resp_f1_preds_3_taken)) 
           & (((IData)(0xfU) << (3U & (IData)((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__s1_vpc 
                                               >> 1U)))) 
              >> 3U));
    vlSelfRef.__VdfgRegularize_h36cfaf1a_0_42 = (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___bpd_io_resp_f2_preds_3_predicted_pc_valid) 
                                                  & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___bpd_io_resp_f2_preds_3_taken)) 
                                                 & (((IData)(0xfU) 
                                                     << 
                                                     (3U 
                                                      & (IData)(
                                                                (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__s2_vpc 
                                                                 >> 1U)))) 
                                                    >> 3U));
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__2567(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__2567\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT__s1_is_jal_3 
        = ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT___GEN_11)) 
           & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT__s1_resp_3_valid));
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3_bpd_queue__DOT__maybe_full) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___f3_bpd_queue_io_deq_bits_preds_3_taken 
            = (1U & (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3_bpd_queue__DOT__ram[9U] 
                     >> 8U));
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___f3_bpd_queue_io_deq_bits_preds_2_taken 
            = (1U & (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3_bpd_queue__DOT__ram[7U] 
                     >> 0x1cU));
    } else {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___f3_bpd_queue_io_deq_bits_preds_3_taken 
            = (1U & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___bpd_io_resp_f3_preds_3_taken));
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___f3_bpd_queue_io_deq_bits_preds_2_taken 
            = (1U & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___bpd_io_resp_f3_preds_2_taken));
    }
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f1_redirects_2 
        = (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___bpd_io_resp_f1_preds_2_predicted_pc_valid) 
            & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___bpd_io_resp_f1_preds_2_taken)) 
           & (((IData)(0xfU) << (3U & (IData)((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__s1_vpc 
                                               >> 1U)))) 
              >> 2U));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f2_redirects_2 
        = (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___bpd_io_resp_f2_preds_2_predicted_pc_valid) 
            & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___bpd_io_resp_f2_preds_2_taken)) 
           & (((IData)(0xfU) << (3U & (IData)((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__s2_vpc 
                                               >> 1U)))) 
              >> 2U));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f1_redirects_1 
        = (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___bpd_io_resp_f1_preds_1_predicted_pc_valid) 
            & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___bpd_io_resp_f1_preds_1_taken)) 
           & (((IData)(0xfU) << (3U & (IData)((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__s1_vpc 
                                               >> 1U)))) 
              >> 1U));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f2_redirects_1 
        = (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___bpd_io_resp_f2_preds_1_predicted_pc_valid) 
            & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___bpd_io_resp_f2_preds_1_taken)) 
           & (((IData)(0xfU) << (3U & (IData)((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__s2_vpc 
                                               >> 1U)))) 
              >> 1U));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f1_redirects_0 
        = (((IData)(1U) << (3U & (IData)((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__s1_vpc 
                                          >> 1U)))) 
           & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___bpd_io_resp_f1_preds_0_predicted_pc_valid) 
              & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___bpd_io_resp_f1_preds_0_taken)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f2_redirects_0 
        = (((IData)(1U) << (3U & (IData)((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__s2_vpc 
                                          >> 1U)))) 
           & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___bpd_io_resp_f2_preds_0_predicted_pc_valid) 
              & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___bpd_io_resp_f2_preds_0_taken)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT__s1_is_jal_2 
        = ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT___GEN_9)) 
           & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT__s1_resp_2_valid));
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__2568(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__2568\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT__s1_is_jal_1 
        = ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT___GEN_7)) 
           & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT__s1_resp_1_valid));
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3_bpd_queue__DOT__maybe_full) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___f3_bpd_queue_io_deq_bits_preds_1_taken 
            = (1U & (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3_bpd_queue__DOT__ram[6U] 
                     >> 0x10U));
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___f3_bpd_queue_io_deq_bits_preds_0_taken 
            = (1U & (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3_bpd_queue__DOT__ram[5U] 
                     >> 4U));
    } else {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___f3_bpd_queue_io_deq_bits_preds_1_taken 
            = (1U & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___bpd_io_resp_f3_preds_1_taken));
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___f3_bpd_queue_io_deq_bits_preds_0_taken 
            = (1U & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___bpd_io_resp_f3_preds_0_taken));
    }
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT__s1_is_jal_0 
        = ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT___GEN_5)) 
           & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT__s1_resp_0_valid));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___bpd_io_resp_f3_meta_0[0U] 
        = (((IData)(vlSelfRef.__VdfgRegularize_h36cfaf1a_0_195) 
            << 0xaU) | (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__btb__DOT__f3_meta_write_way) 
                         << 9U) | (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__ubtb__DOT__io_f3_meta_REG_1) 
                                    << 8U) | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__bim__DOT__io_f3_meta_REG))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___bpd_io_resp_f3_meta_0[1U] 
        = (((IData)(vlSelfRef.__VdfgRegularize_h36cfaf1a_0_195) 
            >> 0x16U) | ((IData)((vlSelfRef.__VdfgRegularize_h36cfaf1a_0_195 
                                  >> 0x20U)) << 0xaU));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___bpd_io_resp_f3_meta_0[2U] 
        = ((0xfffffffcU & (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__loop__DOT___columns_2_io_f3_meta_s_cnt) 
                            << 0x16U) | (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__loop__DOT___columns_1_io_f3_meta_s_cnt) 
                                          << 0xcU) 
                                         | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__loop__DOT___columns_0_io_f3_meta_s_cnt) 
                                            << 2U)))) 
           | ((IData)((vlSelfRef.__VdfgRegularize_h36cfaf1a_0_195 
                       >> 0x20U)) >> 0x16U));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___bpd_io_resp_f3_meta_0[3U] 
        = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__bpd__DOT__banked_predictors_0__DOT__loop__DOT___columns_3_io_f3_meta_s_cnt;
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_85 
        = (IData)(((0x13U == (0x77U & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst)) 
                   & (IData)(vlSelfRef.__VdfgRegularize_h787163e4_0_31)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_129 
        = (IData)(((0x1013U == (0x7077U & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst)) 
                   & (IData)(vlSelfRef.__VdfgRegularize_h787163e4_0_31)));
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__2569(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__2569\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_86 
        = (IData)(((0x13U == (0x77U & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst)) 
                   & (IData)(vlSelfRef.__VdfgRegularize_h787163e4_0_32)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_130 
        = (IData)(((0x1013U == (0x7077U & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst)) 
                   & (IData)(vlSelfRef.__VdfgRegularize_h787163e4_0_32)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_164 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_105) 
           | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_106) 
              | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_136) 
                 | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_107))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_mem_cmd 
        = ((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_136) 
             << 4U) | (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_52) 
                        << 3U) | (((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_53) 
                                     | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_117)) 
                                    | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_136)) 
                                   | (0x8000202fU == 
                                      (0x9800607fU 
                                       & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst))) 
                                  << 2U))) | (((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_117) 
                                                 | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_137)) 
                                                | (0x4000202fU 
                                                   == 
                                                   (0x5800607fU 
                                                    & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst))) 
                                               << 1U) 
                                              | ((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_133) 
                                                   | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_134)) 
                                                  | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_137)) 
                                                 | (0x2000202fU 
                                                    == 
                                                    (0x3800607fU 
                                                     & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst)))));
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__2570(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__2570\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_fcn_dw 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_101) 
           | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_54) 
              | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_56) 
                 | ((IData)(((0x33U == (0x307fU & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst)) 
                             & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_188))) 
                    | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_178) 
                       | ((IData)(((0x41U == (0x1efffc1U 
                                              & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst)) 
                                   & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_62))) 
                          | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_65) 
                             | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_66) 
                                | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_180) 
                                   | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_124) 
                                      | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_69) 
                                         | ((IData)(
                                                    ((0x2033U 
                                                      == 
                                                      (0x307fU 
                                                       & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst)) 
                                                     & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_189))) 
                                            | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_116) 
                                               | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_70) 
                                                  | ((IData)(
                                                             ((0x4033U 
                                                               == 
                                                               (0x507fU 
                                                                & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst)) 
                                                              & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_189))) 
                                                     | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_71) 
                                                        | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_181) 
                                                           | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_73) 
                                                              | ((IData)(
                                                                         ((0x200041U 
                                                                           == 
                                                                           (0x3fffc1U 
                                                                            & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst)) 
                                                                          & (IData)(vlSelfRef.__VdfgRegularize_h36cfaf1a_0_123))) 
                                                                 | ((IData)(
                                                                            ((0x500040U 
                                                                              == 
                                                                              (0x7fffc0U 
                                                                               & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst)) 
                                                                             & (IData)(vlSelfRef.__VdfgRegularize_h36cfaf1a_0_124))) 
                                                                    | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_136) 
                                                                       | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_77) 
                                                                          | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_78) 
                                                                             | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_79) 
                                                                                | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_80) 
                                                                                | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_82) 
                                                                                | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_83) 
                                                                                | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_84) 
                                                                                | ((IData)(
                                                                                ((0x1013U 
                                                                                == 
                                                                                (0x1d0707fU 
                                                                                & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst)) 
                                                                                & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_193))) 
                                                                                | ((IData)(
                                                                                ((0x1033U 
                                                                                == 
                                                                                (0x307fU 
                                                                                & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst)) 
                                                                                & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_193))) 
                                                                                | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_88) 
                                                                                | (IData)(
                                                                                ((0x1b200040U 
                                                                                == 
                                                                                (0x1fffffc0U 
                                                                                & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst)) 
                                                                                & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_191))))))))))))))))))))))))))))))))));
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__2571(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__2571\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_iq_type_1 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_fu_code_3) 
           | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_fu_code_4) 
              | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_102) 
                 | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_114) 
                    | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_116) 
                       | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_105) 
                          | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_106) 
                             | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_136) 
                                | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_107) 
                                   | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_fu_code_8))))))))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT__cs_rs1_type 
        = ((2U & (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_101) 
                   | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_56) 
                      | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_66) 
                         | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_102) 
                            | ((IData)((0x5073U == 
                                        (0x507fU & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst))) 
                               | ((IData)(((0x13U == 
                                            (0x1fU 
                                             & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst)) 
                                           & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_104))) 
                                  | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_108))))))) 
                  << 1U)) | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_fp_ctrl_ren1));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT__cs_csr_cmd 
        = ((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_102) 
             | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_114) 
                | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_116) 
                   | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_108)))) 
            << 2U) | ((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_116) 
                        | (IData)(((0x73U == (0x73ffU 
                                              & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst)) 
                                   & (IData)(vlSelfRef.__VdfgRegularize_h36cfaf1a_0_125)))) 
                       << 1U) | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_114)));
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__2572(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__2572\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT____VdfgRegularize_h8fa566d8_0_10 
        = (1U & (~ ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___rob_io_empty) 
                    & ((~ ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_valid_0) 
                           | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_valid_1) 
                              | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_valid_2) 
                                 | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_valid_3) 
                                    | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_valid_4) 
                                       | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_valid_5) 
                                          | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_valid_6) 
                                             | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_valid_7))))))))) 
                       & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT___dcache_io_lsu_ordered)))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT____Vcellinp__fb__io_enq_bits_fsrc 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___GEN_47)
            ? (7U & (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f4__DOT__ram[0U] 
                     >> 3U)) : 3U);
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f4_io_enq_valid 
        = ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3_clear)) 
           & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3__DOT__maybe_full));
    vlSelfRef.__VdfgRegularize_h36cfaf1a_0_43 = ((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3__DOT__ram[3U] 
                                                  >> 0x12U) 
                                                 & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___f3_bpd_queue_io_deq_bits_preds_3_predicted_pc_valid) 
                                                    & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___f3_bpd_queue_io_deq_bits_preds_3_taken)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT____VdfgRegularize_hce62b063_0_1 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f1_redirects_0)
            ? 0U : ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f1_redirects_1)
                     ? 1U : (2U | (1U & (~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f1_redirects_2))))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f1_do_redirect 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f1_redirects_0) 
           | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f1_redirects_1) 
              | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f1_redirects_2) 
                 | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f1_redirects_3))));
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f2_redirects_0) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT____Vcellinp__f3__io_enq_bits_next_pc 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___bpd_io_resp_f2_preds_0_predicted_pc_bits;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT____Vcellinp__f3__io_enq_bits_cfi_idx_bits = 0U;
    } else if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f2_redirects_1) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT____Vcellinp__f3__io_enq_bits_next_pc 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___bpd_io_resp_f2_preds_1_predicted_pc_bits;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT____Vcellinp__f3__io_enq_bits_cfi_idx_bits = 1U;
    } else {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT____Vcellinp__f3__io_enq_bits_next_pc 
            = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f2_redirects_2)
                ? vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___bpd_io_resp_f2_preds_2_predicted_pc_bits
                : ((IData)(vlSelfRef.__VdfgRegularize_h36cfaf1a_0_42)
                    ? vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___bpd_io_resp_f2_preds_3_predicted_pc_bits
                    : vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f2_next_fetch));
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT____Vcellinp__f3__io_enq_bits_cfi_idx_bits 
            = (2U | (1U & (~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f2_redirects_2))));
    }
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f2_do_redirect 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f2_redirects_0) 
           | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f2_redirects_1) 
              | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f2_redirects_2) 
                 | (IData)(vlSelfRef.__VdfgRegularize_h36cfaf1a_0_42))));
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__2573(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__2573\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3_predicted_redirects_2 
        = ((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3__DOT__ram[3U] 
            >> 0x11U) & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___f3_bpd_queue_io_deq_bits_preds_2_predicted_pc_valid) 
                         & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___f3_bpd_queue_io_deq_bits_preds_2_taken)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3_predicted_redirects_1 
        = ((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3__DOT__ram[3U] 
            >> 0x10U) & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___f3_bpd_queue_io_deq_bits_preds_1_predicted_pc_valid) 
                         & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___f3_bpd_queue_io_deq_bits_preds_1_taken)));
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3_bpd_queue__DOT__maybe_full) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___f3_bpd_queue_io_deq_bits_meta_0[0U] 
            = ((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3_bpd_queue__DOT__ram[1U] 
                << 0x1fU) | (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3_bpd_queue__DOT__ram[0U] 
                             >> 1U));
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___f3_bpd_queue_io_deq_bits_meta_0[1U] 
            = ((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3_bpd_queue__DOT__ram[2U] 
                << 0x1fU) | (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3_bpd_queue__DOT__ram[1U] 
                             >> 1U));
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___f3_bpd_queue_io_deq_bits_meta_0[2U] 
            = ((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3_bpd_queue__DOT__ram[3U] 
                << 0x1fU) | (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3_bpd_queue__DOT__ram[2U] 
                             >> 1U));
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___f3_bpd_queue_io_deq_bits_meta_0[3U] 
            = (0xffffffU & ((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3_bpd_queue__DOT__ram[4U] 
                             << 0x1fU) | (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3_bpd_queue__DOT__ram[3U] 
                                          >> 1U)));
    } else {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___f3_bpd_queue_io_deq_bits_meta_0[0U] 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___bpd_io_resp_f3_meta_0[0U];
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___f3_bpd_queue_io_deq_bits_meta_0[1U] 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___bpd_io_resp_f3_meta_0[1U];
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___f3_bpd_queue_io_deq_bits_meta_0[2U] 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___bpd_io_resp_f3_meta_0[2U];
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___f3_bpd_queue_io_deq_bits_meta_0[3U] 
            = (0xffffffU & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___bpd_io_resp_f3_meta_0[3U]);
    }
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3_redirects_0 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3_mask_0) 
           & ((2U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___bpd_decoder_io_out_cfi_type)) 
              | ((3U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___bpd_decoder_io_out_cfi_type)) 
                 | ((1U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___bpd_decoder_io_out_cfi_type)) 
                    & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___f3_bpd_queue_io_deq_bits_preds_0_taken)))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3_predicted_redirects_0 
        = ((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3__DOT__ram[3U] 
            >> 0xfU) & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___f3_bpd_queue_io_deq_bits_preds_0_predicted_pc_valid) 
                        & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___f3_bpd_queue_io_deq_bits_preds_0_taken)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_iq_type_2 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_54) 
           | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_55) 
              | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_56) 
                 | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_57) 
                    | ((IData)(((0x33U == (0x7fU & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst)) 
                                & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_62))) 
                       | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_63) 
                          | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_64) 
                             | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_65) 
                                | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_66) 
                                   | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_67) 
                                      | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_68) 
                                         | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_69) 
                                            | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_70) 
                                               | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_71) 
                                                  | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_72) 
                                                     | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_73) 
                                                        | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_74) 
                                                           | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_75) 
                                                              | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_76) 
                                                                 | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_77) 
                                                                    | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_78) 
                                                                       | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_79) 
                                                                          | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_80) 
                                                                             | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_81) 
                                                                                | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_82) 
                                                                                | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_83) 
                                                                                | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_84) 
                                                                                | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_85) 
                                                                                | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_86) 
                                                                                | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_87) 
                                                                                | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_88)))))))))))))))))))))))))))))));
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__2574(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__2574\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT__cs_rs2_type 
        = ((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_110) 
             | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_111) 
                | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_101) 
                   | (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_55) 
                       | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_56) 
                          | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_112) 
                             | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_66) 
                                | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_102) 
                                   | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_67) 
                                      | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_113) 
                                         | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_114) 
                                            | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_115) 
                                               | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_69) 
                                                  | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_116) 
                                                     | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_73) 
                                                        | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_117) 
                                                           | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_105) 
                                                              | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_106) 
                                                                 | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_77) 
                                                                    | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_79) 
                                                                       | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_80) 
                                                                          | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_118) 
                                                                             | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_97) 
                                                                                | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_98) 
                                                                                | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_82) 
                                                                                | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_fp_ctrl_sqrt) 
                                                                                | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_84) 
                                                                                | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_85) 
                                                                                | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_86) 
                                                                                | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_88) 
                                                                                | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_107) 
                                                                                | (IData)(
                                                                                ((0x53U 
                                                                                == 
                                                                                (0xdf0007fU 
                                                                                & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst)) 
                                                                                & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_119))))))))))))))))))))))))))))))) 
                      | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_99))))) 
            << 1U) | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_fp_ctrl_ren3) 
                      | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_92) 
                         | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_120) 
                            | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_121)))));
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__2575(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__2575\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_fcn_op 
        = (((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_73) 
              | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_74) 
                 | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_79) 
                    | ((IData)(((0x33U == (0x107fU 
                                           & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst)) 
                                & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_197))) 
                       | ((IData)(((0x33U == (0x7fU 
                                              & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst)) 
                                   & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_198))) 
                          | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_82) 
                             | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_83) 
                                | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_128) 
                                   | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_129) 
                                      | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_130) 
                                         | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_87) 
                                            | ((IData)(
                                                       ((0x5013U 
                                                         == 
                                                         (0x707fU 
                                                          & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst)) 
                                                        & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_192))) 
                                               | ((IData)(
                                                          ((0x501bU 
                                                            == 
                                                            (0x705fU 
                                                             & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst)) 
                                                           & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_193))) 
                                                  | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_88)))))))))))))) 
             << 4U) | ((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_64) 
                         | ((IData)(((0x13U == (0x1fU 
                                                & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst)) 
                                     & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_187))) 
                            | ((IData)(((0x2033U == 
                                         (0x607fU & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst)) 
                                        & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_62))) 
                               | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_71) 
                                  | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_74) 
                                     | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_199) 
                                        | (IData)((
                                                   (3U 
                                                    == 
                                                    (7U 
                                                     & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst)) 
                                                   & ((IData)(
                                                              ((0x30U 
                                                                == 
                                                                (0x78U 
                                                                 & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst)) 
                                                               & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_197))) 
                                                      | ((IData)(
                                                                 ((0x5010U 
                                                                   == 
                                                                   (0x7078U 
                                                                    & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst)) 
                                                                  & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_195))) 
                                                         | ((IData)(
                                                                    ((0x1018U 
                                                                      == 
                                                                      (0x3058U 
                                                                       & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst)) 
                                                                     & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_197))) 
                                                            | (IData)(
                                                                      ((0x10U 
                                                                        == 
                                                                        (0x18U 
                                                                         & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst)) 
                                                                       & ((IData)(
                                                                                ((0x1000U 
                                                                                == 
                                                                                (0x7060U 
                                                                                & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst)) 
                                                                                & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_200))) 
                                                                          | (IData)(
                                                                                ((0x1020U 
                                                                                == 
                                                                                (0x2007060U 
                                                                                & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst)) 
                                                                                & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_200))))))))))))))))) 
                        << 3U) | (4U & (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_69) 
                                         | ((IData)(
                                                    ((0x2033U 
                                                      == 
                                                      (0x207fU 
                                                       & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst)) 
                                                     & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_62))) 
                                            | ((IData)(
                                                       (0x4013U 
                                                        == 
                                                        (0x507fU 
                                                         & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst))) 
                                               | ((IData)(
                                                          ((0x33U 
                                                            == 
                                                            (0x7fU 
                                                             & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst)) 
                                                           & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_201))) 
                                                  | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_71) 
                                                     | ((IData)(
                                                                ((0x1013U 
                                                                  == 
                                                                  (0x305fU 
                                                                   & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst)) 
                                                                 & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_201))) 
                                                        | ((IData)(
                                                                   ((0x501bU 
                                                                     == 
                                                                     (0x705fU 
                                                                      & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst)) 
                                                                    & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_62))) 
                                                           | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_181) 
                                                              | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_fu_code_4) 
                                                                 | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_77) 
                                                                    | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_78))))))))))) 
                                        << 2U)))) | 
           ((2U & (((IData)(((0xbU == (0xbU & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst)) 
                             & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_202))) 
                    | ((IData)(((0x63U == (0x7fU & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst)) 
                                & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_186))) 
                       | ((IData)((0x3013U == (0x307fU 
                                               & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst))) 
                          | ((IData)(((0x3033U == (0x307fU 
                                                   & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst)) 
                                      & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_61))) 
                             | ((IData)(((0x13U == 
                                          (0x7fU & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst)) 
                                         & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_103))) 
                                | ((IData)(((0x2033U 
                                             == (0x207fU 
                                                 & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst)) 
                                            & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_201))) 
                                   | ((IData)(((3U 
                                                == 
                                                (0x1fU 
                                                 & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst)) 
                                               & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_104))) 
                                      | ((IData)(((0x2033U 
                                                   == 
                                                   (0x207fU 
                                                    & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst)) 
                                                  & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_89))) 
                                         | ((IData)(
                                                    ((0x2033U 
                                                      == 
                                                      (0x2077U 
                                                       & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst)) 
                                                     & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_203))) 
                                            | ((IData)(
                                                       ((0x1033U 
                                                         == 
                                                         (0x107fU 
                                                          & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst)) 
                                                        & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_204))) 
                                               | ((IData)(
                                                          ((0x1013U 
                                                            == 
                                                            (0x107fU 
                                                             & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst)) 
                                                           & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_177))) 
                                                  | ((IData)(
                                                             ((0x1033U 
                                                               == 
                                                               (0x200707fU 
                                                                & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst)) 
                                                              & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_176))) 
                                                     | ((IData)(
                                                                ((0x33U 
                                                                  == 
                                                                  (0x307fU 
                                                                   & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst)) 
                                                                 & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_196))) 
                                                        | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_199) 
                                                           | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_80) 
                                                              | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_205) 
                                                                 | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_81) 
                                                                    | ((IData)(
                                                                               ((0x5033U 
                                                                                == 
                                                                                (0x1e007077U 
                                                                                & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst)) 
                                                                                & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_190))) 
                                                                       | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_206))))))))))))))))))) 
                   << 1U)) | ((IData)(((7U == (7U & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst)) 
                                       & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_202))) 
                              | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_180) 
                                 | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_68) 
                                    | ((IData)(((0x501bU 
                                                 == 
                                                 (0x705fU 
                                                  & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst)) 
                                                & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_188))) 
                                       | ((IData)((
                                                   (0x1033U 
                                                    == 
                                                    (0x107fU 
                                                     & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst)) 
                                                   & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_201))) 
                                          | ((IData)(
                                                     ((0x1013U 
                                                       == 
                                                       (0x107fU 
                                                        & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst)) 
                                                      & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_103))) 
                                             | ((IData)(
                                                        ((0x1033U 
                                                          == 
                                                          (0x107fU 
                                                           & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst)) 
                                                         & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_89))) 
                                                | ((IData)(
                                                           ((0x1033U 
                                                             == 
                                                             (0x1077U 
                                                              & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst)) 
                                                            & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_203))) 
                                                   | ((IData)(
                                                              ((0x53U 
                                                                == 
                                                                (0x7fU 
                                                                 & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst)) 
                                                               & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_135))) 
                                                      | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_72) 
                                                         | ((IData)(
                                                                    ((0x33U 
                                                                      == 
                                                                      (0x207fU 
                                                                       & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst)) 
                                                                     & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_204))) 
                                                            | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_205) 
                                                               | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_206) 
                                                                  | (IData)(
                                                                            ((3U 
                                                                              == 
                                                                              (7U 
                                                                               & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst)) 
                                                                             & ((IData)(
                                                                                ((0x30U 
                                                                                == 
                                                                                (0x1078U 
                                                                                & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst)) 
                                                                                & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_198))) 
                                                                                | (IData)(
                                                                                ((0x1030U 
                                                                                == 
                                                                                (0x7070U 
                                                                                & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst)) 
                                                                                & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_193)))))))))))))))))))));
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__2576(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__2576\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_dst_rtype 
        = (((0ULL == (((QData)((IData)(((((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_110) 
                                            << 0x10U) 
                                           | (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_111) 
                                               << 0xfU) 
                                              | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_55) 
                                                 << 0xeU))) 
                                          | (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_56) 
                                              << 0xdU) 
                                             | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_57) 
                                                << 0xcU))) 
                                         | ((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_178) 
                                              << 0xbU) 
                                             | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_179) 
                                                << 0xaU)) 
                                            | (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_63) 
                                                << 9U) 
                                               | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_91) 
                                                  << 8U)))) 
                                        | (((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_92) 
                                              << 7U) 
                                             | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_112) 
                                                << 6U)) 
                                            | (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_66) 
                                                << 5U) 
                                               | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_180) 
                                                  << 4U))) 
                                           | ((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_68) 
                                                << 3U) 
                                               | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_114) 
                                                  << 2U)) 
                                              | (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_115) 
                                                  << 1U) 
                                                 | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_69))))))) 
                       << 0x20U) | (QData)((IData)(
                                                   (((((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_52) 
                                                         << 0x1fU) 
                                                        | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_116) 
                                                           << 0x1eU)) 
                                                       | (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_70) 
                                                           << 0x1dU) 
                                                          | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_181) 
                                                             << 0x1cU))) 
                                                      | ((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_fu_code_4) 
                                                           << 0x1bU) 
                                                          | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_72) 
                                                             << 0x1aU)) 
                                                         | (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_53) 
                                                             << 0x19U) 
                                                            | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_73) 
                                                               << 0x18U)))) 
                                                     | (((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_182) 
                                                           << 0x17U) 
                                                          | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_94) 
                                                             << 0x16U)) 
                                                         | (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_95) 
                                                             << 0x15U) 
                                                            | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_96) 
                                                               << 0x14U))) 
                                                        | ((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_75) 
                                                             << 0x13U) 
                                                            | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_76) 
                                                               << 0x12U)) 
                                                           | (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_77) 
                                                               << 0x11U) 
                                                              | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_78) 
                                                                 << 0x10U))))) 
                                                    | ((((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_79) 
                                                           << 0xfU) 
                                                          | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_80) 
                                                             << 0xeU)) 
                                                         | (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_81) 
                                                             << 0xdU) 
                                                            | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_97) 
                                                               << 0xcU))) 
                                                        | ((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_98) 
                                                             << 0xbU) 
                                                            | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_82) 
                                                               << 0xaU)) 
                                                           | (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_83) 
                                                               << 9U) 
                                                              | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_fp_ctrl_sqrt) 
                                                                 << 8U)))) 
                                                       | (((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_128) 
                                                             << 7U) 
                                                            | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_129) 
                                                               << 6U)) 
                                                           | (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_130) 
                                                               << 5U) 
                                                              | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_87) 
                                                                 << 4U))) 
                                                          | (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_88) 
                                                              << 3U) 
                                                             | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_184))))))))) 
            << 1U) | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_91) 
                      | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_92) 
                         | ((IData)(((7U == (0x1fU 
                                             & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst)) 
                                     & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_187))) 
                            | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_96) 
                               | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_159) 
                                  | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_160) 
                                     | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_161) 
                                        | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_fp_ctrl_sqrt) 
                                           | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_fu_code_8))))))))));
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__2577(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__2577\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_132 
        = ((((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_72) 
               << 0xeU) | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_73) 
                           << 0xdU)) | (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_126) 
                                         << 0xcU) | 
                                        ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_127) 
                                         << 0xbU))) 
            | ((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_77) 
                 << 0xaU) | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_79) 
                             << 9U)) | (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_80) 
                                         << 8U) | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_118) 
                                                   << 7U)))) 
           | (((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_82) 
                 << 6U) | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_128) 
                           << 5U)) | (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_129) 
                                       << 4U) | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_130) 
                                                 << 3U))) 
              | (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_88) 
                  << 2U) | (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_131) 
                             << 1U) | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_50)))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_139 
        = ((6U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT__cs_csr_cmd)) 
           | (7U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT__cs_csr_cmd)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__wait_for_empty_pipeline_0 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT____VdfgRegularize_h8fa566d8_0_10) 
           & ((~ ((~ (IData)((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__reg_custom_2 
                              >> 3U))) & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__csr__DOT__reg_custom_0))) 
              | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rename_stage__DOT__r_uop_is_unique)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT____VdfgRegularize_hce62b063_0_42 
        = (1U & (~ ((IData)((0U != (0x7800000U & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f4__DOT__ram[0xaU]))) 
                    & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT____VdfgRegularize_hce62b063_0_37) 
                       & (~ ((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f4__DOT__ram[8U] 
                              >> 0x1eU) | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f4_io_enq_valid)))))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___GEN_0 
        = (7U & (((IData)(1U) << (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT____VdfgRegularize_hce62b063_0_1)) 
                 | (7U & (((IData)(1U) << (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT____VdfgRegularize_hce62b063_0_1)) 
                          >> 1U))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___f1_predicted_ghist_new_history_old_history_T 
        = (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f1_redirects_0)
             ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___bpd_io_resp_f1_preds_0_is_br)
             : ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f1_redirects_1)
                 ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___bpd_io_resp_f1_preds_1_is_br)
                 : ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f1_redirects_2)
                     ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___bpd_io_resp_f1_preds_2_is_br)
                     : (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___bpd_io_resp_f1_preds_3_is_br)))) 
           & (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f1_redirects_0)
                ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___bpd_io_resp_f1_preds_0_taken)
                : ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f1_redirects_1)
                    ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___bpd_io_resp_f1_preds_1_taken)
                    : ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f1_redirects_2)
                        ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___bpd_io_resp_f1_preds_2_taken)
                        : (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___bpd_io_resp_f1_preds_3_taken)))) 
              & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f1_do_redirect)));
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__2578(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__2578\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT____VdfgRegularize_hce62b063_0_39 
        = (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__s1_vpc 
           == vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT____Vcellinp__f3__io_enq_bits_next_pc);
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___f2_predicted_ghist_new_history_old_history_T 
        = (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f2_redirects_0)
             ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___bpd_io_resp_f2_preds_0_is_br)
             : ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f2_redirects_1)
                 ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___bpd_io_resp_f2_preds_1_is_br)
                 : ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f2_redirects_2)
                     ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___bpd_io_resp_f2_preds_2_is_br)
                     : (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___bpd_io_resp_f2_preds_3_is_br)))) 
           & (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f2_redirects_0)
                ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___bpd_io_resp_f2_preds_0_taken)
                : ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f2_redirects_1)
                    ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___bpd_io_resp_f2_preds_1_taken)
                    : ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f2_redirects_2)
                        ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___bpd_io_resp_f2_preds_2_taken)
                        : (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___bpd_io_resp_f2_preds_3_taken)))) 
              & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f2_do_redirect)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___GEN_4 
        = (7U & (((IData)(1U) << (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT____Vcellinp__f3__io_enq_bits_cfi_idx_bits)) 
                 | (7U & (((IData)(1U) << (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT____Vcellinp__f3__io_enq_bits_cfi_idx_bits)) 
                          >> 1U))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3_mask_1 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3__DOT__maybe_full) 
           & ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3_redirects_0)) 
              & (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3__DOT__ram[3U] 
                 >> 0x10U)));
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3_predicted_redirects_0) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3_predicted_target 
            = (0xffffffffffULL & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___f3_bpd_queue_io_deq_bits_preds_0_predicted_pc_bits);
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT____VdfgRegularize_hce62b063_0_21 = 0U;
    } else if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3_predicted_redirects_1) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3_predicted_target 
            = (0xffffffffffULL & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___f3_bpd_queue_io_deq_bits_preds_1_predicted_pc_bits);
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT____VdfgRegularize_hce62b063_0_21 = 1U;
    } else {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3_predicted_target 
            = (0xffffffffffULL & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3_predicted_redirects_2)
                                   ? vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___f3_bpd_queue_io_deq_bits_preds_2_predicted_pc_bits
                                   : ((IData)(vlSelfRef.__VdfgRegularize_h36cfaf1a_0_43)
                                       ? vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___f3_bpd_queue_io_deq_bits_preds_3_predicted_pc_bits
                                       : (((QData)((IData)(
                                                           vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3__DOT__ram[0x15U])) 
                                           << 0x3bU) 
                                          | (((QData)((IData)(
                                                              vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3__DOT__ram[0x15U])) 
                                              << 0x1bU) 
                                             | ((QData)((IData)(
                                                                vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3__DOT__ram[0x14U])) 
                                                >> 5U))))));
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT____VdfgRegularize_hce62b063_0_21 
            = (2U | (1U & (~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3_predicted_redirects_2))));
    }
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3_predicted_do_redirect 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3_predicted_redirects_0) 
           | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3_predicted_redirects_1) 
              | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3_predicted_redirects_2) 
                 | (IData)(vlSelfRef.__VdfgRegularize_h36cfaf1a_0_43))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT___GEN_4 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT___GEN_3) 
           & (2U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT__cs_rs2_type)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT__cs_imm_sel 
        = (((0U == ((((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_110) 
                        << 0x1cU) | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_111) 
                                     << 0x1bU)) | (
                                                   ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_122) 
                                                    << 0x1aU) 
                                                   | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_55) 
                                                      << 0x19U))) 
                     | (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_56) 
                         << 0x18U) | (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_65) 
                                       << 0x17U) | 
                                      ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_123) 
                                       << 0x16U)))) 
                    | (((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_67) 
                          << 0x15U) | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_113) 
                                       << 0x14U)) | 
                        (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_124) 
                          << 0x13U) | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_125) 
                                       << 0x12U))) 
                       | (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_69) 
                           << 0x11U) | (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_116) 
                                         << 0x10U) 
                                        | (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_71) 
                                            << 0xfU) 
                                           | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_132))))))) 
            << 2U) | (((0U == ((((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_110) 
                                   << 0x1bU) | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_111) 
                                                << 0x1aU)) 
                                 | (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_122) 
                                     << 0x19U) | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_55) 
                                                  << 0x18U))) 
                                | (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_112) 
                                    << 0x17U) | (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_66) 
                                                  << 0x16U) 
                                                 | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_123) 
                                                    << 0x15U)))) 
                               | ((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_67) 
                                    << 0x14U) | (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_113) 
                                                  << 0x13U) 
                                                 | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_114) 
                                                    << 0x12U))) 
                                  | (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_125) 
                                      << 0x11U) | (
                                                   ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_69) 
                                                    << 0x10U) 
                                                   | (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_116) 
                                                       << 0xfU) 
                                                      | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_132))))))) 
                       << 1U) | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_56) 
                                 | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_133) 
                                    | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_134) 
                                       | ((IData)((
                                                   (0x3bU 
                                                    == 
                                                    (0x200707fU 
                                                     & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst)) 
                                                   & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_135))) 
                                          | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_75) 
                                             | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_76))))))));
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__2579(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__2579\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT__csr_en 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_139) 
           | (5U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT__cs_csr_cmd)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT____VdfgRegularize_h65b58d08_0_7 
        = ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs_io_req_0_valid)) 
           & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__store_needs_order) 
              | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rename_stage__DOT__r_valid) 
                 & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__wait_for_empty_pipeline_0))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__dis_stalls_0 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rename_stage__DOT__r_valid) 
           & ((~ ((1U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_state)) 
                  & ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__full)) 
                     & (~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__r_xcpt_val))))) 
              | (((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_rename_stage__DOT__freelist__DOT__r_valid)) 
                  & (1U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_rename_stage__DOT__r_uop_dst_rtype))) 
                 | (((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rename_stage__DOT__freelist__DOT__r_valid)) 
                     & (0U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rename_stage__DOT__r_uop_dst_rtype))) 
                    | (((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__imm_rename_stage__DOT__freelist__DOT__r_valid)) 
                        & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__imm_rename_stage__DOT__r_uop_imm_rename)) 
                       | (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rename_stage__DOT__r_uop_uses_ldq) 
                           & (0U != (((IData)(1U) << 
                                      (7U & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__ldq_tail))) 
                                     & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT___GEN_6) 
                                        | (((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_ldq_oh_7) 
                                              << 7U) 
                                             | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_ldq_oh_6) 
                                                << 6U)) 
                                            | (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_ldq_oh_5) 
                                                << 5U) 
                                               | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_ldq_oh_4) 
                                                  << 4U))) 
                                           | ((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_ldq_oh_3) 
                                                << 3U) 
                                               | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_ldq_oh_2) 
                                                  << 2U)) 
                                              | (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_ldq_oh_1) 
                                                  << 1U) 
                                                 | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_ldq_oh_0)))))))) 
                          | ((~ ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__io_dis_uops_0_ready_REG) 
                                 & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unq_iss_unit__DOT__io_dis_uops_0_ready_REG) 
                                    & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__alu_iss_unit__DOT__io_dis_uops_0_ready_REG) 
                                       & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__io_dis_uops_0_ready_REG))))) 
                             | (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rename_stage__DOT__r_uop_uses_stq) 
                                 & (0U != (((IData)(1U) 
                                            << (7U 
                                                & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_tail))) 
                                           & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__stq_valids)))) 
                                | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__wait_for_empty_pipeline_0) 
                                   | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT____VdfgRegularize_h8fa566d8_0_9))))))))));
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__2580(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__2580\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__ftq__DOT__do_enq 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__ftq__DOT__io_enq_ready_REG) 
           & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f4__DOT__maybe_full) 
              & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT____VdfgRegularize_hce62b063_0_42) 
                 & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___fb_io_enq_ready))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT____VdfgRegularize_hce62b063_0_45 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT____VdfgRegularize_hce62b063_0_42) 
           & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__ftq__DOT__io_enq_ready_REG));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___GEN_1 
        = (3U & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___GEN_0) 
                 | (3U & (((IData)(1U) << (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT____VdfgRegularize_hce62b063_0_1)) 
                          >> 2U))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___GEN_5 
        = (3U & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___GEN_4) 
                 | (3U & (((IData)(1U) << (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT____Vcellinp__f3__io_enq_bits_cfi_idx_bits)) 
                          >> 2U))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f4_io_enq_bits_shadowable_mask_1 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT____VdfgRegularize_hce62b063_0_13) 
           & ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3_mask_1)) 
              | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___bpd_decoder_1_io_out_shadowable)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3_redirects_1 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3_mask_1) 
           & ((2U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___bpd_decoder_1_io_out_cfi_type)) 
              | ((3U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___bpd_decoder_1_io_out_cfi_type)) 
                 | ((1U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___bpd_decoder_1_io_out_cfi_type)) 
                    & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___f3_bpd_queue_io_deq_bits_preds_1_taken)))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT____VdfgRegularize_hce62b063_0_23 
        = (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__s2_vpc 
           == vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3_predicted_target);
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___f3_predicted_ghist_new_history_old_history_T 
        = (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3_predicted_redirects_0)
             ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___f3_bpd_queue_io_deq_bits_preds_0_is_br)
             : ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3_predicted_redirects_1)
                 ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___f3_bpd_queue_io_deq_bits_preds_1_is_br)
                 : ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3_predicted_redirects_2)
                     ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___f3_bpd_queue_io_deq_bits_preds_2_is_br)
                     : (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___f3_bpd_queue_io_deq_bits_preds_3_is_br)))) 
           & (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3_predicted_redirects_0)
                ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___f3_bpd_queue_io_deq_bits_preds_0_taken)
                : ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3_predicted_redirects_1)
                    ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___f3_bpd_queue_io_deq_bits_preds_1_taken)
                    : ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3_predicted_redirects_2)
                        ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___f3_bpd_queue_io_deq_bits_preds_2_taken)
                        : (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___f3_bpd_queue_io_deq_bits_preds_3_taken)))) 
              & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3_predicted_do_redirect)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___GEN_22 
        = (7U & (((IData)(1U) << (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT____VdfgRegularize_hce62b063_0_21)) 
                 | (7U & (((IData)(1U) << (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT____VdfgRegularize_hce62b063_0_21)) 
                          >> 1U))));
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__2581(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__2581\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT___GEN_4) {
        vlSelfRef.__VdfgRegularize_h36cfaf1a_0_122 
            = (0x1fU & (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst 
                        >> 7U));
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_lrs2_rtype 
            = (3U & (- (IData)((1U & (~ (0U != (0x1fU 
                                                & (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst 
                                                   >> 7U))))))));
    } else {
        vlSelfRef.__VdfgRegularize_h36cfaf1a_0_122 
            = (0x1fU & (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst 
                        >> 0x14U));
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_lrs2_rtype 
            = (3U & ((IData)(((0U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT__cs_rs2_type)) 
                              & (0U == (0x1f00000U 
                                        & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst))))
                      ? 3U : (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT__cs_rs2_type)));
    }
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT___GEN_6 
        = (1U & ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT___GEN_5)) 
                 | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT___GEN_4)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_imm_packed 
        = ((0xfe000U & (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst 
                        >> 0xcU)) | ((0x1f00U & (((
                                                   (2U 
                                                    == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT__cs_imm_sel)) 
                                                   | (1U 
                                                      == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT__cs_imm_sel)))
                                                   ? 
                                                  (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst 
                                                   >> 7U)
                                                   : 
                                                  (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst 
                                                   >> 0x14U)) 
                                                 << 8U)) 
                                     | (0xffU & (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst 
                                                 >> 0xcU))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_0__DOT___GEN_33 
        = (((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT___mshrs_0_io_req_sec_rdy)) 
            & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_0_io_req_sec_val)) 
           | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT____VdfgRegularize_h65b58d08_0_7) 
              | (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs_io_req_0_valid) 
                  & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__idx_matches_0_0) 
                     & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT____VdfgRegularize_h65b58d08_0_6))) 
                 | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT____Vcellinp__mshrs__io_req_is_probe_0) 
                    & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__idx_matches_0_0)))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_1__DOT___GEN_33 
        = (((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT___mshrs_1_io_req_sec_rdy)) 
            & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_1_io_req_sec_val)) 
           | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT____VdfgRegularize_h65b58d08_0_7) 
              | (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs_io_req_0_valid) 
                  & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__idx_matches_0_1) 
                     & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT____VdfgRegularize_h65b58d08_0_6))) 
                 | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT____Vcellinp__mshrs__io_req_is_probe_0) 
                    & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__idx_matches_0_1)))));
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__2582(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__2582\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__pred_rename_stage__DOT___GEN_20 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__dis_stalls_0) 
           | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT___core_io_ifu_redirect_flush));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT___core_io_lsu_dis_uops_0_valid 
        = ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__dis_stalls_0)) 
           & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rename_stage__DOT__r_valid));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__ftq__DOT___GEN_8 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__ftq__DOT__do_enq) 
           & (0U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__ftq__DOT__enq_ptr)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__ftq__DOT___GEN_9 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__ftq__DOT__do_enq) 
           & (1U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__ftq__DOT__enq_ptr)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__ftq__DOT___GEN_10 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__ftq__DOT__do_enq) 
           & (2U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__ftq__DOT__enq_ptr)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__ftq__DOT___GEN_11 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__ftq__DOT__do_enq) 
           & (3U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__ftq__DOT__enq_ptr)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__ftq__DOT___GEN_12 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__ftq__DOT__do_enq) 
           & (4U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__ftq__DOT__enq_ptr)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__ftq__DOT___GEN_13 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__ftq__DOT__do_enq) 
           & (5U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__ftq__DOT__enq_ptr)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__ftq__DOT___GEN_14 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__ftq__DOT__do_enq) 
           & (6U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__ftq__DOT__enq_ptr)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__ftq__DOT___GEN_15 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__ftq__DOT__do_enq) 
           & (7U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__ftq__DOT__enq_ptr)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__ftq__DOT___GEN_16 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__ftq__DOT__do_enq) 
           & (8U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__ftq__DOT__enq_ptr)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__ftq__DOT___GEN_17 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__ftq__DOT__do_enq) 
           & (9U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__ftq__DOT__enq_ptr)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__ftq__DOT___GEN_18 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__ftq__DOT__do_enq) 
           & (0xaU == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__ftq__DOT__enq_ptr)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__ftq__DOT___GEN_19 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__ftq__DOT__do_enq) 
           & (0xbU == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__ftq__DOT__enq_ptr)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__ftq__DOT___GEN_20 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__ftq__DOT__do_enq) 
           & (0xcU == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__ftq__DOT__enq_ptr)));
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__2583(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__2583\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__ftq__DOT___GEN_21 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__ftq__DOT__do_enq) 
           & (0xdU == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__ftq__DOT__enq_ptr)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__ftq__DOT___GEN_22 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__ftq__DOT__do_enq) 
           & (0xeU == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__ftq__DOT__enq_ptr)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__ftq__DOT___GEN_23 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__ftq__DOT__do_enq) 
           & (0xfU == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__ftq__DOT__enq_ptr)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT____Vcellinp__fb__io_enq_valid 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f4__DOT__maybe_full) 
           & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT____VdfgRegularize_hce62b063_0_45));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT____Vcellinp__f4__io_deq_ready 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___fb_io_enq_ready) 
           & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT____VdfgRegularize_hce62b063_0_45));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f1_predicted_ghist_saw_not_taken_branch 
        = ((0U != (((IData)(0xfU) << (3U & (IData)(
                                                   (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__s1_vpc 
                                                    >> 1U)))) 
                   & (((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___bpd_io_resp_f1_preds_3_is_br) 
                         << 3U) | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___bpd_io_resp_f1_preds_2_is_br) 
                                   << 2U)) | (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___bpd_io_resp_f1_preds_1_is_br) 
                                               << 1U) 
                                              | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___bpd_io_resp_f1_preds_0_is_br))) 
                      & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f1_do_redirect)
                          ? (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___f1_predicted_ghist_new_history_old_history_T)
                               ? (~ ((IData)(1U) << (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT____VdfgRegularize_hce62b063_0_1)))
                               : 0xfU) & (((8U & ((IData)(1U) 
                                                  << (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT____VdfgRegularize_hce62b063_0_1))) 
                                           | (4U & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___GEN_0))) 
                                          | ((2U & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___GEN_1)) 
                                             | (1U 
                                                & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___GEN_1) 
                                                   | (1U 
                                                      & (((IData)(1U) 
                                                          << (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT____VdfgRegularize_hce62b063_0_1)) 
                                                         >> 3U)))))))
                          : 0xfU)))) | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__s1_ghist_current_saw_branch_not_taken));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f2_predicted_ghist_saw_not_taken_branch 
        = ((0U != (((IData)(0xfU) << (3U & (IData)(
                                                   (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__s2_vpc 
                                                    >> 1U)))) 
                   & ((((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___bpd_io_resp_f2_preds_3_is_br) 
                          & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___bpd_io_resp_f2_preds_3_predicted_pc_valid)) 
                         << 3U) | (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___bpd_io_resp_f2_preds_2_is_br) 
                                    & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___bpd_io_resp_f2_preds_2_predicted_pc_valid)) 
                                   << 2U)) | ((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___bpd_io_resp_f2_preds_1_is_br) 
                                                & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___bpd_io_resp_f2_preds_1_predicted_pc_valid)) 
                                               << 1U) 
                                              | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___bpd_io_resp_f2_preds_0_is_br) 
                                                 & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___bpd_io_resp_f2_preds_0_predicted_pc_valid)))) 
                      & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f2_do_redirect)
                          ? (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___f2_predicted_ghist_new_history_old_history_T)
                               ? (~ ((IData)(1U) << (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT____Vcellinp__f3__io_enq_bits_cfi_idx_bits)))
                               : 0xfU) & (((8U & ((IData)(1U) 
                                                  << (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT____Vcellinp__f3__io_enq_bits_cfi_idx_bits))) 
                                           | (4U & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___GEN_4))) 
                                          | ((2U & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___GEN_5)) 
                                             | (1U 
                                                & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___GEN_5) 
                                                   | (1U 
                                                      & (((IData)(1U) 
                                                          << (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT____Vcellinp__f3__io_enq_bits_cfi_idx_bits)) 
                                                         >> 3U)))))))
                          : 0xfU)))) | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__s2_ghist_current_saw_branch_not_taken));
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__2584(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__2584\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___GEN_16 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3_redirects_0) 
           | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3_redirects_1));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___GEN_23 
        = (3U & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___GEN_22) 
                 | (3U & (((IData)(1U) << (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT____VdfgRegularize_hce62b063_0_21)) 
                          >> 2U))));
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT___GEN_6) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_lrs1_rtype 
            = (3U & ((IData)(((0U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT__cs_rs1_type)) 
                              & (0U == (0xf8000U & vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst))))
                      ? 3U : (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT__cs_rs1_type)));
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT___GEN 
            = (0x1fU & (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst 
                        >> 0xfU));
    } else {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_lrs1_rtype 
            = (3U & (- (IData)((1U & (~ (0U != (0x1fU 
                                                & (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst 
                                                   >> 7U))))))));
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT___GEN 
            = (0x1fU & (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_inst 
                        >> 7U));
    }
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT__imm_ip 
        = ((6U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT__cs_imm_sel))
            ? 0U : vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___decode_0_io_deq_uop_imm_packed);
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_0__DOT___GEN_34 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_0__DOT___GEN_18) 
           & ((0xcU != (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_0__DOT__state)) 
              & ((0xdU != (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_0__DOT__state)) 
                 & ((0xeU != (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_0__DOT__state)) 
                    & ((0xfU != (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_0__DOT__state)) 
                       & ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_0__DOT___GEN_33)) 
                          & ((0x11U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_0__DOT__state)) 
                             & ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_0__DOT___rpq_io_enq_valid_T_1)) 
                                & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_0__DOT___rpq_io_enq_valid_T)))))))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_0__DOT___GEN_51 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_0__DOT___GEN_33) 
           | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_0__DOT___rpq_io_enq_valid_T_1));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_1__DOT___GEN_34 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_1__DOT___GEN_18) 
           & ((0xcU != (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_1__DOT__state)) 
              & ((0xdU != (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_1__DOT__state)) 
                 & ((0xeU != (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_1__DOT__state)) 
                    & ((0xfU != (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_1__DOT__state)) 
                       & ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_1__DOT___GEN_33)) 
                          & ((0x11U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_1__DOT__state)) 
                             & ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_1__DOT___rpq_io_enq_valid_T_1)) 
                                & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_1__DOT___rpq_io_enq_valid_T)))))))));
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__2585(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__2585\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_1__DOT___GEN_51 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_1__DOT___GEN_33) 
           | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_1__DOT___rpq_io_enq_valid_T_1));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_118 
        = ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__dis_stalls_0)) 
           & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT___core_io_lsu_dis_uops_0_valid));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rename_stage__DOT__ren2_br_tags_1_valid 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT___core_io_lsu_dis_uops_0_valid) 
           & (((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rename_stage__DOT__r_uop_is_sfb)) 
               & ((1U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rename_stage__DOT__r_uop_br_type)) 
                  | ((2U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rename_stage__DOT__r_uop_br_type)) 
                     | ((3U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rename_stage__DOT__r_uop_br_type)) 
                        | ((4U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rename_stage__DOT__r_uop_br_type)) 
                           | ((5U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rename_stage__DOT__r_uop_br_type)) 
                              | (6U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rename_stage__DOT__r_uop_br_type)))))))) 
              | (8U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rename_stage__DOT__r_uop_br_type))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_rename_stage__DOT__ren2_br_tags_1_valid 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT___core_io_lsu_dis_uops_0_valid) 
           & (((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_rename_stage__DOT__r_uop_is_sfb)) 
               & ((1U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_rename_stage__DOT__r_uop_br_type)) 
                  | ((2U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_rename_stage__DOT__r_uop_br_type)) 
                     | ((3U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_rename_stage__DOT__r_uop_br_type)) 
                        | ((4U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_rename_stage__DOT__r_uop_br_type)) 
                           | ((5U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_rename_stage__DOT__r_uop_br_type)) 
                              | (6U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_rename_stage__DOT__r_uop_br_type)))))))) 
              | (8U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_rename_stage__DOT__r_uop_br_type))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__imm_rename_stage__DOT____Vcellinp__freelist__io_ren_br_tags_1_valid 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT___core_io_lsu_dis_uops_0_valid) 
           & (((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__imm_rename_stage__DOT__r_uop_is_sfb)) 
               & ((1U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__imm_rename_stage__DOT__r_uop_br_type)) 
                  | ((2U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__imm_rename_stage__DOT__r_uop_br_type)) 
                     | ((3U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__imm_rename_stage__DOT__r_uop_br_type)) 
                        | ((4U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__imm_rename_stage__DOT__r_uop_br_type)) 
                           | ((5U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__imm_rename_stage__DOT__r_uop_br_type)) 
                              | (6U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__imm_rename_stage__DOT__r_uop_br_type)))))))) 
              | (8U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__imm_rename_stage__DOT__r_uop_br_type))));
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__2586(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__2586\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_ld_val 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT___core_io_lsu_dis_uops_0_valid) 
           & ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rename_stage__DOT__r_uop_exception)) 
              & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rename_stage__DOT__r_uop_uses_ldq)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__dis_st_val 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT___core_io_lsu_dis_uops_0_valid) 
           & ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rename_stage__DOT__r_uop_exception)) 
              & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rename_stage__DOT__r_uop_uses_stq)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_119 
        = (0x41U | ((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__REG_3)
                       ? 3U : ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___rob_io_empty)
                                ? 1U : (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_state))) 
                     << 4U) | (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__REG_1)
                                 ? 3U : (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rename_stage__DOT__r_uop_is_unique) 
                                          & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT___core_io_lsu_dis_uops_0_valid))
                                          ? 2U : (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_state))) 
                               << 2U)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___dispatcher_io_dis_uops_3_0_valid 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rename_stage__DOT__r_uop_iq_type_3) 
           & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT___core_io_lsu_dis_uops_0_valid));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___dispatcher_io_dis_uops_0_0_valid 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rename_stage__DOT__r_uop_iq_type_0) 
           & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT___core_io_lsu_dis_uops_0_valid));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___dispatcher_io_dis_uops_1_0_valid 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rename_stage__DOT__r_uop_iq_type_1) 
           & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT___core_io_lsu_dis_uops_0_valid));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___dispatcher_io_dis_uops_2_0_valid 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rename_stage__DOT__r_uop_iq_type_2) 
           & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT___core_io_lsu_dis_uops_0_valid));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__pred_rename_stage__DOT__ren2_alloc_fire_0 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT___core_io_lsu_dis_uops_0_valid) 
           & ((0U != (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__pred_rename_stage__DOT__r_uop_br_type)) 
              & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__pred_rename_stage__DOT__r_uop_is_sfb) 
                 & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__pred_rename_stage__DOT__r_valid))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__imm_rename_stage__DOT__freelist_io_reqs_0 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT___core_io_lsu_dis_uops_0_valid) 
           & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__imm_rename_stage__DOT__r_uop_imm_rename));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_726 
        = ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__r_xcpt_val)) 
           & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rename_stage__DOT__r_uop_exception) 
              & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT___core_io_lsu_dis_uops_0_valid)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_120 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT___core_io_lsu_dis_uops_0_valid) 
           & (0U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_tail)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_121 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT___core_io_lsu_dis_uops_0_valid) 
           & (1U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_tail)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_122 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT___core_io_lsu_dis_uops_0_valid) 
           & (2U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_tail)));
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__2587(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__2587\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_123 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT___core_io_lsu_dis_uops_0_valid) 
           & (3U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_tail)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_124 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT___core_io_lsu_dis_uops_0_valid) 
           & (4U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_tail)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_125 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT___core_io_lsu_dis_uops_0_valid) 
           & (5U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_tail)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_126 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT___core_io_lsu_dis_uops_0_valid) 
           & (6U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_tail)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_127 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT___core_io_lsu_dis_uops_0_valid) 
           & (7U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_tail)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_128 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT___core_io_lsu_dis_uops_0_valid) 
           & (8U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_tail)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_129 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT___core_io_lsu_dis_uops_0_valid) 
           & (9U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_tail)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_130 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT___core_io_lsu_dis_uops_0_valid) 
           & (0xaU == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_tail)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_131 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT___core_io_lsu_dis_uops_0_valid) 
           & (0xbU == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_tail)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_132 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT___core_io_lsu_dis_uops_0_valid) 
           & (0xcU == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_tail)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_133 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT___core_io_lsu_dis_uops_0_valid) 
           & (0xdU == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_tail)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_134 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT___core_io_lsu_dis_uops_0_valid) 
           & (0xeU == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_tail)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_135 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT___core_io_lsu_dis_uops_0_valid) 
           & (0xfU == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_tail)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_136 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT___core_io_lsu_dis_uops_0_valid) 
           & (0x10U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_tail)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_137 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT___core_io_lsu_dis_uops_0_valid) 
           & (0x11U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_tail)));
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__2588(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__2588\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_138 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT___core_io_lsu_dis_uops_0_valid) 
           & (0x12U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_tail)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_139 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT___core_io_lsu_dis_uops_0_valid) 
           & (0x13U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_tail)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_140 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT___core_io_lsu_dis_uops_0_valid) 
           & (0x14U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_tail)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_141 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT___core_io_lsu_dis_uops_0_valid) 
           & (0x15U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_tail)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_142 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT___core_io_lsu_dis_uops_0_valid) 
           & (0x16U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_tail)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_143 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT___core_io_lsu_dis_uops_0_valid) 
           & (0x17U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_tail)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_144 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT___core_io_lsu_dis_uops_0_valid) 
           & (0x18U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_tail)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_145 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT___core_io_lsu_dis_uops_0_valid) 
           & (0x19U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_tail)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_146 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT___core_io_lsu_dis_uops_0_valid) 
           & (0x1aU == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_tail)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_147 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT___core_io_lsu_dis_uops_0_valid) 
           & (0x1bU == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_tail)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_148 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT___core_io_lsu_dis_uops_0_valid) 
           & (0x1cU == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_tail)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_149 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT___core_io_lsu_dis_uops_0_valid) 
           & (0x1dU == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_tail)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_150 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT___core_io_lsu_dis_uops_0_valid) 
           & (0x1eU == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_tail)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_151 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT___core_io_lsu_dis_uops_0_valid) 
           & (0x1fU == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_tail)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rename_stage__DOT__freelist_io_reqs_0 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT___core_io_lsu_dis_uops_0_valid) 
           & ((0U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rename_stage__DOT__r_uop_dst_rtype)) 
              & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rename_stage__DOT__r_valid)));
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__2589(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__2589\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_rename_stage__DOT__freelist_io_reqs_0 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT___core_io_lsu_dis_uops_0_valid) 
           & ((1U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_rename_stage__DOT__r_uop_dst_rtype)) 
              & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_rename_stage__DOT__r_valid)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__fb__DOT__in_mask_3 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT____Vcellinp__fb__io_enq_valid) 
           & (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f4__DOT__ram[7U] 
              >> 9U));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__fb__DOT__in_mask_2 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT____Vcellinp__fb__io_enq_valid) 
           & (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f4__DOT__ram[7U] 
              >> 8U));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__fb__DOT__in_mask_1 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT____Vcellinp__fb__io_enq_valid) 
           & (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f4__DOT__ram[7U] 
              >> 7U));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__fb__DOT__in_mask_0 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT____Vcellinp__fb__io_enq_valid) 
           & (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f4__DOT__ram[7U] 
              >> 6U));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___f4_io_enq_ready 
        = (1U & ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f4__DOT__maybe_full)) 
                 | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT____Vcellinp__f4__io_deq_ready)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___f2_predicted_ghist_new_history_old_history_T_6 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___f2_predicted_ghist_new_history_old_history_T)
            ? (1ULL | (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__s2_ghist_old_history 
                       << 1U)) : ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f2_predicted_ghist_saw_not_taken_branch)
                                   ? VL_SHIFTL_QQI(64,64,32, vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__s2_ghist_old_history, 1U)
                                   : vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__s2_ghist_old_history));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3_mask_2 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3__DOT__maybe_full) 
           & ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___GEN_16)) 
              & (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3__DOT__ram[3U] 
                 >> 0x11U)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___f3_predicted_ghist_new_history_old_history_T_6 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___f3_predicted_ghist_new_history_old_history_T)
            ? (1ULL | (0xfffffffffffffffeULL & (((QData)((IData)(
                                                                 vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3__DOT__ram[3U])) 
                                                 << 0x36U) 
                                                | (((QData)((IData)(
                                                                    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3__DOT__ram[2U])) 
                                                    << 0x16U) 
                                                   | (0x3ffffffffffffeULL 
                                                      & ((QData)((IData)(
                                                                         vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3__DOT__ram[1U])) 
                                                         >> 0xaU))))))
            : ((1U & ((0U != ((((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___f3_bpd_queue_io_deq_bits_preds_3_is_br) 
                                  & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___f3_bpd_queue_io_deq_bits_preds_3_predicted_pc_valid)) 
                                 << 3U) | (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___f3_bpd_queue_io_deq_bits_preds_2_is_br) 
                                            & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___f3_bpd_queue_io_deq_bits_preds_2_predicted_pc_valid)) 
                                           << 2U)) 
                               | ((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___f3_bpd_queue_io_deq_bits_preds_1_is_br) 
                                    & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___f3_bpd_queue_io_deq_bits_preds_1_predicted_pc_valid)) 
                                   << 1U) | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___f3_bpd_queue_io_deq_bits_preds_0_is_br) 
                                             & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___f3_bpd_queue_io_deq_bits_preds_0_predicted_pc_valid)))) 
                              & (((vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3__DOT__ram[3U] 
                                   << 0x11U) | (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3__DOT__ram[3U] 
                                                >> 0xfU)) 
                                 & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3_predicted_do_redirect)
                                     ? (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___f3_predicted_ghist_new_history_old_history_T)
                                          ? (~ ((IData)(1U) 
                                                << (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT____VdfgRegularize_hce62b063_0_21)))
                                          : 0xfU) & 
                                        (((8U & ((IData)(1U) 
                                                 << (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT____VdfgRegularize_hce62b063_0_21))) 
                                          | (4U & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___GEN_22))) 
                                         | ((2U & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___GEN_23)) 
                                            | (1U & 
                                               ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT___GEN_23) 
                                                | (1U 
                                                   & (((IData)(1U) 
                                                       << (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT____VdfgRegularize_hce62b063_0_21)) 
                                                      >> 3U)))))))
                                     : 0xfU)))) | (
                                                   vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3__DOT__ram[1U] 
                                                   >> 0xaU)))
                ? VL_SHIFTL_QQI(64,64,32, (((QData)((IData)(
                                                            vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3__DOT__ram[3U])) 
                                            << 0x35U) 
                                           | (((QData)((IData)(
                                                               vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3__DOT__ram[2U])) 
                                               << 0x15U) 
                                              | ((QData)((IData)(
                                                                 vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3__DOT__ram[1U])) 
                                                 >> 0xbU))), 1U)
                : (((QData)((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3__DOT__ram[3U])) 
                    << 0x35U) | (((QData)((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3__DOT__ram[2U])) 
                                  << 0x15U) | ((QData)((IData)(
                                                               vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__frontend__DOT__f3__DOT__ram[1U])) 
                                               >> 0xbU)))));
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__2590(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__2590\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_185 
        = (1U & (~ ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT____VdfgRegularize_h263fa074_0_139) 
                    & (0U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT___GEN)))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT__imm_i4_1 
        = ((3U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT__cs_imm_sel))
            ? 0U : (0x1fU & (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__decode_0__DOT__imm_ip 
                             >> 9U)));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_0__DOT___GEN_52 
        = (1U & ((0x11U != (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_0__DOT__state)) 
                 | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_0__DOT___GEN_32) 
                    | ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_0__DOT___rpq_io_enq_valid_T)) 
                       | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_0__DOT___GEN_51)))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_1__DOT___GEN_52 
        = (1U & ((0x11U != (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_1__DOT__state)) 
                 | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_1__DOT___GEN_32) 
                    | ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_1__DOT___rpq_io_enq_valid_T)) 
                       | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_1__DOT___GEN_51)))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__issue_slots_7_in_uop_valid 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__shamts_oh_8) 
           & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT____VdfgRegularize_h9d2b670c_0_15) 
              & ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rename_stage__DOT__r_uop_exception)) 
                 & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___dispatcher_io_dis_uops_3_0_valid))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__issue_slots_7_in_uop_valid 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__mem_iss_unit__DOT__shamts_oh_8) 
           & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT____VdfgRegularize_h9d2b670c_0_15) 
              & ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rename_stage__DOT__r_uop_exception)) 
                 & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___dispatcher_io_dis_uops_0_0_valid))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unq_iss_unit__DOT__issue_slots_7_in_uop_valid 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__unq_iss_unit__DOT__shamts_oh_8) 
           & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT____VdfgRegularize_h9d2b670c_0_15) 
              & ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rename_stage__DOT__r_uop_exception)) 
                 & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___dispatcher_io_dis_uops_1_0_valid))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__alu_iss_unit__DOT__issue_slots_7_in_uop_valid 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__alu_iss_unit__DOT__shamts_oh_8) 
           & ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT____VdfgRegularize_h9d2b670c_0_15) 
              & ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rename_stage__DOT__r_uop_exception)) 
                 & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___dispatcher_io_dis_uops_2_0_valid))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__pred_rename_stage__DOT___GEN_22 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__pred_rename_stage__DOT___GEN_17) 
           | (((((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__pred_rename_stage__DOT__ren2_alloc_fire_0) 
                   & (0xfU == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__pred_rename_stage__DOT__r_uop_ftq_idx))) 
                  << 0xfU) | (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__pred_rename_stage__DOT__ren2_alloc_fire_0) 
                               & (0xeU == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__pred_rename_stage__DOT__r_uop_ftq_idx))) 
                              << 0xeU)) | ((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__pred_rename_stage__DOT__ren2_alloc_fire_0) 
                                             & (0xdU 
                                                == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__pred_rename_stage__DOT__r_uop_ftq_idx))) 
                                            << 0xdU) 
                                           | (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__pred_rename_stage__DOT__ren2_alloc_fire_0) 
                                               & (0xcU 
                                                  == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__pred_rename_stage__DOT__r_uop_ftq_idx))) 
                                              << 0xcU))) 
               | (((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__pred_rename_stage__DOT__ren2_alloc_fire_0) 
                     & (0xbU == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__pred_rename_stage__DOT__r_uop_ftq_idx))) 
                    << 0xbU) | (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__pred_rename_stage__DOT__ren2_alloc_fire_0) 
                                 & (0xaU == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__pred_rename_stage__DOT__r_uop_ftq_idx))) 
                                << 0xaU)) | ((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__pred_rename_stage__DOT__ren2_alloc_fire_0) 
                                               & (9U 
                                                  == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__pred_rename_stage__DOT__r_uop_ftq_idx))) 
                                              << 9U) 
                                             | (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__pred_rename_stage__DOT__ren2_alloc_fire_0) 
                                                 & (8U 
                                                    == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__pred_rename_stage__DOT__r_uop_ftq_idx))) 
                                                << 8U)))) 
              | ((((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__pred_rename_stage__DOT__ren2_alloc_fire_0) 
                     & (7U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__pred_rename_stage__DOT__r_uop_ftq_idx))) 
                    << 7U) | (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__pred_rename_stage__DOT__ren2_alloc_fire_0) 
                               & (6U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__pred_rename_stage__DOT__r_uop_ftq_idx))) 
                              << 6U)) | ((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__pred_rename_stage__DOT__ren2_alloc_fire_0) 
                                           & (5U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__pred_rename_stage__DOT__r_uop_ftq_idx))) 
                                          << 5U) | 
                                         (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__pred_rename_stage__DOT__ren2_alloc_fire_0) 
                                           & (4U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__pred_rename_stage__DOT__r_uop_ftq_idx))) 
                                          << 4U))) 
                 | (((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__pred_rename_stage__DOT__ren2_alloc_fire_0) 
                       & (3U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__pred_rename_stage__DOT__r_uop_ftq_idx))) 
                      << 3U) | (((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__pred_rename_stage__DOT__ren2_alloc_fire_0) 
                                 & (2U == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__pred_rename_stage__DOT__r_uop_ftq_idx))) 
                                << 2U)) | ((((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__pred_rename_stage__DOT__ren2_alloc_fire_0) 
                                             & (1U 
                                                == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__pred_rename_stage__DOT__r_uop_ftq_idx))) 
                                            << 1U) 
                                           | ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__pred_rename_stage__DOT__ren2_alloc_fire_0) 
                                              & (0U 
                                                 == (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__pred_rename_stage__DOT__r_uop_ftq_idx))))))));
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__2591(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__2591\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__imm_rename_stage__DOT__freelist__DOT__alloc_masks_0 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__imm_rename_stage__DOT__freelist_io_reqs_0)
            ? ((IData)(1U) << (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__imm_rename_stage__DOT__freelist__DOT__r_sel))
            : 0U);
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__imm_rename_stage__DOT__freelist__DOT__sel_fire_0 
        = (1U & (((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__imm_rename_stage__DOT__freelist__DOT__r_valid)) 
                  | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__imm_rename_stage__DOT__freelist_io_reqs_0)) 
                 & (IData)((0U != vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__imm_rename_stage__DOT__freelist__DOT__free_list))));
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__2592(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__2592\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__next_xcpt_uop_br_mask 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___rob_io_flush_valid)
            ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__r_xcpt_uop_br_mask)
            : ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT___lsu_io_core_lxcpt_valid)
                ? ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_725)
                    ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__lsu__DOT__r_xcpt_uop_br_mask)
                    : (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__r_xcpt_uop_br_mask))
                : ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_726)
                    ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT___dispatcher_io_dis_uops_3_0_bits_br_mask)
                    : (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__r_xcpt_uop_br_mask))));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_727 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_120) 
           | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_val_0));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_216 
        = ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_120)) 
           & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_fflags_0_valid));
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_120) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_152 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT____VdfgRegularize_h9d2b670c_0_15;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_184 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___rob_unsafe_T_16;
    } else {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_152 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_bsy_0;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_184 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_unsafe_0;
    }
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_728 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_121) 
           | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_val_1));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_217 
        = ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_121)) 
           & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_fflags_1_valid));
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_121) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_153 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT____VdfgRegularize_h9d2b670c_0_15;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_185 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___rob_unsafe_T_16;
    } else {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_153 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_bsy_1;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_185 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_unsafe_1;
    }
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_729 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_122) 
           | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_val_2));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_218 
        = ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_122)) 
           & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_fflags_2_valid));
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_122) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_154 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT____VdfgRegularize_h9d2b670c_0_15;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_186 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___rob_unsafe_T_16;
    } else {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_154 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_bsy_2;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_186 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_unsafe_2;
    }
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_730 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_123) 
           | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_val_3));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_219 
        = ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_123)) 
           & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_fflags_3_valid));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_155 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_123)
            ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT____VdfgRegularize_h9d2b670c_0_15)
            : (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_bsy_3));
}

VL_INLINE_OPT void VTestDriver___024root___nba_sequent__TOP__2593(VTestDriver___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestDriver___024root___nba_sequent__TOP__2593\n"); );
    VTestDriver__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_187 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_123)
            ? (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___rob_unsafe_T_16)
            : (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_unsafe_3));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_731 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_124) 
           | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_val_4));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_220 
        = ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_124)) 
           & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_fflags_4_valid));
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_124) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_156 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT____VdfgRegularize_h9d2b670c_0_15;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_188 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___rob_unsafe_T_16;
    } else {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_156 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_bsy_4;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_188 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_unsafe_4;
    }
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_732 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_125) 
           | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_val_5));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_221 
        = ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_125)) 
           & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_fflags_5_valid));
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_125) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_157 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT____VdfgRegularize_h9d2b670c_0_15;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_189 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___rob_unsafe_T_16;
    } else {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_157 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_bsy_5;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_189 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_unsafe_5;
    }
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_733 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_126) 
           | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_val_6));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_222 
        = ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_126)) 
           & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_fflags_6_valid));
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_126) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_158 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT____VdfgRegularize_h9d2b670c_0_15;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_190 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___rob_unsafe_T_16;
    } else {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_158 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_bsy_6;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_190 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_unsafe_6;
    }
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_734 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_127) 
           | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_val_7));
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_223 
        = ((~ (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_127)) 
           & (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_fflags_7_valid));
    if (vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_127) {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_159 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT____VdfgRegularize_h9d2b670c_0_15;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_191 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___rob_unsafe_T_16;
    } else {
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_159 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_bsy_7;
        vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_191 
            = vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_unsafe_7;
    }
    vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_735 
        = ((IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT___GEN_128) 
           | (IData)(vlSelfRef.TestDriver__DOT__testHarness__DOT__chiptop0__DOT__system__DOT__tile_prci_domain__DOT__element_reset_domain_boom_tile__DOT__core__DOT__rob__DOT__rob_val_8));
}
