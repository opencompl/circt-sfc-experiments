// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See VTestDriver.h for the primary calling header

#include "VTestDriver__pch.h"
#include "VTestDriver__Syms.h"
#include "VTestDriver___024unit.h"

extern "C" void* memory_init(int chip_id, long long mem_size, long long word_size, long long line_size, long long id_bits, long long clock_hz, long long mem_base, int addr_bits);

VL_INLINE_OPT void VTestDriver___024unit____Vdpiimwrap_memory_init_TOP____024unit(IData/*31:0*/ chip_id, QData/*63:0*/ mem_size, QData/*63:0*/ word_size, QData/*63:0*/ line_size, QData/*63:0*/ id_bits, QData/*63:0*/ clock_hz, QData/*63:0*/ mem_base, IData/*31:0*/ addr_bits, QData/*63:0*/ &memory_init__Vfuncrtn) {
    VL_DEBUG_IF(VL_DBG_MSGF("+        VTestDriver___024unit____Vdpiimwrap_memory_init_TOP____024unit\n"); );
    // Body
    int chip_id__Vcvt;
    chip_id__Vcvt = chip_id;
    long long mem_size__Vcvt;
    mem_size__Vcvt = mem_size;
    long long word_size__Vcvt;
    word_size__Vcvt = word_size;
    long long line_size__Vcvt;
    line_size__Vcvt = line_size;
    long long id_bits__Vcvt;
    id_bits__Vcvt = id_bits;
    long long clock_hz__Vcvt;
    clock_hz__Vcvt = clock_hz;
    long long mem_base__Vcvt;
    mem_base__Vcvt = mem_base;
    int addr_bits__Vcvt;
    addr_bits__Vcvt = addr_bits;
    void* memory_init__Vfuncrtn__Vcvt;
    memory_init__Vfuncrtn__Vcvt = memory_init(chip_id__Vcvt, mem_size__Vcvt, word_size__Vcvt, line_size__Vcvt, id_bits__Vcvt, clock_hz__Vcvt, mem_base__Vcvt, addr_bits__Vcvt);
    memory_init__Vfuncrtn = VL_CVT_VP_Q(memory_init__Vfuncrtn__Vcvt);
}

extern "C" void memory_tick(void* channel, svBit reset, svBit ar_valid, svBit* ar_ready, long long ar_addr, int ar_id, int ar_size, int ar_len, svBit aw_valid, svBit* aw_ready, long long aw_addr, int aw_id, int aw_size, int aw_len, svBit w_valid, svBit* w_ready, int w_strb, const svOpenArrayHandle w_data, svBit w_last, svBit* r_valid, svBit r_ready, int* r_id, int* r_resp, const svOpenArrayHandle r_data, svBit* r_last, svBit* b_valid, svBit b_ready, int* b_id, int* b_resp);

VL_INLINE_OPT void VTestDriver___024unit____Vdpiimwrap_memory_tick__Vdpioc2_TOP____024unit(QData/*63:0*/ channel, CData/*0:0*/ reset, CData/*0:0*/ ar_valid, CData/*0:0*/ &ar_ready, QData/*63:0*/ ar_addr, IData/*31:0*/ ar_id, IData/*31:0*/ ar_size, IData/*31:0*/ ar_len, CData/*0:0*/ aw_valid, CData/*0:0*/ &aw_ready, QData/*63:0*/ aw_addr, IData/*31:0*/ aw_id, IData/*31:0*/ aw_size, IData/*31:0*/ aw_len, CData/*0:0*/ w_valid, CData/*0:0*/ &w_ready, IData/*31:0*/ w_strb, const VlUnpacked<CData/*7:0*/, 8> &w_data, CData/*0:0*/ w_last, CData/*0:0*/ &r_valid, CData/*0:0*/ r_ready, IData/*31:0*/ &r_id, IData/*31:0*/ &r_resp, VlUnpacked<CData/*7:0*/, 8> &r_data, CData/*0:0*/ &r_last, CData/*0:0*/ &b_valid, CData/*0:0*/ b_ready, IData/*31:0*/ &b_id, IData/*31:0*/ &b_resp) {
    VL_DEBUG_IF(VL_DBG_MSGF("+        VTestDriver___024unit____Vdpiimwrap_memory_tick__Vdpioc2_TOP____024unit\n"); );
    // Body
    void* channel__Vcvt;
    channel__Vcvt = VL_CVT_Q_VP(channel);
    svBit reset__Vcvt;
    reset__Vcvt = reset;
    svBit ar_valid__Vcvt;
    ar_valid__Vcvt = ar_valid;
    svBit ar_ready__Vcvt;
    long long ar_addr__Vcvt;
    ar_addr__Vcvt = ar_addr;
    int ar_id__Vcvt;
    ar_id__Vcvt = ar_id;
    int ar_size__Vcvt;
    ar_size__Vcvt = ar_size;
    int ar_len__Vcvt;
    ar_len__Vcvt = ar_len;
    svBit aw_valid__Vcvt;
    aw_valid__Vcvt = aw_valid;
    svBit aw_ready__Vcvt;
    long long aw_addr__Vcvt;
    aw_addr__Vcvt = aw_addr;
    int aw_id__Vcvt;
    aw_id__Vcvt = aw_id;
    int aw_size__Vcvt;
    aw_size__Vcvt = aw_size;
    int aw_len__Vcvt;
    aw_len__Vcvt = aw_len;
    svBit w_valid__Vcvt;
    w_valid__Vcvt = w_valid;
    svBit w_ready__Vcvt;
    int w_strb__Vcvt;
    w_strb__Vcvt = w_strb;
    static const int w_data__Vopenprops__ulims[2] = {7, 0};
    static const int w_data__Vopenprops__plims[2] = {7, 0};
    static const VerilatedVarProps w_data__Vopenprops(VLVT_UINT8, VLVD_IN|VLVF_DPI_CLAY, VerilatedVarProps::Unpacked{}, 1, w_data__Vopenprops__ulims, VerilatedVarProps::Packed{}, 1, w_data__Vopenprops__plims);
    VerilatedDpiOpenVar w_data__Vopenarray (&w_data__Vopenprops, &w_data);
    svBit w_last__Vcvt;
    w_last__Vcvt = w_last;
    svBit r_valid__Vcvt;
    svBit r_ready__Vcvt;
    r_ready__Vcvt = r_ready;
    int r_id__Vcvt;
    int r_resp__Vcvt;
    static const int r_data__Vopenprops__ulims[2] = {7, 0};
    static const int r_data__Vopenprops__plims[2] = {7, 0};
    static const VerilatedVarProps r_data__Vopenprops(VLVT_UINT8, VLVD_OUT|VLVF_DPI_CLAY, VerilatedVarProps::Unpacked{}, 1, r_data__Vopenprops__ulims, VerilatedVarProps::Packed{}, 1, r_data__Vopenprops__plims);
    VerilatedDpiOpenVar r_data__Vopenarray (&r_data__Vopenprops, &r_data);
    svBit r_last__Vcvt;
    svBit b_valid__Vcvt;
    svBit b_ready__Vcvt;
    b_ready__Vcvt = b_ready;
    int b_id__Vcvt;
    int b_resp__Vcvt;
    memory_tick(channel__Vcvt, reset__Vcvt, ar_valid__Vcvt, &ar_ready__Vcvt, ar_addr__Vcvt, ar_id__Vcvt, ar_size__Vcvt, ar_len__Vcvt, aw_valid__Vcvt, &aw_ready__Vcvt, aw_addr__Vcvt, aw_id__Vcvt, aw_size__Vcvt, aw_len__Vcvt, w_valid__Vcvt, &w_ready__Vcvt, w_strb__Vcvt, &w_data__Vopenarray, w_last__Vcvt, &r_valid__Vcvt, r_ready__Vcvt, &r_id__Vcvt, &r_resp__Vcvt, &r_data__Vopenarray, &r_last__Vcvt, &b_valid__Vcvt, b_ready__Vcvt, &b_id__Vcvt, &b_resp__Vcvt);
    ar_ready = (1U & ar_ready__Vcvt);
    aw_ready = (1U & aw_ready__Vcvt);
    w_ready = (1U & w_ready__Vcvt);
    r_valid = (1U & r_valid__Vcvt);
    r_id = r_id__Vcvt;
    r_resp = r_resp__Vcvt;
    r_last = (1U & r_last__Vcvt);
    b_valid = (1U & b_valid__Vcvt);
    b_id = b_id__Vcvt;
    b_resp = b_resp__Vcvt;
}

extern "C" int jtag_tick(svBit* jtag_TCK, svBit* jtag_TMS, svBit* jtag_TDI, svBit* jtag_TRSTn, svBit jtag_TDO);

VL_INLINE_OPT void VTestDriver___024unit____Vdpiimwrap_jtag_tick_TOP____024unit(CData/*0:0*/ &jtag_TCK, CData/*0:0*/ &jtag_TMS, CData/*0:0*/ &jtag_TDI, CData/*0:0*/ &jtag_TRSTn, CData/*0:0*/ jtag_TDO, IData/*31:0*/ &jtag_tick__Vfuncrtn) {
    VL_DEBUG_IF(VL_DBG_MSGF("+        VTestDriver___024unit____Vdpiimwrap_jtag_tick_TOP____024unit\n"); );
    // Body
    svBit jtag_TCK__Vcvt;
    svBit jtag_TMS__Vcvt;
    svBit jtag_TDI__Vcvt;
    svBit jtag_TRSTn__Vcvt;
    svBit jtag_TDO__Vcvt;
    jtag_TDO__Vcvt = jtag_TDO;
    int jtag_tick__Vfuncrtn__Vcvt;
    jtag_tick__Vfuncrtn__Vcvt = jtag_tick(&jtag_TCK__Vcvt, &jtag_TMS__Vcvt, &jtag_TDI__Vcvt, &jtag_TRSTn__Vcvt, jtag_TDO__Vcvt);
    jtag_TCK = (1U & jtag_TCK__Vcvt);
    jtag_TMS = (1U & jtag_TMS__Vcvt);
    jtag_TDI = (1U & jtag_TDI__Vcvt);
    jtag_TRSTn = (1U & jtag_TRSTn__Vcvt);
    jtag_tick__Vfuncrtn = jtag_tick__Vfuncrtn__Vcvt;
}

extern "C" int tsi_tick(int chip_id, svBit tsi_out_valid, svBit* tsi_out_ready, int tsi_out_bits, svBit* tsi_in_valid, svBit tsi_in_ready, int* tsi_in_bits);

VL_INLINE_OPT void VTestDriver___024unit____Vdpiimwrap_tsi_tick_TOP____024unit(IData/*31:0*/ chip_id, CData/*0:0*/ tsi_out_valid, CData/*0:0*/ &tsi_out_ready, IData/*31:0*/ tsi_out_bits, CData/*0:0*/ &tsi_in_valid, CData/*0:0*/ tsi_in_ready, IData/*31:0*/ &tsi_in_bits, IData/*31:0*/ &tsi_tick__Vfuncrtn) {
    VL_DEBUG_IF(VL_DBG_MSGF("+        VTestDriver___024unit____Vdpiimwrap_tsi_tick_TOP____024unit\n"); );
    // Body
    int chip_id__Vcvt;
    chip_id__Vcvt = chip_id;
    svBit tsi_out_valid__Vcvt;
    tsi_out_valid__Vcvt = tsi_out_valid;
    svBit tsi_out_ready__Vcvt;
    int tsi_out_bits__Vcvt;
    tsi_out_bits__Vcvt = tsi_out_bits;
    svBit tsi_in_valid__Vcvt;
    svBit tsi_in_ready__Vcvt;
    tsi_in_ready__Vcvt = tsi_in_ready;
    int tsi_in_bits__Vcvt;
    int tsi_tick__Vfuncrtn__Vcvt;
    tsi_tick__Vfuncrtn__Vcvt = tsi_tick(chip_id__Vcvt, tsi_out_valid__Vcvt, &tsi_out_ready__Vcvt, tsi_out_bits__Vcvt, &tsi_in_valid__Vcvt, tsi_in_ready__Vcvt, &tsi_in_bits__Vcvt);
    tsi_out_ready = (1U & tsi_out_ready__Vcvt);
    tsi_in_valid = (1U & tsi_in_valid__Vcvt);
    tsi_in_bits = tsi_in_bits__Vcvt;
    tsi_tick__Vfuncrtn = tsi_tick__Vfuncrtn__Vcvt;
}
